#!/usr/bin/env node

const fs = require("fs");
const path = require("path");
const os = require("os");
const { spawnSync } = require("child_process");

let runGuarded;
let extractStringConstants;
let resolveStringArg;
let valueExpressionPattern;
let valueTokens;
let validateIntegrationContract;
let javaProjectGates;
try {
  ({ runGuarded } = require("./lib/validator-runtime"));
  ({ extractStringConstants, resolveStringArg, valueExpressionPattern, valueTokens } = require("./lib/value-resolver"));
  ({ validateIntegrationContract } = require("./lib/integration-contract"));
  javaProjectGates = require("./lib/java-project-gates");
} catch (err) {
  console.error(`[alipay-enterprise-bill] BROKEN failed to load validator support: ${err && err.stack ? err.stack : err}`);
  process.exit(2);
}

const skillDir = path.resolve(__dirname, "..");
const targetDir = path.resolve(process.argv[2] || ".");
const ALIPAY_SDK_VERSION_PATTERN = /^[0-9]+\.[0-9]+\.[0-9]+\.ALL$/;

/**
 * 企业码账单代码生成校验器。
 *
 * 主流程按语言分支执行：
 * - Java/Maven：校验官方 SDK Model、文档 setter、通知路由、失败重试和工程结构。
 * - Node.js：校验 SDK 调用参数、bizContent、通知处理、语法、模块加载和测试。
 * - Python/Go/.NET/PHP：执行接口覆盖、字段、通知和本地可用的构建检查。
 *
 * 该脚本判断生成代码是否具备可信的接入骨架，不替代真实支付宝环境联调。
 */

// SDK Model 与接口文档一一对应，允许字段和必填字段从参数表实时推导。
const modelDocs = {
  AlipayCommerceEcConsumeDetailQueryModel: "references/push-mode/consume-detail-query.md",
  AlipayCommerceEcConsumeDetailBatchqueryModel: "references/push-mode/consume-detail-batchquery.md",
};

const requiredTokens = [
  "alipay.commerce.ec.consume.change.notify",
  "AlipayCommerceEcConsumeDetailQueryRequest",
  "AlipayCommerceEcConsumeDetailBatchqueryRequest",
];

const nodeRequiredTokens = [
  "alipay.commerce.ec.consume.detail.query",
  "alipay.commerce.ec.consume.detail.batchquery",
];

const nodeMethodDocs = {
  "alipay.commerce.ec.consume.detail.query": "references/push-mode/consume-detail-query.md",
  "alipay.commerce.ec.consume.detail.batchquery": "references/push-mode/consume-detail-batchquery.md",
};

const enumDocs = [
  "references/push-mode/consume-change-notify.md",
  "references/common/expense-type-enum.md",
];

runGuarded("alipay-enterprise-bill", main);

function main() {
  const errors = [];
  const warnings = [];
  if (!fs.existsSync(targetDir)) fail(`target directory not found: ${targetDir}`);
  validateIntegrationContract(targetDir, ["bill"], errors);

  const javaFiles = walk(targetDir).filter((f) => f.endsWith(".java"));
  const nodeProject = isNodeProject(targetDir);

  // 按项目技术栈选择一条校验链路，避免语言专属规则互相污染。
  if (javaFiles.length === 0 && nodeProject) {
    checkNodeProject("alipay-enterprise-bill", nodeRequiredTokens, errors, warnings);
    report("alipay-enterprise-bill", errors, warnings);
    return;
  }
  if (javaFiles.length === 0) {
    checkCrossLanguageBillProject(errors, warnings);
    report("alipay-enterprise-bill", errors, warnings);
    return;
  }

  const domainFiles = javaFiles.filter(isBillFile);
  const allText = domainFiles.map((f) => fs.readFileSync(f, "utf8")).join("\n");
  const allCode = stripJavaComments(allText);
  const projectText = javaFiles.map((f) => fs.readFileSync(f, "utf8")).join("\n");

  checkJavaMavenSdkLatest(errors);
  checkSdkStubs(javaFiles, errors);
  checkSdkReflectionBypass(domainFiles, errors);
  checkUnsafeStubs(domainFiles, errors);
  checkSdkModelUsage(allText, modelDocs, errors);
  checkRawBizContent(domainFiles, errors);
  checkCoverage(allCode, requiredTokens, errors);
  checkPackagePaths(javaFiles, errors);
  checkSetters(domainFiles, errors);
  const implementationText = domainFiles
    .filter((file) => !isDemoOrTestSource(file, fs.readFileSync(file, "utf8")))
    .map((file) => stripJavaComments(fs.readFileSync(file, "utf8")))
    .join("\n");
  checkRelatedResponseProjection(implementationText, errors);
  checkEnums(allText, projectText, enumDocs, errors);
  checkWebSocket(allText, projectText, errors);
  javaProjectGates.checkJavaTransportContracts(javaFiles, errors, rel, domainFiles);
  javaProjectGates.checkJavaProductionStateStores(domainFiles, errors, rel);
  javaProjectGates.checkJavaStateTransitionPersistence(domainFiles, errors, rel);
  if (process.env.ALIPAY_VALIDATE_AGGREGATE !== "1") {
    checkJavaMessageClientStartupFailure(javaFiles, errors);
    javaProjectGates.checkJavaAlipayMsgClientContracts(javaFiles, errors, rel);
    javaProjectGates.checkSpringProfileWiring(targetDir, javaFiles, errors, rel);
    javaProjectGates.checkJavaProfiledCoreComponents(domainFiles, errors, rel);
    javaProjectGates.checkJavaConcreteDemoDependency(javaFiles, errors, rel);
    javaProjectGates.checkJavaFailClosedDefaultBackoff(javaFiles, errors, rel);
    javaProjectGates.checkSpringBeanMethodBypass(javaFiles, errors, rel);
    javaProjectGates.checkJavaTestEvidence(targetDir, javaFiles, errors);
  }
  checkBillNotifyRetrySemantics(domainFiles, errors);
  checkJavaUnknownBillNotifySuccess(domainFiles, errors);
  checkJavaFailOpenBillBusiness(domainFiles, errors);
  checkJavaBillMissingIdentifierFallback(domainFiles, errors);
  checkJavaNotificationIdempotency(domainFiles, errors);
  checkJavaProductionMemoryIdempotency(domainFiles, errors);
  checkJavaFailClosedPortPrimary(domainFiles, errors);
  if (hasManualWhitelistComment(allText)) errors.push("code comments must not hand-write field whitelist notes; use 字段来源：接口文档业务请求参数表");

  report("alipay-enterprise-bill", errors, warnings);
}

// -----------------------------------------------------------------------------
// Node.js：SDK 调用、字段、通知、语法和测试。
// -----------------------------------------------------------------------------

function isNodeProject(dir) {
  const files = walk(dir);
  return files.some((f) => path.basename(f) === "package.json")
    && files.some((f) => /\.(?:js|cjs|mjs|ts)$/i.test(f));
}

function checkNodeProject(name, requiredTokens, errors, warnings) {
  const packageFile = findFile(targetDir, "package.json");
  if (!packageFile) {
    errors.push("Node.js project must contain package.json");
    return;
  }

  let pkg = {};
  try {
    pkg = JSON.parse(fs.readFileSync(packageFile, "utf8"));
  } catch (err) {
    errors.push(`package.json is not valid JSON: ${err.message}`);
    return;
  }

  const jsFiles = walk(targetDir).filter((f) => /\.(?:js|cjs|mjs)$/i.test(f) && isNodeBillFile(f));
  const sourceText = jsFiles.map((f) => fs.readFileSync(f, "utf8")).join("\n");
  const sourceCode = stripJsComments(sourceText);

  checkNodeAlipaySdkUsage(pkg, packageFile, sourceCode, errors);
  checkNodeExecAppAuthTokenPlacement(sourceCode, errors);
  checkNodeNotifyVerification(sourceCode, errors);
  checkNodeBizContentFields(jsFiles, nodeMethodDocs, errors);
  checkNodeCoverage(sourceCode, requiredTokens, errors);
  checkNodeBillNotifyHandler(sourceCode, errors);
  checkNodeBillNotifyRetrySemantics(sourceCode, errors);
  checkNodeFailOpenBillBusiness(sourceCode, errors);
  checkNodeUnsafeStubs(sourceCode, errors);
  checkNodeSyntax(jsFiles, errors);
  checkNodeModuleLoading(jsFiles, errors);
  checkNodeTests(pkg, path.dirname(packageFile), errors, warnings);
}

function checkNodeAlipaySdkUsage(pkg, packageFile, text, errors) {
  if (!/alipay-sdk/.test(text)) return;
  const deps = Object.assign({}, pkg.dependencies || {}, pkg.devDependencies || {});
  if (!deps["alipay-sdk"]) errors.push("Node.js code uses alipay-sdk but package.json does not declare alipay-sdk");
  if (/require\s*\(\s*["']alipay-sdk["']\s*\)\s*\.default\b/.test(text)) {
    errors.push("Node.js CommonJS code imports alipay-sdk via .default; use `const { AlipaySdk } = require(\"alipay-sdk\")` after verifying the installed SDK export");
  }
  try {
    const sdkPath = require.resolve("alipay-sdk", { paths: [path.dirname(packageFile)] });
    const sdk = require(sdkPath);
    if (typeof sdk.AlipaySdk !== "function") errors.push("installed alipay-sdk does not export AlipaySdk as a constructor");
  } catch (err) {
    if (fs.existsSync(path.join(path.dirname(packageFile), "node_modules"))) {
      errors.push(`failed to load installed alipay-sdk: ${err.message}`);
    }
  }
}

function checkNodeExecAppAuthTokenPlacement(text, errors) {
  if (/\.exec\s*\(\s*[^,]+,\s*\{\s*bizContent[\s\S]{0,300}?\}\s*,\s*\{[\s\S]{0,160}?appAuthToken\s*:/g.test(text)) {
    errors.push("Node.js alipay-sdk exec(...) passes appAuthToken in the third options argument; for OpenAPI 2.0 put it in the second argument with bizContent");
  }
}

function checkNodeNotifyVerification(text, errors) {
  if (/crypto\s*\.\s*createVerify\s*\(/.test(text) && !/\.checkNotifySign(?:V2)?\s*\(/.test(text)) {
    errors.push("Node.js notification verification hand-rolls crypto.createVerify; use alipay-sdk checkNotifySign/checkNotifySignV2");
  }
  if (/\basync\s+function\s+verify[A-Za-z0-9_]*(?:Sign|Notify)[A-Za-z0-9_]*\s*\(/.test(text)
      && /(?:const|let|var)\s+[A-Za-z0-9_]+\s*=\s*verify[A-Za-z0-9_]*(?:Sign|Notify)[A-Za-z0-9_]*\s*\(/.test(text)
      && !/(?:const|let|var)\s+[A-Za-z0-9_]+\s*=\s*await\s+verify[A-Za-z0-9_]*(?:Sign|Notify)[A-Za-z0-9_]*\s*\(/.test(text)) {
    errors.push("Node.js notification verification helper is async but callers do not await it; failed signatures may be treated as valid");
  }
}

function checkNodeBizContentFields(jsFiles, methodDocs, errors) {
  const docCache = new Map();
  for (const file of jsFiles) {
    const text = stripJsComments(fs.readFileSync(file, "utf8"));
    const functions = extractJsFunctions(text);
    for (const [method, docRel] of Object.entries(methodDocs)) {
      const callPattern = new RegExp(`\\.exec\\s*\\(\\s*["']${escapeRegExp(method)}["']`, "g");
      for (const match of text.matchAll(callPattern)) {
        const fn = functions.find((item) => match.index >= item.start && match.index <= item.end);
        const scope = fn ? fn.body : text;
        const fields = extractNodeBizContentFields(scope);
        if (!fields.found) continue;
        if (!docCache.has(docRel)) docCache.set(docRel, documentedNodeFields(docRel));
        const documented = docCache.get(docRel);

        for (const field of fields.names()) {
          if (!documented.allowed.has(field)) {
            errors.push(`${rel(file)}: ${method} bizContent field ${field} is not in documented business request parameters`);
          }
        }
        for (const field of documented.required) {
          const state = fields.get(field);
          if (!state) {
            errors.push(`${rel(file)}: ${method} bizContent is missing required documented field ${field}`);
          } else if (!state.unconditional && !hasRequiredFieldPreflight(scope, field)) {
            errors.push(`${rel(file)}: ${method} required field ${field} is only conditionally assigned without a documented preflight validation`);
          }
        }
      }
    }
  }
}

function documentedNodeFields(docRel) {
  const rows = extractRequestRows(path.join(skillDir, docRel));
  const allowed = new Set();
  const required = new Set();
  for (const row of rows) {
    if (row.field.includes(".")) continue;
    allowed.add(row.field);
    if (isRequired(row.required)) required.add(row.field);
  }
  return { allowed, required };
}

function extractNodeBizContentFields(scope) {
  // 同时识别对象字面量和后续属性赋值。对象内容不能简单按逗号拆分，
  // 因为字段值可能包含嵌套对象、数组、函数调用或字符串。
  const states = new Map();
  const ifRanges = conditionalRanges(scope);
  let found = false;

  function add(field, unconditional) {
    if (!/^[a-z][a-z0-9_]*$/.test(field)) return;
    const state = states.get(field) || { unconditional: false, conditional: false };
    if (unconditional) state.unconditional = true;
    else state.conditional = true;
    states.set(field, state);
  }

  const literalPattern = /\b(?:const|let|var)\s+bizContent\s*=\s*\{/g;
  for (const match of scope.matchAll(literalPattern)) {
    const open = match.index + match[0].lastIndexOf("{");
    const close = findMatchingBrace(scope, open);
    if (close < 0) continue;
    found = true;
    const unconditional = !isInsideRanges(match.index, ifRanges);
    for (const key of topLevelObjectKeys(scope.slice(open + 1, close))) add(key, unconditional);
  }

  const assignPattern = /\bbizContent\s*(?:\.\s*([A-Za-z_$][\w$]*)|\[\s*["']([^"']+)["']\s*\])\s*=/g;
  for (const match of scope.matchAll(assignPattern)) {
    found = true;
    add(match[1] || match[2], !isInsideRanges(match.index, ifRanges));
  }

  return {
    found,
    get: (field) => states.get(field),
    names: () => Array.from(states.keys()),
  };
}

function conditionalRanges(text) {
  const ranges = [];
  for (const match of text.matchAll(/\bif\s*\([^)]*\)\s*\{/g)) {
    const open = match.index + match[0].lastIndexOf("{");
    const close = findMatchingBrace(text, open);
    if (close > open) ranges.push([match.index, close]);
  }
  return ranges;
}

function hasRequiredFieldPreflight(scope, field) {
  const escaped = escapeRegExp(field);
  return new RegExp(`\\b(?:validate|assert|ensure|require)[A-Za-z0-9_]*\\s*\\([^)]*["']${escaped}["']`, "i").test(scope)
    || new RegExp(`\\bif\\s*\\([^)]*(?:!\\s*)?(?:bizContent\\s*\\.\\s*)?${escaped}[^)]*\\)[\\s\\S]{0,240}\\b(?:throw\\b|return\\s+(?:false|fail))`, "i").test(scope)
    || new RegExp(`\\bif\\s*\\([^)]*(?:!\\s*)?(?:params|request|input)\\s*\\.\\s*${escaped}[^)]*\\)[\\s\\S]{0,240}\\b(?:throw\\b|return\\s+(?:false|fail))`, "i").test(scope);
}

function isInsideRanges(index, ranges) {
  return ranges.some(([start, end]) => index >= start && index <= end);
}

function extractJsFunctions(text) {
  const functions = [];
  const seen = new Set();
  const patterns = [
    /\b(?:async\s+)?function\s+([A-Za-z_$][\w$]*)\s*\([^)]*\)\s*\{/g,
    /\b(?:const|let|var)\s+([A-Za-z_$][\w$]*)\s*=\s*(?:async\s*)?\([^)]*\)\s*=>\s*\{/g,
    /\b(?:const|let|var)\s+([A-Za-z_$][\w$]*)\s*=\s*(?:async\s+)?function\s*\([^)]*\)\s*\{/g,
    /\b(?:async\s+)?([A-Za-z_$][\w$]*)\s*\([^)]*\)\s*\{/g,
  ];
  for (const pattern of patterns) {
    for (const match of text.matchAll(pattern)) {
      const open = match.index + match[0].lastIndexOf("{");
      if (seen.has(open)) continue;
      const close = findMatchingBrace(text, open);
      if (close > open) {
        seen.add(open);
        functions.push({ name: match[1], start: match.index, end: close, body: text.slice(open + 1, close) });
      }
    }
  }
  return functions;
}

function topLevelObjectKeys(body) {
  const keys = [];
  for (const entry of splitTopLevel(body, ",")) {
    const trimmed = entry.trim();
    if (!trimmed || trimmed.startsWith("...")) continue;
    const colon = topLevelColon(trimmed);
    const keyPart = (colon >= 0 ? trimmed.slice(0, colon) : trimmed).trim();
    const literal = keyPart.match(/^["']([^"']+)["']$/);
    if (literal) {
      keys.push(literal[1]);
      continue;
    }
    const ident = keyPart.match(/^([A-Za-z_$][\w$]*)$/);
    if (ident) keys.push(ident[1]);
  }
  return keys;
}

function splitTopLevel(text, delimiter) {
  const parts = [];
  let start = 0;
  let depth = 0;
  let quote = null;
  let escaped = false;
  for (let i = 0; i < text.length; i++) {
    const ch = text[i];
    if (quote) {
      if (escaped) escaped = false;
      else if (ch === "\\") escaped = true;
      else if (ch === quote) quote = null;
      continue;
    }
    if (ch === "\"" || ch === "'" || ch === "`") {
      quote = ch;
      continue;
    }
    if (ch === "{" || ch === "[" || ch === "(") depth++;
    else if (ch === "}" || ch === "]" || ch === ")") depth--;
    else if (ch === delimiter && depth === 0) {
      parts.push(text.slice(start, i));
      start = i + 1;
    }
  }
  parts.push(text.slice(start));
  return parts;
}

function topLevelColon(text) {
  let depth = 0;
  let quote = null;
  let escaped = false;
  for (let i = 0; i < text.length; i++) {
    const ch = text[i];
    if (quote) {
      if (escaped) escaped = false;
      else if (ch === "\\") escaped = true;
      else if (ch === quote) quote = null;
      continue;
    }
    if (ch === "\"" || ch === "'" || ch === "`") quote = ch;
    else if (ch === "{" || ch === "[" || ch === "(") depth++;
    else if (ch === "}" || ch === "]" || ch === ")") depth--;
    else if (ch === ":" && depth === 0) return i;
  }
  return -1;
}

function checkNodeCoverage(text, tokens, errors) {
  for (const token of tokens) {
    if (!text.includes(token)) errors.push(`missing required Node.js interface token: ${token}`);
  }
}

function checkNodeBillNotifyHandler(text, errors) {
  if (!/handle[A-Za-z0-9_]*(?:Consume|Bill)[A-Za-z0-9_]*Notify/.test(text)) {
    errors.push("missing executable bill/consume change notification handler");
  }
  if (!/\bpay_no\b|\bpayNo\b|idempot|dedupe|uniqueKey|businessKey/i.test(text)) {
    errors.push("bill notification handler must derive idempotency from the documented unique business key, such as pay_no for consume notifications");
  }
  if (/\bdefault\s*:[\s\S]{0,420}\breturn\s+true\s*;/.test(text)) {
    errors.push("Node.js bill notification handler must not default unknown msg_method/consume_type to success; return fail or delegate to an explicit unknown handler result so retry semantics are preserved");
  }
}

function checkNodeBillNotifyRetrySemantics(text, errors) {
  const addIndex = text.search(/\bprocessed[A-Za-z0-9_]*\s*\.\s*(?:add|set)\s*\(/);
  if (addIndex < 0) return;
  const workCandidates = [
    text.search(/\bprocess[A-Za-z0-9_]*\s*\(/),
    text.search(/\bquery[A-Za-z0-9_]*ConsumeDetail[A-Za-z0-9_]*\s*\(/),
    text.search(/\bdispatch[A-Za-z0-9_]*\s*\(/),
  ].filter((i) => i >= 0);
  if (workCandidates.length === 0) return;
  const firstWorkIndex = Math.min(...workCandidates);
  const removesOnFailure = /\bprocessed[A-Za-z0-9_]*\s*\.\s*(?:delete|remove)\s*\(/.test(text);
  if (addIndex < firstWorkIndex && !removesOnFailure) {
    errors.push("bill notify idempotency is marked before business processing and is not removed on failure; mark pay_no processed only after success or release it on failure");
  }
}

function checkNodeFailOpenBillBusiness(text, errors) {
  for (const fn of extractJsFunctions(text)) {
    const successHandler = /^(?:process|handle|onNotify|apply|sync).*(?:Bill|Consume|Notify|Notification)/i.test(fn.name || "")
      && /\breturn\s+(?:true|["']success["'])\s*;?/.test(fn.body);
    const persistenceHook = /^(?:persist|save|upsert|store|record|sync|apply|update)(?:Bill|Consume|Expense|Order|Notification)/i.test(fn.name || "");
    if (!successHandler && !persistenceHook) continue;
    if (/\bthrow\b/.test(fn.body)) continue;
    if (hasBusinessSideEffectCall(fn.body)) continue;
    errors.push(`Node.js bill function ${fn.name}(...) is a fail-open business hook with no repository, service, port, gateway, or equivalent side effect; wire a real extension point or fail closed before acknowledging the notification`);
  }
}

function checkNodeUnsafeStubs(text, errors) {
  if (/\b(?:verifySign|checkSign|validateSign)\s*\([^)]*\)\s*\{[\s\S]{0,120}?return\s+true\s*;/.test(text)) {
    errors.push("Node.js signature verification contains a return-true stub");
  }
  if (/TODO_STUB|stub implementation|mock success|return\s+["']success["']\s*;[\s\S]{0,160}\/\/\s*TODO/i.test(text)) {
    errors.push("Node.js code contains stub/mock success logic");
  }
}

function checkNodeSyntax(jsFiles, errors) {
  for (const file of jsFiles) {
    const result = spawnSync(process.execPath, ["--check", file], { cwd: targetDir, encoding: "utf8", maxBuffer: 1024 * 1024 });
    if (result.status !== 0) errors.push(`node --check failed for ${rel(file)}:\n${lastLines(result.stderr || result.stdout)}`);
  }
}

function checkNodeModuleLoading(jsFiles, errors) {
  for (const file of jsFiles) {
    if (!isGeneratedSourceFile(file)) continue;
    if (path.basename(file) === "index.js" && /app\.listen\s*\(/.test(fs.readFileSync(file, "utf8"))) continue;
    const result = spawnSync(process.execPath, ["-e", "require(process.argv[1])", file], { cwd: targetDir, encoding: "utf8", maxBuffer: 1024 * 1024 });
    if (result.status !== 0) errors.push(`Node.js module load failed for ${rel(file)}:\n${lastLines(result.stderr || result.stdout)}`);
  }
}

function checkNodeTests(pkg, cwd, errors, warnings) {
  if (process.env.ALIPAY_VALIDATE_SKIP_NODE_TEST === "1") return;
  if (!pkg.scripts || !pkg.scripts.test) {
    warnings.push("package.json has no test script; skipped npm test");
    return;
  }
  const result = spawnSync("npm", ["test"], { cwd, encoding: "utf8", maxBuffer: 1024 * 1024 * 4 });
  if (result.status !== 0) errors.push(`npm test failed for generated Node.js project:\n${lastLines(`${result.stdout || ""}\n${result.stderr || ""}`, 40)}`);
}

function isGeneratedSourceFile(file) {
  const relPath = rel(file).split(path.sep).join("/");
  return /^(src|lib|app)\//.test(relPath);
}

function isNodeBillFile(file) {
  const relPath = rel(file).split(path.sep).join("/");
  if (/^(config)\//.test(relPath) || /^(src|lib|app)\/common\//.test(relPath)) return true;
  if (/^(src|lib|app)\/bill\//.test(relPath)) return true;
  if (/^(src|lib|app)\/notify\//.test(relPath) && /bill|consume/i.test(relPath)) return true;
  const text = fs.readFileSync(file, "utf8");
  return /alipay\.commerce\.ec\.consume|pay_no|consume\.change\.notify/.test(text);
}

function findFile(dir, name) {
  return walk(dir).find((f) => path.basename(f) === name);
}

function checkJavaMavenSdkLatest(errors) {
  const pom = findFile(targetDir, "pom.xml");
  if (!pom) return;
  const sdkVersion = extractPomSdkVersion(fs.readFileSync(pom, "utf8"));
  if (!sdkVersion) {
    errors.push("pom.xml must declare com.alipay.sdk:alipay-sdk-java with an explicit version, alipay-sdk.version property, or alipay.sdk.version property");
    return;
  }
  if (!ALIPAY_SDK_VERSION_PATTERN.test(sdkVersion)) {
    errors.push(`pom.xml uses invalid alipay-sdk-java version ${sdkVersion}; SDK preflight must extract a version matching x.y.z.ALL from pkg:maven/com.alipay.sdk/alipay-sdk-java@<version> or the Maven dependency snippet, not an arbitrary page asset version`);
    return;
  }
  const latest = fetchLatestAlipaySdkVersion();
  if (!latest) {
    errors.push("unable to verify latest alipay-sdk-java version from Central Portal; extract only pkg:maven/com.alipay.sdk/alipay-sdk-java@<version> or the Maven dependency snippet, and require x.y.z.ALL format. Run `curl -sL \"https://central.sonatype.com/artifact/com.alipay.sdk/alipay-sdk-java\"` with approval or provide the Central Portal current version before generating Java/Maven code");
    return;
  }
  if (sdkVersion !== latest) {
    errors.push(`pom.xml uses alipay-sdk-java ${sdkVersion}, but Central Portal current version is ${latest}; upgrade existing and new Java/Maven projects to the current version`);
  }
}

function fetchLatestAlipaySdkVersion() {
  const result = spawnSync("curl", ["-fsSL", "https://central.sonatype.com/artifact/com.alipay.sdk/alipay-sdk-java"], {
    encoding: "utf8",
    maxBuffer: 1024 * 1024 * 2,
  });
  if (result.status !== 0 || !result.stdout) return null;
  const pkg = result.stdout.match(/pkg:maven\/com\.alipay\.sdk\/alipay-sdk-java@([0-9][0-9A-Za-z._-]*\.ALL)/);
  if (pkg) return pkg[1];
  const dep = result.stdout.match(/<artifactId>\s*alipay-sdk-java\s*<\/artifactId>[\s\S]*?<version>\s*([0-9][0-9A-Za-z._-]*\.ALL)\s*<\/version>/);
  return dep ? dep[1] : null;
}

function extractPomSdkVersion(pomText) {
  const properties = extractPomProperties(pomText);
  const dep = pomText.match(/<groupId>\s*com\.alipay\.sdk\s*<\/groupId>[\s\S]*?<artifactId>\s*alipay-sdk-java\s*<\/artifactId>[\s\S]*?<version>\s*([^<\s]+)\s*<\/version>/);
  if (!dep) return properties.get("alipay-sdk.version") || properties.get("alipay.sdk.version") || null;
  const version = dep[1];
  const propertyRef = version.match(/^\$\{([^}]+)\}$/);
  if (propertyRef) return properties.get(propertyRef[1]) || null;
  return version;
}

function extractPomProperties(pomText) {
  const properties = new Map();
  const block = pomText.match(/<properties>([\s\S]*?)<\/properties>/);
  if (!block) return properties;
  for (const m of block[1].matchAll(/<([A-Za-z0-9_.-]+)>\s*([^<\s]+)\s*<\/\1>/g)) {
    properties.set(m[1], m[2]);
  }
  return properties;
}

function lastLines(text, count = 20) {
  return String(text || "").trim().split(/\r?\n/).slice(-count).join("\n");
}

function hasManualWhitelistComment(text) {
  const comments = [];
  for (const m of text.matchAll(/\/\*[\s\S]*?\*\/|^\s*\/\/.*$/gm)) comments.push(m[0]);
  return comments.some((comment) => /字段白名单|白名单字段|白名单\s*[:：]/.test(comment));
}

// -----------------------------------------------------------------------------
// Python / Go / .NET / PHP：不依赖 Java SDK 的账单通用门禁。
// -----------------------------------------------------------------------------

function checkCrossLanguageBillProject(errors, warnings) {
  const files = walk(targetDir).filter((f) => /\.(?:py|go|cs|php)$/i.test(f) && isCrossLanguageBillFile(f));
  if (files.length === 0) {
    warnings.push("no Java/Node.js bill source files found; skipped bill language-specific gates");
    return;
  }

  const rawText = files.map((f) => fs.readFileSync(f, "utf8")).join("\n");
  const sourceText = files.map((f) => stripCrossLanguageComments(fs.readFileSync(f, "utf8"), f)).join("\n");

  checkCrossLanguageBillCoverage(sourceText, errors);
  checkCrossLanguageBillFields(sourceText, errors);
  checkCrossLanguageBillNotify(files, sourceText, errors, warnings);
  checkCrossLanguageBuild(files, warnings, errors);

  if (/字段白名单|白名单字段|白名单\s*[:：]/.test(rawText)) {
    errors.push("code comments must not hand-write field whitelist notes; use 字段来源：接口文档业务请求参数表");
  }
}

function isCrossLanguageBillFile(file) {
  const relPath = rel(file).split(path.sep).join("/");
  if (/\/(?:node_modules|vendor|target|dist|build|bin|obj|coverage|__pycache__)\//.test(`/${relPath}/`)) return false;
  if (/(^|\/)[^/]*expense[^/]*(\/|$)|\/(?:ec\/employee|ec\/enterprise|department|accounting)\//i.test(`/${relPath}/`)) return false;
  const text = fs.readFileSync(file, "utf8");
  return /alipay\.commerce\.ec\.consume|alipay\.ebpp\.invoice\.ecorder|consume\.change\.notify|Consume|Bill|pay_no|expense_type_sub_category/.test(text);
}

function checkCrossLanguageBillCoverage(text, errors) {
  const required = [
    ["alipay.commerce.ec.consume.detail.query", "AlipayCommerceEcConsumeDetailQueryRequest"],
    ["alipay.commerce.ec.consume.detail.batchquery", "AlipayCommerceEcConsumeDetailBatchqueryRequest"],
    ["alipay.commerce.ec.consume.change.notify", "ConsumeNotifyHandler", "ConsumeNotifyService", "ConsumeChangeNotify"],
  ];
  for (const alternatives of required) {
    if (!alternatives.some((token) => text.includes(token))) {
      errors.push(`missing required non-Java bill interface/notification token: ${alternatives[0]}`);
    }
  }
}

function checkCrossLanguageBillFields(text, errors) {
  for (const field of ["expense_type_sub", "expense_sub_type", "expense_sub_category"]) {
    if (fieldNamePattern(field).test(text)) {
      errors.push(`non-Java bill code uses unsupported guessed expense subtype field: ${field}; use expense_type_sub_category`);
    }
  }

  const mapping = expenseTypeSubtypeMapping();
  const constants = extractStringConstants(text);
  const expenseTypes = extractCrossLanguageFieldValues(text, ["expense_type", "ExpenseType"], constants);
  const subtypes = extractCrossLanguageFieldValues(text, ["expense_type_sub_category", "ExpenseTypeSubCategory"], constants);
  for (const expenseType of expenseTypes) {
    const allowed = mapping.get(expenseType);
    if (!allowed || allowed.size === 0) continue;
    for (const subtype of subtypes) {
      if (!allowed.has(subtype)) {
        errors.push(`non-Java bill expense_type_sub_category ${subtype} is not valid for expense_type ${expenseType}; use references/common/expense-type-enum.md`);
      }
    }
  }
}

function extractCrossLanguageFieldValues(text, fields, constants = new Map()) {
  const values = [];
  const expr = valueExpressionPattern();
  for (const field of fields) {
    const jsonKey = new RegExp(`["']${escapeRegExp(field)}["']\\s*(?:=>|:|=)\\s*${expr}`, "g");
    for (const m of text.matchAll(jsonKey)) {
      const value = resolveStringArg(m[1], constants);
      if (value) values.push(value);
    }

    const property = new RegExp(`\\b${escapeRegExp(field)}\\b[\\s\\S]{0,80}?=\\s*${expr}`, "g");
    for (const m of text.matchAll(property)) {
      const value = resolveStringArg(m[1], constants);
      if (value) values.push(value);
    }
  }
  return Array.from(new Set(values));
}

function expenseTypeSubtypeMapping() {
  const file = path.join(skillDir, "references/common/expense-type-enum.md");
  const text = fs.readFileSync(file, "utf8");
  const mapping = new Map();
  let currentType = null;
  for (const line of text.split(/\r?\n/)) {
    if (!line.startsWith("|") || line.includes("---") || line.includes("费用类型")) continue;
    const cells = line.split("|").map((s) => s.trim());
    const expenseType = cells[1] || "";
    const subtype = cells[3] || "";
    if (expenseType) currentType = expenseType;
    if (!currentType || !subtype) continue;
    if (!mapping.has(currentType)) mapping.set(currentType, new Set());
    mapping.get(currentType).add(subtype);
  }
  return mapping;
}

function checkCrossLanguageBillNotify(files, text, errors, warnings) {
  checkCrossLanguageSignatureStubs(text, errors);
  const hasNotifyFile = files.some((file) => /notify|handler|callback/i.test(path.basename(file)) || /\/notify\//i.test(rel(file)));
  const hasNotifyMethod = /alipay\.commerce\.ec\.consume\.change\.notify/.test(text);
  if ((hasNotifyFile || hasNotifyMethod) && !/checkNotifySign|verifyNotify|verifySign|validateSign|rsaCheck|signature/i.test(text)) {
    warnings.push("bill notification code found but no signature verification token detected; ensure HTTP(S) notifications are verified before business handling");
  }
  if ((hasNotifyFile || hasNotifyMethod) && !/idempot|幂等|pay_no|out_biz_no|trade_no/i.test(text)) {
    warnings.push("bill notification code found but no idempotency key handling token detected; ensure notification retry is safe");
  }
}

function checkCrossLanguageSignatureStubs(text, errors) {
  if (/\b(?:verify|check|validate)[A-Za-z0-9_]*(?:Sign|Signature|Notify)[A-Za-z0-9_]*\s*\([^)]*\)\s*\{[\s\S]{0,180}?\breturn\s+true\b/i.test(text)) {
    errors.push("non-Java signature verification contains a return-true stub");
  }
}

function checkCrossLanguageBuild(files, warnings, errors) {
  const exts = new Set(files.map((f) => path.extname(f).toLowerCase()));
  if (exts.has(".py")) checkPythonSyntax(files.filter((f) => f.endsWith(".py")), warnings, errors);
  if (exts.has(".go")) checkGoBuild(warnings, errors);
  if (exts.has(".cs")) checkDotnetBuild(warnings, errors);
  if (exts.has(".php")) checkPhpSyntax(files.filter((f) => f.endsWith(".php")), warnings, errors);
}

function checkPythonSyntax(files, warnings, errors) {
  if (!commandExists("python3")) {
    warnings.push("python3 not found; skipped Python syntax validation");
    return;
  }
  const script = [
    "import ast, pathlib, sys",
    "for name in sys.argv[1:]:",
    "    path = pathlib.Path(name)",
    "    ast.parse(path.read_text(encoding='utf-8'), filename=str(path))",
  ].join("\n");
  const result = spawnSync("python3", ["-c", script, ...files], {
    cwd: targetDir,
    encoding: "utf8",
    env: Object.assign({}, process.env, { PYTHONDONTWRITEBYTECODE: "1" }),
    maxBuffer: 1024 * 1024,
  });
  if (result.status !== 0) errors.push(`Python syntax validation failed:\n${lastLines(result.stderr || result.stdout)}`);
}

function checkGoBuild(warnings, errors) {
  const goMod = findFile(targetDir, "go.mod");
  if (!goMod) {
    warnings.push("Go source detected but go.mod not found; skipped go test");
    return;
  }
  if (!commandExists("go")) {
    warnings.push("go command not found; skipped go test");
    return;
  }
  const result = spawnSync("go", ["test", "./..."], {
    cwd: path.dirname(goMod),
    encoding: "utf8",
    env: Object.assign({}, process.env, { GOCACHE: path.join(os.tmpdir(), "alipay-skill-go-cache") }),
    maxBuffer: 1024 * 1024 * 4,
  });
  if (result.status !== 0) errors.push(`go test ./... failed:\n${lastLines(`${result.stdout || ""}\n${result.stderr || ""}`, 40)}`);
}

function checkDotnetBuild(warnings, errors) {
  const project = walk(targetDir).find((f) => /\.csproj$/i.test(f));
  if (!project) {
    warnings.push(".NET source detected but no .csproj found; skipped dotnet build");
    return;
  }
  if (!commandExists("dotnet")) {
    warnings.push("dotnet command not found; skipped dotnet build");
    return;
  }
  const result = spawnSync("dotnet", ["build", "--nologo"], {
    cwd: path.dirname(project),
    encoding: "utf8",
    maxBuffer: 1024 * 1024 * 8,
  });
  if (result.status !== 0) errors.push(`dotnet build failed:\n${lastLines(`${result.stdout || ""}\n${result.stderr || ""}`, 40)}`);
}

function checkPhpSyntax(files, warnings, errors) {
  if (!commandExists("php")) {
    warnings.push("php command not found; skipped PHP syntax validation");
    return;
  }
  for (const file of files) {
    const result = spawnSync("php", ["-l", file], { cwd: targetDir, encoding: "utf8", maxBuffer: 1024 * 256 });
    if (result.status !== 0) errors.push(`php -l failed for ${rel(file)}:\n${lastLines(result.stderr || result.stdout)}`);
  }
}

function commandExists(command) {
  const result = spawnSync(command, ["--version"], { encoding: "utf8", maxBuffer: 1024 * 32 });
  return result.status === 0;
}

function fieldNamePattern(field) {
  return new RegExp(`(^|[^A-Za-z0-9_])${escapeRegExp(field)}([^A-Za-z0-9_]|$)`);
}

function stripCrossLanguageComments(text, file) {
  if (file.endsWith(".py")) return text.replace(/^\s*#.*$/gm, "");
  return text
    .replace(/\/\*[\s\S]*?\*\//g, "")
    .replace(/^\s*\/\/.*$/gm, "")
    .replace(/^\s*#.*$/gm, "");
}

// -----------------------------------------------------------------------------
// Java/Maven：文档驱动的 Model、setter、通知与 SDK 校验。
// -----------------------------------------------------------------------------

function checkSetters(javaFiles, errors) {
  const allowed = {};
  for (const [type, doc] of Object.entries(modelDocs)) allowed[type] = allowedSetters(doc);
  for (const file of javaFiles) {
    const text = fs.readFileSync(file, "utf8");
    scanSetterBlocks(text, allowed, file, errors);
  }
}

// query_options is a request for additional response sections, not a hint.
// If generated code requests one of those sections but never reads it, the
// business boundary receives an incomplete bill even though the API call succeeds.
function checkRelatedResponseProjection(text, errors) {
  const mappings = [
    { option: "Order", getter: "getRelatedOrderInfo", field: "related_order_info" },
    { option: "Ticket", getter: "getRelatedVoucherList", field: "related_voucher_list" },
    { option: "Compliance", getter: "getRelatedVoucherList", field: "related_voucher_list" },
    { option: "Refund", getter: "getRelatedRefundList", field: "related_refund_list" },
  ];

  for (const mapping of mappings) {
    if (!hasRelatedQueryOption(text, mapping.option)) continue;
    if (!hasProjectedJavaResponse(text, mapping.getter)) {
      errors.push(`consume.detail.query requests query_options=${mapping.option} but generated code never reads or projects ${mapping.field}; carry the requested response section through DTO conversion to the business port`);
    }
  }
}

function hasRelatedQueryOption(text, option) {
  const tokens = valueTokens(text, option);
  const queryAnchor = "(?:query[_A-Za-z0-9]*options?|setQueryOptions|query[A-Za-z0-9_]*(?:Detail|ByPayNo))";
  return tokens.some((token) => {
    const value = escapeRegExp(token);
    return new RegExp(`${queryAnchor}[\\s\\S]{0,260}\\b${value}\\b|\\b${value}\\b[\\s\\S]{0,260}${queryAnchor}`, "i").test(text);
  });
}

function hasProjectedJavaResponse(text, getter) {
  const escapedGetter = escapeRegExp(getter);
  const directFlow = new RegExp(`\\b(?:return|set[A-Za-z0-9_]*\\s*\\(|(?:to|map|build|handle|process)[A-Za-z0-9_]*\\s*\\([^;]{0,300})[^;\\n]*\\.${escapedGetter}\\s*\\(`);
  if (directFlow.test(text)) return true;

  const assignment = new RegExp(`\\b([A-Za-z_][A-Za-z0-9_]*)\\s*=\\s*[^;\\n]*\\.${escapedGetter}\\s*\\([^;]*\\)\\s*;`, "g");
  for (const match of text.matchAll(assignment)) {
    const tail = text.slice(match.index + match[0].length, match.index + match[0].length + 1200);
    if (new RegExp(`\\b${escapeRegExp(match[1])}\\b`).test(tail)) return true;
  }
  return false;
}

function scanSetterBlocks(text, allowed, file, errors) {
  const vars = {};
  const pattern = /\b([A-Za-z0-9_]+)\s+([A-Za-z0-9_]+)\s*=\s*new\s+\1\s*\(|\b([A-Za-z0-9_]+)\.set([A-Za-z0-9_]+)\s*\(/g;

  function finalize(varName) {
    const state = vars[varName];
    if (!state || !allowed[state.type] || !allowed[state.type].required.size) return;
    for (const setter of allowed[state.type].required) {
      if (!state.called.has(setter)) errors.push(`${rel(file)}: ${state.type} variable ${varName} is missing required documented setter ${setter}`);
    }
  }

  for (const m of text.matchAll(pattern)) {
    if (m[1]) {
      const type = m[1];
      const varName = m[2];
      finalize(varName);
      vars[varName] = { type, called: new Set() };
      continue;
    }

    const varName = m[3];
    const setter = `set${m[4]}`;
    const state = vars[varName];
    if (!state || !allowed[state.type]) continue;
    state.called.add(setter);
    if (!allowed[state.type].all.has(setter)) errors.push(`${rel(file)}: setter ${state.type}.${setter} is not in documentation whitelist`);
  }

  for (const varName of Object.keys(vars)) finalize(varName);
}

function checkWebSocket(text, projectText, errors) {
  const uncommented = stripJavaComments(text);
  if (uncommented.includes("@ClientEndpoint") || /msg_type["']?\s*[:,]\s*["'](?:auth|heartbeat|ack)["']/.test(uncommented)) {
    errors.push("WebSocket implementation appears to hand-roll protocol; use official AlipayMsgClient + MsgHandler");
  }
  if (/WebSocket|AlipayMsgClient|MsgHandler/.test(text) && /AlipayMsgClient|MsgHandler/.test(uncommented)) {
    const hasExecutableClient = /AlipayMsgClient\s+[A-Za-z0-9_]+|AlipayMsgClient\.getInstance\s*\(/.test(uncommented)
      && /setMessageHandler\s*\(/.test(uncommented)
      && /\.connect\s*\(/.test(uncommented);
    if (!hasExecutableClient && !hasSharedBillMessageRouter(projectText)) {
      errors.push("Java WebSocket code mentions AlipayMsgClient/MsgHandler but does not contain executable getInstance + setMessageHandler + connect logic; do not leave official SDK access as comments/logs");
    }
  }
}

function checkBillNotifyRetrySemantics(javaFiles, errors) {
  for (const file of javaFiles) {
    const text = stripJavaComments(fs.readFileSync(file, "utf8"));
    if (!/alipay\.commerce\.ec\.consume\.change\.notify|ConsumeChangeNotify|payNo|pay_no/.test(text)) continue;
    if (!/NotifyHandler|handle\s*\(/.test(text)) continue;

    const putIndex = text.search(/\bprocessed[A-Za-z0-9_]*\s*\.\s*putIfAbsent\s*\(/);
    if (putIndex < 0) continue;

    const workIndexCandidates = [
      text.search(/\bdispatch[A-Za-z0-9_]*\s*\(/),
      text.search(/\bquery[A-Za-z0-9_]*ConsumeDetail[A-Za-z0-9_]*\s*\(/),
      text.search(/\bprocess[A-Za-z0-9_]*\s*\(/),
    ].filter((i) => i >= 0);
    if (workIndexCandidates.length === 0) continue;

    const firstWorkIndex = Math.min(...workIndexCandidates);
    const removesOnFailure = /\bprocessed[A-Za-z0-9_]*\s*\.\s*remove\s*\(/.test(text);
    if (putIndex < firstWorkIndex && !removesOnFailure) {
      errors.push(`${rel(file)}: bill notify idempotency is marked before business processing and is not removed on failure; mark pay_no processed only after success, or remove the key in the failure path so retry is not swallowed`);
    }
  }
}

function checkJavaUnknownBillNotifySuccess(javaFiles, errors) {
  for (const file of javaFiles) {
    const text = stripJavaComments(fs.readFileSync(file, "utf8"));
    if (!/alipay\.commerce\.ec\.consume\.change\.notify|ConsumeChangeNotify|NotifyHandleResult|pay_no|payNo/.test(text)) continue;

    for (const body of switchDefaultBodies(text)) {
      const hasExplicitUnknownHandler = /\b(?:handleUnknown|unknownHandler|onUnknown|unknown[A-Za-z0-9_]*Handler)\s*\(/i.test(body);
      const successDefault = /\breturn\s+(?:true|NotifyHandleResult\.SUCCESS|[A-Za-z0-9_]*Result\.success\s*\()/m.test(body);
      if (successDefault && !hasExplicitUnknownHandler) {
        errors.push(`${rel(file)}: Java bill notification default branch returns success for unknown msg_method/consume_type; use fail/throw or an explicit unknown handler`);
      }
    }
  }
}

function checkJavaFailOpenBillBusiness(files, errors) {
  for (const file of files) {
    const raw = fs.readFileSync(file, "utf8");
    if (!/bill|consume|notify|payNo|pay_no/i.test(`${path.basename(file)}\n${raw}`)) continue;

    for (const method of extractMethods(raw)) {
      const successHandler = /^(?:process|handle|onNotify|apply|sync)/i.test(method.name)
        && /\breturn\s+true\s*;/.test(method.body);
      const persistenceHook = /^(?:persist|save|upsert|store|record|sync|apply|update)(?:Bill|Consume|Expense|Order|Notification)/i.test(method.name);
      if (!successHandler && !persistenceHook) continue;
      if (/\bthrow\s+new\b/.test(method.body)) continue;
      if (hasBusinessSideEffectCall(method.body)) continue;

      errors.push(`${rel(file)}: ${method.name}(...) is a fail-open bill business hook with no repository, service, port, gateway, or equivalent side effect; wire a real extension point or fail closed before acknowledging the notification`);
    }
  }
}

function checkJavaBillMissingIdentifierFallback(files, errors) {
  for (const file of files) {
    const raw = fs.readFileSync(file, "utf8");
    if (!/billIdentifiers|expenseType|expense_type|sceneCode|orderType|matchesExpense/i.test(raw)) continue;
    const text = stripJavaComments(raw);
    for (const method of extractMethods(text)) {
      if (!/matches|route|filter|process|handle/i.test(method.name)) continue;
      const body = method.body;
      const checksAllIdentifiersMissing = /expenseType\s*==\s*null|expenseType\s*\.\s*isEmpty\s*\(/.test(body)
        && /expenseTypeSubCategory\s*==\s*null|expenseTypeSubCategory\s*\.\s*isEmpty\s*\(/.test(body)
        && /sceneCode\s*==\s*null|sceneCode\s*\.\s*isEmpty\s*\(/.test(body)
        && /orderType\s*==\s*null|orderType\s*\.\s*isEmpty\s*\(/.test(body);
      if (!checksAllIdentifiersMissing) continue;
      const missingIdentifierBranch = /(?:expenseType\s*==\s*null|expenseType\s*\.\s*isEmpty\s*\()[\s\S]{0,700}(?:orderType\s*==\s*null|orderType\s*\.\s*isEmpty\s*\()[\s\S]{0,260}return\s+true\s*;/.test(body);
      if (!missingIdentifierBranch) continue;
      errors.push(`${rel(file)}: bill notification treats missing expenseType/expenseTypeSubCategory/sceneCode/orderType as a scenario match; query bill detail before deciding, or explicitly skip/fail unknown-scenario notifications instead of processing them as the selected scenario`);
    }
  }
}

function hasBusinessSideEffectCall(body) {
  const call = /\b([A-Za-z_][A-Za-z0-9_]*)\s*\.\s*([A-Za-z_][A-Za-z0-9_]*)\s*\(/g;
  const meaningfulVerb = /^(?:save|insert|update|upsert|delete|persist|store|write|publish|dispatch|execute|apply|sync|process|handle|record|send|emit|on[A-Z])/;
  for (const match of body.matchAll(call)) {
    const owner = match[1];
    const method = match[2];
    if (/^(?:log|logger|response|res|reply|ctx|context)$/i.test(owner)) continue;
    if (meaningfulVerb.test(method)) return true;
  }
  return false;
}

function switchDefaultBodies(text) {
  const bodies = [];
  for (const match of text.matchAll(/default\s*:/g)) {
    const start = match.index + match[0].length;
    const tail = text.slice(start, start + 700);
    const nextCase = tail.search(/\bcase\s+/);
    const switchEnd = tail.search(/\n\s*}\s*(?:\n|$)/);
    const ends = [nextCase, switchEnd].filter((i) => i >= 0);
    const end = ends.length ? Math.min(...ends) : tail.length;
    bodies.push(tail.slice(0, end));
  }
  return bodies;
}

function hasSharedBillMessageRouter(text) {
  const uncommented = stripJavaComments(text);
  const hasExecutableClient = /AlipayMsgClient\s+[A-Za-z0-9_]+|AlipayMsgClient\.getInstance\s*\(/.test(uncommented)
    && /setMessageHandler\s*\(/.test(uncommented)
    && /\.connect\s*\(/.test(uncommented);
  if (!hasExecutableClient) return false;

  return /alipay\.commerce\.ec\.consume\.change\.notify/.test(uncommented)
    && /\.\s*[A-Za-z0-9_]*(?:Consume|Bill)[A-Za-z0-9_]*\s*\(/.test(uncommented);
}

function isBillFile(file) {
  const relPath = rel(file).split(path.sep).join("/");
  if (/\/(expense)\//.test(`/${relPath}`)) return false;
  if (/\/bill\//.test(`/${relPath}`)) return true;
  const text = fs.readFileSync(file, "utf8");
  return /AlipayCommerceEcConsume|alipay\.commerce\.ec\.consume|Consume|Bill|pay_no|consume/.test(text);
}

function allowedSetters(docRel) {
  const rows = extractRequestRows(path.join(skillDir, docRel));
  const all = new Set();
  const required = new Set();
  for (const row of rows) {
    if (row.field.includes(".")) continue;
    const setter = toSetter(row.field);
    all.add(setter);
    if (isRequired(row.required)) required.add(setter);
  }
  return { all, required };
}

function extractRequestRows(file) {
  const text = fs.readFileSync(file, "utf8");
  const rows = [];
  let inRequestParams = false;
  for (const line of text.split(/\r?\n/)) {
    if (/^###\s+业务请求参数/.test(line)) {
      inRequestParams = true;
      continue;
    }
    if (inRequestParams && /^###\s+/.test(line)) break;
    if (!inRequestParams) continue;
    if (!line.startsWith("|") || line.includes("---") || line.includes("参数英文名")) continue;
    const cells = line.split("|").map((s) => s.trim());
    const field = cells[1];
    if (/^[a-z][a-z0-9_]*(\.[a-z][a-z0-9_]*)*$/.test(field)) rows.push({ field, required: cells[3] || "" });
  }
  return rows;
}

function checkCoverage(text, tokens, errors) {
  for (const token of tokens) if (!text.includes(token)) errors.push(`missing required interface/notification: ${token}`);
}

function checkSdkModelUsage(text, docs, errors) {
  for (const type of Object.keys(docs)) {
    const declaration = new RegExp(`\\b${escapeRegExp(type)}\\s+([A-Za-z0-9_]+)\\s*=\\s*new\\s+${escapeRegExp(type)}\\s*\\(`);
    const m = text.match(declaration);
    if (!m) {
      errors.push(`missing required SDK model construction: ${type}; generated Java must use official Request + Model classes`);
      continue;
    }
    const varName = m[1];
    const setBizModel = new RegExp(`\\.setBizModel\\s*\\(\\s*${escapeRegExp(varName)}\\s*\\)`);
    if (!setBizModel.test(text)) {
      errors.push(`SDK model ${type} variable ${varName} is not passed to request.setBizModel(...)`);
    }
  }
}

function checkRawBizContent(files, errors) {
  const ownsRequest = (type) => /^AlipayCommerceEcConsume[A-Za-z0-9_]*Request$/.test(type);
  for (const file of files) {
    const source = fs.readFileSync(file, "utf8");
    const methodBodies = extractMethods(source).map((method) => method.body);
    const scopes = methodBodies.length > 0 ? methodBodies : [source];
    if (scopes.some((scope) => usesOwnedRequestRawBizContent(scope, ownsRequest))) {
      errors.push("generated Java must not hand-build biz_content with JSON/Map/setBizContent; use official SDK Model setters and request.setBizModel(model)");
      return;
    }
  }
}

function usesOwnedRequestRawBizContent(text, ownsRequest) {
  for (const m of text.matchAll(/\b(Alipay[A-Za-z0-9_]*Request)\s+([A-Za-z0-9_]+)\s*=/g)) {
    if (!ownsRequest(m[1])) continue;
    const varName = m[2];
    const pattern = new RegExp(`\\b${escapeRegExp(varName)}\\s*\\.\\s*(?:setBizContent\\s*\\(|putOtherTextParam\\s*\\(\\s*["']biz_content["'])`);
    if (pattern.test(text)) return true;
  }
  return false;
}

function stripJavaComments(text) {
  return text.replace(/\/\*[\s\S]*?\*\//g, "").replace(/^\s*\/\/.*$/gm, "");
}

function stripJsComments(text) {
  return text.replace(/\/\*[\s\S]*?\*\//g, "").replace(/^\s*\/\/.*$/gm, "");
}

function checkUnsafeStubs(files, errors) {
  for (const file of files) {
    const text = fs.readFileSync(file, "utf8");
    for (const method of extractMethods(text)) {
      if (/verifySign|checkSign|validateSign/.test(method.name) && /\breturn\s+true\s*;/.test(method.body)) {
        errors.push(`${rel(file)}: ${method.name}(...) is a security stub returning true; implement SDK signature verification or use the documented SDK message client`);
      }
      if (/Stub implementation for compilation purposes/.test(method.body)
          || /UnsupportedOperationException/.test(method.body) && !isExplicitFailClosedAdapter(text, method)) {
        errors.push(`${rel(file)}: generated code contains a stub implementation in ${method.name}(...)`);
      }
    }
  }
}

function isExplicitFailClosedAdapter(fileText, method) {
  if (!/UnsupportedOperationException/.test(method.body)) return false;
  const body = stripJavaComments(method.body).trim();
  const throwsOnly = /^\{\s*throw\s+new\s+UnsupportedOperationException\s*\([\s\S]*\)\s*;\s*\}$/.test(body);
  const boundary = /fail[- ]closed|not configured|未配置|@ConditionalOnMissingBean|\b(?:Port|Adapter|Gateway)\b/i.test(fileText);
  const sdkOrSecurity = /Alipay[A-Za-z0-9_]*Request|alipayClient\s*\.\s*execute|verifySign|checkSign|validateSign/.test(`${method.name}\n${method.body}`);
  return throwsOnly && boundary && !sdkOrSecurity;
}

function checkJavaNotificationIdempotency(files, errors) {
  for (const file of files) {
    const raw = fs.readFileSync(file, "utf8");
    if (!/bill|consume|notify|notification|payNo|pay_no|幂等/i.test(`${path.basename(file)}\n${raw}`)) continue;
    if (!/\b(?:PROCESSING|IN_PROGRESS)\b/.test(raw) || !/\b(?:DONE|COMPLETED|PROCESSED)\b/.test(raw)) continue;

    for (const method of extractMethods(raw)) {
      if (!/(?:tryAcquire|acquire|claim|reserve|lock)/i.test(method.name)) continue;
      if (!/putIfAbsent\s*\(/.test(method.body)) continue;
      if (collapsesInFlightAndCompleted(method.body)) {
        errors.push(`${rel(file)}: ${method.name}(...) collapses in-progress and completed idempotency states into the same boolean result; return distinct states or throw/retry for in-progress so a concurrent notification is not acknowledged as completed`);
      }
    }
  }
}

function collapsesInFlightAndCompleted(body) {
  if (/return\s+[^;]*putIfAbsent\s*\([^;]+(?:==|!=)\s*null\s*;/.test(body)) return true;
  const assigned = body.match(/\b([A-Za-z_][A-Za-z0-9_]*)\s*=\s*[^;]*putIfAbsent\s*\([^;]+;/);
  if (!assigned || !/\breturn\s+(?:true|false)\s*;/.test(body)) return false;
  const previous = escapeRegExp(assigned[1]);
  const distinguishesCompleted = new RegExp(`\\b${previous}\\b\\s*==\\s*(?:[A-Za-z0-9_]+\\.)?(?:DONE|COMPLETED|PROCESSED)\\b`).test(body);
  const rejectsInFlight = /\bthrow\s+new\b/.test(body)
    || /\b(?:PROCESSING|IN_PROGRESS)\b[\s\S]{0,180}\breturn\s+(?:RETRY|FAIL|ERROR)\b/.test(body);
  return !distinguishesCompleted || !rejectsInFlight;
}

function checkJavaProductionMemoryIdempotency(files, errors) {
  for (const file of files) {
    const raw = fs.readFileSync(file, "utf8");
    if (isDemoOrTestSource(file, raw)) continue;
    // 注意：不要求是 Spring Bean。裸 new 的内存幂等存储（例如 handler 内 new XxxStore()
    // 持有 ConcurrentHashMap）同样不可跨实例/重启，必须被拦截。
    if (!/bill|consume|notify|notification|payNo|pay_no|幂等|idempot/i.test(`${path.basename(file)}\n${raw}`)) continue;
    if (!hasMutableInMemoryStateField(raw)) continue;
    errors.push(`${rel(file)}: production notification idempotency uses a process-local Map/Set; use a shared durable store for multi-instance and restart safety, or restrict the in-memory implementation to an explicit demo/test profile`);
  }
}

// fail-closed 默认端口（未配置即抛异常的 Port/Adapter/Gateway 实现）不得标 @Primary：
// @Primary 会让默认失败实现盖过接入方注册的真实实现，导致真实业务永远不生效。
// 正确做法是 @ConditionalOnMissingBean(<Port>.class)，真实实现存在时默认实现自动让位。
function checkJavaFailClosedPortPrimary(files, errors) {
  for (const file of files) {
    const rawWithComments = fs.readFileSync(file, "utf8");
    if (isDemoOrTestSource(file, rawWithComments)) continue;
    // 去注释后判定，避免命中 Javadoc 中提及的 {@code @Primary} 等说明文字。
    const raw = stripJavaComments(rawWithComments);
    if (!/@Primary\b/.test(raw)) continue;
    const failClosed = /NotConfigured|fail[- ]closed|未配置/i.test(raw)
      && /\bthrow\s+new\b/.test(raw);
    const portLike = /\b(?:implements|extends)\b[^\{]*\b[A-Za-z0-9_]*(?:Port|Adapter|Gateway)\b/.test(raw)
      || /\b[A-Za-z0-9_]*(?:Port|Adapter|Gateway)\b/.test(`${path.basename(file)}`);
    if (failClosed && portLike) {
      errors.push(`${rel(file)}: fail-closed default port is annotated @Primary, which overrides any real implementation the integrator registers; use @ConditionalOnMissingBean(<Port>.class) instead so the real implementation wins`);
    }
  }
}

function hasMutableInMemoryStateField(text) {
  for (const match of text.matchAll(/\b(?:Map|ConcurrentMap|ConcurrentHashMap|Set|HashSet)\s*<([^;\n=]+)>\s+([A-Za-z_][A-Za-z0-9_]*)\s*=\s*new\s+(?:ConcurrentHashMap|HashMap|ConcurrentSkipListMap|HashSet|LinkedHashSet)\b/g)) {
    const generic = match[1];
    const name = match[2];
    if (isHandlerRegistryField(name, generic)) continue;
    return true;
  }
  return false;
}

function isHandlerRegistryField(name, generic) {
  return /handler|router|route|dispatch|registry|mapping/i.test(name)
    && /Handler|MsgHandler|MessageHandler|Consumer|Function|Callback/i.test(generic);
}

function isDemoOrTestSource(file, text) {
  const relPath = rel(file).split(path.sep).join("/");
  return /(^|\/)(?:test|tests|demo|demos|examples)(\/|$)/i.test(relPath)
    || hasExplicitDemoOrTestAnnotation(text);
}

function hasExplicitDemoOrTestAnnotation(text) {
  const annotations = text.match(/@(?:(?:[A-Za-z_$][\w$]*\.)*)?(?:Profile|ConditionalOnProperty)\s*\([^)]*\)/g) || [];
  return annotations.some((annotation) => {
    const values = Array.from(annotation.matchAll(/["']([^"']+)["']/g), (match) => match[1]);
    return values.length > 0 && values.every((value) => /(^|[-_.])(?:test|demo)(?:[-_.]|$)/i.test(value));
  });
}

function checkJavaMessageClientStartupFailure(files, errors) {
  for (const file of files) {
    const raw = stripJavaComments(fs.readFileSync(file, "utf8"));
    if (!/AlipayMsgClient/.test(raw) || !/\.connect\s*\(/.test(raw)) continue;
    for (const method of extractMethods(raw)) {
      if (!/\.connect\s*\(/.test(method.body)) continue;
      const catches = catchBodies(method.body);
      if (catches.length && catches.some((body) => !hasSafeConnectFailurePolicy(body))) {
        errors.push(`${rel(file)}: ${method.name}(...) catches initial AlipayMsgClient.connect failure without fail-fast or both retry and health/readiness signaling; do not leave the application running while message intake is unavailable`);
      }
    }
  }
}

function catchBodies(body) {
  const result = [];
  for (const match of body.matchAll(/\bcatch\s*\([^)]*\)\s*\{/g)) {
    const open = match.index + match[0].length - 1;
    const close = findMatchingBrace(body, open);
    if (close > open) result.push(body.slice(open + 1, close));
  }
  return result;
}

function hasSafeConnectFailurePolicy(body) {
  const failsFast = /\bthrow\b|System\s*\.\s*exit\s*\(|SpringApplication\s*\.\s*exit\s*\(|Runtime\s*\.\s*getRuntime\s*\(\s*\)\s*\.\s*halt\s*\(/.test(body);
  const retries = /\b(?:retry|reconnect|backoff|reschedule|schedule|connectAsync)\b|\.connect\s*\(/i.test(body);
  const signalsHealth = /\b(?:health|readiness|availability|liveness)\b|REFUSING_TRAFFIC|\bDOWN\b|setConnected\s*\(\s*false\s*\)|mark[A-Za-z0-9_]*(?:Unavailable|Down)/i.test(body);
  return failsFast || retries && signalsHealth;
}

function extractMethods(text) {
  const methods = [];
  const pattern = /\b(?:public|private|protected)\s+(?:static\s+)?[A-Za-z0-9_<>, ?\[\]]+\s+([A-Za-z0-9_]+)\s*\(([^)]*)\)\s*(?:throws\s+[^{]+)?\{/g;
  for (const m of text.matchAll(pattern)) {
    const open = m.index + m[0].length - 1;
    const close = findMatchingBrace(text, open);
    if (close < 0) continue;
    methods.push({ name: m[1], body: text.slice(open, close + 1) });
  }
  return methods;
}

function findMatchingBrace(text, open) {
  // 字符串中的 JSON 大括号和注释中的示例代码不能结束 Java 方法体。
  let depth = 0;
  let quote = null;
  let escaped = false;
  let lineComment = false;
  let blockComment = false;
  for (let i = open; i < text.length; i++) {
    const ch = text[i];
    const next = text[i + 1];

    if (lineComment) {
      if (ch === "\n") lineComment = false;
      continue;
    }
    if (blockComment) {
      if (ch === "*" && next === "/") {
        blockComment = false;
        i++;
      }
      continue;
    }
    if (quote) {
      if (escaped) {
        escaped = false;
      } else if (ch === "\\") {
        escaped = true;
      } else if (ch === quote) {
        quote = null;
      }
      continue;
    }

    if (ch === "/" && next === "/") {
      lineComment = true;
      i++;
      continue;
    }
    if (ch === "/" && next === "*") {
      blockComment = true;
      i++;
      continue;
    }
    if (ch === "\"" || ch === "'" || ch === "`") {
      quote = ch;
      continue;
    }

    if (ch === "{") depth++;
    else if (ch === "}") {
      depth--;
      if (depth === 0) return i;
    }
  }
  return -1;
}

function checkEnums(text, projectText, docs, errors) {
  const allowed = new Set();
  for (const doc of docs) {
    const s = fs.readFileSync(path.join(skillDir, doc), "utf8");
    for (const m of s.matchAll(/\b[A-Z][A-Z0-9_]{2,}\b/g)) allowed.add(m[0]);
  }
  const constants = extractStringConstants(`${projectText}\n${text}`);
  for (const m of text.matchAll(/case\s+([^:\n]+)\s*:([\s\S]{0,240})/g)) {
    if (!/(pay_no|consume|expense_type|bill|Bill|Consume)/.test(m[2])) continue;
    const value = resolveStringArg(m[1], constants);
    if (value && /^[A-Z][A-Z0-9_]+$/.test(value) && !allowed.has(value)) {
      errors.push(`enum case not found in bill docs: ${value}`);
    }
  }
}

function checkSdkStubs(files, errors) {
  const sdkPath = `${path.sep}src${path.sep}main${path.sep}java${path.sep}com${path.sep}alipay${path.sep}api${path.sep}`;
  const offenders = [];
  for (const file of files) {
    const text = fs.readFileSync(file, "utf8");
    if (file.includes(sdkPath) || /^\s*package\s+com\.alipay\.api(\.|;)/m.test(text) || /Stub implementation for compilation purposes/.test(text)) {
      offenders.push(rel(file));
    }
  }
  if (offenders.length) {
    const sample = offenders.slice(0, 8).join(", ");
    const suffix = offenders.length > 8 ? `, ... ${offenders.length - 8} more` : "";
    errors.push(`generated code must not define local Alipay SDK stubs or shadow com.alipay.api classes; remove ${offenders.length} offending files and use the official alipay-sdk-java dependency: ${sample}${suffix}`);
  }
}

function checkSdkReflectionBypass(files, errors) {
  for (const file of files) {
    const text = stripJavaComments(fs.readFileSync(file, "utf8"));
    const sdkRelevant = /com\.alipay\.api|Alipay[A-Za-z0-9_]*(?:Request|Response|Model)|alipayClient\s*\.\s*execute/.test(text);
    const reflectionBypass = /java\.lang\.reflect|\.getClass\s*\(\s*\)|\.getMethod\s*\(|\.invoke\s*\(|BeanUtils|PropertyUtils/.test(text);
    if (sdkRelevant && reflectionBypass) {
      errors.push(`${rel(file)}: generated Java must not use reflection/BeanUtils to bypass official SDK Request/Model/Response compile-time types; inspect the SDK jar with jar tf or javap and use real getters/setters`);
    }
  }
}

function checkPackagePaths(files, errors) {
  const src = `${path.sep}src${path.sep}main${path.sep}java${path.sep}`;
  for (const file of files) {
    const text = fs.readFileSync(file, "utf8");
    const m = text.match(/^\s*package\s+([a-zA-Z0-9_.]+)\s*;/m);
    if (!m || !file.includes(src)) continue;
    const expected = path.dirname(file).slice(file.indexOf(src) + src.length).split(path.sep).join(".");
    if (m[1] !== expected) errors.push(`${rel(file)}: package ${m[1]} does not match path ${expected}`);
  }
}

function walk(dir) {
  return fs.readdirSync(dir, { withFileTypes: true }).flatMap((entry) => {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory() && shouldSkipDir(entry.name)) return [];
    return entry.isDirectory() ? walk(full) : [full];
  });
}

function shouldSkipDir(name) {
  return new Set([".git", ".idea", ".codefuse", "node_modules", "target", "dist", "build", "coverage", "vendor", "bin", "obj", "__pycache__", ".venv", "venv"]).has(name);
}

function toSetter(field) {
  return `set${field.split("_").map((p) => p ? p[0].toUpperCase() + p.slice(1) : "").join("")}`;
}

function isRequired(value) {
  return /^(必须|必选)$/.test(value);
}

function escapeRegExp(value) {
  return value.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

function rel(file) { return path.relative(targetDir, file); }

function report(name, errors, warnings) {
  for (const w of warnings) console.warn(`[${name}] WARN ${w}`);
  if (errors.length) {
    for (const e of errors) console.error(`[${name}] ERROR ${e}`);
    process.exit(1);
  }
  console.log(`[${name}] OK`);
}

function fail(msg) {
  console.error(`[alipay-enterprise-bill] ERROR ${msg}`);
  process.exit(1);
}
