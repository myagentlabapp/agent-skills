#!/usr/bin/env node
"use strict";

const assert = require("assert");
const fs = require("fs");
const os = require("os");
const path = require("path");
const { spawnSync } = require("child_process");

const skillDir = path.resolve(__dirname, "..");
const scriptsDir = path.join(skillDir, "scripts");
const validator = path.join(scriptsDir, "validate_codegen.js");
const runtime = path.join(scriptsDir, "lib", "validator-runtime.js");
const resolver = require(path.join(scriptsDir, "lib", "value-resolver.js"));
const javaProjectGates = require(path.join(scriptsDir, "lib", "java-project-gates.js"));

testRuntime();
testMissingSupportIsBroken();
testValueResolver();
require("./java-project-gates.test").run(javaProjectGates);
testFixtures();
testRawBizContentDomainBoundary();
testRelatedResponseProjection();
testFailClosedBusinessBehavior();
testFailClosedUnsupportedOperationBoundary();
testNotificationIdempotencyStates();
testIntegrationContract();
console.log("[alipay-enterprise-bill tests] OK");

function testRuntime() {
  const ok = runNode(["-e", `require(${JSON.stringify(runtime)}).runGuarded("test", () => {})`]);
  assert.strictEqual(ok.status, 0, output(ok));

  const broken = runNode(["-e", `require(${JSON.stringify(runtime)}).runGuarded("test", () => { throw new ReferenceError("missing"); })`]);
  assert.strictEqual(broken.status, 2, output(broken));
  assert.match(output(broken), /\[test\] BROKEN/);
}

function testMissingSupportIsBroken() {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), "alipay-bill-broken-"));
  const isolatedValidator = path.join(dir, "validate_codegen.js");
  fs.copyFileSync(validator, isolatedValidator);
  const result = runNode([isolatedValidator, path.join(__dirname, "fixtures", "valid")]);
  assert.strictEqual(result.status, 2, output(result));
  assert.match(output(result), /BROKEN failed to load validator support/);
}

function testValueResolver() {
  const text = [
    "const EXPENSE_TYPE_TICKET = \"TICKET\";",
    "const BILL_NOTIFY = 'alipay.commerce.ec.consume.change.notify';",
  ].join("\n");
  const constants = resolver.extractStringConstants(text);
  assert.strictEqual(resolver.resolveStringArg("BillConstants.EXPENSE_TYPE_TICKET", constants), "TICKET");
  assert.deepStrictEqual(resolver.valueTokens(text, "alipay.commerce.ec.consume.change.notify"), ["alipay.commerce.ec.consume.change.notify", "BILL_NOTIFY"]);
}

function testFixtures() {
  assertExit(path.join(__dirname, "fixtures", "valid"), 0);
  assertExit(path.join(__dirname, "fixtures", "invalid"), 1);
}

function testRawBizContentDomainBoundary() {
  const foreignDir = fs.mkdtempSync(path.join(os.tmpdir(), "alipay-bill-foreign-biz-content-"));
  fs.writeFileSync(path.join(foreignDir, "EnterpriseOpenRuleService.java"), [
    "class EnterpriseOpenRuleService {",
    "  String billScope;",
    "  void create(String json) {",
    "    AlipayEbppInvoiceEnterpriseconsumeEnterpriseopenruleCreateRequest request = newRequest();",
    "    request.setBizContent(json);",
    "  }",
    "}",
  ].join("\n"));
  assert.doesNotMatch(output(runNode([validator, foreignDir])), /must not hand-build biz_content/);

  const ownedDir = fs.mkdtempSync(path.join(os.tmpdir(), "alipay-bill-owned-biz-content-"));
  fs.writeFileSync(path.join(ownedDir, "BillQueryService.java"), [
    "class BillQueryService {",
    "  public void query(String json) {",
    "    AlipayCommerceEcConsumeDetailQueryRequest request = newRequest();",
    "    request.setBizContent(json);",
    "  }",
    "}",
  ].join("\n"));
  assert.match(output(runNode([validator, ownedDir])), /must not hand-build biz_content/);
}

function testRelatedResponseProjection() {
  const invalidDir = fs.mkdtempSync(path.join(os.tmpdir(), "alipay-bill-related-response-"));
  fs.writeFileSync(path.join(invalidDir, "TicketBillService.java"), [
    "class TicketBillService {",
    "  void handle() {",
    "    queryByPayNo(\"enterprise\", \"payNo\", Collections.singletonList(\"Ticket\"));",
    "  }",
    "  void queryByPayNo(String enterpriseId, String payNo, List<String> queryOptions) {",
    "    AlipayCommerceEcConsumeDetailQueryModel model = new AlipayCommerceEcConsumeDetailQueryModel();",
    "    model.setEnterpriseId(enterpriseId);",
    "    model.setPayNo(payNo);",
    "    model.setQueryOptions(queryOptions);",
    "    response.getConsumeInfo();",
    "  }",
    "}",
  ].join("\n"));
  assert.match(output(runNode([validator, invalidDir])), /never reads or projects related_voucher_list/);

  const validDir = fs.mkdtempSync(path.join(os.tmpdir(), "alipay-bill-related-response-"));
  fs.writeFileSync(path.join(validDir, "TicketBillService.java"), fs.readFileSync(path.join(invalidDir, "TicketBillService.java"), "utf8")
    .replace("response.getConsumeInfo();", "response.getConsumeInfo(); detail.setVouchers(response.getRelatedVoucherList());"));
  assert.doesNotMatch(output(runNode([validator, validDir])), /never reads or projects related_voucher_list/);
}

function testFailClosedBusinessBehavior() {
  const failOpenDir = fs.mkdtempSync(path.join(os.tmpdir(), "alipay-bill-fail-open-"));
  fs.writeFileSync(path.join(failOpenDir, "BillNotificationService.java"), [
    "class BillNotificationService {",
    "  static final String METHOD = \"alipay.commerce.ec.consume.change.notify\";",
    "  private void persistBill(String payNo) {",
    "    System.out.println(payNo);",
    "  }",
    "}",
  ].join("\n"));
  const failOpen = runNode([validator, failOpenDir]);
  assert.strictEqual(failOpen.status, 1, output(failOpen));
  assert.match(output(failOpen), /fail-open bill business hook/);

  const failClosedDir = fs.mkdtempSync(path.join(os.tmpdir(), "alipay-bill-fail-closed-"));
  fs.writeFileSync(path.join(failClosedDir, "BillNotificationService.java"), [
    "class BillNotificationService {",
    "  static final String METHOD = \"alipay.commerce.ec.consume.change.notify\";",
    "  private void persistBill(String payNo) {",
    "    throw new IllegalStateException(\"bill persistence port is not configured\");",
    "  }",
    "}",
  ].join("\n"));
  const failClosed = runNode([validator, failClosedDir]);
  assert.doesNotMatch(output(failClosed), /fail-open bill business hook/);
}

function testFailClosedUnsupportedOperationBoundary() {
  const allowedDir = fs.mkdtempSync(path.join(os.tmpdir(), "alipay-bill-fail-closed-uoe-"));
  fs.writeFileSync(path.join(allowedDir, "FailClosedBillPersistencePort.java"), [
    "class FailClosedBillPersistencePort {",
    "  public void saveBill() {",
    "    throw new UnsupportedOperationException(\"BillPersistencePort not configured; fail-closed\");",
    "  }",
    "}",
  ].join("\n"));
  assert.doesNotMatch(output(runNode([validator, allowedDir])), /stub implementation in saveBill/);

  const stubDir = fs.mkdtempSync(path.join(os.tmpdir(), "alipay-bill-uoe-stub-"));
  fs.writeFileSync(path.join(stubDir, "BillQueryService.java"), [
    "class BillQueryService {",
    "  public void queryBill() {",
    "    throw new UnsupportedOperationException(\"later\");",
    "  }",
    "}",
  ].join("\n"));
  assert.match(output(runNode([validator, stubDir])), /stub implementation in queryBill/);
}

function testNotificationIdempotencyStates() {
  const unsafeDir = fs.mkdtempSync(path.join(os.tmpdir(), "alipay-bill-idempotency-unsafe-"));
  const unsafeFile = path.join(unsafeDir, "src", "main", "java", "com", "example", "app", "bill", "ProcessedStore.java");
  fs.mkdirSync(path.dirname(unsafeFile), { recursive: true });
  fs.writeFileSync(unsafeFile, [
    "@Repository",
    "class ProcessedStore {",
    "  enum State { PROCESSING, DONE }",
    "  private final Map<String, State> states = new ConcurrentHashMap<>();",
    "  public boolean tryAcquire(String payNo) {",
    "    return states.putIfAbsent(payNo, State.PROCESSING) == null;",
    "  }",
    "}",
  ].join("\n"));
  const unsafe = output(runNode([validator, unsafeDir]));
  assert.match(unsafe, /collapses in-progress and completed idempotency states/);
  assert.match(unsafe, /production notification idempotency uses a process-local Map\/Set/);

  const safeDir = fs.mkdtempSync(path.join(os.tmpdir(), "alipay-bill-idempotency-safe-"));
  fs.writeFileSync(path.join(safeDir, "BillNotifyStore.java"), [
    "@Profile(\"demo\")",
    "@Repository",
    "class BillNotifyStore {",
    "  enum State { PROCESSING, DONE }",
    "  private final Map<String, State> states = new ConcurrentHashMap<>();",
    "  public boolean tryAcquire(String payNo) {",
    "    State previous = states.putIfAbsent(payNo, State.PROCESSING);",
    "    if (previous == null) return true;",
    "    if (previous == State.DONE) return false;",
    "    throw new IllegalStateException(\"bill notification is processing; retry\");",
    "  }",
    "}",
  ].join("\n"));
  const safe = output(runNode([validator, safeDir]));
  assert.doesNotMatch(safe, /collapses in-progress and completed idempotency states/);
  assert.doesNotMatch(safe, /production notification idempotency uses a process-local Map\/Set/);

  const routerDir = fs.mkdtempSync(path.join(os.tmpdir(), "alipay-bill-router-registry-"));
  const routerFile = path.join(routerDir, "MessageRouterHandler.java");
  fs.writeFileSync(routerFile, [
    "class MessageRouterHandler {",
    "  private final Map<String, DomainMessageHandler> handlers = new ConcurrentHashMap<>();",
    "  public void register(String msgMethod, DomainMessageHandler handler) {",
    "    handlers.put(msgMethod, handler);",
    "  }",
    "}",
    "interface DomainMessageHandler {}",
  ].join("\n"));
  const router = output(runNode([validator, routerDir]));
  assert.doesNotMatch(router, /production notification idempotency uses a process-local Map\/Set/);
}

function testIntegrationContract() {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), "alipay-bill-contract-"));
  copyDir(path.join(__dirname, "fixtures", "valid"), dir);
  const meta = path.join(dir, ".alipay-skill");
  fs.mkdirSync(meta, { recursive: true });
  const contract = {
    schemaVersion: 1,
    projectMode: "existing",
    domains: {
      bill: {
        status: "CONFIRMED",
        joinPoints: [{
          capability: "consume.change",
          status: "CONFIRMED",
          strategy: "service",
          evidenceFiles: ["bill_service.py"],
          symbols: ["handle_bill_notification"],
        }],
        changes: [{ path: "bill_service.py", action: "reuse" }],
      },
    },
    gaps: [],
  };
  fs.writeFileSync(path.join(meta, "integration-contract.json"), JSON.stringify(contract, null, 2));
  assertExit(dir, 0, { ALIPAY_PROJECT_MODE: "existing" });
  contract.projectMode = "greenfield";
  fs.writeFileSync(path.join(meta, "integration-contract.json"), JSON.stringify(contract, null, 2));
  assertExit(dir, 1, { ALIPAY_PROJECT_MODE: "existing" });
  contract.projectMode = "existing";
  contract.domains.bill.joinPoints[0].symbols = ["MissingBillHandler"];
  fs.writeFileSync(path.join(meta, "integration-contract.json"), JSON.stringify(contract, null, 2));
  assertExit(dir, 1, { ALIPAY_PROJECT_MODE: "existing" });
}

function assertExit(target, expected, extraEnv = {}) {
  const result = runNode([validator, target], extraEnv);
  assert.strictEqual(result.status, expected, output(result));
}

function runNode(args, extraEnv = {}) {
  return spawnSync(process.execPath, args, {
    encoding: "utf8",
    env: Object.assign({}, process.env, extraEnv),
  });
}

function output(result) {
  return `${result.stdout || ""}\n${result.stderr || ""}`.trim();
}

function copyDir(from, to) {
  for (const entry of fs.readdirSync(from, { withFileTypes: true })) {
    const source = path.join(from, entry.name);
    const target = path.join(to, entry.name);
    if (entry.isDirectory()) {
      fs.mkdirSync(target, { recursive: true });
      copyDir(source, target);
    } else {
      fs.copyFileSync(source, target);
    }
  }
}
