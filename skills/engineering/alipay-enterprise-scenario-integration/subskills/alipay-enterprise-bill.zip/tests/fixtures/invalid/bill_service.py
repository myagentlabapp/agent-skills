DETAIL_METHOD = "alipay.commerce.ec.consume.detail.query"
NOTIFY_METHOD = "alipay.commerce.ec.consume.change.notify"


def handle_bill_notification(pay_no):
    return {"method": NOTIFY_METHOD, "pay_no": pay_no}
