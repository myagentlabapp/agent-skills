# 账单 Node.js 质量门禁

本文件只约束 Node.js 生成代码。通用原则见 [账单通用代码生成规则](../codegen-general-rules.md)，字段和接口来源见 [账单字段和接口规则](../field-interface-rules.md)。

1. 必须读取真实安装的 `alipay-sdk` 导出形态。CommonJS 使用 `const { AlipaySdk } = require("alipay-sdk")`；不得写 `require("alipay-sdk").default`。
2. OpenAPI 2.0 `alipaySdk.exec(method, params, options)` 中，`appAuthToken` 必须作为第二个参数里的网关通参参与签名，例如 `exec(method, { bizContent, appAuthToken })`。
3. HTTP(S) 账单通知验签必须使用 SDK `checkNotifySign` / `checkNotifySignV2`，不得手写 `crypto.createVerify` 拼接验签串。
4. HTTP(S) 通知验签 helper 如果是 `async`，调用方必须 `await`；否则会把 Promise 当成验签通过。
5. `bizContent` 字段必须来自对应接口 Markdown 的“业务请求参数”表；发送请求前必须保证无条件必填字段已校验并赋值，条件必填字段按文档“必选条件”校验。
6. 推模式必须覆盖账单变动通知、单笔账单详情查询和批量账单详情查询；账单响应解析不得把响应字段反写到请求参数。
7. 账单通知幂等必须使用通知文档中的唯一业务键，消费账单默认使用 `pay_no`；只有业务处理成功后才能标记为已处理，如果先占位锁定，失败路径必须释放或标记为可重试。
8. 账单通知遇到未知 `msg_method` 或未知 `consume_type` 时，默认必须返回 `fail` 或由显式 unknown handler 返回处理结果；不得无处理地返回 `success`。
9. 生成后必须通过 `node --check`、模块加载和 `npm test`；测试脚本存在但失败时不得宣布生成完成。
10. 不得生成 SDK stub、固定成功返回、空验签或本地模拟接口来绕过 SDK 能力缺失。
