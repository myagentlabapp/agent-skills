# alipay.ebpp.invoice.ecorder.order.changed

## 公共请求参数

| 参数 | 类型 | 是否必选 | 最大长度 | 描述 | 示例值 |
| :--- | :--- | :--- | :--- | :--- | :--- |
| notify_id | String | 必选 | 50 | 通知ID | 5608cccc09ddb39d41c2e3c06e3d9fejh2 |
| utc_timestamp | String | 必选 | 13 | 消息发送时的服务端时间 | 1514210452731 |
| msg_method | String | 必选 | 100 | 消息接口名称 | alipay.ebpp.invoice.ecorder.order.changed |
| app_id | String | 必选 | 20 | 消息接受方的应用id | 2014060600164699 |
| version | String | 必选 | 5 | 版本号(1.1版本为标准消息) | 1.0或者1.1 |
| biz_content | String | 必选 | | 消息报文 | 参见消息属性 |
| sign | String | 必选 | | 签名 | WcO+t3D8Kg71dTlKwN7r9PzUOXeaBJwp8/FOuSxcuSkXsoVYxBpsAidprySCjHCjmaglNcjoKJQLJ28/Asl93joTW39FX6i07lXhnbPknezAlwmvPdnQuI01HZsZF9V1i6ggZjBiAd5lG8bZtTxZOJ87ub2i9GuJ3Nr/NUc9VeY= |
| sign_type | String | 必选 | 10 | 签名类型 | RSA2 |
| charset | String | 必选 | 10 | 编码集，该字符集为验签和解密所需要的字符集 | UTF-8 |

## 消息属性

| 参数英文名 | 类型 | 是否必选 | 长度/取值 | 描述 | 示例值 |
|---|---|---|---|---|---|
| account_id | String | 必选 | 32 | 共同账户ID | 2088000000000000 |
| order_id | String | 必选 | 32 | 订单ID | 2020103022000000000000000000 |
| order_type | String | 必选 | 64 | 订单类型<br>更多类型查看[费用类型枚举](../../common/expense-type-enum.md)里的费用子类型 | METRO |
| pay_no | String | 必选 | 128 | 关联支付宝交易号 | 2020103022000000000000000000 |
| biz_out_no | String | 必选 | 128 | 外部业务号 | 1234567890 |
| partner_id | String | 必选 | 32 | 合作伙伴ID | 2213221384399593 |
| gmt_create | String | 必选 | 32 | 创建时间 | 2022-01-01 00:00:00 |
| gmt_modified | String | 必选 | 32 | 修改时间 | 2022-01-01 00:00:00 |
| notify_reason | String | 必选 | 64 | 通知原因<br>**枚举值**：订单归集: ORDER_COLLECT<br>订单更新: ORDER_UPDATE<br>订单退款: ORDER_REFUND | ORDER_COLLECT |
| ext_info | String | 必选 | 1024 | 扩展信息，JSON格式<br>包含：expenseRuleGroupId（费控规则ID）、expense_scene_code（费用场景）、expense_type（费用类型）、expense_type_sub_category（费用类型子类目） | {"expense_scene_code": "","expenseRuleGroupId": "","expense_type": "","expense_type_sub_category": ""} |
| user_id | String | 特殊可选 | 32 | 用户支付宝UID<br>新商户建议使用open_id替代该字段 | 20880000000000000 |
| open_id | String | 特殊可选 | 128 | 用户支付宝UID | 074a1CcTG1LelxKe4xQC0zgNdId0nxi95b5lsNpazWYoCo5 |
| enterprise_id | String | 可选 | 32 | 企业ID | 2088000351583735 |
| employee_id | String | 可选 | 32 | 员工ID | 2284000351583735 |

**注意**：user_id 和 open_id 二选一传入

### 消息示例

```bash
curl -X POST 'NOTIFY_URL' \
--header 'Content-Type: application/x-www-form-urlencoded; charset=UTF-8' \
--data-urlencode 'charset=UTF-8' \
--data-urlencode 'biz_content={
	"gmt_create":"2022-01-01 00:00:00",
	"biz_out_no":"1234567890",
	"notify_reason":"ORDER_COLLECT",
	"open_id":"074a1CcTG1LelxKe4xQC0zgNdId0nxi95b5lsNpazWYoCo5",
	"enterprise_id":"2088000351583735",
	"gmt_modified":"2022-01-01 00:00:00",
	"ext_info":"{\"expense_scene_code\": \",\"expenseRuleGroupId\": \",\"expense_type\": \",\"expense_type_sub_category\": \",}",
	"account_id":"2088000000000000",
	"partner_id":"2213221384399593",
	"user_id":"20880000000000000",
	"pay_no":"2020103022000000000000000000",
	"employee_id":"2284000351583735",
	"order_id":"2020103022000000000000000000",
	"order_type":"METRO"
}' \
--data-urlencode 'utc_timestamp=${now}' \
--data-urlencode 'sign=${sign}' \
--data-urlencode 'app_id=${appid}' \
--data-urlencode 'version=1.1' \
--data-urlencode 'sign_type=RSA2' \
--data-urlencode 'notify_id=${notify_id}' \
--data-urlencode 'msg_method=alipay.ebpp.invoice.ecorder.order.changed'
```

**说明：** NOTIFY_URL是开发者在开放平台控制台上设置的应用网关地址

## 通知应答

| 响应报文 | 描述 | 是否重试 | 是否区分大小写 |
| :--- | :--- | :--- | :--- |
| success | 消息处理成功 | 否 | 否 |
| fail | 消息处理失败 | 是 | 否 |

说明：消息服务会根据响应报文判断商户系统是否已经成功处理消息。如果HTTP同步响应报文返回 success 字符串，消息服务则认为消息已经处理成功，停止投递，如果返回 fail ，表示消息获取失败，支付宝会根据投递重试策略重新发送消息到应用网关地址；

投递重试策略：一般情况下，25 小时以内完成 8 次通知，除了第一次是实时投递外，后续的每次重试都会间隔一段时间，间隔频率一般是：2m、10m、10m、1h、2h、6h、15h（第二次消息投递是在第一次投递失败后的 2 分钟；第三次投递是在第二次投递失败后的 10 分钟，以此类推）
