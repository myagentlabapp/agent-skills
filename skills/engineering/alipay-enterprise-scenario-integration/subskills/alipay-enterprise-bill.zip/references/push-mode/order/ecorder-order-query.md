# alipay.ebpp.invoice.ecorder.order.query(企业码订单查询)
支持第三方代理调用：本接口支持第三方开发者代用户发起调用
## 通用场景
企业码订单查询
注意：【调用条件】：无【返回约束】：无【其他】：无
### 公共请求参数
|参数英文名|类型|是否必选|长度/取值|描述|示例值|
|---|---|---|---|---|---|
|app_id|String|必选|32|支付宝分配给开发者的应用ID|2014072300007148|
|method|String|必选|128|接口名称|alipay.ebpp.invoice.ecorder.order.query|
|format|String|可选|40|仅支持JSON|JSON|
|charset|String|必选|10|请求使用的编码格式，如utf-8,gbk,gb2312等|utf-8|
|sign_type|String|必选|10|商户生成签名字符串所使用的签名算法类型，目前支持RSA2和RSA，推荐使用RSA2|RSA2|
|sign|String|必选|344|商户请求参数的签名串，详见[签名](https://opendocs.alipay.com/common/02khjm)|详见示例|
|timestamp|String|必选|19|发送请求的时间，格式"yyyy-MM-dd HH:mm:ss"|2014-07-24 03:07:50|
|version|String|必选|3|调用的接口版本，固定为：1.0|1.0|
|app_auth_token|String|可选|40|详见[应用授权概述](https://opendocs.alipay.com/isv/10467/xldcyq)||
|biz_content|String|必选||请求参数的集合，最大长度不限，除公共参数外所有请求参数都必须放在这个参数中传递，具体参照各产品快速接入文档||
### 业务请求参数
|参数英文名|类型|是否必选|长度/取值|描述|示例值|
|---|---|---|---|---|---|
|enterprise_id|String|特殊可选|32|企业ID**注意事项**enterprise_id和[account_id, agreement_id]具有依赖关系：当[account_id, agreement_id]都有值时，enterprise_id可选；当[account_id, agreement_id]同时为空时，enterprise_id必填；account_id和agreement_id必须同时有值或没值|2088501296144291|
|account_id|String|特殊可选|32|共同账户ID**注意事项**enterprise_id和[account_id, agreement_id]具有依赖关系：当[account_id, agreement_id]都有值时，enterprise_id可选；当[account_id, agreement_id]同时为空时，enterprise_id必填；account_id和agreement_id必须同时有值或没值|2088000000000000|
|agreement_no|String|特殊可选|64|授权签约协议号**注意事项**enterprise_id和[account_id, agreement_id]具有依赖关系：当[account_id, agreement_id]都有值时，enterprise_id可选；当[account_id, agreement_id]同时为空时，enterprise_id必填；account_id和agreement_id必须同时有值或没值|20200000000000000000|
|order_id|String|必须|32|订单ID|2020103022000000000000000000|
|order_type|String|必须|64|订单类型**枚举值**地铁:METRO公交:BUS外卖:TAKE_AWAY快递:ONLINE_EXPRESS到店:REACH_SHOP团餐:GROUP_BUY_MEAL其他:OTHER票务:TICKET用车:CAR在线订酒店:ONLINE_HOTEL在线订火车票:ONLINE_TRAIN在线订机票:ONLINE_PLANE|METRO|
### 请求示例
#### 默认示例
##### java
```
 package com.java.sdk.demo;

import com.alipay.api.AlipayApiException;
import com.alipay.api.AlipayClient;
import com.alipay.api.DefaultAlipayClient;
import com.alipay.api.AlipayConfig;
import com.alipay.api.response.AlipayEbppInvoiceEcorderOrderQueryResponse;
import com.alipay.api.domain.AlipayEbppInvoiceEcorderOrderQueryModel;
import com.alipay.api.request.AlipayEbppInvoiceEcorderOrderQueryRequest;

import com.alipay.api.FileItem;
import java.util.Base64;
import java.util.ArrayList;
import java.util.List;

public class AlipayEbppInvoiceEcorderOrderQuery {

    public static void main(String[] args) throws AlipayApiException {
        // 初始化SDK
        AlipayClient alipayClient = new DefaultAlipayClient(getAlipayConfig());

        // 构造请求参数以调用接口
        AlipayEbppInvoiceEcorderOrderQueryRequest request = new AlipayEbppInvoiceEcorderOrderQueryRequest();
        AlipayEbppInvoiceEcorderOrderQueryModel model = new AlipayEbppInvoiceEcorderOrderQueryModel();
        
        // 设置企业ID
        model.setEnterpriseId("2088501296144291");
        
        // 设置共同账户ID
        model.setAccountId("2088000000000000");
        
        // 设置授权签约协议号
        model.setAgreementNo("20200000000000000000");
        
        // 设置订单ID
        model.setOrderId("2020103022000000000000000000");
        
        // 设置订单类型
        model.setOrderType("METRO");
        
        request.setBizModel(model);
        // 第三方代调用模式下请设置app_auth_token
        // request.putOtherTextParam("app_auth_token", "<-- 请填写应用授权令牌 -->");

        AlipayEbppInvoiceEcorderOrderQueryResponse response = alipayClient.execute(request);
        System.out.println(response.getBody());

        if (response.isSuccess()) {
            System.out.println("调用成功");
        } else {
            System.out.println("调用失败");
            // sdk版本是"4.38.0.ALL"及以上,可以参考下面的示例获取诊断链接
            // String diagnosisUrl = DiagnosisUtils.getDiagnosisUrl(response);
            // System.out.println(diagnosisUrl);
        }
    }

    private static AlipayConfig getAlipayConfig() {
        String privateKey  = "<-- 请填写您的应用私钥，例如：MIIEvQIBADANB ... ... -->";
        String alipayPublicKey = "<-- 请填写您的支付宝公钥，例如：MIIBIjANBg... -->";
        AlipayConfig alipayConfig = new AlipayConfig();
        alipayConfig.setServerUrl("https://openapi.alipay.com/gateway.do");
        alipayConfig.setAppId("<-- 请填写您的AppId，例如：2019091767145019 -->");
        alipayConfig.setPrivateKey(privateKey);
        alipayConfig.setFormat("json");
        alipayConfig.setAlipayPublicKey(alipayPublicKey);
        alipayConfig.setCharset("UTF-8");
        alipayConfig.setSignType("RSA2");
        return alipayConfig;
    }
}
```
 

##### php
```
 <?php
require_once '../aop/AopClient.php';
require_once '../aop/AopCertClient.php';
require_once '../aop/AopCertification.php';
require_once '../aop/AlipayConfig.php';
require_once '../aop/request/AlipayEbppInvoiceEcorderOrderQueryRequest.php';

// 初始化SDK
$alipayClient = new AopClient(getAlipayConfig());
// 构造请求参数以调用接口
$request = new AlipayEbppInvoiceEcorderOrderQueryRequest();
$model = array();

// 设置企业ID
$model['enterprise_id'] = "2088501296144291";

// 设置共同账户ID
$model['account_id'] = "2088000000000000";

// 设置授权签约协议号
$model['agreement_no'] = "20200000000000000000";

// 设置订单ID
$model['order_id'] = "2020103022000000000000000000";

// 设置订单类型
$model['order_type'] = "METRO";

$request->setBizContent(json_encode($model,JSON_UNESCAPED_UNICODE));
// 如果是第三方代调用模式，请设置app_auth_token（应用授权令牌）
$responseResult = $alipayClient->execute($request, null, "<-- 请填写应用授权令牌 -->", null);
$responseApiName = str_replace(".","_",$request->getApiMethodName())."_response";
$response = $responseResult->$responseApiName;
if(!empty($response->code)&&$response->code==10000){
    echo("调用成功");
}
else{
    echo("调用失败");
}

function getAlipayConfig()
{
    $privateKey  = '<-- 请填写您的应用私钥，例如：MIIEvQIBADANB ... ... -->';
    $alipayPublicKey = '<-- 请填写您的支付宝公钥，例如：MIIBIjANBg... -->';
    $alipayConfig = new AlipayConfig();
    $alipayConfig->setServerUrl('https://openapi.alipay.com/gateway.do');
    $alipayConfig->setAppId('<-- 请填写您的AppId，例如：2019091767145019 -->');
    $alipayConfig->setPrivateKey($privateKey);
    $alipayConfig->setFormat('json');
    $alipayConfig->setAlipayPublicKey($alipayPublicKey);
    $alipayConfig->setCharset('UTF-8');
    $alipayConfig->setSignType('RSA2');
    return $alipayConfig;
}
```
 

##### csharp
```
 using System;
using System.Collections.Generic;
using Aop.Api;
using Aop.Api.Request;
using Aop.Api.Response;
using Aop.Api.Domain;
using Aop.Api.Util;
namespace SdkDemoTest
{
    public class AlipayEbppInvoiceEcorderOrderQuery
    {
        public static void Main(string[] args) 
        {
            // 初始化SDK
            IAopClient alipayClient = new DefaultAopClient(GetAlipayConfig());
            // 构造请求参数以调用接口
            AlipayEbppInvoiceEcorderOrderQueryRequest request = new AlipayEbppInvoiceEcorderOrderQueryRequest();
            AlipayEbppInvoiceEcorderOrderQueryModel model = new AlipayEbppInvoiceEcorderOrderQueryModel();
            
            // 设置企业ID
            model.EnterpriseId = "2088501296144291";
            
            // 设置共同账户ID
            model.AccountId = "2088000000000000";
            
            // 设置授权签约协议号
            model.AgreementNo = "20200000000000000000";
            
            // 设置订单ID
            model.OrderId = "2020103022000000000000000000";
            
            // 设置订单类型
            model.OrderType = "METRO";
            
            request.SetBizModel(model);
            // 第三方代调用模式下请设置app_auth_token
            // request.PutOtherTextParam("app_auth_token", "<-- 请填写应用授权令牌 -->");

            AlipayEbppInvoiceEcorderOrderQueryResponse response = alipayClient.Execute(request);

            if(!response.IsError)
            {
                Console.WriteLine("调用成功");
            }
            else
            {
                Console.WriteLine("调用失败");
            }
        }

        private static AlipayConfig GetAlipayConfig()
        {
            string privateKey  = "<-- 请填写您的应用私钥，例如：MIIEvQIBADANB ... ... -->";
            string alipayPublicKey = "<-- 请填写您的支付宝公钥，例如：MIIBIjANBg... -->";
            AlipayConfig alipayConfig = new AlipayConfig();
            alipayConfig.ServerUrl = "https://openapi.alipay.com/gateway.do";
            alipayConfig.AppId = "<-- 请填写您的AppId，例如：2019091767145019 -->";
            alipayConfig.PrivateKey = privateKey;
            alipayConfig.Format = "json";
            alipayConfig.AlipayPublicKey = alipayPublicKey;
            alipayConfig.Charset = "UTF-8";
            alipayConfig.SignType = "RSA2";
            return alipayConfig;
        }
    }
}
```
 

##### http
```
 curl 'https://openapi.alipay.com/gateway.do?charset=UTF-8&method=alipay.ebpp.invoice.ecorder.order.query&format=json&sign=${sign}&app_id=${appid}&version=1.0&sign_type=RSA2&timestamp=${now}' \
 -F 'app_auth_token=${app_auth_token}' \
 -F 'biz_content={
	"enterprise_id":"2088501296144291",
	"account_id":"2088000000000000",
	"agreement_no":"20200000000000000000",
	"order_id":"2020103022000000000000000000",
	"order_type":"METRO"
}' 
```
 

### 业务响应参数
|参数英文名|类型|是否必选|长度/取值|描述|示例值|
|---|---|---|---|---|---|
|order_info|EcOrderItem|必须|null|企业码订单详情||
|order_info.account_id|String|可选|32|共同账户ID|2088000000000000|
|order_info.enterprise_id|String|可选|32|企业ID|2088000351583735|
|order_info.user_id|String|可选|32|用户支付宝UID新商户建议使用open_id替代该字段。对于新商户，user_id字段未来计划逐步回收，存量商户可继续使用。如使用open_id，请确认 应用-开发配置-openid配置管理 已启用。无该配置项，可查看[openid配置申请](https://opendocs.alipay.com/mini/0ai9ok?pathHash=de631c06)。|2088000000000000|
|order_info.open_id|String|可选|128|用户支付宝UID&nbsp; 详情可查看[ openid简介](https://opendocs.alipay.com/mini/0ai2i6?pathHash=13dd5946)|074a1CcTG1LelxKe4xQC0zgNdId0nxi95b5lsNpazWYoCo5|
|order_info.employee_id|String|可选|32|员工ID|2284000351583735|
|order_info.order_id|String|可选|32|订单ID|2020103022000000000000000000|
|order_info.order_type|String|可选|16|订单类型 METRO：地铁 TAKE_AWAY：外卖 OTHER：其他 REACH_SHOP：到店**枚举值**地铁:METRO外卖:TAKE_AWAY其他:OTHER到店:REACH_SHOP|METRO|
|order_info.pay_no|String|可选|128|关联支付宝交易号|2020103022000000000000000000|
|order_info.biz_out_no|String|可选|128|外部业务号|1234567890|
|order_info.partner_id|String|可选|32|合作伙伴ID|2234000000000000|
|order_info.gmt_create|String|可选|32|创建时间|2022-01-01 00:00:00|
|order_info.gmt_modified|String|可选|32|修改时间|2022-01-01 00:00:00|
|order_info.order_content|String|可选|65536|订单内容，JSON格式。**详细字段说明**：[order-content.md](../../common/order-content.md)（地铁、外卖、其他场景）|{"merchant_id": ""}|
|sub_order_list|EcOrderItem|可选|null|企业码子订单详情列表||
|sub_order_list.account_id|String|可选|32|共同账户ID|2088000000000000|
|sub_order_list.enterprise_id|String|可选|32|企业ID|2088000351583735|
|sub_order_list.user_id|String|可选|32|用户支付宝UID新商户建议使用open_id替代该字段。对于新商户，user_id字段未来计划逐步回收，存量商户可继续使用。如使用open_id，请确认 应用-开发配置-openid配置管理 已启用。无该配置项，可查看[openid配置申请](https://opendocs.alipay.com/mini/0ai9ok?pathHash=de631c06)。|2088000000000000|
|sub_order_list.open_id|String|可选|128|用户支付宝UID&nbsp; 详情可查看[ openid简介](https://opendocs.alipay.com/mini/0ai2i6?pathHash=13dd5946)|074a1CcTG1LelxKe4xQC0zgNdId0nxi95b5lsNpazWYoCo5|
|sub_order_list.employee_id|String|可选|32|员工ID|2284000351583735|
|sub_order_list.order_id|String|可选|32|订单ID|2020103022000000000000000000|
|sub_order_list.order_type|String|可选|16|订单类型 METRO：地铁 TAKE_AWAY：外卖 OTHER：其他 REACH_SHOP：到店**枚举值**地铁:METRO外卖:TAKE_AWAY其他:OTHER到店:REACH_SHOP|METRO|
|sub_order_list.pay_no|String|可选|128|关联支付宝交易号|2020103022000000000000000000|
|sub_order_list.biz_out_no|String|可选|128|外部业务号|1234567890|
|sub_order_list.partner_id|String|可选|32|合作伙伴ID|2234000000000000|
|sub_order_list.gmt_create|String|可选|32|创建时间|2022-01-01 00:00:00|
|sub_order_list.gmt_modified|String|可选|32|修改时间|2022-01-01 00:00:00|
|sub_order_list.order_content|String|可选|65536|订单内容，JSON格式。**详细字段说明**：[order-content.md](../../common/order-content.md)（地铁、外卖、其他场景）|{"merchant_id": ""}|
### 公共响应参数
|参数英文名|类型|是否必选|长度/取值|描述|示例值|
|---|---|---|---|---|---|
|code|String|必须|~|网关返回码，[详见文档](https://docs.open.alipay.com/common/105806)|40004|
|msg|String|必须|~|网关返回码描述，[详见文档](https://docs.open.alipay.com/common/105806)|Business Failed|
|sub_code|String|可选|~|业务返回码，参见具体的API接口文档||
|sub_msg|String|可选|~|业务返回码描述，参见具体的API接口文档||
|sign|String|必须|64|签名，[详见文档](https://docs.open.alipay.com/291/106074)|DZXh8eeTuAHoYE3w1J+POiPhfDxOYBfUNn1lkeT/V7P4zJdyojWEa6IZs6Hz0yDW5Cp/viufUb5I0/V5WENS3OYR8zRedqo6D+fUTdLHdc+EFyCkiQhBxIzgngPdPdfp1PIS7BdhhzrsZHbRqb7o4k3Dxc+AAnFauu4V6Zdwczo=|
### 响应示例
#### 正常响应示例
```
 {
	"alipay_ebpp_invoice_ecorder_order_query_response":{
		"code":"10000",
		"msg":"Success",
		"order_info":{
			"account_id":"2088000000000000",
			"enterprise_id":"2088000351583735",
			"user_id":"2088000000000000",
			"open_id":"074a1CcTG1LelxKe4xQC0zgNdId0nxi95b5lsNpazWYoCo5",
			"employee_id":"2284000351583735",
			"order_id":"2020103022000000000000000000",
			"order_type":"METRO",
			"pay_no":"2020103022000000000000000000",
			"biz_out_no":"1234567890",
			"partner_id":"2234000000000000",
			"gmt_create":"2022-01-01 00:00:00",
			"gmt_modified":"2022-01-01 00:00:00",
			"order_content":"{\"merchant_id\": \"\"}"
		},
		"sub_order_list":[
			{
				"account_id":"2088000000000000",
				"enterprise_id":"2088000351583735",
				"user_id":"2088000000000000",
				"open_id":"074a1CcTG1LelxKe4xQC0zgNdId0nxi95b5lsNpazWYoCo5",
				"employee_id":"2284000351583735",
				"order_id":"2020103022000000000000000000",
				"order_type":"METRO",
				"pay_no":"2020103022000000000000000000",
				"biz_out_no":"1234567890",
				"partner_id":"2234000000000000",
				"gmt_create":"2022-01-01 00:00:00",
				"gmt_modified":"2022-01-01 00:00:00",
				"order_content":"{\"merchant_id\": \"\"}"
			}
		]
	},
	"sign":"ERITJKEIJKJHKKKKKKKHJEREEEEEEEEEEE"
}
```
 
#### 异常响应示例
```
 {"alipay_ebpp_invoice_ecorder_order_query_response":{"code":"20000","msg":"Service Currently Unavailable","sub_code":"isp.unknow-error","sub_msg":"系统繁忙"},"sign":"ERITJKEIJKJHKKKKKKKHJEREEEEEEEEEEE"}
```
 
### 业务错误码
|错误码|错误描述|解决方案|
|---|---|---|
|SYSTEM_ERROR|系统繁忙|服务器异常 可能发生了网络或者系统异常，导致服务调用失败，商户可以用同样的请求发起重试|
|INVALID_PARAMETER|参数有误|请根据接口返回的参数非法的具体错误信息，修改参数后进行重试|
|ORDER_NOT_EXIST|订单不存在|请检查参数是否有误或联系小二|
|PERMISSION_DENIED|权限不足|可以通过检查入参的企业ID来解决，如确认企业ID无误后未能解决，请联系企业码客服或技术支持|
