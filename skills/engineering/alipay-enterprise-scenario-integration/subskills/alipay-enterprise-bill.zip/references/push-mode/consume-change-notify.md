# alipay.commerce.ec.consume.change.notify(企业码账单消息通知)

## 公共请求参数

| 参数 | 类型 | 是否必选 | 最大长度 | 描述 | 示例值 |
| :--- | :--- | :--- | :--- | :--- | :--- |
| notify_id | String | 必选 | 50 | 通知ID | 5608cccc09ddb39d41c2e3c06e3d9fejh2 |
| utc_timestamp | String | 必选 | 13 | 消息发送时的服务端时间 | 1514210452731 |
| msg_method | String | 必选 | 100 | 消息接口名称 | alipay.commerce.ec.consume.change.notify |
| app_id | String | 必选 | 20 | 消息接受方的应用id | 2014060600164699 |
| version | String | 必选 | 5 | 版本号(1.1版本为标准消息) | 1.0或者1.1 |
| biz_content | String | 必选 | | 消息报文 | 参见消息属性 |
| sign | String | 必选 | 344 | 签名 | WcO+t3D8Kg71dTlKwN7r9PzUOXeaBJwp8/FOuSxcuSkXsoVYxBpsAidprySCjHCjmaglNcjoKJQLJ28/Asl93joTW39FX6i07lXhnbPknezAlwmvPdnQuI01HZsZF9V1i6ggZjBiAd5lG8bZtTxZOJ87ub2i9GuJ3Nr/NUc9VeY= |
| sign_type | String | 必选 | 10 | 签名类型 | RSA2 |
| charset | String | 必选 | 10 | 编码集，该字符集为验签和解密所需要的字符集 | UTF-8 |

## 消息属性

| 参数英文名 | 类型 | 是否必选 | 长度/取值 | 描述 | 示例值 |
|---|---|---|---|---|---|
| account_id | String | 必选 | 32 | 共同账户ID | 2088610274868075 |
| enterprise_id | String | 必选 | 32 | 企业ID | 2088441400705849 |
| employee_id | String | 必选 | 32 | 员工ID | 2288084000121721 |
| pay_no | String | 必选 | 128 | 支付宝账单号 | 2022101722001489310531022044 |
| consume_type | String | 必选 | 64 | 账单类型<br>**枚举值**：消费账单: CONSUME<br>退款账单: REFUND | CONSUME |
| gmt_biz_create | String | 必选 | 32 | 账单创建时间<br>格式：yyyy-MM-dd HH:mm:ss | 2022-01-01 01:01:01 |
| consume_amount | String | 必选 | 11 | 账单金额<br>2位小数，单位：元 | 26.88 |
| notify_reason | String | 必选 | 64 | 通知原因<br>**枚举值**：账单归集: COLLECT<br>账单汇总成功: SUMMARY_SUCCESS<br>订单完结: ORDER_COMPLETE | COLLECT |
| notify_msg | String | 必选 | 128 | 通知描述 | 账单归集 |
| user_id | String | 特殊可选 | 32 | 员工支付宝UID<br>新商户建议使用open_id替代该字段 | 2088000000000000 |
| open_id | String | 特殊可选 | 128 | 员工支付宝UID | 074a1CcTG1LelxKe4xQC0zgNdId0nxi95b5lsNpazWYoCo5 |
| related_pay_no | String | 条件必选 | 128 | 关联消费账单交易流水号<br>退款账单这个字段才有值 | 2022101722001489310531022044 |
| gmt_recieve_pay | String | 可选 | 32 | 账单支付时间<br>格式：yyyy-MM-dd HH:mm:ss | 2022-01-01 01:01:01 |
| peer_pay_amount | String | 可选 | 11 | 企业代付金额<br>2位小数，单位：元 | 25.00 |
| expense_rule_group_id | String | 可选 | 32 | 费控规则ID | 2022101700152608840000353934 |
| expense_scene_code | String | 可选 | 64 | 费用场景 | OVERTIME |
| expense_type | String | 可选 | 64 | 费用类型<br>**枚举值**：餐饮: MEAL | MEAL |
| expense_type_sub_category | String | 可选 | 64 | 费用类型子类目 | REACH_SHOP |
| ext_infos | String | 可选 | 1024 | 扩展参数，JSON格式 | 无 |

**注意**：user_id 和 open_id 二选一传入

### 消息示例

```bash
curl -X POST 'NOTIFY_URL' \
--header 'Content-Type: application/x-www-form-urlencoded; charset=UTF-8' \
--data-urlencode 'charset=UTF-8' \
--data-urlencode 'biz_content={
	"account_id":"2088610274868075",
	"user_id":"2088000000000000",
	"open_id":"074a1CcTG1LelxKe4xQC0zgNdId0nxi95b5lsNpazWYoCo5",
	"enterprise_id":"2088441400705849",
	"employee_id":"2288084000121721",
	"pay_no":"2022101722001489310531022044",
	"related_pay_no":"2022101722001489310531022044",
	"consume_type":"CONSUME",
	"gmt_biz_create":"2022-01-01 01:01:01",
	"gmt_recieve_pay":"2022-01-01 01:01:01",
	"consume_amount":"26.88",
	"peer_pay_amount":"25.00",
	"expense_rule_group_id":"2022101700152608840000353934",
	"expense_scene_code":"OVERTIME",
	"expense_type":"MEAL",
	"expense_type_sub_category":"REACH_SHOP",
	"notify_reason":"COLLECT",
	"notify_msg":"账单归集",
	"ext_infos":"无"
}' \
--data-urlencode 'utc_timestamp=${now}' \
--data-urlencode 'sign=${sign}' \
--data-urlencode 'app_id=${appid}' \
--data-urlencode 'version=1.1' \
--data-urlencode 'sign_type=RSA2' \
--data-urlencode 'notify_id=${notify_id}' \
--data-urlencode 'msg_method=alipay.commerce.ec.consume.change.notify'
```

**说明：** NOTIFY_URL是开发者在开放平台控制台上设置的应用网关地址

## 通知应答

| 响应报文 | 描述 | 是否重试 | 是否区分大小写 |
| :--- | :--- | :--- | :--- |
| success | 消息处理成功 | 否 | 否 |
| fail | 消息处理失败 | 是 | 否 |

说明：消息服务会根据响应报文判断商户系统是否已经成功处理消息。如果HTTP同步响应报文返回 success 字符串，消息服务则认为消息已经处理成功，停止投递，如果返回 fail ，表示消息获取失败，支付宝会根据投递重试策略重新发送消息到应用网关地址；

投递重试策略：一般情况下，25 小时以内完成 8 次通知，除了第一次是实时投递外，后续的每次重试都会间隔一段时间，间隔频率一般是：2m、10m、10m、1h、2h、6h、15h（第二次消息投递是在第一次投递失败后的 2 分钟；第三次投递是在第二次投递失败后的 10 分钟，以此类推）
