# alipay.commerce.ec.consume.detail.batchquery(账单详情批量查询)
支持第三方代理调用：本接口支持第三方开发者代用户发起调用
## 通用场景
账单详情批量查询
注意：【调用条件】：查询时间范围不能超过24h【返回约束】：无【其他】：无
### 公共请求参数
|参数英文名|类型|是否必选|长度/取值|描述|示例值|
|---|---|---|---|---|---|
|app_id|String|必选|32|支付宝分配给开发者的应用ID|2014072300007148|
|method|String|必选|128|接口名称|alipay.commerce.ec.consume.detail.batchquery|
|format|String|可选|40|仅支持JSON|JSON|
|charset|String|必选|10|请求使用的编码格式，如utf-8,gbk,gb2312等|utf-8|
|sign_type|String|必选|10|商户生成签名字符串所使用的签名算法类型，目前支持RSA2和RSA，推荐使用RSA2|RSA2|
|sign|String|必选|344|商户请求参数的签名串，详见[签名](https://opendocs.alipay.com/common/02khjm)|详见示例|
|timestamp|String|必选|19|发送请求的时间，格式"yyyy-MM-dd HH:mm:ss"|2014-07-24 03:07:50|
|version|String|必选|3|调用的接口版本，固定为：1.0|1.0|
|app_auth_token|String|可选|40|详见[应用授权概述](https://opendocs.alipay.com/isv/10467/xldcyq)||
|biz_content|String|必选||请求参数的集合，最大长度不限，除公共参数外所有请求参数都必须放在这个参数中传递，具体参照各产品快速接入文档||
### 业务请求参数
|参数英文名|类型|是否必选|长度/取值|描述|示例值|
|---|---|---|---|---|---|
|enterprise_id|String|特殊可选|32|企业ID，推荐查询方式**注意事项**通过企业码2.0签约接口签约，只填写企业id，无需填写共同账户id和授权签约协议号。**必选条件**通过企业码2.0签约接口签约，只填写企业id，无需填写共同账户id和授权签约协议号。|2088123456789000|
|account_id|String|特殊可选|32|共同账户ID**注意事项**通过企业码1.0接口签约的共同账户，和agreement_no搭配使用。**必选条件**通过企业码2.0签约接口签约，只填写企业id，无需填写共同账户id和授权签约协议号。|2088123456789000|
|agreement_no|String|特殊可选|128|授权签约协议号**注意事项**可通过签约消息获取。配合共同账户id使用，当填写企业共同账户id时，此字段必填。**必选条件**通过企业码2.0签约接口签约，只填写企业id，无需填写共同账户id和授权签约协议号。|20205820659822371223|
|start_date|String|必须|32|起始时间**注意事项**格式：yyyy-MM-dd HH:mm:ss，起始和截止时间不能大于1天|yyyy-MM-dd HH:mm:ss|
|end_date|String|必须|32|截止时间**注意事项**格式：yyyy-MM-dd HH:mm:ss，起始和截止时间不能大于1天|yyyy-MM-dd HH:mm:ss|
|employee_id|String|必须|32|企业码员工id**注意事项**如果传入此字段，只支持在职的员工id查询|228801013090|
|expense_rule_group_id|String|必须|64|费控规则组id（非制度id)|2024012900152608590000516577|
|page_num|String|可选|4|页码**注意事项**本参数为空或小于1默认显示第一页|1|
|page_size|String|可选|4|每页大小**注意事项**本参数为空或小于1默认20条，超过20默认按20条查询；不足20条则按实际记录数返回|20|
### 请求示例
#### 默认示例
##### java
```
 package com.java.sdk.demo;

import com.alipay.api.AlipayApiException;
import com.alipay.api.AlipayClient;
import com.alipay.api.DefaultAlipayClient;
import com.alipay.api.AlipayConfig;
import com.alipay.api.domain.AlipayCommerceEcConsumeDetailBatchqueryModel;
import com.alipay.api.response.AlipayCommerceEcConsumeDetailBatchqueryResponse;
import com.alipay.api.request.AlipayCommerceEcConsumeDetailBatchqueryRequest;

import com.alipay.api.FileItem;
import java.util.Base64;
import java.util.ArrayList;
import java.util.List;

public class AlipayCommerceEcConsumeDetailBatchquery {

    public static void main(String[] args) throws AlipayApiException {
        // 初始化SDK
        AlipayClient alipayClient = new DefaultAlipayClient(getAlipayConfig());

        // 构造请求参数以调用接口
        AlipayCommerceEcConsumeDetailBatchqueryRequest request = new AlipayCommerceEcConsumeDetailBatchqueryRequest();
        AlipayCommerceEcConsumeDetailBatchqueryModel model = new AlipayCommerceEcConsumeDetailBatchqueryModel();
        
        // 设置企业ID
        model.setEnterpriseId("2088123456789000");
        
        // 设置共同账户ID
        model.setAccountId("2088123456789000");
        
        // 设置授权签约协议号
        model.setAgreementNo("20205820659822371223");
        
        // 设置起始时间
        model.setStartDate("yyyy-MM-dd HH:mm:ss");
        
        // 设置截止时间
        model.setEndDate("yyyy-MM-dd HH:mm:ss");
        
        // 设置员工id
        model.setEmployeeId("228801013090");
        
        // 设置费控规则id
        model.setExpenseRuleGroupId("2024012900152608590000516577");
        
        // 设置页数
        model.setPageNum("1");
        
        // 设置每页大小
        model.setPageSize("20");
        
        request.setBizModel(model);
        // 第三方代调用模式下请设置app_auth_token
        // request.putOtherTextParam("app_auth_token", "<-- 请填写应用授权令牌 -->");

        AlipayCommerceEcConsumeDetailBatchqueryResponse response = alipayClient.execute(request);
        System.out.println(response.getBody());

        if (response.isSuccess()) {
            System.out.println("调用成功");
        } else {
            System.out.println("调用失败");
            // sdk版本是"4.38.0.ALL"及以上,可以参考下面的示例获取诊断链接
            // String diagnosisUrl = DiagnosisUtils.getDiagnosisUrl(response);
            // System.out.println(diagnosisUrl);
        }
    }

    private static AlipayConfig getAlipayConfig() {
        String privateKey  = "<-- 请填写您的应用私钥，例如：MIIEvQIBADANB ... ... -->";
        String alipayPublicKey = "<-- 请填写您的支付宝公钥，例如：MIIBIjANBg... -->";
        AlipayConfig alipayConfig = new AlipayConfig();
        alipayConfig.setServerUrl("https://openapi.alipay.com/gateway.do");
        alipayConfig.setAppId("<-- 请填写您的AppId，例如：2019091767145019 -->");
        alipayConfig.setPrivateKey(privateKey);
        alipayConfig.setFormat("json");
        alipayConfig.setAlipayPublicKey(alipayPublicKey);
        alipayConfig.setCharset("UTF-8");
        alipayConfig.setSignType("RSA2");
        return alipayConfig;
    }
}
```
 

##### php
```
 <?php
require_once '../aop/AopClient.php';
require_once '../aop/AopCertClient.php';
require_once '../aop/AopCertification.php';
require_once '../aop/AlipayConfig.php';
require_once '../aop/request/AlipayCommerceEcConsumeDetailBatchqueryRequest.php';

// 初始化SDK
$alipayClient = new AopClient(getAlipayConfig());
// 构造请求参数以调用接口
$request = new AlipayCommerceEcConsumeDetailBatchqueryRequest();
$model = array();

// 设置企业ID
$model['enterprise_id'] = "2088123456789000";

// 设置共同账户ID
$model['account_id'] = "2088123456789000";

// 设置授权签约协议号
$model['agreement_no'] = "20205820659822371223";

// 设置起始时间
$model['start_date'] = "yyyy-MM-dd HH:mm:ss";

// 设置截止时间
$model['end_date'] = "yyyy-MM-dd HH:mm:ss";

// 设置员工id
$model['employee_id'] = "228801013090";

// 设置费控规则id
$model['expense_rule_group_id'] = "2024012900152608590000516577";

// 设置页数
$model['page_num'] = "1";

// 设置每页大小
$model['page_size'] = "20";

$request->setBizContent(json_encode($model,JSON_UNESCAPED_UNICODE));
// 如果是第三方代调用模式，请设置app_auth_token（应用授权令牌）
$responseResult = $alipayClient->execute($request, null, "<-- 请填写应用授权令牌 -->", null);
$responseApiName = str_replace(".","_",$request->getApiMethodName())."_response";
$response = $responseResult->$responseApiName;
if(!empty($response->code)&&$response->code==10000){
    echo("调用成功");
}
else{
    echo("调用失败");
}

function getAlipayConfig()
{
    $privateKey  = '<-- 请填写您的应用私钥，例如：MIIEvQIBADANB ... ... -->';
    $alipayPublicKey = '<-- 请填写您的支付宝公钥，例如：MIIBIjANBg... -->';
    $alipayConfig = new AlipayConfig();
    $alipayConfig->setServerUrl('https://openapi.alipay.com/gateway.do');
    $alipayConfig->setAppId('<-- 请填写您的AppId，例如：2019091767145019 -->');
    $alipayConfig->setPrivateKey($privateKey);
    $alipayConfig->setFormat('json');
    $alipayConfig->setAlipayPublicKey($alipayPublicKey);
    $alipayConfig->setCharset('UTF-8');
    $alipayConfig->setSignType('RSA2');
    return $alipayConfig;
}
```
 

##### csharp
```
 using System;
using System.Collections.Generic;
using Aop.Api;
using Aop.Api.Request;
using Aop.Api.Response;
using Aop.Api.Domain;
using Aop.Api.Util;
namespace SdkDemoTest
{
    public class AlipayCommerceEcConsumeDetailBatchquery
    {
        public static void Main(string[] args) 
        {
            // 初始化SDK
            IAopClient alipayClient = new DefaultAopClient(GetAlipayConfig());
            // 构造请求参数以调用接口
            AlipayCommerceEcConsumeDetailBatchqueryRequest request = new AlipayCommerceEcConsumeDetailBatchqueryRequest();
            AlipayCommerceEcConsumeDetailBatchqueryModel model = new AlipayCommerceEcConsumeDetailBatchqueryModel();
            
            // 设置企业ID
            model.EnterpriseId = "2088123456789000";
            
            // 设置共同账户ID
            model.AccountId = "2088123456789000";
            
            // 设置授权签约协议号
            model.AgreementNo = "20205820659822371223";
            
            // 设置起始时间
            model.StartDate = "yyyy-MM-dd HH:mm:ss";
            
            // 设置截止时间
            model.EndDate = "yyyy-MM-dd HH:mm:ss";
            
            // 设置员工id
            model.EmployeeId = "228801013090";
            
            // 设置费控规则id
            model.ExpenseRuleGroupId = "2024012900152608590000516577";
            
            // 设置页数
            model.PageNum = "1";
            
            // 设置每页大小
            model.PageSize = "20";
            
            request.SetBizModel(model);
            // 第三方代调用模式下请设置app_auth_token
            // request.PutOtherTextParam("app_auth_token", "<-- 请填写应用授权令牌 -->");

            AlipayCommerceEcConsumeDetailBatchqueryResponse response = alipayClient.Execute(request);

            if(!response.IsError)
            {
                Console.WriteLine("调用成功");
            }
            else
            {
                Console.WriteLine("调用失败");
            }
        }

        private static AlipayConfig GetAlipayConfig()
        {
            string privateKey  = "<-- 请填写您的应用私钥，例如：MIIEvQIBADANB ... ... -->";
            string alipayPublicKey = "<-- 请填写您的支付宝公钥，例如：MIIBIjANBg... -->";
            AlipayConfig alipayConfig = new AlipayConfig();
            alipayConfig.ServerUrl = "https://openapi.alipay.com/gateway.do";
            alipayConfig.AppId = "<-- 请填写您的AppId，例如：2019091767145019 -->";
            alipayConfig.PrivateKey = privateKey;
            alipayConfig.Format = "json";
            alipayConfig.AlipayPublicKey = alipayPublicKey;
            alipayConfig.Charset = "UTF-8";
            alipayConfig.SignType = "RSA2";
            return alipayConfig;
        }
    }
}
```
 

##### http
```
 curl 'https://openapi.alipay.com/gateway.do?charset=UTF-8&method=alipay.commerce.ec.consume.detail.batchquery&format=json&sign=${sign}&app_id=${appid}&version=1.0&sign_type=RSA2&timestamp=${now}' \
 -F 'app_auth_token=${app_auth_token}' \
 -F 'biz_content={
	"enterprise_id":"2088123456789000",
	"account_id":"2088123456789000",
	"agreement_no":"20205820659822371223",
	"start_date":"yyyy-MM-dd HH:mm:ss",
	"end_date":"yyyy-MM-dd HH:mm:ss",
	"employee_id":"228801013090",
	"expense_rule_group_id":"2024012900152608590000516577",
	"page_num":"1",
	"page_size":"20"
}' 
```
 

### 业务响应参数
|参数英文名|类型|是否必选|长度/取值|描述|示例值|
|---|---|---|---|---|---|
|page_num|String|必须|4|当期页数|1|
|page_size|String|必须|4|当期页记录数|20|
|consume_info_list|EcConsumeInfo|可选|null|账单信息列表||
|consume_info_list.account_id|String|必须|32|共同账户ID|2088000000000000|
|consume_info_list.user_id|String|特殊可选|32|员工支付宝UID新商户建议使用open_id替代该字段。对于新商户，user_id字段未来计划逐步回收，存量商户可继续使用。如使用open_id，请确认 应用-开发配置-openid配置管理 已启用。无该配置项，可查看[openid配置申请](https://opendocs.alipay.com/mini/0ai9ok?pathHash=de631c06)。**必选条件**除特殊业务场景之外，该字段都必选|2088000000000000|
|consume_info_list.open_id|String|特殊可选|128|员工支付宝UID&nbsp; 详情可查看[ openid简介](https://opendocs.alipay.com/mini/0ai2i6?pathHash=13dd5946)**必选条件**除特殊业务场景之外，该字段都必选|074a1CcTG1LelxKe4xQC0zgNdId0nxi95b5lsNpazWYoCo5|
|consume_info_list.enterprise_id|String|可选|32|企业ID|2088000000000000|
|consume_info_list.employee_id|String|可选|32|员工账号ID|2288084000066059|
|consume_info_list.pay_no|String|必须|128|交易流水号|2022101722001489310531022048|
|consume_info_list.consume_type|String|必须|16|账单类型 -消费账单：CONSUME -退款账单：REFUND -转账账单：TRANSFER**枚举值**支付:CONSUME退款:REFUND转账:TRANSFER|CONSUME|
|consume_info_list.gmt_biz_create|String|必须|32|账单创建时间，格式：yyyy-MM-dd HH:mm:ss|2022-01-01 01:01:01|
|consume_info_list.consume_biz_type|String|必须|20|账单业务类型 -因公支付：EC_PAY -因公收款：EC_CLLCT**枚举值**因公支付:EC_PAY因公收款:EC_CLLCT|EC_PAY|
|consume_info_list.gmt_receive_pay|String|可选|32|账单支付时间，格式：yyyy-MM-dd HH:mm:ss|2022-01-01 01:01:02|
|consume_info_list.consume_fee_with_discount|String|可选|32|订单原价，单位：元，包含营销资产|35.01|
|consume_info_list.consume_amount|String|必须|32|账单金额，单位：元，不包含营销资产|26.88|
|consume_info_list.benefit_amount|String|可选|32|员工优惠金额，单位：元|5.32|
|consume_info_list.peer_pay_amount|String|可选|32|企业代付金额，单位：元|25.00|
|consume_info_list.related_pay_no|String|特殊可选|128|退款账单关联的消费账单交易流水号，退款账单才有值**必选条件**退款账单必选|2022111522001440840546335528|
|consume_info_list.biz_out_no|String|可选|256|外部交易流水号|1234567890|
|consume_info_list.category_name|String|可选|32|账单分类名称，如餐饮等**枚举值**餐饮:餐饮|餐饮|
|consume_info_list.merchant_id|String|可选|64|商户ID|1556908648226107394|
|consume_info_list.merchant_name|String|可选|255|商户名称|支付宝（中国）网络技术有限公司|
|consume_info_list.peer_refund_status|String|可选|32|该字段只对因公付交易生效，默认为INIT。当消费账单有退款，该值会变为REFUND_PART或REFUND_FULL；退款账单该值无意义，为初始值INIT。 未退款：INIT 部分退款：REFUND_PART， 全额退款：REFUND_FULL**枚举值**默认:INIT部分退款:REFUND_PART全额退款:REFUND_FULL|REFUND_PART|
|consume_info_list.peer_refund_amount|String|可选|32|消费账单企业代付部分退款金额，单位：元。退款账单该值无意义，值为0。|6.88|
|consume_info_list.peer_payer_card_no|String|可选|64|实际出资支付宝账号|2234000000000000|
|consume_info_list.agreement_peer_payer_id|String|可选|64|协议出资支付宝账号|2234000000000000|
|consume_info_list.seller_id|String|可选|64|卖家ID|2234000000000000|
|consume_info_list.shop_id|String|可选|64|门店ID|2234000000000000|
|consume_info_list.store_id|String|可选|64|外部门店ID|123456|
|consume_info_list.expense_rule_group_id|String|可选|32|使用规则ID|2022060200152608840000248211|
|consume_info_list.expense_scene_code|String|可选|64|费用场景/一级场景**注意事项**若在费控中创建的制度和规则，报销创建的申请单，使用的是一级场景，则对应交易此字段代表一级场景。反之使用的是费用场景，则此字段代表费用场景|OVERTIME|
|consume_info_list.expense_type|String|可选|16|费用类型**枚举值**餐饮:MEAL公交地铁:METRO用车:CAR默认:DEFAULT医疗:HEALTH生活服务:LIVINGSERVICE票务:TICKET|MEAL|
|consume_info_list.expense_type_sub_category|String|可选|16|费用类型子类目/二级场景**枚举值**外卖:TAKE_AWAY到店:REACH_SHOP默认:DEFAULT生活服务:LIVINGSERVICE地铁:METRO到院就医:REACH_HOSPITAL票务:TICKET**注意事项**若在费控中创建的制度和规则，报销创建的申请单，使用的是二级场景，则对应交易此字段代表二级场景。反之使用的是费用类型子类，则此字段代表费用类型子类|TAKE_AWAY|
|consume_info_list.invoice_open_mode|String|可选|64|开票模式 企业汇总开：ENTERPRISE_AUTO_BATCH**枚举值**企业汇总开票:ENTERPRISE_AUTO_BATCH|ENTERPRISE_AUTO_BATCH|
|consume_info_list.summary_apply_id|String|可选|32|汇总批次ID|2022060200152608840000248211|
|consume_info_list.fund_biz_type|String|可选|64|出资模式 个人出资：PERSONAL 企业出资：ENTERPRISE 三方垫资合作伙伴出资：TP 记账：ACCOUNTING**枚举值**个人出资:PERSONAL企业出资:ENTERPRISE三方垫资合作伙伴出资:TP记账:ACCOUNTING|ENTERPRISE|
|consume_info_list.scene_code|String|可选|32|账单场景 TAKE_AWAY：外卖 METRO：地铁 OTHER：其他**枚举值**外卖:TAKE_AWAY地铁:METRO其他:OTHER|TAKE_AWAY|
|consume_info_list.order_complete_label|String|必须|10|订单完结标识，0标识“未完结”，1标识“已完结”**枚举值**未完结:0已完结:1|0|
|consume_info_list.order_complete_time|String|可选|32|2022-01-01 01:01:02 订单完结时间|2022-01-01 01:01:02|
|consume_info_list.ext_infos|String|可选|4096|账单扩展信息，Json格式，可能出现的key值和说明如枚举所示**枚举值**汇总信息:SUMMARY_INFO商户扩展信息:MERCHANT_EXTEND_INFO终端设备信息:TERMINAL_INFO优惠扩展信息:BENEFIT_INFO消费上报位置:CONSUMPTION_LOCATION资产明细:ASSETS_INFO|{"SUMMARY_INFO": ""}|
|consume_info_list.consume_category|String|可选|32|员工消费记账分类： "cater": "餐饮" "purchase": "采购" "trip": "出行" "train": "培训" "entertainment": "娱乐" "hotel": "酒店" "pay": "缴费" "rent": "房租" "other": "其他"**枚举值**餐饮:cater采购:purchase出行:trip娱乐:entertainment酒店:hotel缴费:pay房租:rent其他:other|cater|
|consume_info_list.consume_memo|String|可选|255|员工消费记账备注|商务招待|
|consume_info_list.payer_card_no|String|可选|20|付款方卡号|2088641043864840|
|consume_info_list.payer_name|String|可选|128|付款方名称|李某某|
|consume_info_list.payer_logon_id|String|可选|128|付款方登录账号|xxxx@alipay.com|
|consume_info_list.opposite_full_name|String|可选|128|收款方全称（如果是个人会显示脱敏后的名称）|上海支付宝数字技术有限公司|
|consume_info_list.consume_title|String|可选|128|商户收款时传的商品备注说明，在账单内进行表达|智盘消费_杭州-A空间-潘多拉-润仟祥黄焖鸡-2118_刷脸时间_2024-08-16 18:03|
|consume_info_list.refund_status|String|必须|32|当消费账单有退款，该值会变为REFUND_PART或REFUND_FULL；退款账单该值无意义，为初始值INIT。**枚举值**未退款:INIT部分退款:REFUND_PART全额退款:REFUND_FULL|REFUND_FULL|
|consume_info_list.refund_amount|String|必须|32|消费账单退款金额，单位：元。退款账单该值无意义，值为0。|1|
|consume_info_list.peer_payer_card_name|String|必须|128|实际出资人名称|xx有限公司|
### 公共响应参数
|参数英文名|类型|是否必选|长度/取值|描述|示例值|
|---|---|---|---|---|---|
|code|String|必须|~|网关返回码，[详见文档](https://docs.open.alipay.com/common/105806)|40004|
|msg|String|必须|~|网关返回码描述，[详见文档](https://docs.open.alipay.com/common/105806)|Business Failed|
|sub_code|String|可选|~|业务返回码，参见具体的API接口文档||
|sub_msg|String|可选|~|业务返回码描述，参见具体的API接口文档||
|sign|String|必须|64|签名，[详见文档](https://docs.open.alipay.com/291/106074)|DZXh8eeTuAHoYE3w1J+POiPhfDxOYBfUNn1lkeT/V7P4zJdyojWEa6IZs6Hz0yDW5Cp/viufUb5I0/V5WENS3OYR8zRedqo6D+fUTdLHdc+EFyCkiQhBxIzgngPdPdfp1PIS7BdhhzrsZHbRqb7o4k3Dxc+AAnFauu4V6Zdwczo=|
### 响应示例
#### 正常响应示例
```
 {
	"alipay_commerce_ec_consume_detail_batchquery_response":{
		"code":"10000",
		"msg":"Success",
		"page_num":"1",
		"page_size":"20",
		"consume_info_list":[
			{
				"account_id":"2088000000000000",
				"user_id":"2088000000000000",
				"open_id":"074a1CcTG1LelxKe4xQC0zgNdId0nxi95b5lsNpazWYoCo5",
				"enterprise_id":"2088000000000000",
				"employee_id":"2288084000066059",
				"pay_no":"2022101722001489310531022048",
				"consume_type":"CONSUME",
				"gmt_biz_create":"2022-01-01 01:01:01",
				"consume_biz_type":"EC_PAY",
				"gmt_receive_pay":"2022-01-01 01:01:02",
				"consume_fee_with_discount":"35.01",
				"consume_amount":"26.88",
				"benefit_amount":"5.32",
				"peer_pay_amount":"25.00",
				"related_pay_no":"2022111522001440840546335528",
				"biz_out_no":"1234567890",
				"category_name":"餐饮",
				"merchant_id":"1556908648226107394",
				"merchant_name":"支付宝（中国）网络技术有限公司",
				"peer_refund_status":"REFUND_PART",
				"peer_refund_amount":"6.88",
				"peer_payer_card_no":"2234000000000000",
				"agreement_peer_payer_id":"2234000000000000",
				"seller_id":"2234000000000000",
				"shop_id":"2234000000000000",
				"store_id":"123456",
				"expense_rule_group_id":"2022060200152608840000248211",
				"expense_scene_code":"OVERTIME",
				"expense_type":"MEAL",
				"expense_type_sub_category":"TAKE_AWAY",
				"invoice_open_mode":"ENTERPRISE_AUTO_BATCH",
				"summary_apply_id":"2022060200152608840000248211",
				"fund_biz_type":"ENTERPRISE",
				"scene_code":"TAKE_AWAY",
				"order_complete_label":"0",
				"order_complete_time":"2022-01-01 01:01:02",
				"ext_infos":"{\"MERCHANT_EXTEND_INFO\":\"xxx\"}",
				"consume_category":"cater",
				"consume_memo":"商务招待",
				"payer_card_no":"2088641043864840",
				"payer_name":"李某某",
				"payer_logon_id":"xxxx@alipay.com",
				"opposite_full_name":"上海支付宝数字技术有限公司",
				"consume_title":"智盘消费_杭州-A空间-潘多拉-润仟祥黄焖鸡-2118_刷脸时间_2024-08-16 18:03",
				"refund_status":"REFUND_FULL",
				"refund_amount":"1",
				"peer_payer_card_name":"xx有限公司"
			}
		]
	},
	"sign":"ERITJKEIJKJHKKKKKKKHJEREEEEEEEEEEE"
}
```
 
#### 异常响应示例
```
 {"alipay_commerce_ec_consume_detail_batchquery_response":{"code":"20000","msg":"Service Currently Unavailable","sub_code":"isp.unknow-error","sub_msg":"系统繁忙"},"sign":"ERITJKEIJKJHKKKKKKKHJEREEEEEEEEEEE"}
```
 
### 业务错误码
|错误码|错误描述|解决方案|
|---|---|---|
|SYSTEM_ERROR|系统繁忙|服务器异常 可能发生了网络或者系统异常，导致服务调用失败，商户可以用同样的请求发起重试|
|INVALID_PARAMETER|参数有误|请根据接口返回的参数非法的具体错误信息，修改参数后进行重试|
|PERMISSION_DENIED|权限不足，请检查该企业是否有权限|可以通过检查入参的企业ID来解决，如确认企业ID无误后未能解决，请联系企业码客服或技术支持|