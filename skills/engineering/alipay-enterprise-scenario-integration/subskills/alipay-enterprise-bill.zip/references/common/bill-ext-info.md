# 账单 ext_infos 扩展字段说明

本文档详细说明 `alipay.commerce.ec.consume.detail.query` 接口返回的 `ext_infos` 字段结构。

## SUMMARY_INFO（账单汇总信息）

| 字段名 | 字段类型 | 字段含义 | 备注 |
|--------|----------|----------|------|
| batchId | String | 汇总批次ID | |
| invoiceExpenseType | String | 票据费用类型 | GOODS：餐费<br>SERVER：服务费 |

## MERCHANT_EXTEND_INFO（商户扩展信息）

| 字段名 | 字段类型 | 字段含义 | 备注 |
|--------|----------|----------|------|
| merchantName | String | 商户名称 | |
| serviceName | String | 门店名称 | |
| locationInfo | Object | 商户位置信息 | |
| └address | String | 地址 | |
| └provinceId | String | 省份编码 | |
| └provinceName | String | 省份名称 | |
| └cityId | String | 城市编码 | |
| └cityName | String | 城市名称 | |
| └districtId | String | 区编码 | |
| └districtName | String | 区名称 | |
| └latitude | String | 经度 | |
| └longitude | String | 纬度 | |
| └poiId | String | 高德poiId | |
| mccInfo | Object | 商户MCC信息 | |
| └mcc1Code | String | 一级MCC编码 | |
| └mcc1Name | String | 一级MCC名称 | |
| └mcc2Code | String | 二级MCC编码 | |
| └mcc2Name | String | 二级MCC名称 | |
| merchantCertInfoDTO | Object | 商户营业执照信息 | |
| └certType | String | 营业执照类型code | |
| └certNo | String | 营业执照号码 | |
| └certName | String | 营业执照名称 | |

## ASSETS_INFO（因公资产消费详情）

| 字段名 | 字段类型 | 字段含义 | 备注 |
|--------|----------|----------|------|
| assetsList | Array | 资产列表 | |
| └assetId | String | 资产ID | 对应quota_id |
| └assetType | String | 资产类别 | CAP或COUPON |
| └employeeId | String | 资产所属员工ID | |
| └peerPayAmount | String | 资产代付金额 | 单位：元 |

## BENEFIT_INFO（员工优惠详情）

| 字段名 | 字段类型 | 字段含义 | 备注 |
|--------|----------|----------|------|
| totalBenefitAmount | String | 优惠总金额 | 单位：元 |
| benefitItems | Array | 优惠详情列表 | |
| └activityId | String | 企业码活动ID | |
| └activityName | String | 企业码活动名称 | |
| └promotionId | String | 海豚平台活动ID | |
| └promotionName | String | 海豚平台活动名称 | |
| └couponIds | List | 券ID列表 | |
| └benefitAmount | String | 活动优惠金额 | 单位：元 |

## TERMINAL_INFO（终端设备信息）

| 字段名 | 字段类型 | 字段含义 | 备注 |
|--------|----------|----------|------|
| TerminalInfo | Object | 终端设备信息 | |
| └bizTid | String | 设备业务号 | |
| └sn | String | 设备SN码 | |
| └terminalType | String | 设备类型 | |
| └businessCode | String | 支付方式 | |
| └bizProduct | String | 产品码 | |

## CONSUMPTION_LOCATION（消费上报位置）

| 字段名 | 字段类型 | 字段含义 | 备注 |
|--------|----------|----------|------|
| ConsumptionLocationDTO | Object | 消费上报位置信息 | 用户授权后可获取 |
| └provinceId | String | 省份行政编码 | |
| └provinceName | String | 省份名称 | |
| └cityId | String | 城市行政编码 | |
| └cityName | String | 城市名称 | |
| └districtId | String | 区县行政编码 | |
| └districtName | String | 区县名称 | |
| └address | String | 详细地址 | |
| └longitude | String | 经度 | |
| └latitude | String | 纬度 | |

## THIRD_PARTY_PAYMENT_INFO（代收款三方信息）

| 字段名 | 字段类型 | 字段含义 | 备注 |
|--------|----------|----------|------|
| ThirdPartyPaymentInfoDTO | Object | 代收款三方信息 | |
| └InstitutionInfoDTO | Object | 制度详情 | |
| └└InstitutionId | String | 制度ID | |
| └└InstitutionName | String | 制度名称 | |
| └ThirdPartyPayeeInfoDTO | Object | 代收款人详情 | |
| └└thirdPartyPayeeAlipayUserId | String | 代收款员工的支付宝uid | |
| └└thirdPartyPayeeEmployeeId | String | 代收款员工id | |
| └└thirdPartyPayeeName | String | 代收款员工名称 | |
| └PayerInfoDTO | Object | 实付人详情 | |
| └└payerAlipayUserId | String | 实付人支付宝uid | |
| └└payerName | String | 实付人姓名 | |
| └tradeMemo | String | 收款事由 | |

## TINY_APP_INFO（小程序信息）

| 字段名 | 字段类型 | 字段含义 | 备注 |
|--------|----------|----------|------|
| EcTinyAppInfo | Object | 小程序信息 | |
| └tinyAppName | String | 小程序名称 | |

## TRADE_BUSINESS_INFO（因公付交易信息）

| 字段名 | 字段类型 | 字段含义 | 备注 |
|--------|----------|----------|------|
| EcTradeBusinessInfo | Object | 因公付交易拓展信息 | |
| └paymentId | String | 付款事由ID | |
| └ruleGroupId | String | 指定消费规则ID | |

## EXPENSE_INFO（费控信息）

注：此拓展信息记录为收银台上展示的规则和制度信息

| 字段名 | 字段类型 | 字段含义 | 备注 |
|--------|----------|----------|------|
| standard_id | String | 规则ID | |
| standard_name | String | 规则名称 | |
| institution_id | String | 制度ID | |
| institution_name | String | 制度名称 | |

## EC_ACCOUNT_INFO（企业码出资账号信息）

| 字段名 | 字段类型 | 字段含义 | 备注 |
|--------|----------|----------|------|
| ec_account_type | String | 企业码实际出资方式类型 | 公务卡：CORPORATE_CARD<br>通用个垫：GEN_PER_ADV_PAY<br>花呗：PER_ALI_CREDIT<br>联名卡：UNION_CARD<br>企业余额：ENT_ACCOUNT_BALANCE<br>企业对公快捷：ENT_FA_EXPRESS |
| ec_account_name | String | 企业码实际出资方式名称 | |

## 代码示例

```json
{
  "SUMMARY_INFO":"[{\"batchId\":\"2022072500152500960000003956\",\"invoiceExpenseType\":\"GOODS\"},{\"batchId\":\"2022072500152500960000003957\",\"invoiceExpenseType\":\"SERVER\"}]",
  "MERCHANT_EXTEND_INFO":"{\"locationInfo\":{\"address\":\"益州大道中段银泰城悦坊1层14-1-6号\",\"cityId\":\"510100\",\"cityName\":\"成都市\",\"districtId\":\"510107\",\"districtName\":\"武侯区\",\"latitude\":\"30.541282\",\"longitude\":\"104.060031\",\"poiId\":\"B0FFILH23G\",\"provinceId\":\"510000\",\"provinceName\":\"四川省\"},\"mccInfo\":{\"mcc1Code\":\"A0001\",\"mcc1Name\":\"餐饮\",\"mcc2Code\":\"B0004\",\"mcc2Name\":\"中式快餐\"},\"merchantName\":\"众口斋锅贴\",\"serviceName\":\"众口斋锅贴(银泰城店)\"}",
  "ASSETS_INFO":"{\"assetsList\":[{\"assetId\":\"2022102600152611740033984210\",\"assetType\":\"COUPON\",\"employeeId\":\"2288059000141790\",\"peerPayAmount\":\"10.0\"},{\"assetId\":\"2022102600152611740033984211\",\"assetType\":\"COUPON\",\"employeeId\":\"2288059000141791\",\"peerPayAmount\":\"10.0\"}]}",
  "BENEFIT_INFO":"{\"benefitItems\":[{\"benefitAmount\":5,\"activityId\":\"CP13467688\",\"activityName\":\" 身份付优惠券测试-斗尘\"}],\"totalBenefitAmount\":5}",
  "TRADE_BUSINESS_INFO":"{\"paymentId\":\"test001\",\"ruleGroupId\":\"2023121200152608840000615146\"}"
}
```
