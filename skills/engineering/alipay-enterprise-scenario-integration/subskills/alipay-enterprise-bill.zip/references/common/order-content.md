# 订单 order_content 字段说明

本文档详细说明 `alipay.ebpp.invoice.ecorder.order.query` 接口返回的 `order_content` 字段结构。

## 地铁场景

| 字段名 | 字段类型 | 字段含义 | 备注 |
|--------|----------|----------|------|
| parent_order | String | 是否是父订单 | 0：否，1：是 |
| parent_order_id | String | 父订单ID | |
| merchant_id | String | 商户ID | |
| merchant_name | String | 商户名称 | |
| seller_id | String | 卖家UID | |
| peer_pay_refund_amount | String | 代付退款金额 | |
| peer_pay_refund_status | String | 代付退款状态 | INIT: 未退款<br>REFUND_PART: 部分退款<br>REFUND_FULL: 全部退款 |
| order_time | String | 订单业务时间 | 一般为地铁出站时间或者公交上车时间 |
| pay_time | String | 订单支付时间 | |
| order_amount | String | 订单原价 | 单位：元 |
| actual_total_amount | String | 订单实付总金额 | 单位：元 |
| peer_pay_amount | String | 代付金额 | 单位：元 |
| city_code | String | 城市代码 | |
| city_name | String | 城市名称 | |
| card_no | String | 卡号 | |
| card_type | String | 卡类型 | |
| vehicle_type | String | 交通工具类型 | METRO：地铁<br>BUS：公交 |
| start_line | String | 进站线路 | |
| end_line | String | 到达线路 | |
| start_pos_time | String | 进站时间 | |
| end_pos_time | String | 出站时间 | |
| start_pos_id | String | 进站pos机ID | |
| end_pos_id | String | 出站pos机ID | |
| start_station | String | 进站站点名称 | |
| end_station | String | 出站站点名称 | |
| tax_rate | String | 税率 | |
| apply_reason | String | 出行事由 | |
| ext_infos | String | 扩展信息 | agreement_peer_payer_id：协议代付人UID<br>expenseRuleGroupId：费控规则ID<br>expense_type：费用类型<br>expense_type_sub_category：费用类型子类目<br>expense_scene_code：费用场景 |
| gmt_create | String | 创建时间 | |
| gmt_modified | String | 修改时间 | |

## 外卖场景

| 字段名 | 字段类型 | 字段含义 | 备注 |
|--------|----------|----------|------|
| parent_order | String | 是否是父订单 | 0：否，1：是 |
| parent_order_id | String | 父订单ID | |
| order_source | String | 订单来源 | |
| pay_time | String | 订单支付时间 | |
| order_amount | String | 订单总金额（原价） | 单位：元 |
| actual_total_amount | String | 买家实付总金额 | 单位：元 |
| actual_goods_amount | String | 买家实付餐品 | 单位：元 |
| actual_deliver_amount | String | 买家实付配送费 | 单位：元 |
| alipay_order_id | String | 订单中心订单ID | |
| biz_create_time | String | 订单创建时间 | |
| biz_modified_time | String | 订单更新时间 | |
| biz_end_time | String | 订单结束时间 | |
| status_code | String | 订单状态 | WAIT_PAY：待支付<br>SERVING：服务中<br>IN_DELIVERY：配送中<br>TO_USE：待使用<br>REFUNDING：退款中<br>CLOSED：已关闭<br>REFUNDED：已退款<br>FINISHED：已完成 |
| status_desc | String | 状态描述 | |
| shop_id | String | 门店ID | |
| shop_type | String | 店铺类型 | |
| shop_name | String | 门店名 | |
| shop_city_code | String | 门店所在城市代码 | |
| shop_address | String | 门店地址 | |
| settle_merchant_type | String | 结算商户属性 | |
| item_info | String | 商品信息 | goodsOrderId：商品订单ID<br>goodsId：商品id<br>goodsName：商品名称<br>quantity：数量<br>status：状态<br>price：商品价格<br>extInfo：扩展信息 |
| deliver_model | String | 配送方式 | PLATFORM_DELIVERY：平台配送<br>SELF_DELIVERY：自配送<br>NO_DELIVERY：无配送模式 |
| sub_channel | String | 饿侧二级渠道标识 | |
| out_status_desc | String | 外部状态描述 | |
| peer_refund_amount | String | 企业退款金额（元） | |
| consignee | String | 收货人姓名 | 取值来自供应服务商如饿了么 |
| consignee_mobile | String | 收货人电话 | 取值来自供应服务商如饿了么 |
| consignee_province_name | String | 收货人所在省份 | 取值来自供应服务商如饿了么 |
| consignee_city_name | String | 收货人所在城市 | 取值来自供应服务商如饿了么 |
| consignee_district_name | String | 收货人所在区县 | 取值来自供应服务商如饿了么 |
| deliver_address | String | 配送地址 | 取值来自供应服务商如饿了么 |
| order_remark | String | 订单备注 | 取值来自供应服务商如饿了么 |
| ext_info | String | 扩展信息 | agreement_peer_payer_id：协议代付人UID<br>expenseRuleGroupId：费控规则ID<br>expense_type：费用类型<br>expense_type_sub_category：费用类型子类目<br>expense_scene_code：费用场景 |

## 其他场景

| 字段名 | 字段类型 | 字段含义 | 备注 |
|--------|----------|----------|------|
| parent_order | String | 是否是父订单 | 0：否，1：是 |
| parent_order_id | String | 父订单ID | |
| order_time | String | 订单时间 | |
| pay_time | String | 订单支付时间 | |
| order_amount | String | 订单金额 | |
| merchant_id | String | 商户ID | |
| merchant_name | String | 商户名称 | |
| peer_pay_amount | String | 代付金额 | |
| peer_refund_amount | String | 代付退款金额 | |
| peer_refund_status | String | 代付退款状态 | INIT: 未退款<br>REFUND_PART: 部分退款<br>REFUND_FULL: 全部退款 |
| ext_infos | String | 扩展信息 | agreement_peer_payer_id：协议代付人UID<br>expenseRuleGroupId：费控规则ID<br>expense_type：费用类型<br>expense_type_sub_category：费用类型子类目<br>expense_scene_code：费用场景 |
