# dut.agent.third（第三方代扣执行）

## 接口定位

| 项 | 值 |
| --- | --- |
| 模块 | 代扣 |
| 网关 | `https://mapi.alipay.com/gateway.do` |
| `service` | `dut.agent.third` |
| 接入模型 | 旧版 MAPI Query String + MAPI 签名 |
| 返回形态 | XML 同步返回；最终结果由主动查询确认 |

该接口用于基于 12306 原始支付串发起三方免密代扣。代扣链路生成时必须同时覆盖代扣结果查询；代扣结果通知面向商户侧，不在接入方代码中实现。

## 固定值

| 参数 | 值 | 规则 |
| --- | --- | --- |
| `protocol_code` | `mr_dut_third` | 火车票/12306 场景固定值 |
| `item_code` | `DEFAULT` | 固定值 |
| `enable_pay_channels` | `enterprisePay` | 因公付代扣必须传 |

不要使用历史航空票样例中的 `air_dut_third`。三方免密代扣火车票场景必须使用 `mr_dut_third`。

## 请求参数

| 参数 | 含义 | 规则 |
| --- | --- | --- |
| `service` | 接口名称 | 固定为 `dut.agent.third` |
| `partner` | ISV/商户 PID | 外层服务商 PID，从配置读取，不得硬编码 |
| `_input_charset` | 请求字符集 | 签名、URL 编码和响应兜底解码必须一致 |
| `sign_type` | 签名类型 | 按商户 MAPI 配置，常见为 `RSA` |
| `sign` | MAPI 签名 | 排除 `sign`、`sign_type` 和空值后只签外层 MAPI 参数，不重签 12306 内层参数 |
| `protocol_code` | 代扣协议码 | 固定 `mr_dut_third` |
| `item_code` | 代扣项目码 | 固定 `DEFAULT` |
| `enable_pay_channels` | 支付渠道 | 因公付场景固定 `enterprisePay` |
| `submit_param` | 12306 原始支付 Query String 的 base64 | 必传；保持原始 key、value、编码和签名 |
| `business_info` | 因公付账户选择 JSON 字符串 | 因公付必传，格式 `{"assignJointAccountId":"<account_id>"}` |
| `trans_account_out` | 客票平台付款方支付宝人民币资金账号 | 必传；从产品路由或账户配置获取，不得由 `partner` 拼接推导 |
| `payer_user_id` | 实际付款员工支付宝 UID | 必传业务字段；发起前校验非空 |
| `out_biz_no` | ISV 侧业务流水号 | 必传，用于本地对账、查询关联和幂等 |
| `create_time` | 代扣发起时间 | 格式如 `YYYY-MM-DD HH:mm:ss` |
| `operator_id`、`operator_name` | 多操作员字段 | 商户账号启用多操作员时才传 |
| `dut_security_code_sign` | 旧代扣安全码摘要 | 历史 MAPI 字段；除非当前产品路由要求，否则不要臆造 |

历史 MAPI 文档还可能出现 `pnr`、`airline_account`、`platform_pid`、`platform_sign`、`user_pay_type` 等航空票或平台推广字段。火车票/12306 因公付场景不要默认生成这些字段；只有当前产品路由、已签约能力或用户明确要求时才作为可选扩展接入，并说明来源。

## 运行时必填校验

发起请求前必须校验以下字段非空且非空白：

- `business_info.assignJointAccountId`
- `trans_account_out`
- `payer_user_id`
- `submit_param`
- `out_biz_no`

缺失时直接拒绝请求，不要先落库、不要发起 MAPI 请求、不要把 `assignJointAccountId:null` 或空资金账号写进请求。代扣执行还必须在落库和发起前完成协议有效性确认、`submit_param` 只读诊断、`ord_pmt_timeout` 时效检查，以及 `payer_user_id` 与当前外部交易的绑定检查。协议有效性确认必须发生在生成新代扣订单和调用 `dut.agent.third` 之前。

协议有效性不仅是 `NORMAL` 状态，还必须确认协议主体就是本次付款人：本地可信协议记录或可信协议查询响应中的 `alipay_user_id` 必须等于本次 `dut.agent.third` 请求的 `payer_user_id`。如果协议记录绑定的是其他支付宝 UID，即使状态是 `NORMAL`，也应按身份不匹配拒绝，不得落新代扣订单、不得调用 MAPI。


## `submit_param` 构造

`submit_param` 不是 JSON。构造步骤：

1. 获取 12306 原始支付 URL。
2. 截取 `?` 后的原始 Query String。
3. 保留原始 key、value、URL 编码、空值字段和 12306 侧 `sign`，不要重排、改写或重签。若上游按当前产品契约已去除非支付噪音参数，接收处理后的 Query String；代码不要在没有明确契约的情况下自行删除字段。字段白名单只用于只读校验和风险拦截，不能用来重拼 `submit_param`，也不能要求字段顺序与样例一致。
4. 对这段 Query String 做 base64。
5. 将 base64 结果作为外层 MAPI 参数 `submit_param`。

12306 内层字段要按已确认的支付串样例字段清单做白名单校验。当前接通样例为 15 个子参数；如果上下文没有提供完整字段清单，先要求补齐或暂停生成具体白名单，不能为了凑字段数臆造参数名。生成代码应把字段集合集中成常量或配置，并拆成三类：

- 允许字段集合：只允许已确认样例里的字段进入新代扣发起；出现示例字段以外的参数时返回 `SUBMIT_PARAM_SIGN_ERROR` 风险诊断并拒绝或暂停确认，不得静默忽略后继续发起。
- 必填且非空字段集合：至少包括 `service`、`partner`、`ord_id_ext`，以及当前产品路由明确要求非空的金额、币种、时间、签名等字段。必填字段缺失、值为空或全空白时 fail fast。
- 允许空值字段集合：例如当前样例中允许为空的客户端扩展字段，只能原样保留在 base64 前的 Query String 中；不得补默认值、删除、重排或重签。

白名单校验不比较字段顺序；同一组合法字段只要拼接格式正确、必填和可空规则满足，就不能因为顺序与样例不同而拒绝。

常见 12306 内层字段包括 `dispatch_cluster_target`、`ord_amt`、`ord_cur`、`ord_id_ext`、`ord_time_ext`、`notify_url`、`ord_pmt_timeout`、`partner`、`service=alipay.acquire.mr.ord.createandpay`、`return_url`、`req_access_type=wap`、`req_client_ip_ext`、`sign_type=RSA`、内层 `sign` 和客户端 IP 相关字段。具体字段名以已确认字段清单为准；生成代码不要为了凑字段数臆造参数。

生成代码可以只读解析 `submit_param` 用于校验和建立映射，但不能重排、改写或重签 12306 内层参数。代扣发起前至少校验：

- `service` 等于 `alipay.acquire.mr.ord.createandpay`。
- `partner` 非空，并保存为后续 `dut.agent.query.third.trade_partner`。
- `ord_id_ext` 非空，并保存为 12306 原始订单号。
- 原始 Query String 片段均为 `key=value` 且只能以 `&` 拼接；不能接受 `;`、换行或空白作为分隔符。连续 `&&`、结尾 `&`、空片段、非 `key=value` 片段、空 key、重复 key、关键字段空值或当前产品契约外异常字段应返回 `SUBMIT_PARAM_SIGN_ERROR` 风险诊断并拒绝发起或暂停确认。普通允许空值字段不得擅自删除、补值、重排或重签。
- 如果内层 `ord_pmt_timeout` 存在，先按真实上游支付串样例、产品契约或配置化解析策略确认格式；当前底层文档没有明确格式时，不要臆测为固定 epoch 秒/毫秒或固定日期格式。配置化解析策略必须从运行时配置、构造参数或明确产品常量进入解析代码，不能只有类内 setter、默认枚举值或注释说明。无法识别格式时返回明确诊断并暂停发起；解析后已过期或距离当前不足 60 秒时拒绝发起新代扣，并返回 `PAYMENT_TIMEOUT` 风险诊断。已有订单幂等重试不应被 `ord_pmt_timeout` 拦截；需要用 `ord_id_ext` 命中幂等时，可先做不触发时效判断的只读结构提取，再在确认没有已有订单后执行时效校验。
- 内层 `notify_url`、`return_url` 属于 12306/商户侧原始参数，只能随 `submit_param` 原样保留；不要解析成接入方回调地址、页面跳转地址、验签入口或状态更新逻辑。`ord_amt`、`ord_cur`、`ord_time_ext` 等对账字段如当前业务需要，可只读解析并随本地订单保存。
- 同一个 `submit_param`、`ord_id_ext` 或 `out_order_no` 必须与同一个 `payer_user_id` 绑定；不要用同一笔外部交易换付款人重试。重复外部单号或重复支付串应作为幂等重试处理，或重新获取新的上游支付串后再发起新支付。幂等重试必须在发起 MAPI 前返回已有订单/已有同步结果/明确幂等结果，不得生成新 `out_biz_no` 或再次调用 `dut.agent.third`。代扣入口必须先按 `out_order_no` 查询已有订单，并且这一步必须发生在 `submit_param` 构造、base64、解码、白名单/必填校验、`ord_pmt_timeout` 校验或 `ord_id_ext` 提取之前；只有 `out_order_no` 未命中时，才允许轻量提取 `ord_id_ext` 做第二路径幂等查询。对已存在订单且 `payer_user_id` 一致的重试，优先返回已有幂等结果；不要因为当前协议状态已变为 `UNSIGNING/FAILED`、原支付串 `ord_pmt_timeout` 已过期/不足 60 秒，或本次支付串存在缺少 `partner`、示例外字段、重复 key、错误分隔符等结构异常而再次进入新单门禁后拒绝已有结果。协议 `NORMAL + alipay_user_id=payer_user_id` 门禁和 `ord_pmt_timeout` 时效门禁都用于新代扣发起。幂等返回里的 `out_order_no` 应使用已有订单保存的 canonical 值；如果通过 `ord_id_ext` 命中已有订单但本次 `out_order_no` 与已有订单不一致，返回已有订单的 `out_order_no` 或拒绝/诊断，不能混合返回本次入参。

## 同步 XML 返回

接口返回 XML 同步响应，常见字段包括 `is_success`、`request`、`response`、`trade`、`out_order_no`、`trade_no`、`trade_status`、`protocol_code`、`item_code`、`user_pay_type`、`trans_account_out`、`pay_account_no`、`pay_logon_id`、`receive_account_no`、`receive_logon_id`、`total_fee`、`available_balance`、`contract_credit_available_amount`、`credit_available_amount`、`web_notify_url` 等。

处理建议：

- 先判断 HTTP 状态；非 2xx 按传输失败处理。
- 根据 `Content-Type charset`、XML declaration、`_input_charset` 顺序决定响应字符集。
- 已按响应 charset 解码为字符串后，用字符流解析 XML。
- 按 MAPI XML 同步响应规则抽取业务响应节点并验签；验签失败、缺少 `sign`、XML 解析失败或无法抽取签名参数时，同步响应只表示本次无法确认，必须保持发起代扣后的原订单状态（例如 `WITHHOLDING`），不得置为 `SYNC_FAILED` 或其他失败态，也不得写回 `out_order_no`、`trade_no` 等响应字段；返回给调用方时也不得把未验签响应里的业务字段原样返回，只能返回失败诊断和本地已可信定位字段。
- 验签通过后，才允许解析并持久化同步返回中的 `out_order_no` 或 `trade_no`，供代扣查询使用。
- 金额、付款账号、收款账号、交易状态等返回字段可用于本地对账；不要把余额、信用额度、预存卡余额等展示性字段作为支付成功的唯一依据。
- 同步成功不等于最终支付成功；接入方应通过主动查询确认最终结果。

## 代扣结果通知边界

代扣结果通知面向商户侧，不是接入方服务端能力。生成接入方代码时必须遵守：

- 不给 `dut.agent.third` 额外传接入方外层 `notify_url`，不新增 `withholdNotifyUrl`、`notifyProperties.getWithholdUrl()` 等接入方回调配置。
- 不生成 `/notify/withhold`、`WithholdingNotifyHandler`、`handleWithholdNotify`、通知验签、`notify_id` 幂等、`notify_verify`、通知测试或通知状态流转。
- 12306 原始支付串中的内层 `notify_url`、`return_url` 属于商户侧原始参数，只能随 `submit_param` 原样保留；不要改写、替换或暴露为接入方回调/跳转地址，不生成代扣 `return_url` 承接、验签或状态逻辑。
- 最终支付结果由 `dut.agent.query.third` 主动查询确认，或由上游商户系统在接入方之外处理。

## 生成要求

- 代扣链路必须同时生成代扣执行和代扣查询；不得生成接入方代扣通知处理，也不得生成代扣 `return_url` 页面承接处理。
- `submit_param` 必须按原始 Query String base64 构造，不能解析成 JSON；测试要覆盖编码、空值字段和内层 `sign` 不被删除、不被重拼，且字段顺序不同不会被白名单误拒绝。
- `submit_param` 内层校验必须有字段白名单、必填字段集合、允许空值字段集合；测试要覆盖示例外字段、必填字段缺失、必填字段空值、允许空值字段保留、重复 key、连续/结尾 `&`、非 `key=value` 片段和错误分隔符场景。
- 外层 `partner` 与内层 `submit_param.partner` 含义不同，必须分别保存。
- `trade_partner` 取 decoded `submit_param.partner`，不是外层 `partner`。
- 代扣新单发起前必须先确认协议有效，再对 `submit_param` 做只读诊断：缺少 `service/partner/ord_id_ext`、存在非 `key=value` 片段、空 key、重复 key、关键字段空值、拼接分隔符错误或当前产品契约外异常字段时拒绝或暂停确认；`ord_pmt_timeout` 的格式必须来自真实样例/产品契约/配置化解析策略，不能无依据固定猜成 epoch 秒，解析后已过期或距当前不足 60 秒时不得调用 MAPI。协议未确认 `NORMAL`、处于 `SIGNING/UNSIGNING/FAILED`、缺少协议定位、查询不可确认或协议 `alipay_user_id` 与本次 `payer_user_id` 不一致时不得落新代扣订单、不得调用 `dut.agent.third`。不要在已有订单幂等判断前执行会抛出 `PAYMENT_TIMEOUT` 的完整 `submit_param` 校验。
- 同一外部交易与 `payer_user_id` 的绑定必须有测试覆盖，避免用相同 `submit_param`、`ord_id_ext` 或 `out_order_no` 切换付款人重试；同付款人的重复请求也必须测试不再次调用 MAPI、不生成新 `out_biz_no`，而是返回已有订单/已有同步结果/明确幂等结果。测试还应覆盖已有订单幂等重试在当前协议状态变化、原支付串 `ord_pmt_timeout` 过期/不足 60 秒，或同 `out_order_no` 命中但本次支付串结构异常时仍返回已有结果，不落新单、不调用 MAPI。
- 代扣执行测试必须覆盖 `ord_id_ext` 命中已有订单但本次 `out_order_no` 不同的场景：返回已有订单 canonical `out_order_no`，或明确拒绝/诊断；不得返回已有 `out_biz_no/trade_no` 搭配本次未落库的 `out_order_no`。
- 代扣执行测试必须覆盖协议门禁：无协议、`SIGNING`、`UNSIGNING`、`FAILED`、协议查询不可确认或协议 `alipay_user_id` 与本次 `payer_user_id` 不一致时拒绝且不调用 `dut.agent.third`，只有本地可信 `NORMAL` 且协议主体等于付款人，或查询可信确认通过且主体匹配，才允许新发起代扣。
- 代扣执行返回给调用方时应显式携带本地 `out_biz_no` 以及可用于后续查询的 `out_order_no` 或 `trade_no`。
- 代扣执行同步 XML 响应必须先验签再更新本地状态或写回 `trade_no/out_order_no`；测试应覆盖验签失败、缺少签名、XML 解析失败或无法抽取签名参数时订单保持原状态（不得断言 `SYNC_FAILED`）、响应字段不被写回，并覆盖带 `<request><param name="...">` 的真实 MAPI XML 结构。
