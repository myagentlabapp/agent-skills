# 字段与接口规则

## 固定常量

| 常量 | 值 | 使用范围 |
| --- | --- | --- |
| `PRODUCT_CODE` | `DUT_AGENT_THIRD_P` | 签约、查询、解约 |
| `SALES_PRODUCT_CODE` | `DUT_AGENT_THIRD_V2` | 签约 |
| `SCENE` | `INDUSTRY|B2B_TICKET_AGENT` | 签约、查询、解约 |
| `PROTOCOL_CODE` | `mr_dut_third` | 代扣执行、代扣查询 |
| `ITEM_CODE` | `DEFAULT` | 代扣执行、代扣查询 |
| `ENABLE_PAY_CHANNELS` | `enterprisePay` | 因公付代扣执行 |

禁止把火车票场景写成 `air_dut_third`。

## 接口覆盖规则

三方免密代扣启用后必须覆盖签约 + 代扣完整链路，不提供“只签约/只代扣”拆分选择。下表按链路阶段列出覆盖要求，不代表可选范围。

| 链路阶段 | 接口文档 | 必须覆盖 |
| --- | --- | --- |
| 签约 | [协议页面签约](agreement/alipay.dut.customer.agreement.page.sign.md)、[协议查询](agreement/alipay.dut.customer.agreement.query.md)、[协议解约](agreement/alipay.dut.customer.agreement.unsign.md) | 页面跳转 URL、协议落库、协议查询刷新、解约请求、协议状态更新、`return_url` 处理建议；不得生成签约/解约 `notify_url` 或通知处理 |
| 代扣 | [第三方代扣执行](withholding/dut.agent.third.md)、[代扣结果查询](withholding/dut.agent.query.third.md) | `submit_param` 构造、内层字段校验、外层签名、同步 XML 解析、主动查询、订单状态更新、`payer_user_id/out_order_no/trade_partner/ord_id_ext` 来源和映射；不得生成接入方代扣通知处理 |

## 字段来源

| 字段 | 来源 |
| --- | --- |
| `partner` | 服务商/ISV 支付宝 PID |
| `external_user_id` | 服务商侧用户唯一标识 |
| `employee_open_id` / `openid` | 服务商可能只能获得的员工 openid；只能作为协议查询定位条件，不能作为代扣 `payer_user_id` |
| `principal_id` | 协议查询可信响应中的签约主体 ID；openid 查询路径下记录为员工支付宝 UID，供协议解约、代扣执行和主动查询使用 |
| `alipay_user_id` | 用户支付宝 UID；普通 UID 查询时来自服务商已掌握的 UID 或可信响应 `alipay_user_id`，openid 查询时来自可信响应 `principal_id` |
| `agreement_no` | 签约成功返回 |
| `external_sign_no` | 可选商户签约号；签约时传入才进入请求并持久化，查询/解约需要时从本地协议记录复用进 MAPI 请求，未传不得臆造或强制要求；代码必须有真实入参、实体字段、签约/查询/解约请求组装和测试覆盖 |
| `wallet_sign_url` / `sign_url` | ALIPAYAPP 钱包 H5 签约最终启动链接，格式为 `alipays://platformapi/startapp?appId=20000067&url=<encoded_mapi_sign_url>` |
| `assignJointAccountId` | 因公付账户 ID，由上游企业详情/账户查询获得 |
| `payer_user_id` | 实际付款员工支付宝 UID；用于代扣执行和主动查询，查询时从本地代扣订单复用执行代扣保存的同一 UID |
| `trans_account_out` | 客票平台付款方支付宝人民币资金账号 |
| `notify_url` | 仅指 12306 原始支付串里的内层商户侧字段；接入方不得新增外层代扣 `notify_url` 或回调配置 |
| `return_url` | 签约接口中是协议页面承接地址；`submit_param` 内层 `return_url` 是 12306/商户侧原始字段，代扣链路不得生成接入方跳转承接或状态逻辑 |
| `submit_param` | 12306 原始支付 URL 的 Query String base64 |
| `submit_param` 内层字段白名单 | 12306 支付串样例确认的子参数集合；当前接通样例为 15 个子参数。生成代码要集中维护允许字段、必填字段和允许空值字段，白名单只用于只读校验和风险拦截，不得用于重拼或重签 `submit_param` |
| `ord_pmt_timeout` | `submit_param` 内层支付超时时间；格式需来自真实支付串样例、产品契约或配置化解析策略，且策略必须从运行时配置、构造参数或明确产品常量进入解析代码；不得无依据固定猜成 epoch 秒；只读解析后已过期或距当前不足 60 秒时不得发起代扣 |
| `trade_partner` | 12306 商户 PID，来自解码后的 `submit_param.partner` |
| `out_order_no` | 当前代扣查询路由要求的订单号，必须来自明确业务映射、代扣执行返回或上游入参，不能随手生成 |
| `error` / `error_code` | MAPI 同步响应或通知返回的错误码，原样记录并透传给排查链路 |
| `agreement_detail`、`prod_properties`、`zm_auth_info`、`sub_merchant` | 协议类扩展字段，仅在当前产品路由要求时传入或保存 |
| `pay_account_no`、`receive_account_no`、`total_fee` | 代扣同步响应或查询响应中的对账字段，用于辅助校验和对账 |

## 火车票接通样例评审规则

本节只保留样例到通用代码的字段映射提醒；签名、HTTP、验签、状态流转和 `submit_param` 细节见 [通用代码生成规则](codegen-general-rules.md) 与对应接口文档。

- 外层 `partner` 是服务商/ISV PID，不能硬编码样例值。
- `PRODUCT_CODE`、`SALES_PRODUCT_CODE`、`SCENE`、`PROTOCOL_CODE`、`ITEM_CODE`、`ENABLE_PAY_CHANNELS` 使用上方固定常量，禁止串到航空票或其他产品路由。
- `ALIPAYAPP` 签约返回钱包 schema，`PC` 返回 MAPI URL；`channel` 先归一化再分支。
- `DUT_AGENT_THIRD_P` 签约/解约无服务端 `notify_url`；协议状态靠协议查询确认，协议 `return_url` 不能直接落最终状态。
- `external_sign_no` 可省略；签约传入才在本地协议、查询请求和解约请求中复用，未传不得随机生成或改为必填。
- 协议查询落库必须区分本地 `external_user_id`、员工 openid 和支付宝 `alipay_user_id`；使用 openid + `app_id` 查询时，可信响应里的 `principal_id` 保存为支付宝 UID，供协议解约、代扣执行和主动查询使用。
- `submit_param.partner` 是 12306 商户 PID，也是 `trade_partner` 来源，不是外层 `partner`。
- `submit_param` 按原始 Query String base64；白名单不校验字段顺序，异常字段、重复 key、坏分隔符或关键字段空值按风险诊断处理。
- `ord_pmt_timeout` 格式来源和时效门禁只用于新代扣；已有订单幂等重试不受当前支付串时效影响。
- `out_order_no` 与 `ord_id_ext` 分开保存；主动查询使用的订单号、商户 PID、付款人 UID 等字段都从代扣订单上下文读取，没有明确来源时，把缺口暴露为代扣返回解析、上游入参或持久化订单字段设计问题。
- 同一 `submit_param`、`ord_id_ext` 或 `out_order_no` 绑定同一 `payer_user_id`；重复请求按幂等处理，不换付款人重试。
- 新代扣前校验 `assignJointAccountId`、`trans_account_out`、`payer_user_id` 非空，并确认协议 `NORMAL` 且协议主体等于本次付款人。
- 代扣结果通知、代扣内层 `notify_url` 和代扣内层 `return_url` 都不由接入方处理。
- 错误码用于诊断和透传，不要求全量枚举，但不能吞掉 `ILLEGAL_SIGN`、`SYSTEM_ERROR`、`TRADE_NOT_EXIST`、`SUBMIT_PARAM_SIGN_ERROR`、`PAYMENT_TIMEOUT`、`TRADE_BUYER_NOT_MATCH`、`PAY_TYPE_NOT_AVAILABLE`、`USER_SIGN_NOT_FOUND` 等关键错误。

## 禁止项

以下是字段与接口层面的禁区；更细的签名、HTTP、响应解析和测试要求见通用规则与接口文档。

- 禁止把商户专属 PID、账户 ID、回调域名、样例外部单号或样例用户号硬编码在通用代码里。
- 禁止按 OpenAPI、航空票或其他产品模型生成本域接口。
- 禁止签名前提前 URL 编码业务值，或让签名/验签字节编码与 `_input_charset` 不一致。
- 禁止 `ALIPAYAPP` 签约返回裸 MAPI URL，或未归一化 `channel` 就分支。
- 禁止给 `DUT_AGENT_THIRD_P` 签约/解约传 `notify_url`，或生成签约/解约通知处理。
- 禁止用协议 `return_url` 直接写最终协议状态，或把协议查询不可确认写成协议失败。
- 禁止把 `alipay_user_id` 当作本地 `external_user_id`，或生成只接收 `alipay_user_id` 的协议确认入口。
- 禁止把员工 openid 当作代扣 `payer_user_id`；openid 查询路径必须从可信响应 `principal_id` 落库出支付宝 UID。
- 禁止把签约未传的 `external_sign_no` 后续随机生成、改为必填，或只停留在注释/测试文案。
- 禁止把 `submit_param` 当 JSON 解析、重排、改写、删除普通空值字段或重签。
- 禁止没有字段清单就臆造 `submit_param` 白名单，或忽略示例外字段、重复 key、坏分隔符、关键字段空值后继续发起代扣。
- 禁止把 `ord_pmt_timeout` 在无依据时固定解析为 epoch 秒，或让已有订单幂等重试被当前支付串时效拦截。
- 禁止生成接入方代扣通知、外层代扣 `notify_url`、代扣内层 `return_url` 承接或通知状态流转。
- 禁止用时间戳、UUID、本地随机流水或 `ord_id_ext` 冒充 `dut.agent.query.third.out_order_no`。
- 禁止同一 `submit_param`、`ord_id_ext` 或 `out_order_no` 换 `payer_user_id` 重试，或幂等命中后再次生成 `out_biz_no` 并调用 MAPI。
- 禁止在协议未可信确认为 `NORMAL` 或协议主体不等于本次 `payer_user_id` 时发起新代扣。
- 禁止主动查询覆盖已成功终态，或未完成验签、身份比对和对账就写回响应业务字段。
- 禁止主动查询用任一身份/对账字段匹配来放行另一个可比对字段冲突的响应。
- 禁止主动查询未实际更新时返回 `updated`，或在业务失败/缺少 `trade_status` 时直接写交易失败态。
