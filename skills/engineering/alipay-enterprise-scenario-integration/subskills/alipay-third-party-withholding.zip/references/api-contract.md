# 三方免密代扣接口文档索引

本文只作为接口索引和读取边界说明。生成代码时不要把本文当作五个接口的完整契约；应先读取流程和通用规则，再逐个读取下面的单接口文档。

## 接口总览

| 链路 | 用途 | `service` | 单接口文档 | 响应形式 |
| --- | --- | --- | --- | --- |
| 签约 | 代扣协议页面签约 | `alipay.dut.customer.agreement.page.sign` | [协议页面签约](agreement/alipay.dut.customer.agreement.page.sign.md) | 页面跳转；协议状态主动查询确认 |
| 签约 | 代扣协议查询 | `alipay.dut.customer.agreement.query` | [协议查询](agreement/alipay.dut.customer.agreement.query.md) | JSON/XML 同步返回，按实际响应解析 |
| 签约 | 代扣协议解约 | `alipay.dut.customer.agreement.unsign` | [协议解约](agreement/alipay.dut.customer.agreement.unsign.md) | JSON/XML 同步返回；解约结果主动查询确认 |
| 代扣 | 第三方代扣执行 | `dut.agent.third` | [第三方代扣执行](withholding/dut.agent.third.md) | XML 同步返回；最终结果主动查询确认 |
| 代扣 | 代扣结果查询 | `dut.agent.query.third` | [代扣结果查询](withholding/dut.agent.query.third.md) | XML 同步返回 |

五个接口都使用旧版 MAPI 网关 `https://mapi.alipay.com/gateway.do`、URL Query String 参数和 MAPI `sign`。不要按 OpenAPI `method/app_id/biz_content` 模型生成。

## 读取边界

三方免密代扣不做“只签约/只代扣”拆分选择。只要接入本域，必须读取并覆盖五个接口文档，形成签约 + 协议确认/解约 + 代扣执行 + 代扣查询的完整链路。

本域不包含接入方代扣结果通知。代扣内层通知面向 12306/商户侧，不得生成接入方代扣通知入口。

## 通用基础参数

| 参数 | 用法 |
| --- | --- |
| `service` | 接口名，取单接口文档对应值。 |
| `partner` | ISV/商户 PID，例如 `<isv_pid>`；不得把商户专属 PID 写死在通用代码里。 |
| `_input_charset` | 新接入优先使用 `utf-8`；历史文档和老样例也出现过 `gbk`。签名、验签和响应解码要与该字符集保持一致。 |
| `sign_type` | 接通样例使用 `RSA`；原始 MAPI 文档中也有 `MD5` 样例。除非目标 MAPI 产品明确支持，否则不要切到 OpenAPI 常见的 `RSA2`。 |
| `sign` | 对请求参数做 MAPI 签名后的结果；待签名串过滤空值、`sign` 和 `sign_type` 后按参数名排序拼接。 |
| `format` | 协议类接口常见为 `JSON`；代扣执行/查询按 XML 返回处理。 |

## 通用同步响应处理

所有 MAPI 同步调用都先判断 HTTP 传输结果，再解析业务响应：

- HTTP 非 2xx：按传输失败处理并返回或抛出明确错误；不要把 `errorStream`、HTML 错误页或网关错误文本当作正常 JSON/XML 继续解析。
- HTTP 2xx：协议类接口按单接口文档的 JSON/XML/页面跳转约定处理；代扣执行和代扣查询按 XML 解析。
- 响应字符集优先从响应 `Content-Type` 的 `charset` 或 XML declaration 读取；没有声明时使用 `_input_charset`；最后才 fallback 到 UTF-8。
- 代扣执行/查询同步 XML 如果已经在 HTTP 层按响应 charset 解码为字符串，XML 解析器必须用字符流解析，例如 Java `StringReader`/`InputSource`；不要再 `xml.getBytes(UTF-8)` 后用字节流解析。
- 同步响应里的 `error`/`error_code` 要原样保留，便于重试、对账和人工排查；不要把所有错误折叠成一个泛化异常。
- 错误码附录用于诊断和映射，不要求生成全量枚举类。需要枚举时只纳入当前业务会处理的错误，并保留未知错误透传能力。
