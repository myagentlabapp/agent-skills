# 费控 Python/Go/.NET 质量门禁

本文件只约束 Python、Go、.NET 等非 Java/Node.js 生成代码。通用原则见 [费控通用代码生成规则](../codegen-general-rules.md)，字段和接口来源见 [费控字段和接口规则](../field-interface-rules.md)。

1. 生成前必须确认当前语言使用官方 SDK 还是 HTTP(S) 网关调用；没有真实 SDK 能力时使用文档字段手拼请求体，但字段名和嵌套路径必须完全来自接口文档。
2. 制度创建必须生成 `standard_info_list`；`standard_condition_info_list` 必须挂在使用规则下，费用子类使用 `standard_info_list.expense_type_sub_category`。
3. 不得生成文档不存在、近义改名、扁平化或跨接口借用字段；常见反例包括 `expense_type_sub`、`expense_sub_type`、`standard_rules`、`condition_list`、`use_rules`。
4. 内部费控制度不得只配置商户、时间、位置等使用限制；调用 `institution.create` 前必须具备发放规则、制度可用额度的限额条件，或已实现手工发放接口。
5. 外部费控 SPI 必须真实实现咨询、扣减、退还、状态查询和幂等；不得固定返回允许消费、扣减成功、退还成功、固定额度或空幂等查询。
6. 不得生成验签直接 `return true`、`NotImplementedError` / `NotImplementedException`、本地 SDK stub 或 mock-success 逻辑。
7. 生成后必须运行本域 validator；validator 会做跨语言字段结构和 SPI 占位检查，并在运行时存在时执行 Python 语法检查、`go test ./...` 或 `dotnet build`。
