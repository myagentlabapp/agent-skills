# alipay.ebpp.invoice.institution.create(制度新增)
支持第三方代理调用：本接口支持第三方开发者代用户发起调用
## 通用场景
制度新增，包含制度下使用规则列表、发放规则列表和适用范围的新增。
注意：制度下最多支持10条使用规则，10条发放规则
### 公共请求参数
|参数英文名|类型|是否必选|长度/取值|描述|示例值|
|---|---|---|---|---|---|
|app_id|String|必选|32|支付宝分配给开发者的应用ID|2014072300007148|
|method|String|必选|128|接口名称|alipay.ebpp.invoice.institution.create|
|format|String|可选|40|仅支持JSON|JSON|
|charset|String|必选|10|请求使用的编码格式，如utf-8,gbk,gb2312等|utf-8|
|sign_type|String|必选|10|商户生成签名字符串所使用的签名算法类型，目前支持RSA2和RSA，推荐使用RSA2|RSA2|
|sign|String|必选|344|商户请求参数的签名串，详见[签名](https://ideservice.alipay.com/cms/site/02khjm)|详见示例|
|timestamp|String|必选|19|发送请求的时间，格式"yyyy-MM-dd HH:mm:ss"|2014-07-24 03:07:50|
|version|String|必选|3|调用的接口版本，固定为：1.0|1.0|
|app_auth_token|String|可选|40|详见[应用授权概述](https://ideservice.alipay.com/cms/site/04h2nx)|null|
|biz_content|String|必选||请求参数的集合，最大长度不限，除公共参数外所有请求参数都必须放在这个参数中传递，具体参照各产品快速接入文档|null|
### 业务请求参数
|参数英文名|类型|是否必选|长度/取值|描述|示例值|
|---|---|---|---|---|---|
|enterprise_id|String|特殊可选|32|企业id**注意事项**通过企业码2.0签约接口签约，只填写企业id，无需填写共同账户id和授权签约协议号。**必选条件**2.0签约的企业必须填写该字段|2088123412341234|
|institution_name|String|必须|50|制度名称**注意事项**敏感词校验，请避免填写敏感词|费用制度|
|outer_source_id|String|可选|64|外部唯一标识，可用于防止重复创建**注意事项**企业维度内全局唯一|0b26c12b16900047742372557ee431|
|expense_type|String|必须|32|费用类型**枚举值**餐饮:MEAL地铁:METRO**注意事项**更多费用类型，查看详细文档 [详细文档](expense-type-enum.md)|MEAL|
|institution_desc|String|可选|200|制度描述**注意事项**敏感词校验，请避免填写敏感词|餐补制度|
|effective_start_date|Date|必须|32|制度生效起始时间**注意事项**最小粒度为天，最早是当日，时分秒必须为00:00:00。|2022-09-10 00:00:00|
|effective_end_date|Date|必须|32|制度生效结束时间**注意事项**最小粒度为天，结束时间不早于起始时间，时分秒必须为23:59:59，最晚不超过2222-01-01 23:59:59|2022-09-30 23:59:59|
|consult_mode|String|可选|16|费控咨询模式，默认为0。**枚举值**支付宝内部计算规则可用额度:0咨询外部服务商规则可用额度:1**注意事项**事项一： 咨询模式为1时，存在以下约束： 1、不可创建发放规则 2、不可创建额度相关规则的条件 3、使用规则的消费模式只支持“默认”。 事项二： 企业可同时创建内算和外算制度，初次接入外算请先联系技术支持做数据配置。 |0|
|issue_rule_info_list|IssueRuleInfo|可选|null|发放规则列表**注意事项**一个制度下最多可创建10条发放规则也可以不创建发放规则。咨询模式为“咨询外部服务商”时不支持设置发放规则。||
|issue_rule_info_list.issue_rule_name|String|可选|20|发放规则名称**注意事项**创建或修改时，会校验敏感词，请避免填写敏感词。|日额度|
|issue_rule_info_list.target_type|String|可选|32|发放规则归属的目标类型**枚举值**制度:INSTITUTION**注意事项**制度创建接口无需填写此字段。新增发放规则接口需要填写该字段，指定新增规则对应的目标类型，例如：新增发放规则为制度下的发放规则，则填写INSTITUTION|INSTITUTION|
|issue_rule_info_list.target_id|String|可选|32|目标id**注意事项**制度创建接口无需填写此字段，发放规则新增时与target_type配合填写，当target_type为INSTITUTION时，该字段填写对应的制度id，表示创建的发放规则为指定制度id下的发放规则|2023042600152617860000076000|
|issue_rule_info_list.outer_source_id|String|可选|64|外部发放规则id**注意事项**事项一：制度内发放规则该字段不允许重复。 事项二：创建制度时该字段必填。 事项三：创建发放规则时选填，如果填写可保证创建发放规则幂等。|123456|
|issue_rule_info_list.quota_type|String|必须|32|额度类型**枚举值**点券:COUPON（周期发放推荐使用）余额:CAP|COUPON|
|issue_rule_info_list.issue_type|String|必须|32|发放类型**枚举值**按日发放:ISSUE_DAY按月发放:ISSUE_MONTH按周发放:ISSUE_WEEK按季发放:ISSUE_SEASON按年发放:ISSUE_YEAR按间夜发放:ISSUE_ROOM_NIGHT**注意事项**更多说明请参考文档[接入文档](issue-rule-fields.md)|ISSUE_MONTH|
|issue_rule_info_list.effective_period|String|可选|100|生效时间段**注意事项**发放资产的有效时间段，该字段为空时，默认为不限制。当发放资产为余额时，仅支持设置为不限，当发放资产为点券时，可支持设置多种值。具体传值格式请参考文档 [接入文档](issue-rule-fields.md)|{\"all\":true}|
|issue_rule_info_list.invalid_mode|Number|可选|32|累计类型，默认为0 可选值：0（不可累计）、1（可累计）、2（累计天数）、3（累计到指定日期）**注意事项**当资产按日、月、周、季、年周期发放时，资产有效期默认为周期起始和结束时间，如果想延长资产的有效期，可通过该字段自定义发放资产的结束时间期，例如：发放周期为按日发放，默认点券有效期为发放日的00:00:00-23:59:59，通过将该字段设置为1，发放点券时结束时间将设置为长期有效。如果设置为2或3，需要配置invalid_mode_value使用，具体设置说明请参考文档[接入文档](issue-rule-fields.md)|0|
|issue_rule_info_list.invalid_mode_value|String|可选|10240|累计类型值**注意事项**与invalid_mode配置使用，具体使用说明请参考文档 [接入文档](issue-rule-fields.md)|3213|
|issue_rule_info_list.issue_amount_value|String|必须|10240|发放金额，单位元**注意事项**支持两种发放： 1、按城市发放不同的金额 2、按统一标准发放金额 具体填写说明请参考文档[接入文档](issue-rule-fields.md)|200|
|issue_rule_info_list.share_mode|Number|可选|32|是否可转赠**注意事项**可选值：0（不可转赠）、1（可转赠），默认为0。 该字段决定发放规则发放的资产是否可转赠给同制度下的其他人员|0|
|issue_rule_info_list.issue_start_date|Date|特殊可选|32|发放规则有效起始时间**注意事项**如果target_type指定INSTITUTION，则使用制度有效期起始时间，无法指定。|2022-08-10 00:00:00|
|issue_rule_info_list.issue_end_date|Date|特殊可选|32|发放规则有效结束时间**注意事项**如果target_type指定INSTITUTION，则使用制度有效期结束时间，无法指定|2022-12-31 23:59:59|
|standard_info_list|StandardInfo|必须|null|使用规则列表**注意事项**一个制度下最少有1条使用规则，最多创建10条使用规则。||
|standard_info_list.outer_source_id|String|可选|64|外部使用规则id，制度内使用规则该字段不允许重复**注意事项**事项一：制度内使用规则该字段不允许重复。 事项二：创建制度时该字段必填。 事项三：创建使用规则时选填，如果填写可保证创建使用规则幂等。|123456|
|standard_info_list.standard_name|String|必须|50|规则名称|单笔额度1元钱|
|standard_info_list.open_rule_id|String|可选|32|开票规则id，可通过接口alipay.ebpp.invoice.enterpriseconsume.enterpriseopenrule.create 创建并得到开票规则ID|2021070100152721370000002201|
|standard_info_list.payment_policy|String|可选|32|支付策略 当笔消费金额大于规则可用余额时，用于控制支付策略，该字段缺省时采取因公账户和个人账户组合支付策略**枚举值**全部个人支付:PERSONAL因公账户和个人账户组合支付:COMBINATION|PERSONAL|
|standard_info_list.consume_mode|String|可选|32|消费模式，不填为默认模式，枚举值：COUPON_ONLY（仅支持点券，发放规则指定发放点券或者手工发放点券的时候使用） COUPON_AND_CAP（支持点券+余额，发放规则指定发放点券和余额或者手工发放点券和余额的时候使用） COUNT（仅支持次卡） DEFAULT（默认模式，没有发放规则或者手工发放的时候使用）；**枚举值**仅支持点券:COUPON_ONLY支持点券+余额:COUPON_AND_CAP仅支持次卡:COUNT默认模式:DEFAULT|COUPON_ONLY|
|standard_info_list.expense_type_sub_category|String|可选|32|费用类型子类**枚举值**外卖:TAKE_AWAY到店:REACH_SHOP地铁:METRO用车:CAR默认:DEFAULT**注意事项**更多费用类型子类，查看详细文档 [详细文档](expense-type-enum.md)|TAKE_AWAY|
|standard_info_list.standard_desc|String|可选|48|使用规则描述(敏感词校验)|使用规则描述样例|
|standard_info_list.asset_share_source_info|AssetShareSourceInfo|可选|null|当前规则可使用的其他资产来源信息||
|standard_info_list.asset_share_source_info.share_mode|String|可选|32|当前规则可用的资产来源类型，搭配source_id_list使用。**枚举值**制度:INSTITUTION**注意事项**如果当前值为INSTITUTION，source_id_list内填写制度id列表，表示当前规则可使用列表中的制度的资产。|INSTITUTION|
|standard_info_list.asset_share_source_info.source_id_list|String|可选|28|资产共享来源id列表，与share_mode配合设置，如果share_mode为INSTITUTION，该值则填写制度id列表**注意事项**事项一：目前最多支持10个制度id； 事项二：不能设置本使用规则所属的制度id； 事项三：仅支持发放币种相同的制度之间共享资产； 事项四：制度的multi_employee_share_mode需要一致才可共享。|["2023031600152614950000031117"]|
|standard_info_list.standard_condition_info_list|StandardConditionInfo|可选|null|使用规则条件列表||
|standard_info_list.standard_condition_info_list.rule_factor|String|可选|32|条件类型**注意事项**指定条件id修改条件时，该字段不可变更，因此无需填写。 如需填写请参考文档填写 [详细文档](rule-factors.md)|QUOTA_TOTAL|
|standard_info_list.standard_condition_info_list.rule_value|String|必须|65535|费控条件值**注意事项**请参考文档填写[详细文档](rule-factors.md)|500|
|standard_info_list.standard_condition_info_list.rule_operator|String|可选|32|费控条件操作符 枚举值： LT("=","大于等于") GT(">","大于")**枚举值**小于:LT小于等于:LE等于:EQ不等于:NE大于等于:GE大于:GT**注意事项**该字段为保留字段，目前未被使用，无需填写|LE|
|standard_info_list.standard_condition_info_list.rule_name|String|可选|32|费控条件名称**注意事项**敏感词校验，请避免填写敏感词|单次消费金额|
|standard_info_list.personal_qrcode_mode|Number|可选|32|个人收款码转账是否支持因公付，默认为0。可选值：0（不支持）、1（支持）**注意事项**适用场景：个人收款码转账需支持因公付。默认无需设置此字段|0|
|institution_scope_info|InstitutionScopeInfo|可选|null|制度适用范围信息||
|institution_scope_info.adapter_type|String|特殊可选|32|制度适用范围，支持配置全员、指定员工和指定部门**枚举值**全员:EMPLOYEE_ALL指定员工:EMPLOYEE_SELECT指定部门:EMPLOYEE_DEPARTMENT**注意事项**填写指定员工时，设置人员上限为1000人；填写指定部门时，设置部门上限为100个。如需增加更多人员或部门可通过制度修改接口进行增量添加。**必选条件**创建制度时如需配置适用范围，该字段必填。|EMPLOYEE_SELECT|
|institution_scope_info.owner_type|String|特殊可选|32|员工id类型**枚举值**企业码员工id类型:ENTERPRISE_PAY_UID员工手机号类型:PHONE**注意事项**当适用范围为指定员工时该字段必填，表征员工id类型**必选条件**当适用范围为指定员工时该字段必填，表征员工id类型|ENTERPRISE_PAY_UID|
|institution_scope_info.owner_id_list|String|可选|32|适用范围归属id列表**注意事项**事项一：本接口可操作员工个数不超过1000，部门个数不超过100，超出以上范围请使用修改制度接口进行操作。 事项二：adapterType为EMPLOYEE_ALL时，无需填写；adapterType为EMPLOYEE_SELECT时，填写员工id（可通过设置owner_type来指定id类型，支持员工员工企业码id和员工手机号）; adapterType为EMPLOYEE_DEPARTMENT时，填写部门id|["2288004000000000"]|
|multi_employee_share_mode|String|可选|1|制度下额度是否支持多人共享。如果支持，则制度下资产所有人共享；如果不支持，则制度下的资产为个人资产，成员之间不共享。**枚举值**不支持:0支持:1**注意事项**该字段缺省为0，即默认为不支持共享。制度下不支持多人共享资产和单人资产共存，因此该字段决定了制度下所有资产的共享属性。|1|
|currency|String|可选|3|该字段用于管控制度下发放的资产币种，不填写默认为人民币，设置该字段后，制度下手工发放的资产币种均为设置值。**枚举值**英镑:GBP港元:HKD美元:USD新加坡元:SGD日元:JPY加拿大元:CAD澳大利亚元:AUD欧元:EUR新西兰元:NZD韩圆:KRW泰铢:THB瑞士法郎:CHF瑞典克朗:SEK丹麦克朗:DKK挪威克朗:NOK马来西亚林吉特:MYR印度尼西亚盾:IDR菲律宾比索:PHP毛里求斯卢比:MUR以色列新谢克尔:ILS斯里兰卡卢比:LKR俄国卢布:RUB阿联酋迪拉姆:AED捷克克郎:CZK南非兰特:ZAR卡塔尔里亚尔:QAR人民币:CNY**注意事项**事项一：如需配置非人民币币种，请先联系小二开通； 事项二：配置非人民币币种的制度，其使用规则不支持配置限额条件； 事项三：配置非人民币币种的制度不支持配置发放规则。|USD|
|scene_type|String|可选|32|因公场景**枚举值**加班:OVERTIME补贴福利:SUBSIDY差旅:TRAVEL招待:ENTERTAIN通用:DEFAULT|OVERTIME|
|agreement_no|String|可选|32|授权签约协议号（该字段将废弃，不建议使用，可用enterprise_id字段替换）**注意事项**可通过签约消息获取。配合account_id使用，当填写account_id时，此字段必填。|20225415889003553|
|owner_type|String|可选|32|适配id类型**枚举值**员工支付宝id类型:EMPLOYEE员工企业码id类型:ENTERPRISE_PAY_UID员工手机号类型:PHONE员工支付宝openid类型:EMPLOYEE_OPEN_ID**注意事项**事项一：当adapterType为指定员工时，通过该字段指定操作的owner_id类型，全员和指定部门时无需填写该字段。 事项二：使用企业id对接时，支持ENTERPRISE_PAY_UID和PHONE类型，使用共同账户id对接时，支持EMPLOYEE类型。|ENTERPRISE_PAY_UID|
|owner_id_list|String|可选|65535|适配id列表**注意事项**事项一：本接口可操作员工个数不超过1000，部门个数不超过100，添加更多适配范围请使用制度修改接口进行操作。 事项二：adapterType为EMPLOYEE_ALL时，无需填写；adapterType为EMPLOYEE_SELECT时，填写员工id（可通过设置owner_type来指定id类型，支持员工支付宝id，员工企业码id和员工手机号）; adapterType为EMPLOYEE_DEPARTMENT时，填写部门id|["2088402266061144","2088402266063146"]|
|owner_open_id_list|String|可选|65535|适配开放id列表**注意事项**切换open_id后请该字段：adapterType为EMPLOYEE_ALL时，无需填写；adapterType为EMPLOYEE_SELECT时，填写员工id（可通过设置owner_type来指定id类型，支持员工open_id，员工企业码id和员工手机号）; adapterType为EMPLOYEE_DEPARTMENT时，填写部门id|["abcdxxxx"]|
|payment_mode|String|可选|128|费控制度的出资类型**枚举值**企付:PEER_PAY个垫:OWNER_PAY，缺省使用PEER_PAY|PEER_PAY|
|adapter_type|String|可选|32|制度适配范围**枚举值**全员:EMPLOYEE_ALL指定员工:EMPLOYEE_SELECT部门:EMPLOYEE_DEPARTMENT**注意事项**该字段不填写，则表示暂不设置适配范围；填写指定员工时，设置人员上限为1000人；填写指定部门时，设置部门上限为100个。如需增加更多人员或部门可通过适配范围修改接口进行增量添加。|EMPLOYEE_ALL|
|account_id|String|可选|32|企业共同账户id（该字段将废弃，不建议使用，可用enterprise_id字段替换）**注意事项**通过企业码1.0接口签约的共同账户，和agreement_no搭配使用。|2088000194958956|
### 请求示例
#### 默认示例
##### csharp
```
 using System;
using System.Collections.Generic;
using Aop.Api;
using Aop.Api.Request;
using Aop.Api.Response;
using Aop.Api.Domain;
using Aop.Api.Util;
namespace SdkDemoTest
{
    public class AlipayEbppInvoiceInstitutionCreate
    {
        public static void Main(string[] args) 
        {
            // 初始化SDK
            IAopClient alipayClient = new DefaultAopClient(GetAlipayConfig());
            // 构造请求参数以调用接口
            AlipayEbppInvoiceInstitutionCreateRequest request = new AlipayEbppInvoiceInstitutionCreateRequest();
            AlipayEbppInvoiceInstitutionCreateModel model = new AlipayEbppInvoiceInstitutionCreateModel();
            
            // 设置企业id
            model.EnterpriseId = "2088123412341234";
            
            // 设置制度名称
            model.InstitutionName = "费用制度";
            
            // 设置外部唯一标识
            model.OuterSourceId = "0b26c12b16900047742372557ee431";
            
            // 设置费用类型
            model.ExpenseType = "MEAL";
            
            // 设置制度描述
            model.InstitutionDesc = "餐补制度";
            
            // 设置制度生效起始时间
            model.EffectiveStartDate = "2022-09-10 00:00:00";
            
            // 设置制度生效结束时间
            model.EffectiveEndDate = "2022-09-30 23:59:59";
            
            // 设置费控咨询模式
            model.ConsultMode = "0";
            
            // 设置发放规则列表
            List<IssueRuleInfo> issueRuleInfoList = new List<IssueRuleInfo>();
            IssueRuleInfo issueRuleInfoList0 = new IssueRuleInfo();
            issueRuleInfoList0.IssueStartDate = "2022-08-10 00:00:00";
            issueRuleInfoList0.InvalidMode = 0;
            issueRuleInfoList0.TargetType = "INSTITUTION";
            issueRuleInfoList0.IssueType = "ISSUE_MONTH";
            issueRuleInfoList0.EffectivePeriod = "{\"all\":true}";
            issueRuleInfoList0.OuterSourceId = "123456";
            issueRuleInfoList0.ShareMode = 0;
            issueRuleInfoList0.TargetId = "2023042600152617860000076000";
            issueRuleInfoList0.IssueAmountValue = "200";
            issueRuleInfoList0.IssueEndDate = "2022-12-31 23:59:59";
            issueRuleInfoList0.InvalidModeValue = "3213";
            issueRuleInfoList0.IssueRuleName = "日额度";
            issueRuleInfoList0.QuotaType = "COUPON";
            issueRuleInfoList.Add(issueRuleInfoList0);
            model.IssueRuleInfoList = issueRuleInfoList;
            
            // 设置使用规则列表
            List<StandardInfo> standardInfoList = new List<StandardInfo>();
            StandardInfo standardInfoList0 = new StandardInfo();
            standardInfoList0.StandardDesc = "使用规则描述样例";
            List<StandardConditionInfo> standardConditionInfoList = new List<StandardConditionInfo>();
            StandardConditionInfo standardConditionInfoList0 = new StandardConditionInfo();
            standardConditionInfoList0.RuleFactor = "QUOTA_TOTAL";
            standardConditionInfoList0.RuleName = "单次消费金额";
            standardConditionInfoList0.RuleValue = "500";
            standardConditionInfoList.Add(standardConditionInfoList0);
            standardInfoList0.StandardConditionInfoList = standardConditionInfoList;
            standardInfoList0.ExpenseTypeSubCategory = "TAKE_AWAY";
            standardInfoList0.PersonalQrcodeMode = 0;
            standardInfoList0.PaymentPolicy = "PERSONAL";
            standardInfoList0.ConsumeMode = "COUPON_ONLY";
            standardInfoList0.OuterSourceId = "123456";
            AssetShareSourceInfo assetShareSourceInfo = new AssetShareSourceInfo();
            assetShareSourceInfo.ShareMode = "INSTITUTION";
            List<String> sourceIdList = new List<String>();
            sourceIdList.Add("2023031600152614950000031117");
            assetShareSourceInfo.SourceIdList = sourceIdList;
            standardInfoList0.AssetShareSourceInfo = assetShareSourceInfo;
            standardInfoList0.StandardName = "单笔额度1元钱";
            standardInfoList0.OpenRuleId = "2021070100152721370000002201";
            standardInfoList.Add(standardInfoList0);
            model.StandardInfoList = standardInfoList;
            
            // 设置制度适用范围信息
            InstitutionScopeInfo institutionScopeInfo = new InstitutionScopeInfo();
            institutionScopeInfo.AdapterType = "EMPLOYEE_SELECT";
            List<String> ownerIdList = new List<String>();
            ownerIdList.Add("2288004000000000");
            institutionScopeInfo.OwnerIdList = ownerIdList;
            institutionScopeInfo.OwnerType = "ENTERPRISE_PAY_UID";
            model.InstitutionScopeInfo = institutionScopeInfo;
            
            // 设置是否支持多人共享额度
            model.MultiEmployeeShareMode = "1";
            
            // 设置币种
            model.Currency = "USD";
            
            // 设置出资类型
            model.PaymentMode = "OWNER_PAY";
            
            request.SetBizModel(model);
            // 第三方代调用模式下请设置app_auth_token
            // request.PutOtherTextParam("app_auth_token", "<-- 请填写应用授权令牌 -->");

            AlipayEbppInvoiceInstitutionCreateResponse response = alipayClient.Execute(request);

            if(!response.IsError)
            {
                Console.WriteLine("调用成功");
            }
            else
            {
                Console.WriteLine("调用失败");
            }
        }

        private static AlipayConfig GetAlipayConfig()
        {
            string privateKey  = "<-- 请填写您的应用私钥，例如：MIIEvQIBADANB ... ... -->";
            string alipayPublicKey = "<-- 请填写您的支付宝公钥，例如：MIIBIjANBg... -->";
            AlipayConfig alipayConfig = new AlipayConfig();
            alipayConfig.ServerUrl = "https://openapi.alipay.com/gateway.do";
            alipayConfig.AppId = "<-- 请填写您的AppId，例如：2019091767145019 -->";
            alipayConfig.PrivateKey = privateKey;
            alipayConfig.Format = "json";
            alipayConfig.AlipayPublicKey = alipayPublicKey;
            alipayConfig.Charset = "UTF-8";
            alipayConfig.SignType = "RSA2";
            return alipayConfig;
        }
    }
}
```
 

##### java
```
 package com.java.sdk.demo;

import com.alipay.api.AlipayApiException;
import com.alipay.api.AlipayClient;
import com.alipay.api.DefaultAlipayClient;
import com.alipay.api.AlipayConfig;
import com.alipay.api.domain.AlipayEbppInvoiceInstitutionCreateModel;
import com.alipay.api.domain.StandardInfo;
import com.alipay.api.domain.IssueRuleInfo;
import com.alipay.api.domain.AssetShareSourceInfo;
import com.alipay.api.domain.InstitutionScopeInfo;
import com.alipay.api.request.AlipayEbppInvoiceInstitutionCreateRequest;
import com.alipay.api.domain.StandardConditionInfo;
import com.alipay.api.response.AlipayEbppInvoiceInstitutionCreateResponse;

import com.alipay.api.FileItem;
import java.util.Base64;
import java.util.ArrayList;
import java.util.List;
import java.util.TimeZone;
import java.text.ParseException;
import java.text.SimpleDateFormat;

public class AlipayEbppInvoiceInstitutionCreate {

    public static void main(String[] args) throws AlipayApiException, ParseException {
        // 初始化SDK
        AlipayClient alipayClient = new DefaultAlipayClient(getAlipayConfig());
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        sdf.setTimeZone(TimeZone.getTimeZone("GMT+8"));

        // 构造请求参数以调用接口
        AlipayEbppInvoiceInstitutionCreateRequest request = new AlipayEbppInvoiceInstitutionCreateRequest();
        AlipayEbppInvoiceInstitutionCreateModel model = new AlipayEbppInvoiceInstitutionCreateModel();
        
        // 设置企业id
        model.setEnterpriseId("2088123412341234");
        
        // 设置制度名称
        model.setInstitutionName("费用制度");
        
        // 设置外部唯一标识
        model.setOuterSourceId("0b26c12b16900047742372557ee431");
        
        // 设置费用类型
        model.setExpenseType("MEAL");
        
        // 设置制度描述
        model.setInstitutionDesc("餐补制度");
        
        // 设置制度生效起始时间
        model.setEffectiveStartDate(sdf.parse("2022-09-10 00:00:00"));
        
        // 设置制度生效结束时间
        model.setEffectiveEndDate(sdf.parse("2022-09-30 23:59:59"));
        
        // 设置费控咨询模式
        model.setConsultMode("0");
        
        // 设置发放规则列表
        List<IssueRuleInfo> issueRuleInfoList = new ArrayList<IssueRuleInfo>();
        IssueRuleInfo issueRuleInfoList0 = new IssueRuleInfo();
        issueRuleInfoList0.setIssueStartDate(sdf.parse("2022-08-10 00:00:00"));
        issueRuleInfoList0.setInvalidMode(0L);
        issueRuleInfoList0.setTargetType("INSTITUTION");
        issueRuleInfoList0.setIssueType("ISSUE_MONTH");
        issueRuleInfoList0.setEffectivePeriod("{\"all\":true}");
        issueRuleInfoList0.setOuterSourceId("123456");
        issueRuleInfoList0.setShareMode(0L);
        issueRuleInfoList0.setTargetId("2023042600152617860000076000");
        issueRuleInfoList0.setIssueAmountValue("200");
        issueRuleInfoList0.setIssueEndDate(sdf.parse("2022-12-31 23:59:59"));
        issueRuleInfoList0.setInvalidModeValue("3213");
        issueRuleInfoList0.setIssueRuleName("日额度");
        issueRuleInfoList0.setQuotaType("COUPON");
        issueRuleInfoList.add(issueRuleInfoList0);
        model.setIssueRuleInfoList(issueRuleInfoList);
        
        // 设置使用规则列表
        List<StandardInfo> standardInfoList = new ArrayList<StandardInfo>();
        StandardInfo standardInfoList0 = new StandardInfo();
        standardInfoList0.setStandardDesc("使用规则描述样例");
        List<StandardConditionInfo> standardConditionInfoList = new ArrayList<StandardConditionInfo>();
        StandardConditionInfo standardConditionInfoList0 = new StandardConditionInfo();
        standardConditionInfoList0.setRuleFactor("QUOTA_TOTAL");
        standardConditionInfoList0.setRuleName("单次消费金额");
        standardConditionInfoList0.setRuleValue("500");
        standardConditionInfoList.add(standardConditionInfoList0);
        standardInfoList0.setStandardConditionInfoList(standardConditionInfoList);
        standardInfoList0.setExpenseTypeSubCategory("TAKE_AWAY");
        standardInfoList0.setPersonalQrcodeMode(0L);
        standardInfoList0.setPaymentPolicy("PERSONAL");
        standardInfoList0.setConsumeMode("COUPON_ONLY");
        standardInfoList0.setOuterSourceId("123456");
        AssetShareSourceInfo assetShareSourceInfo = new AssetShareSourceInfo();
        assetShareSourceInfo.setShareMode("INSTITUTION");
        List<String> sourceIdList = new ArrayList<String>();
        sourceIdList.add("2023031600152614950000031117");
        assetShareSourceInfo.setSourceIdList(sourceIdList);
        standardInfoList0.setAssetShareSourceInfo(assetShareSourceInfo);
        standardInfoList0.setStandardName("单笔额度1元钱");
        standardInfoList0.setOpenRuleId("2021070100152721370000002201");
        standardInfoList.add(standardInfoList0);
        model.setStandardInfoList(standardInfoList);
        
        // 设置制度适用范围信息
        InstitutionScopeInfo institutionScopeInfo = new InstitutionScopeInfo();
        institutionScopeInfo.setAdapterType("EMPLOYEE_SELECT");
        List<String> ownerIdList = new ArrayList<String>();
        ownerIdList.add("2288004000000000");
        institutionScopeInfo.setOwnerIdList(ownerIdList);
        institutionScopeInfo.setOwnerType("ENTERPRISE_PAY_UID");
        model.setInstitutionScopeInfo(institutionScopeInfo);
        
        // 设置是否支持多人共享额度
        model.setMultiEmployeeShareMode("1");
        
        // 设置币种
        model.setCurrency("USD");
        
        // 设置出资类型
        model.setPaymentMode("OWNER_PAY");
        
        request.setBizModel(model);
        // 第三方代调用模式下请设置app_auth_token
        // request.putOtherTextParam("app_auth_token", "<-- 请填写应用授权令牌 -->");

        AlipayEbppInvoiceInstitutionCreateResponse response = alipayClient.execute(request);
        System.out.println(response.getBody());

        if (response.isSuccess()) {
            System.out.println("调用成功");
        } else {
            System.out.println("调用失败");
            // sdk版本是"4.38.0.ALL"及以上,可以参考下面的示例获取诊断链接
            // String diagnosisUrl = DiagnosisUtils.getDiagnosisUrl(response);
            // System.out.println(diagnosisUrl);
        }
    }

    private static AlipayConfig getAlipayConfig() {
        String privateKey  = "<-- 请填写您的应用私钥，例如：MIIEvQIBADANB ... ... -->";
        String alipayPublicKey = "<-- 请填写您的支付宝公钥，例如：MIIBIjANBg... -->";
        AlipayConfig alipayConfig = new AlipayConfig();
        alipayConfig.setServerUrl("https://openapi.alipay.com/gateway.do");
        alipayConfig.setAppId("<-- 请填写您的AppId，例如：2019091767145019 -->");
        alipayConfig.setPrivateKey(privateKey);
        alipayConfig.setFormat("json");
        alipayConfig.setAlipayPublicKey(alipayPublicKey);
        alipayConfig.setCharset("UTF-8");
        alipayConfig.setSignType("RSA2");
        return alipayConfig;
    }
}
```
 

##### php
```
 <?php
require_once '../aop/AopClient.php';
require_once '../aop/AopCertClient.php';
require_once '../aop/AopCertification.php';
require_once '../aop/AlipayConfig.php';
require_once '../aop/request/AlipayEbppInvoiceInstitutionCreateRequest.php';

// 初始化SDK
$alipayClient = new AopClient(getAlipayConfig());
// 构造请求参数以调用接口
$request = new AlipayEbppInvoiceInstitutionCreateRequest();
$model = array();

// 设置企业id
$model['enterprise_id'] = "2088123412341234";

// 设置制度名称
$model['institution_name'] = "费用制度";

// 设置外部唯一标识
$model['outer_source_id'] = "0b26c12b16900047742372557ee431";

// 设置费用类型
$model['expense_type'] = "MEAL";

// 设置制度描述
$model['institution_desc'] = "餐补制度";

// 设置制度生效起始时间
$model['effective_start_date'] = "2022-09-10 00:00:00";

// 设置制度生效结束时间
$model['effective_end_date'] = "2022-09-30 23:59:59";

// 设置费控咨询模式
$model['consult_mode'] = "0";

// 设置发放规则列表
$issueRuleInfoList = array();
$issueRuleInfoList0 = array();
$issueRuleInfoList0['issue_start_date'] = "2022-08-10 00:00:00";
$issueRuleInfoList0['invalid_mode'] = 0;
$issueRuleInfoList0['target_type'] = "INSTITUTION";
$issueRuleInfoList0['issue_type'] = "ISSUE_MONTH";
$issueRuleInfoList0['effective_period'] = "{\"all\":true}";
$issueRuleInfoList0['outer_source_id'] = "123456";
$issueRuleInfoList0['share_mode'] = 0;
$issueRuleInfoList0['target_id'] = "2023042600152617860000076000";
$issueRuleInfoList0['issue_amount_value'] = "200";
$issueRuleInfoList0['issue_end_date'] = "2022-12-31 23:59:59";
$issueRuleInfoList0['invalid_mode_value'] = "3213";
$issueRuleInfoList0['issue_rule_name'] = "日额度";
$issueRuleInfoList0['quota_type'] = "COUPON";
$issueRuleInfoList[] = $issueRuleInfoList0;
$model['issue_rule_info_list'] = $issueRuleInfoList;

// 设置使用规则列表
$standardInfoList = array();
$standardInfoList0 = array();
$standardInfoList0['standard_desc'] = "使用规则描述样例";
$standardConditionInfoList = array();
$standardConditionInfoList0 = array();
$standardConditionInfoList0['rule_factor'] = "QUOTA_TOTAL";
$standardConditionInfoList0['rule_name'] = "单次消费金额";
$standardConditionInfoList0['rule_value'] = "500";
$standardConditionInfoList[] = $standardConditionInfoList0;
$standardInfoList0['standard_condition_info_list'] = $standardConditionInfoList;
$standardInfoList0['expense_type_sub_category'] = "TAKE_AWAY";
$standardInfoList0['personal_qrcode_mode'] = 0;
$standardInfoList0['payment_policy'] = "PERSONAL";
$standardInfoList0['consume_mode'] = "COUPON_ONLY";
$standardInfoList0['outer_source_id'] = "123456";
$assetShareSourceInfo = array();
$assetShareSourceInfo['share_mode'] = "INSTITUTION";
$sourceIdList = array();
$sourceIdList[] = "2023031600152614950000031117";
$assetShareSourceInfo['source_id_list'] = $sourceIdList;
$standardInfoList0['asset_share_source_info'] = $assetShareSourceInfo;
$standardInfoList0['standard_name'] = "单笔额度1元钱";
$standardInfoList0['open_rule_id'] = "2021070100152721370000002201";
$standardInfoList[] = $standardInfoList0;
$model['standard_info_list'] = $standardInfoList;

// 设置制度适用范围信息
$institutionScopeInfo = array();
$institutionScopeInfo['adapter_type'] = "EMPLOYEE_SELECT";
$ownerIdList = array();
$ownerIdList[] = "2288004000000000";
$institutionScopeInfo['owner_id_list'] = $ownerIdList;
$institutionScopeInfo['owner_type'] = "ENTERPRISE_PAY_UID";
$model['institution_scope_info'] = $institutionScopeInfo;

// 设置是否支持多人共享额度
$model['multi_employee_share_mode'] = "1";

// 设置币种
$model['currency'] = "USD";

// 设置出资类型
$model['payment_mode'] = "OWNER_PAY";

$request->setBizContent(json_encode($model,JSON_UNESCAPED_UNICODE));
// 如果是第三方代调用模式，请设置app_auth_token（应用授权令牌）
$responseResult = $alipayClient->execute($request, null, "<-- 请填写应用授权令牌 -->", null);
$responseApiName = str_replace(".","_",$request->getApiMethodName())."_response";
$response = $responseResult->$responseApiName;
if(!empty($response->code)&&$response->code==10000){
    echo("调用成功");
}
else{
    echo("调用失败");
}

function getAlipayConfig()
{
    $privateKey  = '<-- 请填写您的应用私钥，例如：MIIEvQIBADANB ... ... -->';
    $alipayPublicKey = '<-- 请填写您的支付宝公钥，例如：MIIBIjANBg... -->';
    $alipayConfig = new AlipayConfig();
    $alipayConfig->setServerUrl('https://openapi.alipay.com/gateway.do');
    $alipayConfig->setAppId('<-- 请填写您的AppId，例如：2019091767145019 -->');
    $alipayConfig->setPrivateKey($privateKey);
    $alipayConfig->setFormat('json');
    $alipayConfig->setAlipayPublicKey($alipayPublicKey);
    $alipayConfig->setCharset('UTF-8');
    $alipayConfig->setSignType('RSA2');
    return $alipayConfig;
}
```
 

##### http
```
 curl 'https://openapi.alipay.com/gateway.do?charset=UTF-8&method=alipay.ebpp.invoice.institution.create&format=json&sign=${sign}&app_id=${appid}&version=1.0&sign_type=RSA2&timestamp=${now}' \
 -F 'app_auth_token=${app_auth_token}' \
 -F 'biz_content={
    "enterprise_id":"2088123412341234",
    "institution_name":"费用制度",
    "outer_source_id":"0b26c12b16900047742372557ee431",
    "expense_type":"MEAL",
    "institution_desc":"餐补制度",
    "effective_start_date":"2022-09-10 00:00:00",
    "effective_end_date":"2022-09-30 23:59:59",
    "consult_mode":"0",
    "issue_rule_info_list":[
        {
            "issue_start_date":"2022-08-10 00:00:00",
            "invalid_mode":0,
            "target_type":"INSTITUTION",
            "issue_type":"ISSUE_MONTH",
            "effective_period":"{\\\"all\\\":true}",
            "outer_source_id":"123456",
            "share_mode":0,
            "target_id":"2023042600152617860000076000",
            "issue_amount_value":"200",
            "issue_end_date":"2022-12-31 23:59:59",
            "invalid_mode_value":"3213",
            "issue_rule_name":"日额度",
            "quota_type":"COUPON"
        }
    ],
    "standard_info_list":[
        {
            "standard_desc":"使用规则描述样例",
            "standard_condition_info_list":[
                {
                    "rule_factor":"QUOTA_TOTAL",
                    "rule_name":"单次消费金额",
                    "rule_value":"500"
                }
            ],
            "expense_type_sub_category":"TAKE_AWAY",
            "personal_qrcode_mode":0,
            "payment_policy":"PERSONAL",
            "consume_mode":"COUPON_ONLY",
            "outer_source_id":"123456",
            "asset_share_source_info":{
                "share_mode":"INSTITUTION",
                "source_id_list":[
                    "2023031600152614950000031117"
                ]
            },
            "standard_name":"单笔额度1元钱",
            "open_rule_id":"2021070100152721370000002201"
        }
    ],
    "institution_scope_info":{
        "adapter_type":"EMPLOYEE_SELECT",
        "owner_id_list":[
            "2288004000000000"
        ],
        "owner_type":"ENTERPRISE_PAY_UID"
    },
    "multi_employee_share_mode":"1",
    "currency":"USD",
    "payment_mode":"OWNER_PAY"
}' 
```
 

### 公共响应参数
|参数英文名|类型|是否必选|长度/取值|描述|示例值|
|---|---|---|---|---|---|
|code|String|必须|~|网关返回码，[详见文档](https://docs.open.alipay.com/common/105806)|40004|
|msg|String|必须|~|网关返回码描述，[详见文档](https://docs.open.alipay.com/common/105806)|Business Failed|
|sub_code|String|可选|~|业务返回码，参见具体的API接口文档||
|sub_msg|String|可选|~|业务返回码描述，参见具体的API接口文档||
|sign|String|必须|64|签名，[详见文档](https://docs.open.alipay.com/291/106074)|DZXh8eeTuAHoYE3w1J+POiPhfDxOYBfUNn1lkeT/V7P4zJdyojWEa6IZs6Hz0yDW5Cp/viufUb5I0/V5WENS3OYR8zRedqo6D+fUTdLHdc+EFyCkiQhBxIzgngPdPdfp1PIS7BdhhzrsZHbRqb7o4k3Dxc+AAnFauu4V6Zdwczo=|
### 业务响应参数
|参数英文名|类型|是否必选|长度/取值|描述|示例值|
|---|---|---|---|---|---|
|institution_id|String|必须|32|制度id|2022031000152617000000000001|
|standard_id_info_list|StandardIdInfo|必须|null|使用规则id列表||
|standard_id_info_list.standard_id|String|必须|100|使用规则id|2022020900152608000000000001|
|standard_id_info_list.outer_source_id|String|必须|100|外部使用规则id|123456|
|issue_rule_id_info_list|IssueRuleIdInfo|可选|null|发放规则id列表||
|issue_rule_id_info_list.issue_rule_id|String|必须|100|发放规则id|2022031000152621000000000001|
|issue_rule_id_info_list.outer_source_id|String|必须|100|外部发放规则id|123456|
### 响应示例
#### 正常响应示例
```
 {
    "alipay_ebpp_invoice_institution_create_response":{
        "code":"10000",
        "msg":"Success",
        "institution_id":"2022031000152617000000000001",
        "standard_id_info_list":[
            {
                "standard_id":"2022020900152608000000000001",
                "outer_source_id":"123456"
            }
        ],
        "issue_rule_id_info_list":[
            {
                "issue_rule_id":"2022031000152621000000000001",
                "outer_source_id":"123456"
            }
        ]
    },
    "sign":"ERITJKEIJKJHKKKKKKKHJEREEEEEEEEEEE"
}
```
 
#### 异常响应示例
```
 {"alipay_ebpp_invoice_institution_create_response":{"code":"20000","msg":"Service Currently Unavailable","sub_code":"isp.unknow-error","sub_msg":"系统繁忙"},"sign":"ERITJKEIJKJHKKKKKKKHJEREEEEEEEEEEE"}
```
 
### 业务错误码
|错误码|错误描述|解决方案|
|---|---|---|
|SYSTEM_ERROR|系统繁忙|服务器异常 可能发生了网络或者系统异常，导致服务调用失败，商户可以用同样的请求发起重试|
|INVALID_PARAMETER|参数有误|请根据接口返回的参数非法的具体错误信息，修改参数后进行重试|
|ENTERPRISE_SYNC_EXTERIOR_EXCEPTION|向外部渠道同步规则时异常（该错误码已废弃）|请重试或联系技术支持|
|INSTITUTION_CREATE_FAIL|创建制度失败（该错误码已废弃）|系统异常，可重试处理|
|PERMISSION_DENIED|权限不足，未能查到企业和ISV之间的映射关系|检查传入的企业ID是否正确|
|RECORD_EXIST|制度已经存在或制度下发放规则和使用规则的outer_source_id重复|制度下使用规则和发放规则的outer_source_id必须唯一，如果仍报错，可尝试更换制度的outer_source_id|