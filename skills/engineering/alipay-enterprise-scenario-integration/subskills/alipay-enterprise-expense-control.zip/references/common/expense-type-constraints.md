# 费用类型与使用规则因子约束

## 前言
使用规则因子的格式、示例和注意事项，参考[文档](rule-factors.md)。本文档主要描述费用类型和使用规则因子之间的约束关系。

规则因子分为三类：

1）必须使用（例如：餐饮到店必须至少有一个商户相关的规则因子对应的条件）；

2）建议使用，根据历史接入情况判断该场景下规则因子被多数服务商使用；

3）可使用，该规则因子可以在该场景下使用，按需进行接入；

## 明细
### 线下到店类
| **费用类型-费用类型子类** | **指定门店/广泛商户** | **必须使用** | **建议使用规则因子** | **可使用规则因子** |
| --- | --- | --- | --- | --- |
| + 餐饮MEAL - 餐饮到店（REACH_SHOP）<br/>+ 生活服务（LIVINGSERVICE）- 生活服务（LIVINGSERVICE）<br/>+ 加油（OIL）- 到店加油(REACH_SHOP_OIL)<br/>+ 酒店（HOTEL）- 到店住宿（REACH_SHOP_HOTEL）<br/>+ 商城（MALL）- 线下商超(OFFLINE_MALL)<br/>+ 医疗(HEALTH) - 到院就医(REACH_HOSPITAL) | 指定门店（商户需要入驻企业码） | 至少使用其中一个的规则因子：<br/>+ MEAL_MERCHANT（指定餐饮商户名单 - 仅餐饮使用）/MERCHANT（指定商户名单 - 其他场景使用）<br/>+ SHOP（门店）<br/>+ SHOP_GROUP（门店组） | + ALARM_CLOCK_TIME（使用时间）<br/>+ AREA（可用位置） | 通用：<br/>+ GOODS_ID（商品ID白名单）<br/>+ GOODS_ID_BLACK_LIST（商品ID黑名单）<br/>+ MERCHANT_LABEL（商户服务标签）<br/>+ 额度类：参考附录额度类规则因子<br/>特殊：<br/>+ OIL_CATEGORY（油品类型 - 加油到店特有）<br/>+ REQUIRE_APPROVE（需要审批 - 到店住宿特有） |
| | 广泛商户 | 至少使用其中一个的规则因子：<br/>+ MCC（商户类型）<br/>+ BRAND（品牌）<br/>+ RECEIPT_IDENTITY_WHITE_LIST（收单身份白名单）<br/>+ COMPOSITE_MERCHANT（复合商户） | + ALARM_CLOCK_TIME（使用时间）<br/>+ AREA（可用位置） | 通用：<br/>+ RECEIPT_IDENTITY_BLACK_LIST（收单身份黑名单）<br/>+ GOODS_ID（商品ID白名单）<br/>+ GOODS_ID_BLACK_LIST（商品ID黑名单）<br/>+ MERCHANT_LABEL（商户服务标签）<br/>+ 额度类：参考附录额度类规则因子<br/>特殊：<br/>+ OIL_CATEGORY（油品类型 - 加油到店特有）<br/>+ REQUIRE_APPROVE（需要审批 - 到店住宿特有） |


### 非线下到店类
| **费用类型-费用类型子类** | **必用** | **建议使用规则因子** | **可使用规则因子** |
| --- | --- | --- | --- |
| 餐饮MEAL-外卖（TAKE_AWAY） | 必用规则因子：<br/>+ TAKE_AWAY_CATEGORY（商户类型）<br/>以下两个规则因子二选一：<br/>+ SUPPLIER_CHANNEL（供应商渠道）<br/>+ SERVICE（服务） | + ALARM_CLOCK_TIME（使用时间）<br/>+ BOOK_SWITCH（是否开启预定）<br/>+ SHIPPING_ADDRESS（可用收餐地址） | + MARKED_WORDS（提示单文案）<br/>+ MERCHANT_LABEL（商户服务标签）<br/>+ GOODS_CATEGORY_BLACK_LIST（商品类目黑名单）<br/>+ SELF_TAKE_SWITCH（是否开启到店自提）<br/>+ 额度类：参考附录额度类规则因子 |
| 地铁（METRO）-地铁（METRO） | 必用规则因子：<br/>+ CARD_TYPE（卡类型） | + ALARM_CLOCK_TIME（使用时间） | + REQUIRE_APPROVE（是否需要审批）<br/>+ FILL_REASON（申请事由是否必填）<br/>+ 额度类：参考附录额度类规则因子 |
| 公交（BUS）-公交（BUS） | 必用规则因子：<br/>+ CARD_TYPE（卡类型） | + ALARM_CLOCK_TIME（使用时间） | + 额度类：参考附录额度类规则因子 |
| 用车（CAR）-用车（CAR） | 必用规则因子：<br/>+ SERVICE（服务） | + ALARM_CLOCK_TIME（使用时间）<br/>+ CAR_TYPE（车型）<br/>+ FILL_REASON（申请事由是否必填）<br/>+ ALLOW_CHANGE_DESTINATION（允许修改目的地）<br/>+ BOARDING_LOCATION（上车地点）<br/>+ GET_OFF_LOCATION（下车地点）<br/>+ CROSS_CITY（是否允许跨城）<br/>+ ALLOW_BOOK_CAR（允许预约用车） | + 额度类：参考附录额度类规则因子 |
| 票务（TICKET）-票务（TICKET） | 必用规则因子：<br/>+ MERCHANT（指定商户名单）。企业码票务场景必须绑定 12306 商户 PID `2088011519249952`，规则值为 `{"2088011519249952":["-1"]}` |  | + ALARM_CLOCK_TIME（使用时间）<br/>+ 额度类：参考附录额度类规则因子 |
| 备用金（DEFAULT）- 备用金（DEFAULT） | 至少有一个规则因子即可 | + ALARM_CLOCK_TIME（使用时间） | + AREA（可用位置）<br/>+ MERCHANT（指定商户名单 - 其他场景使用）<br/>+ SHOP（门店）<br/>+ SHOP_GROUP（门店组）<br/>+ MCC（商户类型）<br/>+ BRAND（品牌）<br/>+ RECEIPT_IDENTITY_WHITE_LIST（收单身份白名单<br/>+ RECEIPT_IDENTITY_BLACK_LIST（收单身份黑名单）<br/>+ COMPOSITE_MERCHANT（复合商户）<br/>+ GOODS_ID（商品ID白名单）<br/>+ GOODS_ID_BLACK_LIST（商品ID黑名单）<br/>+ MERCHANT_LABEL（商户服务标签）<br/>+ ALI_PLATFORM_TYPE（线上淘系商户）<br/>+ CURRENCY_LIST（消费币种列表）<br/>+ 额度类：参考附录额度类规则因子 |




## 附录
### 额度类规则因子
+ QUOTA_DAY（日额度）
+ QUOTA_WEEK（周额度）
+ QUOTA_MONTH（月额度）
+ QUOTA_SEASON（季额度）
+ QUOTA_YEAR（年额度）
+ QUOTA_ONCE（单笔额度）
+ QUOTA_TOTAL（有效期总额度）
+ ALLOW_MINIMUM（低消限额）
+ OWNER_PAY_MINIMUM（个付低消限额）
+ QUOTA_UNLIMITED（不限额）
+ QUOTA_ONCE_PERCENT（按比例单笔额度）
