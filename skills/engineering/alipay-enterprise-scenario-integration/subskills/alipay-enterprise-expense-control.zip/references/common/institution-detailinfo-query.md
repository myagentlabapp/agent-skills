# alipay.ebpp.invoice.institution.detailinfo.query(制度详情查询)
支持第三方代理调用：本接口支持第三方开发者代用户发起调用
## 通用场景
单个制度查询，返回制度详细信息，包含制度下使用规则列表和发放规则列表
### 公共请求参数
|参数英文名|类型|是否必选|长度/取值|描述|示例值|
|---|---|---|---|---|---|
|app_id|String|必选|32|支付宝分配给开发者的应用ID|2014072300007148|
|method|String|必选|128|接口名称|alipay.ebpp.invoice.institution.detailinfo.query|
|format|String|可选|40|仅支持JSON|JSON|
|charset|String|必选|10|请求使用的编码格式，如utf-8,gbk,gb2312等|utf-8|
|sign_type|String|必选|10|商户生成签名字符串所使用的签名算法类型，目前支持RSA2和RSA，推荐使用RSA2|RSA2|
|sign|String|必选|344|商户请求参数的签名串，详见[签名](https://ideservice.alipay.com/cms/site/02khjm)|详见示例|
|timestamp|String|必选|19|发送请求的时间，格式"yyyy-MM-dd HH:mm:ss"|2014-07-24 03:07:50|
|version|String|必选|3|调用的接口版本，固定为：1.0|1.0|
|app_auth_token|String|可选|40|详见[应用授权概述](https://ideservice.alipay.com/cms/site/04h2nx)|null|
|biz_content|String|必选||请求参数的集合，最大长度不限，除公共参数外所有请求参数都必须放在这个参数中传递，具体参照各产品快速接入文档|null|
### 业务请求参数
|参数英文名|类型|是否必选|长度/取值|描述|示例值|
|---|---|---|---|---|---|
|account_id|String|特殊可选|32|企业共同账户id**注意事项**通过企业码1.0接口签约的共同账户，和agreement_no搭配使用。|2088000194958956|
|agreement_no|String|特殊可选|32|授权签约协议号**注意事项**可通过签约消息获取。配合共同账户id使用，当填写企业共同账户id时，此字段必填。|20215425001112341234|
|enterprise_id|String|特殊可选|32|企业ID**注意事项**通过企业码2.0签约接口签约，只填写企业id，无需填写共同账户id和授权签约协议号。|2088000194958956|
|institution_id|String|特殊可选|32|制度id**注意事项**如果指定外部唯一标识进行查询，则该字段可以不传。**必选条件**和外部唯一标识二选一必填|2022071800152609780000004052|
|outer_source_id|String|特殊可选|32|外部唯一标识**注意事项**如果创建时，传入该值，则可通过指定该值进行制度查询。**必选条件**和制度id二选一必填|0b249cd916969304726395528e002c|
|owner_type|String|可选|32|适配id类型**枚举值**员工支付宝id类型:EMPLOYEE员工企业码id类型:ENTERPRISE_PAY_UID员工手机号类型:PHONE**注意事项**请与创建制度下适配范围时传的owner_type保持一致，企业id对接支持PHONE和ENTERPRISE_PAY_UID类型，共同账户id对接仅支持EMPLOYEE|PHONE|
### 请求示例
#### 默认示例
##### csharp
```
 using System;
using System.Collections.Generic;
using Aop.Api;
using Aop.Api.Request;
using Aop.Api.Response;
using Aop.Api.Domain;
using Aop.Api.Util;
namespace SdkDemoTest
{
    public class AlipayEbppInvoiceInstitutionDetailinfoQuery
    {
        public static void Main(string[] args) 
        {
            // 初始化SDK
            IAopClient alipayClient = new DefaultAopClient(GetAlipayConfig());
            // 构造请求参数以调用接口
            AlipayEbppInvoiceInstitutionDetailinfoQueryRequest request = new AlipayEbppInvoiceInstitutionDetailinfoQueryRequest();
            AlipayEbppInvoiceInstitutionDetailinfoQueryModel model = new AlipayEbppInvoiceInstitutionDetailinfoQueryModel();
            
            // 设置企业共同账户id
            model.AccountId = "2088000194958956";
            
            // 设置授权签约协议号
            model.AgreementNo = "20215425001112341234";
            
            // 设置企业ID
            model.EnterpriseId = "2088000194958956";
            
            // 设置制度id
            model.InstitutionId = "2022071800152609780000004052";
            
            // 设置外部唯一标识
            model.OuterSourceId = "0b249cd916969304726395528e002c";
            
            // 设置适配id类型
            model.OwnerType = "PHONE";
            
            request.SetBizModel(model);
            // 第三方代调用模式下请设置app_auth_token
            // request.PutOtherTextParam("app_auth_token", "<-- 请填写应用授权令牌 -->");

            AlipayEbppInvoiceInstitutionDetailinfoQueryResponse response = alipayClient.Execute(request);

            if(!response.IsError)
            {
                Console.WriteLine("调用成功");
            }
            else
            {
                Console.WriteLine("调用失败");
            }
        }

        private static AlipayConfig GetAlipayConfig()
        {
            string privateKey  = "<-- 请填写您的应用私钥，例如：MIIEvQIBADANB ... ... -->";
            string alipayPublicKey = "<-- 请填写您的支付宝公钥，例如：MIIBIjANBg... -->";
            AlipayConfig alipayConfig = new AlipayConfig();
            alipayConfig.ServerUrl = "https://openapi.alipay.com/gateway.do";
            alipayConfig.AppId = "<-- 请填写您的AppId，例如：2019091767145019 -->";
            alipayConfig.PrivateKey = privateKey;
            alipayConfig.Format = "json";
            alipayConfig.AlipayPublicKey = alipayPublicKey;
            alipayConfig.Charset = "UTF-8";
            alipayConfig.SignType = "RSA2";
            return alipayConfig;
        }
    }
}
```
 

##### java
```
 package com.java.sdk.demo;

import com.alipay.api.AlipayApiException;
import com.alipay.api.AlipayClient;
import com.alipay.api.DefaultAlipayClient;
import com.alipay.api.AlipayConfig;
import com.alipay.api.response.AlipayEbppInvoiceInstitutionDetailinfoQueryResponse;
import com.alipay.api.domain.AlipayEbppInvoiceInstitutionDetailinfoQueryModel;
import com.alipay.api.request.AlipayEbppInvoiceInstitutionDetailinfoQueryRequest;

import com.alipay.api.FileItem;
import java.util.Base64;
import java.util.ArrayList;
import java.util.List;

public class AlipayEbppInvoiceInstitutionDetailinfoQuery {

    public static void main(String[] args) throws AlipayApiException {
        // 初始化SDK
        AlipayClient alipayClient = new DefaultAlipayClient(getAlipayConfig());

        // 构造请求参数以调用接口
        AlipayEbppInvoiceInstitutionDetailinfoQueryRequest request = new AlipayEbppInvoiceInstitutionDetailinfoQueryRequest();
        AlipayEbppInvoiceInstitutionDetailinfoQueryModel model = new AlipayEbppInvoiceInstitutionDetailinfoQueryModel();
        
        // 设置企业共同账户id
        model.setAccountId("2088000194958956");
        
        // 设置授权签约协议号
        model.setAgreementNo("20215425001112341234");
        
        // 设置企业ID
        model.setEnterpriseId("2088000194958956");
        
        // 设置制度id
        model.setInstitutionId("2022071800152609780000004052");
        
        // 设置外部唯一标识
        model.setOuterSourceId("0b249cd916969304726395528e002c");
        
        // 设置适配id类型
        model.setOwnerType("PHONE");
        
        request.setBizModel(model);
        // 第三方代调用模式下请设置app_auth_token
        // request.putOtherTextParam("app_auth_token", "<-- 请填写应用授权令牌 -->");

        AlipayEbppInvoiceInstitutionDetailinfoQueryResponse response = alipayClient.execute(request);
        System.out.println(response.getBody());

        if (response.isSuccess()) {
            System.out.println("调用成功");
        } else {
            System.out.println("调用失败");
            // sdk版本是"4.38.0.ALL"及以上,可以参考下面的示例获取诊断链接
            // String diagnosisUrl = DiagnosisUtils.getDiagnosisUrl(response);
            // System.out.println(diagnosisUrl);
        }
    }

    private static AlipayConfig getAlipayConfig() {
        String privateKey  = "<-- 请填写您的应用私钥，例如：MIIEvQIBADANB ... ... -->";
        String alipayPublicKey = "<-- 请填写您的支付宝公钥，例如：MIIBIjANBg... -->";
        AlipayConfig alipayConfig = new AlipayConfig();
        alipayConfig.setServerUrl("https://openapi.alipay.com/gateway.do");
        alipayConfig.setAppId("<-- 请填写您的AppId，例如：2019091767145019 -->");
        alipayConfig.setPrivateKey(privateKey);
        alipayConfig.setFormat("json");
        alipayConfig.setAlipayPublicKey(alipayPublicKey);
        alipayConfig.setCharset("UTF-8");
        alipayConfig.setSignType("RSA2");
        return alipayConfig;
    }
}
```
 

##### php
```
 <?php
require_once '../aop/AopClient.php';
require_once '../aop/AopCertClient.php';
require_once '../aop/AopCertification.php';
require_once '../aop/AlipayConfig.php';
require_once '../aop/request/AlipayEbppInvoiceInstitutionDetailinfoQueryRequest.php';

// 初始化SDK
$alipayClient = new AopClient(getAlipayConfig());
// 构造请求参数以调用接口
$request = new AlipayEbppInvoiceInstitutionDetailinfoQueryRequest();
$model = array();

// 设置企业共同账户id
$model['account_id'] = "2088000194958956";

// 设置授权签约协议号
$model['agreement_no'] = "20215425001112341234";

// 设置企业ID
$model['enterprise_id'] = "2088000194958956";

// 设置制度id
$model['institution_id'] = "2022071800152609780000004052";

// 设置外部唯一标识
$model['outer_source_id'] = "0b249cd916969304726395528e002c";

// 设置适配id类型
$model['owner_type'] = "PHONE";

$request->setBizContent(json_encode($model,JSON_UNESCAPED_UNICODE));
// 如果是第三方代调用模式，请设置app_auth_token（应用授权令牌）
$responseResult = $alipayClient->execute($request, null, "<-- 请填写应用授权令牌 -->", null);
$responseApiName = str_replace(".","_",$request->getApiMethodName())."_response";
$response = $responseResult->$responseApiName;
if(!empty($response->code)&&$response->code==10000){
    echo("调用成功");
}
else{
    echo("调用失败");
}

function getAlipayConfig()
{
    $privateKey  = '<-- 请填写您的应用私钥，例如：MIIEvQIBADANB ... ... -->';
    $alipayPublicKey = '<-- 请填写您的支付宝公钥，例如：MIIBIjANBg... -->';
    $alipayConfig = new AlipayConfig();
    $alipayConfig->setServerUrl('https://openapi.alipay.com/gateway.do');
    $alipayConfig->setAppId('<-- 请填写您的AppId，例如：2019091767145019 -->');
    $alipayConfig->setPrivateKey($privateKey);
    $alipayConfig->setFormat('json');
    $alipayConfig->setAlipayPublicKey($alipayPublicKey);
    $alipayConfig->setCharset('UTF-8');
    $alipayConfig->setSignType('RSA2');
    return $alipayConfig;
}
```
 

##### http
```
 curl 'https://openapi.alipay.com/gateway.do?charset=UTF-8&method=alipay.ebpp.invoice.institution.detailinfo.query&format=json&sign=${sign}&app_id=${appid}&version=1.0&sign_type=RSA2&timestamp=${now}' \
 -F 'app_auth_token=${app_auth_token}' \
 -F 'biz_content={
	"account_id":"2088000194958956",
	"agreement_no":"20215425001112341234",
	"enterprise_id":"2088000194958956",
	"institution_id":"2022071800152609780000004052",
	"outer_source_id":"0b249cd916969304726395528e002c",
	"owner_type":"PHONE"
}' 
```
 

### 公共响应参数
|参数英文名|类型|是否必选|长度/取值|描述|示例值|
|---|---|---|---|---|---|
|code|String|必须|~|网关返回码，[详见文档](https://docs.open.alipay.com/common/105806)|40004|
|msg|String|必须|~|网关返回码描述，[详见文档](https://docs.open.alipay.com/common/105806)|Business Failed|
|sub_code|String|可选|~|业务返回码，参见具体的API接口文档||
|sub_msg|String|可选|~|业务返回码描述，参见具体的API接口文档||
|sign|String|必须|64|签名，[详见文档](https://docs.open.alipay.com/291/106074)|DZXh8eeTuAHoYE3w1J+POiPhfDxOYBfUNn1lkeT/V7P4zJdyojWEa6IZs6Hz0yDW5Cp/viufUb5I0/V5WENS3OYR8zRedqo6D+fUTdLHdc+EFyCkiQhBxIzgngPdPdfp1PIS7BdhhzrsZHbRqb7o4k3Dxc+AAnFauu4V6Zdwczo=|
### 业务响应参数
|参数英文名|类型|是否必选|长度/取值|描述|示例值|
|---|---|---|---|---|---|
|institution_id|String|必须|32|制度id|2023042600152617860000076700|
|institution_name|String|必须|50|制度名称|餐补制度|
|outer_source_id|String|特殊可选|64|外部唯一标识**必选条件**如果创建时，填写了outer_source_id，查询时可返回|0b249cd9169693047263955280052c|
|scene_type|String|必须|32|因公场景**枚举值**加班:OVERTIME补贴福利:SUBSIDY差旅:TRAVEL招待:ENTERTAIN通用:DEFAULT市内交通:CITYTRAFFIC|OVERTIME|
|expense_type|String|必须|32|费用类型**枚举值**餐饮:MEAL地铁:METRO**注意事项**更多费用类型，查看详细文档 [详细文档](expense-type-enum.md)|MEAL|
|institution_desc|String|必须|200|制度描述|工作餐制度|
|effective_start_date|Date|必须|32|制度生效起始时间**注意事项**最小粒度为天，最早是当日，时分秒必须为00:00:00。|2000-01-01 00:00:00|
|effective_end_date|Date|必须|32|制度生效结束时间**注意事项**最小粒度为天，结束时间不早于起始时间，时分秒必须为23:59:59，最晚不超过2222-01-01 23:59:59|2001-01-01 23:59:59|
|issue_rule_info_list|IssueRuleInfo|可选|null|发放规则信息列表||
|issue_rule_info_list.issue_rule_name|String|可选|20|发放规则名称**注意事项**创建或修改时，会校验敏感词，请避免填写敏感词。|日额度|
|issue_rule_info_list.issue_rule_id|String|特殊可选|32|发放规则id**注意事项**创建时无需填写，修改时必填**必选条件**当接口类型为查询、编辑时必填|2022032400152624930000000001|
|issue_rule_info_list.target_type|String|可选|32|发放规则归属的目标类型**枚举值**制度:INSTITUTION**注意事项**制度创建接口无需填写此字段。新增发放规则接口需要填写该字段，指定新增规则对应的目标类型，例如：新增发放规则为制度下的发放规则，则填写INSTITUTION|INSTITUTION|
|issue_rule_info_list.target_id|String|可选|32|目标id**注意事项**制度创建接口无需填写此字段，发放规则新增时与target_type配合填写，当target_type为INSTITUTION时，该字段填写对应的制度id，表示创建的发放规则为指定制度id下的发放规则|2023042600152617860000076000|
|issue_rule_info_list.outer_source_id|String|可选|64|外部发放规则id**注意事项**事项一：制度内发放规则该字段不允许重复。 事项二：创建制度时该字段必填。 事项三：创建发放规则时选填，如果填写可保证创建发放规则幂等。|123456|
|issue_rule_info_list.quota_type|String|必须|32|额度类型**枚举值**点券:COUPON余额:CAP|COUPON|
|issue_rule_info_list.issue_type|String|必须|32|发放类型**枚举值**按日发放:ISSUE_DAY按月发放:ISSUE_MONTH按周发放:ISSUE_WEEK按季发放:ISSUE_SEASON按年发放:ISSUE_YEAR按间夜发放:ISSUE_ROOM_NIGHT**注意事项**更多说明请参考文档[接入文档](issue-rule-fields.md)|ISSUE_MONTH|
|issue_rule_info_list.effective_period|String|可选|100|生效时间段**注意事项**发放资产的有效时间段，该字段为空时，默认为不限制。当发放资产为余额时，仅支持设置为不限，当发放资产为点券时，可支持设置多种值。具体传值格式请参考文档 [接入文档](issue-rule-fields.md)|{\"all\":true}|
|issue_rule_info_list.invalid_mode|Number|可选|32|累计类型，默认为0 可选值：0（不可累计）、1（可累计）、2（累计天数）、3（累计到指定日期）**注意事项**当资产按日、月、周、季、年周期发放时，资产有效期默认为周期起始和结束时间，如果想延长资产的有效期，可通过该字段自定义发放资产的结束时间期，例如：发放周期为按日发放，默认点券有效期为发放日的00:00:00-23:59:59，通过将该字段设置为1，发放点券时结束时间将设置为长期有效。如果设置为2或3，需要配置invalid_mode_value使用，具体设置说明请参考文档[接入文档](issue-rule-fields.md)|0|
|issue_rule_info_list.invalid_mode_value|String|可选|10240|累计类型值**注意事项**与invalid_mode配置使用，具体使用说明请参考文档 [接入文档](issue-rule-fields.md)|3213|
|issue_rule_info_list.issue_amount_value|String|必须|10240|发放金额，单位元**注意事项**支持两种发放： 1、按城市发放不同的金额 2、按统一标准发放金额 具体填写说明请参考文档[接入文档](issue-rule-fields.md)|200|
|issue_rule_info_list.share_mode|Number|可选|32|是否可转赠**注意事项**可选值：0（不可转赠）、1（可转赠），默认为0。 该字段决定发放规则发放的资产是否可转赠给同制度下的其他人员|0|
|issue_rule_info_list.issue_start_date|Date|特殊可选|32|发放规则有效起始时间**注意事项**如果target_type指定INSTITUTION，则使用制度有效期起始时间，无法指定。|2022-08-10 00:00:00|
|issue_rule_info_list.issue_end_date|Date|特殊可选|32|发放规则有效结束时间**注意事项**如果target_type指定INSTITUTION，则使用制度有效期结束时间，无法指定|2022-12-31 23:59:59|
|standard_info_list|StandardInfo|可选|null|使用规则列表（已废弃）**注意事项**该字段已废弃，请使用：standard_info_detail_list||
|standard_info_list.standard_id|String|可选|32|制度ID（创建使用规则时非必填）|2022091300152608010000334322|
|standard_info_list.outer_source_id|String|可选|64|外部使用规则id，制度内使用规则该字段不允许重复**注意事项**事项一：制度内使用规则该字段不允许重复。 事项二：创建制度时该字段必填。 事项三：创建使用规则时选填，如果填写可保证创建使用规则幂等。|123456|
|standard_info_list.standard_name|String|必须|50|规则名称|单笔额度1元钱|
|standard_info_list.open_rule_id|String|可选|32|开票规则id，可通过接口alipay.ebpp.invoice.enterpriseconsume.enterpriseopenrule.create 创建并得到开票规则ID|2021070100152721370000002201|
|standard_info_list.payment_policy|String|可选|32|支付策略 当笔消费金额大于规则可用余额时，用于控制支付策略，该字段缺省时采取因公账户和个人账户组合支付策略**枚举值**全部个人支付:PERSONAL因公账户和个人账户组合支付:COMBINATION|PERSONAL|
|standard_info_list.consume_mode|String|可选|32|消费模式，不填为默认模式，枚举值：COUPON_ONLY（仅支持点券） COUPON_AND_CAP（支持点券+余额） DEFAULT（默认模式） COUNT（仅支持次卡） 点券：消费时找员工的点券，没有或者用完了不可付； 点券+余额：消费时找员工的点券，没有找员工的余额，没有或者用完了不可付； 默认：有给员工设置员工余额以员工余额为准，用完为止。否则只受规则里的限额和企业账户资金上限管控； 次卡：消费时找员工的次卡，没有或者用完了不可付。**枚举值**仅支持点券:COUPON_ONLY支持点券+余额:COUPON_AND_CAP默认模式:DEFAULT仅支持次卡:COUNT|COUPON_ONLY|
|standard_info_list.expense_type_sub_category|String|可选|32|费用类型子类**枚举值**外卖:TAKE_AWAY到店:REACH_SHOP地铁:METRO用车:CAR默认:DEFAULT**注意事项**更多费用类型子类，查看详细文档 [详细文档](expense-type-enum.md)|TAKE_AWAY|
|standard_info_list.standard_desc|String|可选|48|使用规则描述(敏感词校验)|使用规则描述样例|
|standard_info_list.standard_condition_info_list|StandardConditionInfo|可选|null|使用规则条件列表||
|standard_info_list.standard_condition_info_list.rule_id|String|特殊可选|32|费控条件ID**注意事项**创建时由支付宝生成，无需外部传入，修改时条件时需要填写**必选条件**当接口类型为查询、编辑时必填|2021052100152602010000000001|
|standard_info_list.standard_condition_info_list.rule_factor|String|可选|32|条件类型**注意事项**指定条件id修改条件时，该字段不可变更，因此无需填写。 如需填写请参考文档填写 [详细文档](expense-type-constraints.md)|QUOTA_TOTAL|
|standard_info_list.standard_condition_info_list.rule_value|String|必须|65535|费控条件值**注意事项**请参考文档填写[详细文档](expense-type-constraints.md)|500|
|standard_info_list.standard_condition_info_list.rule_operator|String|可选|32|费控条件操作符 枚举值： LT("=","大于等于") GT(">","大于")**枚举值**小于:LT小于等于:LE等于:EQ不等于:NE大于等于:GE大于:GT**注意事项**该字段为保留字段，目前未被使用，无需填写|LE|
|standard_info_list.standard_condition_info_list.rule_name|String|可选|32|费控条件名称**注意事项**敏感词校验，请避免填写敏感词|单次消费金额|
|standard_info_list.asset_share_source_info|AssetShareSourceInfo|可选|null|当前规则可使用的其他资产来源信息||
|standard_info_list.asset_share_source_info.share_mode|String|可选|32|当前规则可用的资产来源类型，搭配source_id_list使用。**枚举值**制度:INSTITUTION**注意事项**如果当前值为INSTITUTION，source_id_list内填写制度id列表，表示当前规则可使用列表中的制度的资产。|INSTITUTION|
|standard_info_list.asset_share_source_info.source_id_list|String|可选|28|资产共享来源id列表，与share_mode配合设置，如果share_mode为INSTITUTION，该值则填写制度id列表**注意事项**事项一：目前最多支持10个制度id； 事项二：不能设置本使用规则所属的制度id； 事项三：仅支持发放币种相同的制度之间共享资产； 事项四：制度的multi_employee_share_mode需要一致才可共享。|["2023031600152614950000031117"]|
|standard_info_list.personal_qrcode_mode|Number|可选|32|个人收款码转账是否支持因公付，默认为0。可选值：0（不支持）、1（支持）**注意事项**适用场景：个人收款码转账需支持因公付。默认无需设置此字段|0|
|standard_info_detail_list|StandardInfo|必须|null|使用规则列表||
|standard_info_detail_list.standard_id|String|可选|32|制度ID（创建使用规则时非必填）|2022091300152608010000334322|
|standard_info_detail_list.outer_source_id|String|可选|64|外部使用规则id，制度内使用规则该字段不允许重复**注意事项**事项一：制度内使用规则该字段不允许重复。 事项二：创建制度时该字段必填。 事项三：创建使用规则时选填，如果填写可保证创建使用规则幂等。|123456|
|standard_info_detail_list.standard_name|String|必须|50|规则名称|单笔额度1元钱|
|standard_info_detail_list.open_rule_id|String|可选|32|开票规则id，可通过接口alipay.ebpp.invoice.enterpriseconsume.enterpriseopenrule.create 创建并得到开票规则ID|2021070100152721370000002201|
|standard_info_detail_list.payment_policy|String|可选|32|支付策略 当笔消费金额大于规则可用余额时，用于控制支付策略，该字段缺省时采取因公账户和个人账户组合支付策略**枚举值**全部个人支付:PERSONAL因公账户和个人账户组合支付:COMBINATION|PERSONAL|
|standard_info_detail_list.consume_mode|String|可选|32|消费模式，不填为默认模式，枚举值：COUPON_ONLY（仅支持点券） COUPON_AND_CAP（支持点券+余额） DEFAULT（默认模式） COUNT（仅支持次卡） 点券：消费时找员工的点券，没有或者用完了不可付； 点券+余额：消费时找员工的点券，没有找员工的余额，没有或者用完了不可付； 默认：有给员工设置员工余额以员工余额为准，用完为止。否则只受规则里的限额和企业账户资金上限管控； 次卡：消费时找员工的次卡，没有或者用完了不可付。**枚举值**仅支持点券:COUPON_ONLY支持点券+余额:COUPON_AND_CAP默认模式:DEFAULT仅支持次卡:COUNT|COUPON_ONLY|
|standard_info_detail_list.expense_type_sub_category|String|可选|32|费用类型子类**枚举值**外卖:TAKE_AWAY到店:REACH_SHOP地铁:METRO用车:CAR默认:DEFAULT**注意事项**更多费用类型子类，查看详细文档 [详细文档](expense-type-enum.md)|TAKE_AWAY|
|standard_info_detail_list.standard_desc|String|可选|48|使用规则描述(敏感词校验)|使用规则描述样例|
|standard_info_detail_list.standard_condition_info_list|StandardConditionInfo|可选|null|使用规则条件列表||
|standard_info_detail_list.standard_condition_info_list.rule_id|String|特殊可选|32|费控条件ID**注意事项**创建时由支付宝生成，无需外部传入，修改时条件时需要填写**必选条件**当接口类型为查询、编辑时必填|2021052100152602010000000001|
|standard_info_detail_list.standard_condition_info_list.rule_factor|String|可选|32|条件类型**注意事项**指定条件id修改条件时，该字段不可变更，因此无需填写。 如需填写请参考文档填写 [详细文档](expense-type-constraints.md)|QUOTA_TOTAL|
|standard_info_detail_list.standard_condition_info_list.rule_value|String|必须|65535|费控条件值**注意事项**请参考文档填写[详细文档](expense-type-constraints.md)|500|
|standard_info_detail_list.standard_condition_info_list.rule_operator|String|可选|32|费控条件操作符 枚举值： LT("=","大于等于") GT(">","大于")**枚举值**小于:LT小于等于:LE等于:EQ不等于:NE大于等于:GE大于:GT**注意事项**该字段为保留字段，目前未被使用，无需填写|LE|
|standard_info_detail_list.standard_condition_info_list.rule_name|String|可选|32|费控条件名称**注意事项**敏感词校验，请避免填写敏感词|单次消费金额|
|standard_info_detail_list.asset_share_source_info|AssetShareSourceInfo|可选|null|当前规则可使用的其他资产来源信息||
|standard_info_detail_list.asset_share_source_info.share_mode|String|可选|32|当前规则可用的资产来源类型，搭配source_id_list使用。**枚举值**制度:INSTITUTION**注意事项**如果当前值为INSTITUTION，source_id_list内填写制度id列表，表示当前规则可使用列表中的制度的资产。|INSTITUTION|
|standard_info_detail_list.asset_share_source_info.source_id_list|String|可选|28|资产共享来源id列表，与share_mode配合设置，如果share_mode为INSTITUTION，该值则填写制度id列表**注意事项**事项一：目前最多支持10个制度id； 事项二：不能设置本使用规则所属的制度id； 事项三：仅支持发放币种相同的制度之间共享资产； 事项四：制度的multi_employee_share_mode需要一致才可共享。|["2023031600152614950000031117"]|
|standard_info_detail_list.personal_qrcode_mode|Number|可选|32|个人收款码转账是否支持因公付，默认为0。可选值：0（不支持）、1（支持）**注意事项**适用场景：个人收款码转账需支持因公付。默认无需设置此字段|0|
|effective|String|必须|32|制度启用停用状态**枚举值**停用:0启用:1|0|
|consult_mode|String|可选|32|费控咨询模式**枚举值**支付宝内部计算规则可用额度:0咨询外部服务商规则可用额度:1**注意事项**默认模式为0，该字段如果未返回表示该制度咨询模式为0|0|
|adapter_type|String|必须|32|若适用范围为EMPLOYEE_ALL，则表示制度对企业下全员生效，owner_id_list不返回；若适配范围为EMPLOYEE_SELECT，owner_id_list返回员工对应的id信息，返回的id类型通过owner_type区分；若适配范围为EMPLOYEE_DEPARTMENT，则表示对指定的部门生效，返回owner_id_list为部门id列表**枚举值**适配全员:EMPLOYEE_ALL自定义员工:EMPLOYEE_SELECT指定部门:EMPLOYEE_DEPARTMENT|EMPLOYEE_ALL|
|owner_id_list|String|可选|100|适配id列表**注意事项**adapter_type为： EMPLOYEE_DEPARTMENT：返回部门ID EMPLOYEE_SELECT：当owner_type为PHONE时返回手机号，其他值则根据对接方式返回支付宝用户ID，或企业码员工ID。当制度下指定员工个数超过1000或者指定部门个数超过100时，不返回。|["2288078000164693"]|
|owner_open_id_list|String|必须|100|适配开放id列表**注意事项**切换open_id后返回该字段：adapterType为EMPLOYEE_ALL时，不返回；adapterType为EMPLOYEE_SELECT时，返回员工id（可通过设置owner_type来指定id类型，支持员工open_id，员工企业码id和员工手机号）; adapterType为EMPLOYEE_DEPARTMENT时，返回部门id|["abcdxxxx"]|
|owner_type|String|可选|32|适配id类型**枚举值**员工支付宝id类型:EMPLOYEE员工企业码id类型:ENTERPRISE_PAY_UID员工手机号类型:PHONE员工支付宝openid类型:EMPLOYEE_OPEN_ID**注意事项**请与创建制度下适配范围时传的owner_type保持一致，企业id对接支持PHONE和ENTERPRISE_PAY_UID类型，共同账户id对接仅支持EMPLOYEE|PHONE|
|multi_employee_share_mode|String|可选|1|制度下额度是否支持多人共享。如果支持，则制度下资产所有人共享；如果不支持，则制度下的资产为个人资产，成员之间不共享。**枚举值**不支持:1支持:0**注意事项**创建制度时若该字段未填写，默认值为0，即不支持共享。|1|
|currency|String|可选|3|制度下可发放币种**枚举值**英镑:GBP港元:HKD美元:USD新加坡元:SGD日元:JPY加拿大元:CAD澳大利亚元:AUD欧元:EUR新西兰元:NZD韩圆:KRW泰铢:THB瑞士法郎:CHF瑞典克朗:SEK丹麦克朗:DKK挪威克朗:NOK马来西亚林吉特:MYR印度尼西亚盾:IDR菲律宾比索:PHP毛里求斯卢比:MUR以色列新谢克尔:ILS斯里兰卡卢比:LKR俄国卢布:RUB阿联酋迪拉姆:AED捷克克郎:CZK南非兰特:ZAR卡塔尔里亚尔:QAR人民币:CNY**注意事项**创建制度时如未设置该字段，默认返回人民币|USD|
|payment_mode|String|可选|128|费控制度出资类型**枚举值**企付:PEER_PAY个垫:OWNER_PAY|OWNER_PAY|
### 响应示例
#### 正常响应示例
```
 {
	"alipay_ebpp_invoice_institution_detailinfo_query_response":{
		"code":"10000",
		"msg":"Success",
		"institution_id":"2023042600152617860000076700",
		"institution_name":"餐补制度",
		"outer_source_id":"0b249cd9169693047263955280052c",
		"scene_type":"OVERTIME",
		"expense_type":"MEAL",
		"institution_desc":"工作餐制度",
		"effective_start_date":"2000-01-01 00:00:00",
		"effective_end_date":"2001-01-01 23:59:59",
		"issue_rule_info_list":[
			{
				"issue_rule_name":"日额度",
				"issue_rule_id":"2022032400152624930000000001",
				"target_type":"INSTITUTION",
				"target_id":"2023042600152617860000076000",
				"outer_source_id":"123456",
				"quota_type":"COUPON",
				"issue_type":"ISSUE_MONTH",
				"effective_period":"{\\\"all\\\":true}",
				"invalid_mode":0,
				"invalid_mode_value":"3213",
				"issue_amount_value":"200",
				"share_mode":0,
				"issue_start_date":"2022-08-10 00:00:00",
				"issue_end_date":"2022-12-31 23:59:59"
			}
		],
		"standard_info_list":{
			"standard_id":"2022091300152608010000334322",
			"outer_source_id":"123456",
			"standard_name":"单笔额度1元钱",
			"open_rule_id":"2021070100152721370000002201",
			"payment_policy":"PERSONAL",
			"consume_mode":"COUPON_ONLY",
			"expense_type_sub_category":"TAKE_AWAY",
			"standard_desc":"使用规则描述样例",
			"standard_condition_info_list":[
				{
					"rule_id":"2021052100152602010000000001",
					"rule_factor":"QUOTA_TOTAL",
					"rule_value":"500",
					"rule_name":"单次消费金额"
				}
			],
			"asset_share_source_info":{
				"share_mode":"INSTITUTION",
				"source_id_list":[
					"2023031600152614950000031117"
				]
			},
			"personal_qrcode_mode":0
		},
		"standard_info_detail_list":[
			{
				"standard_id":"2022091300152608010000334322",
				"outer_source_id":"123456",
				"standard_name":"单笔额度1元钱",
				"open_rule_id":"2021070100152721370000002201",
				"payment_policy":"PERSONAL",
				"consume_mode":"COUPON_ONLY",
				"expense_type_sub_category":"TAKE_AWAY",
				"standard_desc":"使用规则描述样例",
				"standard_condition_info_list":[
					{
						"rule_id":"2021052100152602010000000001",
						"rule_factor":"QUOTA_TOTAL",
						"rule_value":"500",
						"rule_name":"单次消费金额"
					}
				],
				"asset_share_source_info":{
					"share_mode":"INSTITUTION",
					"source_id_list":[
						"2023031600152614950000031117"
					]
				},
				"personal_qrcode_mode":0
			}
		],
		"effective":"0",
		"consult_mode":"0",
		"adapter_type":"EMPLOYEE_ALL",
		"owner_id_list":[
			"2288078000164693"
		],
		"owner_open_id_list":[
			"abcdxxxx"
		],
		"owner_type":"PHONE",
		"multi_employee_share_mode":"1",
		"currency":"USD",
		"payment_mode":"OWNER_PAY"
	},
	"sign":"ERITJKEIJKJHKKKKKKKHJEREEEEEEEEEEE"
}
```
 
#### 异常响应示例
```
 {"alipay_ebpp_invoice_institution_detailinfo_query_response":{"code":"20000","msg":"Service Currently Unavailable","sub_code":"isp.unknow-error","sub_msg":"系统繁忙"},"sign":"ERITJKEIJKJHKKKKKKKHJEREEEEEEEEEEE"}
```
 
### 业务错误码
|错误码|错误描述|解决方案|
|---|---|---|
|SYSTEM_ERROR|系统繁忙|服务器异常 可能发生了网络或者系统异常，导致服务调用失败，商户可以用同样的请求发起重试|
|INVALID_PARAMETER|参数有误|请根据接口返回的参数非法的具体错误信息，修改参数后进行重试|
|PERMISSION_DENIED|权限不足，未能查到企业和ISV之间的映射关系|检查传入的企业ID是否正确|