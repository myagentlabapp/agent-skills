# SPI接口集成

## 下载服务端 SDK
为了帮助服务商开发 SPI 接口，支付宝提供了开放平台服务端 SDK，包含 Java、PHP、Python、NodeJS 和 .NET 等语言的版本，封装了签名、验签逻辑。请先下载对应语言版本的 SDK 并引入开发工程。

各语言版本服务端 SDK 详细使用说明，详情可查看 [服务端 SDK 使用说明](https://ideservice.alipay.com/cms/site/0j0cjj)。

## 通信规范
### 协议规则
外部商家接入支付宝开放平台出口网关，提供的服务必须满足以下规范。

| 项目 | 规范 |
|---|---|
| 网络传输协议 | 支持 HTTP、HTTPS |
| 数据提交方法 | 支持 GET、POST |
| Content-Type | application/x-www-form-urlencoded |
| 响应报文格式 | JSON |
| 签名算法 | 支持 RSA、RSA2 |
| 字符集 | 支持 GBK、UTF-8 |

### 请求报文格式
**Header 参数**

由 SPI 接口文档中的 Header 参数定义，Header 中的 key 具有固定前缀 `x_`。

**Query 参数**

| 字段类型 | 字段 | 类型 | 必填 | 描述 | 示例值 |
|---|---|---|---|---|---|
| 系统字段（固定） | method | String | 是 | 接口 | alipay.xxx |
|  | charset | String | 是 | 字符集 | UTF-8 |
|  | version | String | 是 | 版本号，默认 1.0 | 1.0 |
|  | biz_app_id | String | 否 | 商家 app_id | 2018XXXXXXXX1234 |
|  | invoke_app_id | String | 否 | 调用方 app_id | 2018XXXXXXXX4321 |
|  | utc_timestamp | String | 是 | 时间戳（秒） | 1546077067 |
|  | sign_type | String | 是 | 签名算法，支持 RSA、RSA2 | RSA2 |
|  | sign | String | 是 | 签名值 | *** |
|  | merchant_app_id | String | 否 | 商家app_id,支持OPEN_ID时传入 | 2018XXXXXXXX5678 |
| 业务字段（自定义） | 由 SPI 接口文档中的 Query 参数定义，所有业务字段与系统字段处于同一层级 |  |  |  |  |

**Body 参数**

由 SPI 接口文档中的 Body 参数定义，Content-Type 为：`application/x-www-form-urlencoded`。

### 响应报文格式
**响应参数定义**

| 字段 | 类型 | 必填 | 描述 | 示例值 |
|---|---|---|---|---|
| response | String | 是 | JSON 格式字符串 | {"code":"10000","msg":"success","key_1":"Value1"} |
| sign | String | 否 | 签名值。仅当 SPI 响应报文需要签名时必填 | TqnBnkILs86FJWRqWWZptqIpSKLIp2vnwod177h7GLyWuLhzgRHpXgXd8GoD4flyHrHBTycQdiUjWw6VqCE5rYHrJU3iYqI1e0MLlhCb |
| app_cert_sn | String | 否 | 应用证书编号。如果应用在密钥管理升级了证书模式，则商家返回报文加签需要使用证书进行加签，同时响应报文需要返回证书编号字段 app_cert_sn | 6cd4ee7e4f31c1adba2380cc65da4a3a |

**response 定义**

| 字段 | 类型 | 必填 | 描述 | 示例值 |
|---|---|---|---|---|
| code | String | 是 | 错误码，只有两种。成功-10000 失败-40004 | 40004 |
| msg | String | 是 | 错误描述，只有两种。成功-Success 失败-Business Failed | Business Failed |
| sub_code | String | 否 | 业务错误码，在业务失败的情况下返回，与 SPI 接口文档里的"业务错误码"保持一致，值不能为 null 或 ""，在业务成功的情况下不能返回 | INVALID_PARAMS |
| sub_msg | String | 否 | 业务错误描述，在业务失败的情况下返回 | 无效参数 |
| 业务字段（自定义） | 由 SPI 接口文档中的响应参数定义 |  |  |  |

### 响应报文示例
**成功报文示例（含签名，非证书模式）**，**不能返回 sub_code 和 sub_msg**

```json
{
    "response": {
        "code": "10000",
        "msg": "Success",
        "name": "lisi"
    },
    "sign": "TqnBnkILs86FJWRqWWZptqIpSKLIp2vnwod177h7GLyWuLhzgRHpXgXd8GoD4flyHrHBTycQdiUjWw6VqCE5rYHrJU3iYqI1e0MLlhCb"
}
```

**成功报文示例（含签名，证书模式）**，**不能返回 sub_code 和 sub_msg**

```json
{
    "response": {
        "code": "10000",
        "msg": "Success",
        "name": "lisi"
    },
    "app_cert_sn": "6cd4ee7e4f31c1adba2380cc65da4a3a",
    "sign": "TqnBnkILs86FJWRqWWZptqIpSKLIp2vnwod177h7GLyWuLhzgRHpXgXd8GoD4flyHrHBTycQdiUjWw6VqCE5rYHrJU3iYqI1e0MLlhCb"
}
```

**成功报文示例（不含签名，响应不加签模式）**，**不能返回 sub_code 和 sub_msg**

```json
{
    "response": {
        "code": "10000",
        "msg": "Success",
        "name": "lisi"
    }
}
```

**失败报文示例（含签名，非证书模式）**

```json
{
    "response": {
        "code": "40004",
        "msg": "Business Failed",
        "sub_code": "INVALID_PARAMS",
        "sub_msg": "无效参数"
    },
    "sign": "TqnBnkILs86FJWRqWWZptqIpSKLIp2vnwod177h7GLyWuLhzgRHpXgXd8GoD4flyHrHBTycQdiUjWw6VqCE5rYHrJU3iYqI1e0MLlhCb"
}
```

**失败报文示例（含签名，证书模式）**

```json
{
    "response": {
        "code": "40004",
        "msg": "Business Failed",
        "sub_code": "INVALID_PARAMS",
        "sub_msg": "无效参数"
    },
    "app_cert_sn": "6cd4ee7e4f31c1adba2380cc65da4a3a",
    "sign": "TqnBnkILs86FJWRqWWZptqIpSKLIp2vnwod177h7GLyWuLhzgRHpXgXd8GoD4flyHrHBTycQdiUjWw6VqCE5rYHrJU3iYqI1e0MLlhCb"
}
```

**失败报文示例（不含签名，响应不加签模式）**

```json
{
    "response": {
        "code": "40004",
        "msg": "Business Failed",
        "sub_code": "INVALID_PARAMS",
        "sub_msg": "无效参数"
    }
}
```

### 商家验签规则
**支付宝出口网关签名流程**：支付宝出口网关会对 HTTP 请求加签，同时将签名值放在 sign 参数中。

**参与签名的参数包括两部分**：**业务参数（包括 SPI 接口定义的 header、query、body 参数）+ 系统参数（除去 sign、sign_type 以外的所有系统字段）**。所有签名参数组装成待签名的 map，然后对此 map 按照 key 的 ASCII 码从小到大排序并生成 k=v 字符串对，k=v 对之间以"&"连接，然后待签名字符串按 charset 设定的编码类型、私钥及加签类型生成签名值。

**假设收到的 HTTP 请求体中内容如下：**

```
query: biz_app_id=2018XXX123&charset=UTF-8&invoke_app_id=2018XXX321&method=spi.xxx&query_key=query_value&utc_timestamp=1546077067&version=1.0&sign=xxxxxxxxx(sign值)
body: body_a=body_a_content&body_b=body_b_content
header: header_key=header_value
```

**可以整理得到所有待验签参数：**

```
biz_app_id=2018XXX123
charset=UTF-8
invoke_app_id=2018XXX321
method=spi.xxx
query_key=query_value
utc_timestamp=1546077067
version=1.0
body_a=body_a_content
body_b=body_b_content
header_key=header_value
```

**根据待验签参数 key 按 ASCII 顺序排序：**

```
biz_app_id=2018XXX123
body_a=body_a_content
body_b=body_b_content
charset=UTF-8
header_key=header_value
invoke_app_id=2018XXX321
method=spi.xxx
query_key=query_value
utc_timestamp=1546077067
version=1.0
```

**生成待验签字符串：**

```
biz_app_id=2018XXX123&body_a=body_a_content&body_b=body_b_content&charset=UTF-8&header_key=header_value&invoke_app_id=2018XXX321&method=spi.xxx&query_key=query_value&utc_timestamp=1546077067&version=1.0
```

**验签**：使用非对称验签算法 RSA（SHA1withRSA）或者 RSA2（SHA256withRSA）对待验签字符串进行验签，具体验签算法由 sign_type 指定。验签建议使用 [支付宝开放平台 SDK](https://ideservice.alipay.com/cms/site/0j0cjj) 封装的验签工具类进行验签，调用方法如下：

```java
/**
 * 明文公钥模式：RSA/RSA2验签，sign和sign_type不参与验签
 *
 * @param params    签名参数：业务参数（包括SPI接口定义的header、query、body参数）+系统参数（除去sign、sign_type以外的所有系统字段）
 * @param publicKey 支付宝公钥明文
 * @param charset   验签字符集
 * @param signType  验签算法（RSA/RSA2）
 */
boolean AlipaySignature.rsaCheckV1(Map<String, String> params, String publicKey,
        String charset, String signType)

/**
 * 证书模式：RSA/RSA2验签，sign和sign_type不参与验签
 *
 * @param params               签名参数：业务参数（包括SPI接口定义的header、query、body参数）+系统参数（除去sign、sign_type以外的所有系统字段）
 * @param alipayPublicCertPath 支付宝公钥证书
 * @param charset              验签字符集
 * @param signType             验签算法（RSA/RSA2）
 */
boolean AlipaySignature.rsaCertCheckV1(Map<String, String> params, String alipayPublicCertPath,
        String charset, String signType)
```

### 商家签名规则
**说明**：若在 **服务基础配置** > **响应是否加签** 中，选择 **否**，则跳过当前步骤，进行下一步。商家响应报文必须为 JSON 格式。非证书模式响应报文示例如下：

```json
{
    "response": {
        "code": "10000",
        "msg": "Success",
        "key": "value"
    },
    "sign": "xxx"
}
```

**生成签名字符串**：对 response 节点的值进行加签，待签名字符串为：

```json
{
    "code": "10000",
    "msg": "Success",
    "key": "value"
}
```

**签名**：签名算法与签名算法一致，由 sign_type 指定。建议使用支付宝开放平台 SDK 封装的签名工具类进行签名，调用方法如下：

```java
/**
 * RSA/RSA2签名，sign和sign_type不参与签名
 *
 * @param content    待签名内容
 * @param privateKey 私钥
 * @param charset    字符集
 * @param signType   签名类型
 * @return 签名值
 * @throws AlipayApiException
 */
public static String rsaSign(String content, String privateKey, String charset, String signType)
```

**注意**：支付宝在进行响应报文的验签过程中，不会对响应报文进行任何逻辑的排序，因此需要保证加签的原文与支付宝侧收到的响应报文顺序一致，否则将导致支付宝侧验签失败情况，下列几种情况需要避免：
1. 加签前对 response 节点的值进行任何的排序和过滤逻辑。
2. 服务端框架将响应对象序列化为响应报文的序列化方式，与生成加签原文的序列化方式不同。（Java 语言的 spring 框架可以通过返回 String 类型+标注 @ResponseBody 来屏蔽框架序列化，保证序列化方式一致，代码详见下述demo，其余服务端框架请自行探索。）

## 服务端实现 Demo
以下 Demo 是通过 Java 实现的 SPI 服务样例，包括验签 **支付宝请求报文、业务逻辑处理、商家加签** 以及 **响应报文构造** 的逻辑。**该 Demo 仅供参考，不同语言环境可根据该 Demo 的处理思路自行实现。**

```java
@RequestMapping(value = "/isv/spi/service")
@ResponseBody
public String spiService(@RequestParam Map<String, String> params, @RequestHeader Map<String, String> headers) {
    // http响应结果载体
    JSONObject result = new JSONObject();
    // 业务处理结果载体
    JSONObject response = new JSONObject();
    // 1、验签支付宝请求报文
    boolean isPass = false;

    // 提取spi接口定义的header参数,接口定义所有参数都需要参与验签（接口没有定义header参数则忽略这一步）
    String spiHeader = headers.get("spi_header");
    params.put("spi_header", spiHeader);

    isPass = AlipaySignature.rsaCheckV1(params, alipayPublicKey, "UTF-8", "RSA2");
    if (isPass) {
        // 2、验签成功：处理业务逻辑，并构造业务处理结果
        response.put("code", "10000");
        response.put("msg", "Success");
        response.put("biz", "value");
        JSONObject person = new JSONObject();
        person.put("age", "18");
        person.put("height", "180");
        response.put("person", person);   // response中嵌套复杂类型数据结构场景
    } else {
        // 3、验签失败：构造错误码
        response.put("code", "40004");
        response.put("msg", "Business Failed");
        response.put("sub_code", "ISV-VERIFICATION-FAILED");
        response.put("sub_msg", "验签失败");
    }
    // 4、业务处理结果加签 （可选，查看 服务基础配置 章节）
    // contentToSign为 {"code":"10000","msg":"Success","biz":"value","person":{"age":"18","height":"180"}}
    String contentToSign = response.toJSONString();
    String sign = null;
    sign = AlipaySignature.rsaSign(contentToSign, isvPrivateKey, "UTF-8", "RSA2");
    // 5、构造http响应结果
    result.put("sign", sign);
    //可选，查看 服务基础配置
    result.put("response", response);
    // 返回json格式响应报文
    return result.toJSONString();
}
```
