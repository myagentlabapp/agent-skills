# spi.alipay.commerce.ec.expensecontrol.quota.pay(企业因公额度扣减)
调用服务商接口进行额度扣减

注意：

在调用 SPI 时，外部商户响应报文中的统一错误码只有两种：10000 和 40004，具体信息如下图所示：

| code（返回码） | msg（返回码描述） | sub_code（明细返回码） | sub_msg（明细返回码描述） | 解决方案 |
|---|---|---|---|---|
| 10000 | Success（接口调用成功，调用结果请参考具体的 SPI 文档所对应的业务返回参数） | - | - | - |
| 40004 | Business Failed（业务处理失败） | 对应业务错误码，明细错误码和解决方案请参见具体的 SPI 文档。 | - | - |

## 公共请求参数
|参数|类型|是否必选|最大长度|描述|示例值|
|---|---|---|---|---|---|
|method|String|必选|128|接口名称|alipay.trade.order.settle|
|charset|String|必选|10|请求使用的编码格式，如utf-8,gbk,gb2312等|utf-8|
|version|String|必选|3|版本号，默认1.0|1.0|
|utc_timestamp|String|必选|19|发送请求的时间戳，单位秒|1699271704|
|sign_type|String|必选|10|签名类型，开发者在支付宝开放平台配置接口加签方式|RSA2|
|sign|String|必选|344|商户请求参数的签名串|详见示例|

## 业务请求参数
|参数|类型|是否必选|最大长度|描述|示例值|
|---|---|---|---|---|---|
|standard_id|String|必选|32|规则ID|2021101500152601000000000382|
|trade_no|String|必选|128|支付宝交易号，可以作为幂等ID|2021092222001106280506131871|
|enterprise_id|String|必选|64|企业ID|2088000450803244|
|employee_id|String|必选|64|消费员工ID|2288094003774365|
|apply_amount|Number|必选|32|咨询金额（分）|2000|
|biz_date|Date|必选|32|业务时间|2022-11-28 00:00:01|

## 公共响应参数
|参数|类型|是否必选|最大长度|描述|示例值|
|---|---|---|---|---|---|
|code|String|必选|-|网关返回码|40004|
|msg|String|必选|-|网关返回码描述|Business Failed|
|sub_code|String|可选|-|业务返回码，参见具体的API接口文档|ACQ.TRADE_HAS_SUCCESS|
|sub_msg|String|可选|-|业务返回码描述，参见具体的API接口文档|交易已被支付|
|sign|String|必选|-|签名|DZXh8eeTuAHoYE3w1J+POiPhfDxOYBfUNn1lkeT/V7P4zJdyojWEa6IZs6Hz0yDW5Cp/viufUb5I0/V5WENS3OYR8zRedqo6D+fUTdLHdc+EFyCkiQhBxIzgngPdPdfp1PIS7BdhhzrsZHbRqb7o4k3Dxc+AAnFauu4V6Zdwczo=|

## 业务响应参数
|参数|类型|是否必选|最大长度|描述|示例值|
|---|---|---|---|---|---|
|result|ExpenseControlQuotaPayResult|必选|-|费控额度扣减结果|-|
|result.result|Boolean|必选|8|扣减是否成功|true|
|result.result_code|String|可选|32|结果编码|INVALID_STANDARD|
|result.result_msg|String|可选|64|执行结果描述|找不到对应规则|

## 业务错误码
|错误码|错误描述|解决方案|
|---|---|---|
|SYSTEM_ERROR|系统繁忙|查看是否有逻辑错误|
|INVALID_PARAMETER|参数有误，参数不正确|参数错误，检查入参是否正确|
|UNKNOWN_ERROR|通用错误类型|兜底业务异常，如被限流、无权限等|

## 响应示例
### 正常响应示例
```json
{
    "response": {
        "code": "10000",
        "msg": "Success",
        "result": {
            "result": true,
            "result_code": "INVALID_STANDARD",
            "result_msg": "找不到对应规则"
        }
    },
    "sign": "ERITJKEIJKJHKKKKKKKHJEREEEEEEEEEEE"
}
```

### 异常响应示例
```json
{
    "response": {
        "code": "40004",
        "msg": "Business Failed",
        "sub_code": "SYSTEM_ERROR",
        "sub_msg": "系统繁忙"
    },
    "sign": "ERITJKEIJKJHKKKKKKKHJEREEEEEEEEEEE"
}
```
