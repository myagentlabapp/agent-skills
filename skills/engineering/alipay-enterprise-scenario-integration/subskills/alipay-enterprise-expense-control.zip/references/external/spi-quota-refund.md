# spi.alipay.commerce.ec.expensecontrol.quota.refund(费控额度退款)
1、用户支付后若未查询到交易结果或支付失败，则会调用此接口恢复已经扣减的额度。（refund_mode = RECOVER）若最后交易成功，则仍然会调用扣减接口进行额度扣减。
2、用户发起退款后，则会调用此接口进行退款，可进行多次退款直至所有金额都被退款完毕。（refund_mode = REFUND）

注意：

在调用 SPI 时，外部商户响应报文中的统一错误码只有两种：10000 和 40004，具体信息如下图所示：

| code（返回码） | msg（返回码描述） | sub_code（明细返回码） | sub_msg（明细返回码描述） | 解决方案 |
|---|---|---|---|---|
| 10000 | Success（接口调用成功，调用结果请参考具体的 SPI 文档所对应的业务返回参数） | - | - | - |
| 40004 | Business Failed（业务处理失败） | 对应业务错误码，明细错误码和解决方案请参见具体的 SPI 文档。 | - | - |

## 公共请求参数
|参数|类型|是否必选|最大长度|描述|示例值|
|---|---|---|---|---|---|
|method|String|必选|128|接口名称|alipay.trade.order.settle|
|charset|String|必选|10|请求使用的编码格式，如utf-8,gbk,gb2312等|utf-8|
|version|String|必选|3|版本号，默认1.0|1.0|
|utc_timestamp|String|必选|19|发送请求的时间戳，单位秒|1699271704|
|sign_type|String|必选|10|签名类型，开发者在支付宝开放平台配置接口加签方式|RSA2|
|sign|String|必选|344|商户请求参数的签名串|详见示例|

## 业务请求参数
|参数|类型|是否必选|最大长度|描述|示例值|
|---|---|---|---|---|---|
|trade_no|String|必选|128|正向交易订单号|2021092222001106280506131871|
|refund_no|String|必选|128|trade_no + refund_no 为退款唯一幂等条件。RECOVER 时退款单据号为 "-1"|325456576765475|
|refund_mode|String|必选|8|额度退还模式|RECOVER|
|enterprise_id|String|必选|64|企业ID|2088000450803244|
|employee_id|String|必选|64|消费员工id|2288094003774365|
|refund_amount|Number|必选|32|退款金额（分）|2000|
|refund_time|Date|特殊可选|32|退款时间，RECOVER 时为空|2022-11-28 00:00:01|

**refund_mode枚举值：**
- RECOVER：未查到交易状态，额度恢复（额度可能再次扣减）
- REFUND：订单发起退款，可多次退款

## 公共响应参数
|参数|类型|是否必选|最大长度|描述|示例值|
|---|---|---|---|---|---|
|code|String|必选|-|网关返回码|40004|
|msg|String|必选|-|网关返回码描述|Business Failed|
|sub_code|String|可选|-|业务返回码，参见具体的API接口文档|ACQ.TRADE_HAS_SUCCESS|
|sub_msg|String|可选|-|业务返回码描述，参见具体的API接口文档|交易已被支付|
|sign|String|必选|-|签名|DZXh8eeTuAHoYE3w1J+POiPhfDxOYBfUNn1lkeT/V7P4zJdyojWEa6IZs6Hz0yDW5Cp/viufUb5I0/V5WENS3OYR8zRedqo6D+fUTdLHdc+EFyCkiQhBxIzgngPdPdfp1PIS7BdhhzrsZHbRqb7o4k3Dxc+AAnFauu4V6Zdwczo=|

## 业务响应参数
|参数|类型|是否必选|最大长度|描述|示例值|
|---|---|---|---|---|---|
|result|ExpenseControlQuotaRefundResult|必选|-|额度退款结果|-|
|result.result|Boolean|必选|8|扣减是否成功|true|
|result.result_code|String|可选|32|结果编码|INVALID_TRADE_NO|
|result.result_msg|String|可选|64|执行结果描述，找不到正向交易号|找不到正向交易号|

**result_code枚举值：**
- INVALID_TRADE_NO：找不到正向交易号
- QUOTA_NOT_DEDUCT：额度未被扣减
- QUOTA_RECOVERED：额度已被恢复（额度已有恢复记录，则返回此错误码）
- QUOTA_REFUNDED：额度已被退款（额度已有退款记录，则返回此错误码）
- AMOUNT_EXCEED：退款额度已超限（退款或恢复的额度已经超过扣减的金额）

## 业务错误码
|错误码|错误描述|解决方案|
|---|---|---|
|SYSTEM_ERROR|系统繁忙|查看是否有逻辑错误|
|INVALID_PARAMETER|参数有误，参数不正确|参数错误，检查入参是否正确|
|UNKNOWN_ERROR|通用错误类型|兜底业务异常，如被限流、无权限等|

## 响应示例
### 正常响应示例
```json
{
    "response": {
        "code": "10000",
        "msg": "Success",
        "result": {
            "result": true,
            "result_code": "INVALID_TRADE_NO",
            "result_msg": "找不到正向交易号"
        }
    },
    "sign": "ERITJKEIJKJHKKKKKKKHJEREEEEEEEEEEE"
}
```

### 异常响应示例
```json
{
    "response": {
        "code": "40004",
        "msg": "Business Failed",
        "sub_code": "SYSTEM_ERROR",
        "sub_msg": "系统繁忙"
    },
    "sign": "ERITJKEIJKJHKKKKKKKHJEREEEEEEEEEEE"
}
```
