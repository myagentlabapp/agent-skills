# 企业码费控 - 内部费控模式

## 概述

内部费控模式下，服务商将管控规则和额度通过接口同步到企业码，由企业码进行费控管控。

## 流程图

```
┌─────────────────────────────────────────────────────────────────────────┐
│                           内部费控模式流程                               │
└─────────────────────────────────────────────────────────────────────────┘

【制度管理】
场景前置决策：生成制度创建代码前，如果方案型 Skill 或用户上下文已给出费用类型和费用类型子类，直接沿用；如果无法推断，必须先询问用户确认。未确认场景前不得生成制度创建代码。

企业管理员 → 服务商系统 → 支付宝企业码
   │              │              │
   ├─创建费控制度─┤→ alipay.ebpp.invoice.institution.create
   │              │              │      【关键步骤：需先确认场景和选择规则因子】
   │              │              │      1. 确认费用类型和费用类型子类（场景）参考文档 ../common/expense-type-enum.md
   │              │              │      2. 根据场景查阅 ../common/expense-type-constraints.md 确定必须使用的规则因子
   │              │              │      3. 查阅 ../common/rule-factors.md 获取规则因子值的结构和示例值
   │              │              │      4. 查阅 ../common/issue-rule-fields.md 获取发放规则字段示例值（可选）
   │              │              │      5. 查阅 ../common/institution-create.md 接口文档
   ├─编辑费控制度─┤→ alipay.ebpp.invoice.institution.modify
   ├─删除费控制度─┤→ alipay.ebpp.invoice.institution.delete
   ├─查询制度列表─┤→ alipay.ebpp.invoice.institution.pageinfo.query
   ├─查询制度详情─┤→ alipay.ebpp.invoice.institution.detailinfo.query
   └─查询适用成员─┘→ alipay.ebpp.invoice.institution.scopepageinfo.query
                      (员工数>1000或部门数>100时使用)

【手工发放管理】（可选，适用于差旅、招待等场景）
企业管理员 → 服务商系统 → 支付宝企业码
   │              │              │
   └─手工发放额度─┤→ alipay.ebpp.invoice.expensecontrol.quota.create
   └─查询发放明细─┘→ alipay.ebpp.invoice.issuebatch.issuerecords.batchquery

【额度管理】（可选）
企业管理员 → 服务商系统 → 支付宝企业码
   │              │              │
   ├─查询可用额度─┤→ alipay.ebpp.invoice.expensecontrol.quota.query
   ├─修改可用额度─┤→ alipay.ebpp.invoice.expensecontrol.quota.modify
   └─删除可用额度─┘→ alipay.ebpp.invoice.expensecontrol.quota.delete
```

## 接口文档

| 阶段 | 接口说明 | 接口文档 | 备注 |
|------|----------|----------|------|
| **制度管理** | 创建费控制度 | [institution-create.md](../common/institution-create.md) | **关键步骤**：<br>1. 确认[费用类型和子类](../common/expense-type-enum.md)<br>2. 选择[规则因子](../common/expense-type-constraints.md)<br>3. 查看[规则因子明细](../common/rule-factors.md)<br>4. 配置[发放规则](../common/issue-rule-fields.md)（可选） |
| | 编辑费控制度 | [institution-modify.md](../common/institution-modify.md) | |
| | 删除费控制度 | [institution-delete.md](../common/institution-delete.md) | |
| | 查询制度列表 | [institution-pageinfo-query.md](../common/institution-pageinfo-query.md) | |
| | 查询制度详情 | [institution-detailinfo-query.md](../common/institution-detailinfo-query.md) | |
| | 查询适用成员 | [institution-scopepageinfo-query.md](../common/institution-scopepageinfo-query.md) | 员工>1000或部门>100时使用 |
| **手工发放管理**（可选） | 创建手工发放额度 | [quota-create.md](quota-create.md) | 适用于差旅、招待等场景 |
| | 查询发放明细 | [issuebatch-issuerecords-query.md](issuebatch-issuerecords-query.md) | |
| **额度管理**（可选） | 查询员工可用额度 | [quota-query.md](quota-query.md) | |
| | 修改员工可用额度 | [quota-modify.md](quota-modify.md) | |
| | 删除员工可用额度 | [quota-delete.md](quota-delete.md) | |

## 参考文档

- [费用类型枚举](../common/expense-type-enum.md) - 费用类型及子类定义
- [费用类型与规则因子约束](../common/expense-type-constraints.md) - 各场景下规则因子的使用约束
- [使用规则因子枚举](../common/rule-factors.md) - 所有规则因子详细说明
- [发放规则字段说明](../common/issue-rule-fields.md) - 发放规则字段详细说明
