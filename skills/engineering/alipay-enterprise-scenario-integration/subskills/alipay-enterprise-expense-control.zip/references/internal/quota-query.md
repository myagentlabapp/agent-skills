# alipay.ebpp.invoice.expensecontrol.quota.query(查询余额/点券)
支持第三方代理调用：本接口支持第三方开发者代用户发起调用
## 通用场景
查询余额或者点券
### 公共请求参数
|参数英文名|类型|是否必选|长度/取值|描述|示例值|
|---|---|---|---|---|---|
|app_id|String|必选|32|支付宝分配给开发者的应用ID|2014072300007148|
|method|String|必选|128|接口名称|alipay.ebpp.invoice.expensecontrol.quota.query|
|format|String|可选|40|仅支持JSON|JSON|
|charset|String|必选|10|请求使用的编码格式，如utf-8,gbk,gb2312等|utf-8|
|sign_type|String|必选|10|商户生成签名字符串所使用的签名算法类型，目前支持RSA2和RSA，推荐使用RSA2|RSA2|
|sign|String|必选|344|商户请求参数的签名串，详见[签名](https://ideservice.alipay.com/cms/site/02khjm)|详见示例|
|timestamp|String|必选|19|发送请求的时间，格式"yyyy-MM-dd HH:mm:ss"|2014-07-24 03:07:50|
|version|String|必选|3|调用的接口版本，固定为：1.0|1.0|
|app_auth_token|String|可选|40|详见[应用授权概述](https://ideservice.alipay.com/cms/site/04h2nx)|null|
|biz_content|String|必选||请求参数的集合，最大长度不限，除公共参数外所有请求参数都必须放在这个参数中传递，具体参照各产品快速接入文档|null|
### 业务请求参数
|参数英文名|类型|是否必选|长度/取值|描述|示例值|
|---|---|---|---|---|---|
|account_id|String|特殊可选|32|企业共同账户ID**注意事项**通过企业码1.0接口签约的共同账户，和agreement_no搭配使用。|2088000194958956|
|agreement_no|String|特殊可选|32|授权签约协议号**注意事项**可通过签约消息获取。配合共同账户id使用，当填写企业共同账户id时，此字段必填。|20215425001112341234|
|target_type|String|特殊可选|32|额度维度**枚举值**费用类型维度:EXPENSE_TYPE规则聚合维度:RULE_GROUP_AGGREGATION制度维度:INSTITUTION**必选条件**当未指定额度id查询时，需填写该字段|EXPENSE_TYPE|
|target_id|String|特殊可选|32|额度维度ID**注意事项**当 target_type=EXPENSE_TYPE 时，值为 MEAL（工作餐） 当target_type=RULE_GROUP_AGGREGATION 时，值为费控规则聚合ID 当target_type=INSTITUTION 时，值为制度ID，target_type和target_id要正确对应，否则会导致查不到额度。|MEAL|
|owner_type|String|必须|32|额度所属者类型**枚举值**支付宝id:EMPLOYEE员工企业码id:ENTERPRISE_PAY_UID员工手机号:PHONE企业类型:ENTERPRISE**注意事项**使用企业id对接时，支持ENTERPRISE_PAY_UID和PHONE类型，使用共同账户id对接时，支持EMPLOYEE类型。请注意与创建额度时填写的owner_type保持一致，否则会导致查不到额度。|EMPLOYEE|
|owner_id|String|特殊可选|32|额度所属者ID新商户建议使用owner_open_id替代该字段。对于新商户，owner_id字段未来计划逐步回收，存量商户可继续使用。如使用owner_open_id，请确认 应用-开发配置-openid配置管理 已启用。无该配置项，可查看[openid配置申请](https://opendocs.alipay.com/mini/0ai9ok?pathHash=de631c06)。**注意事项**owner_type为EMPLOYEE时为员工支付宝ID owner_type为PHONE时为员工手机号 owner_type为ENTERPRISE_PAY_UID时为员工企业码ID|2088210888827370|
|owner_open_id|String|特殊可选|128|额度所属者开放ID&nbsp; 详情可查看[ openid简介](https://opendocs.alipay.com/mini/0ai2i6?pathHash=13dd5946)**注意事项**owner_type为EMPLOYEE时为员工开放id owner_type为PHONE时为员工手机号 owner_type为ENTERPRISE_PAY_UID时为员工企业码ID|abcdxxxx|
|quota_id_list|String|可选|28|额度ID列表**注意事项**最多传入10个quota_id|["2024103100152611410000000061"]|
|page_size|Number|必须|100|每页条数**注意事项**每页查询上限20条|20|
|page_num|Number|必须|100|页码|1|
|enterprise_id|String|特殊可选|32|企业id**注意事项**通过企业码2.0签约接口签约，如填写企业id，accout_id和agreement_no可以不填写|2088000194958956|
|quota_type|String|可选|32|额度类型**枚举值**点券:COUPON余额:CAP**注意事项**支持点券和余额，不填写则默认查询所有类型的额度|COUPON|
### 请求示例
#### 默认示例
##### csharp
```
 using System;
using System.Collections.Generic;
using Aop.Api;
using Aop.Api.Request;
using Aop.Api.Response;
using Aop.Api.Domain;
using Aop.Api.Util;
namespace SdkDemoTest
{
    public class AlipayEbppInvoiceExpensecontrolQuotaQuery
    {
        public static void Main(string[] args) 
        {
            // 初始化SDK
            IAopClient alipayClient = new DefaultAopClient(GetAlipayConfig());
            // 构造请求参数以调用接口
            AlipayEbppInvoiceExpensecontrolQuotaQueryRequest request = new AlipayEbppInvoiceExpensecontrolQuotaQueryRequest();
            AlipayEbppInvoiceExpensecontrolQuotaQueryModel model = new AlipayEbppInvoiceExpensecontrolQuotaQueryModel();
            
            // 设置企业共同账户ID
            model.AccountId = "2088000194958956";
            
            // 设置授权签约协议号
            model.AgreementNo = "20215425001112341234";
            
            // 设置额度维度
            model.TargetType = "EXPENSE_TYPE";
            
            // 设置额度维度id
            model.TargetId = "MEAL";
            
            // 设置额度所属者类型
            model.OwnerType = "EMPLOYEE";
            
            // uid参数未来计划废弃，存量商户可继续使用，新商户请使用openid。请根据应用-开发配置-openid配置选择支持的字段。
            // model.OwnerId = "2088210888827370";
            
            // 设置额度所属者开放ID
            model.OwnerOpenId = "abcdxxxx";
            
            // 设置额度ID列表
            List<String> quotaIdList = new List<String>();
            quotaIdList.Add("2024103100152611410000000061");
            model.QuotaIdList = quotaIdList;
            
            // 设置每页条数
            model.PageSize = 20;
            
            // 设置页码
            model.PageNum = 1;
            
            // 设置企业id
            model.EnterpriseId = "2088000194958956";
            
            // 设置额度类型
            model.QuotaType = "COUPON";
            
            request.SetBizModel(model);
            // 第三方代调用模式下请设置app_auth_token
            // request.PutOtherTextParam("app_auth_token", "<-- 请填写应用授权令牌 -->");

            AlipayEbppInvoiceExpensecontrolQuotaQueryResponse response = alipayClient.Execute(request);

            if(!response.IsError)
            {
                Console.WriteLine("调用成功");
            }
            else
            {
                Console.WriteLine("调用失败");
            }
        }

        private static AlipayConfig GetAlipayConfig()
        {
            string privateKey  = "<-- 请填写您的应用私钥，例如：MIIEvQIBADANB ... ... -->";
            string alipayPublicKey = "<-- 请填写您的支付宝公钥，例如：MIIBIjANBg... -->";
            AlipayConfig alipayConfig = new AlipayConfig();
            alipayConfig.ServerUrl = "https://openapi.alipay.com/gateway.do";
            alipayConfig.AppId = "<-- 请填写您的AppId，例如：2019091767145019 -->";
            alipayConfig.PrivateKey = privateKey;
            alipayConfig.Format = "json";
            alipayConfig.AlipayPublicKey = alipayPublicKey;
            alipayConfig.Charset = "UTF-8";
            alipayConfig.SignType = "RSA2";
            return alipayConfig;
        }
    }
}
```
 

##### java
```
 package com.java.sdk.demo;

import com.alipay.api.AlipayApiException;
import com.alipay.api.AlipayClient;
import com.alipay.api.DefaultAlipayClient;
import com.alipay.api.AlipayConfig;
import com.alipay.api.request.AlipayEbppInvoiceExpensecontrolQuotaQueryRequest;
import com.alipay.api.domain.AlipayEbppInvoiceExpensecontrolQuotaQueryModel;
import com.alipay.api.response.AlipayEbppInvoiceExpensecontrolQuotaQueryResponse;

import com.alipay.api.FileItem;
import java.util.Base64;
import java.util.ArrayList;
import java.util.List;

public class AlipayEbppInvoiceExpensecontrolQuotaQuery {

    public static void main(String[] args) throws AlipayApiException {
        // 初始化SDK
        AlipayClient alipayClient = new DefaultAlipayClient(getAlipayConfig());

        // 构造请求参数以调用接口
        AlipayEbppInvoiceExpensecontrolQuotaQueryRequest request = new AlipayEbppInvoiceExpensecontrolQuotaQueryRequest();
        AlipayEbppInvoiceExpensecontrolQuotaQueryModel model = new AlipayEbppInvoiceExpensecontrolQuotaQueryModel();
        
        // 设置企业共同账户ID
        model.setAccountId("2088000194958956");
        
        // 设置授权签约协议号
        model.setAgreementNo("20215425001112341234");
        
        // 设置额度维度
        model.setTargetType("EXPENSE_TYPE");
        
        // 设置额度维度id
        model.setTargetId("MEAL");
        
        // 设置额度所属者类型
        model.setOwnerType("EMPLOYEE");
        
        // uid参数未来计划废弃，存量商户可继续使用，新商户请使用openid。请根据应用-开发配置-openid配置选择支持的字段。
        // model.setOwnerId("2088210888827370");
        
        // 设置额度所属者开放ID
        model.setOwnerOpenId("abcdxxxx");
        
        // 设置额度ID列表
        List<String> quotaIdList = new ArrayList<String>();
        quotaIdList.add("2024103100152611410000000061");
        model.setQuotaIdList(quotaIdList);
        
        // 设置每页条数
        model.setPageSize(20L);
        
        // 设置页码
        model.setPageNum(1L);
        
        // 设置企业id
        model.setEnterpriseId("2088000194958956");
        
        // 设置额度类型
        model.setQuotaType("COUPON");
        
        request.setBizModel(model);
        // 第三方代调用模式下请设置app_auth_token
        // request.putOtherTextParam("app_auth_token", "<-- 请填写应用授权令牌 -->");

        AlipayEbppInvoiceExpensecontrolQuotaQueryResponse response = alipayClient.execute(request);
        System.out.println(response.getBody());

        if (response.isSuccess()) {
            System.out.println("调用成功");
        } else {
            System.out.println("调用失败");
            // sdk版本是"4.38.0.ALL"及以上,可以参考下面的示例获取诊断链接
            // String diagnosisUrl = DiagnosisUtils.getDiagnosisUrl(response);
            // System.out.println(diagnosisUrl);
        }
    }

    private static AlipayConfig getAlipayConfig() {
        String privateKey  = "<-- 请填写您的应用私钥，例如：MIIEvQIBADANB ... ... -->";
        String alipayPublicKey = "<-- 请填写您的支付宝公钥，例如：MIIBIjANBg... -->";
        AlipayConfig alipayConfig = new AlipayConfig();
        alipayConfig.setServerUrl("https://openapi.alipay.com/gateway.do");
        alipayConfig.setAppId("<-- 请填写您的AppId，例如：2019091767145019 -->");
        alipayConfig.setPrivateKey(privateKey);
        alipayConfig.setFormat("json");
        alipayConfig.setAlipayPublicKey(alipayPublicKey);
        alipayConfig.setCharset("UTF-8");
        alipayConfig.setSignType("RSA2");
        return alipayConfig;
    }
}
```
 

##### php
```
 <?php
require_once '../aop/AopClient.php';
require_once '../aop/AopCertClient.php';
require_once '../aop/AopCertification.php';
require_once '../aop/AlipayConfig.php';
require_once '../aop/request/AlipayEbppInvoiceExpensecontrolQuotaQueryRequest.php';

// 初始化SDK
$alipayClient = new AopClient(getAlipayConfig());
// 构造请求参数以调用接口
$request = new AlipayEbppInvoiceExpensecontrolQuotaQueryRequest();
$model = array();

// 设置企业共同账户ID
$model['account_id'] = "2088000194958956";

// 设置授权签约协议号
$model['agreement_no'] = "20215425001112341234";

// 设置额度维度
$model['target_type'] = "EXPENSE_TYPE";

// 设置额度维度id
$model['target_id'] = "MEAL";

// 设置额度所属者类型
$model['owner_type'] = "EMPLOYEE";

// uid参数未来计划废弃，存量商户可继续使用，新商户请使用openid。请根据应用-开发配置-openid配置选择支持的字段。
// $model['owner_id'] = "2088210888827370";

// 设置额度所属者开放ID
$model['owner_open_id'] = "abcdxxxx";

// 设置额度ID列表
$quotaIdList = array();
$quotaIdList[] = "2024103100152611410000000061";
$model['quota_id_list'] = $quotaIdList;

// 设置每页条数
$model['page_size'] = 20;

// 设置页码
$model['page_num'] = 1;

// 设置企业id
$model['enterprise_id'] = "2088000194958956";

// 设置额度类型
$model['quota_type'] = "COUPON";

$request->setBizContent(json_encode($model,JSON_UNESCAPED_UNICODE));
// 如果是第三方代调用模式，请设置app_auth_token（应用授权令牌）
$responseResult = $alipayClient->execute($request, null, "<-- 请填写应用授权令牌 -->", null);
$responseApiName = str_replace(".","_",$request->getApiMethodName())."_response";
$response = $responseResult->$responseApiName;
if(!empty($response->code)&&$response->code==10000){
    echo("调用成功");
}
else{
    echo("调用失败");
}

function getAlipayConfig()
{
    $privateKey  = '<-- 请填写您的应用私钥，例如：MIIEvQIBADANB ... ... -->';
    $alipayPublicKey = '<-- 请填写您的支付宝公钥，例如：MIIBIjANBg... -->';
    $alipayConfig = new AlipayConfig();
    $alipayConfig->setServerUrl('https://openapi.alipay.com/gateway.do');
    $alipayConfig->setAppId('<-- 请填写您的AppId，例如：2019091767145019 -->');
    $alipayConfig->setPrivateKey($privateKey);
    $alipayConfig->setFormat('json');
    $alipayConfig->setAlipayPublicKey($alipayPublicKey);
    $alipayConfig->setCharset('UTF-8');
    $alipayConfig->setSignType('RSA2');
    return $alipayConfig;
}
```
 

##### http
```
 curl 'https://openapi.alipay.com/gateway.do?charset=UTF-8&method=alipay.ebpp.invoice.expensecontrol.quota.query&format=json&sign=${sign}&app_id=${appid}&version=1.0&sign_type=RSA2&timestamp=${now}' \
 -F 'app_auth_token=${app_auth_token}' \
 -F 'biz_content={
	"account_id":"2088000194958956",
	"agreement_no":"20215425001112341234",
	"target_type":"EXPENSE_TYPE",
	"target_id":"MEAL",
	"owner_type":"EMPLOYEE",
	"owner_id":"2088210888827370",
	"owner_open_id":"abcdxxxx",
	"quota_id_list":[
		"2024103100152611410000000061"
	],
	"page_size":20,
	"page_num":1,
	"enterprise_id":"2088000194958956",
	"quota_type":"COUPON"
}' 
```
 

### 公共响应参数
|参数英文名|类型|是否必选|长度/取值|描述|示例值|
|---|---|---|---|---|---|
|code|String|必须|~|网关返回码，[详见文档](https://docs.open.alipay.com/common/105806)|40004|
|msg|String|必须|~|网关返回码描述，[详见文档](https://docs.open.alipay.com/common/105806)|Business Failed|
|sub_code|String|可选|~|业务返回码，参见具体的API接口文档||
|sub_msg|String|可选|~|业务返回码描述，参见具体的API接口文档||
|sign|String|必须|64|签名，[详见文档](https://docs.open.alipay.com/291/106074)|DZXh8eeTuAHoYE3w1J+POiPhfDxOYBfUNn1lkeT/V7P4zJdyojWEa6IZs6Hz0yDW5Cp/viufUb5I0/V5WENS3OYR8zRedqo6D+fUTdLHdc+EFyCkiQhBxIzgngPdPdfp1PIS7BdhhzrsZHbRqb7o4k3Dxc+AAnFauu4V6Zdwczo=|
### 业务响应参数
|参数英文名|类型|是否必选|长度/取值|描述|示例值|
|---|---|---|---|---|---|
|page_num|Number|可选|100|当前页数|1|
|page_size|Number|可选|100|当前记录数|20|
|total_page_count|Number|可选|100|总页数|5|
|expense_quota_info_list|ExpenseQuotaInfo|可选|null|额度列表||
|expense_quota_info_list.quota_id|String|必须|28|额度ID|2021062800152601350000001468|
|expense_quota_info_list.enterprise_id|String|必须|32|企业ID|2088000194958956|
|expense_quota_info_list.quota_type|String|必须|32|额度类型**枚举值**点券:COUPON余额:CAP|CAP|
|expense_quota_info_list.owner_type|String|必须|32|额度所属者id类型**枚举值**员工支付宝uid类型:EMPLOYEE员工企业码id类型:ENTERPRISE_PAY_UID员工手机号类型:PHONE企业类型:ENTERPRISE员工支付宝openId类型:EMPLOYEE_OPEN_ID|EMPLOYEE|
|expense_quota_info_list.owner_id|String|特殊可选|32|额度所属者ID owner_type为EMPLOYEE时为员工支付宝ID owner_type为ENTERPRISE_PAY_UID时为员工企业码ID owner_type为PHONE时为员工手机号 owner_type为ENTERPRISE时为企业ID|2088xxx|
|expense_quota_info_list.owner_open_id|String|可选|32|owner_type为EMPLOYEE时为员工open_id owner_type为PHONE时为员工手机号 owner_type为ENTERPRISE_PAY_UID时为员工企业码ID|abcdxxxx|
|expense_quota_info_list.target_type|String|必须|32|额度维度**枚举值**费用类型维度:EXPENSE_TYPE规则聚合维度:RULE_GROUP_AGGREGATION制度:INSTITUTION|EXPENSE_TYPE|
|expense_quota_info_list.target_id|String|必须|32|额度维度ID 当 target_type=EXPENSE_TYPE 时，值为 MEAL（工作餐） 当target_type=RULE_GROUP_AGGREGATION 时，值为费控规则聚合ID 当target_type=INSTITUTION 时，值为制度ID|MEAL|
|expense_quota_info_list.quota_total|String|必须|100|总金额（单位分）|100|
|expense_quota_info_list.quota_available|String|必须|100|可用金额（单位分）|20|
|expense_quota_info_list.quota_locked|String|必须|100|锁定金额（单位分）|10|
|expense_quota_info_list.quota_used|String|必须|100|已用金额（单位分）|70|
|expense_quota_info_list.effective_start_date|Date|可选|32|额度生效时间|2021-01-01 00:00:00|
|expense_quota_info_list.effective_end_date|Date|可选|32|额度失效时间|2021-10-01 00:00:00|
|expense_quota_info_list.freeze|Boolean|可选|10|额度是否冻结，冻结后因公付不可用|true|
|expense_quota_info_list.currency|String|可选|3|额度对应的币种**枚举值**英镑:GBP港元:HKD美元:USD新加坡元:SGD日元:JPY加拿大元:CAD澳大利亚元:AUD欧元:EUR新西兰元:NZD韩圆:KRW泰铢:THB瑞士法郎:CHF瑞典克朗:SEK丹麦克朗:DKK挪威克朗:NOK马来西亚林吉特:MYR印度尼西亚盾:IDR菲律宾比索:PHP毛里求斯卢比:MUR以色列新谢克尔:ILS斯里兰卡卢比:LKR俄国卢布:RUB阿联酋迪拉姆:AED捷克克郎:CZK南非兰特:ZAR卡塔尔里亚尔:QAR人民币:CNY**注意事项**创建制度时如未配置currency字段，默认为人民币|USD|
### 响应示例
#### 正常响应示例
```
 {
	"alipay_ebpp_invoice_expensecontrol_quota_query_response":{
		"code":"10000",
		"msg":"Success",
		"page_num":1,
		"page_size":20,
		"total_page_count":5,
		"expense_quota_info_list":[
			{
				"quota_id":"2021062800152601350000001468",
				"enterprise_id":"2088000194958956",
				"quota_type":"CAP",
				"owner_type":"EMPLOYEE",
				"owner_id":"2088xxx",
				"owner_open_id":"abcdxxxx",
				"target_type":"EXPENSE_TYPE",
				"target_id":"MEAL",
				"quota_total":"100",
				"quota_available":"20",
				"quota_locked":"10",
				"quota_used":"70",
				"effective_start_date":"2021-01-01 00:00:00",
				"effective_end_date":"2021-10-01 00:00:00",
				"freeze":true,
				"currency":"USD"
			}
		]
	},
	"sign":"ERITJKEIJKJHKKKKKKKHJEREEEEEEEEEEE"
}
```
 
#### 异常响应示例
```
 {"alipay_ebpp_invoice_expensecontrol_quota_query_response":{"code":"20000","msg":"Service Currently Unavailable","sub_code":"isp.unknow-error","sub_msg":"系统繁忙"},"sign":"ERITJKEIJKJHKKKKKKKHJEREEEEEEEEEEE"}
```
 
### 业务错误码
|错误码|错误描述|解决方案|
|---|---|---|
|SYSTEM_ERROR|系统繁忙|服务器异常 可能发生了网络或者系统异常，导致服务调用失败，商户可以用同样的请求发起重试|
|INVALID_PARAMETER|参数有误|请根据接口返回的参数非法的具体错误信息，修改参数后进行重试|
|PERMISSION_DENIED|权限不足，未能查到企业和isv之间的映射关系|检查传入的企业id是否正确|