# alipay.ebpp.invoice.expensecontrol.quota.create(创建余额/点券)
支持第三方代理调用：本接口支持第三方开发者代用户发起调用
## 通用场景
创建余额或者点券，可支持批量创建点券
注意：不支持外算制度创建余额
### 公共请求参数
|参数英文名|类型|是否必选|长度/取值|描述|示例值|
|---|---|---|---|---|---|
|app_id|String|必选|32|支付宝分配给开发者的应用ID|2014072300007148|
|method|String|必选|128|接口名称|alipay.ebpp.invoice.expensecontrol.quota.create|
|format|String|可选|40|仅支持JSON|JSON|
|charset|String|必选|10|请求使用的编码格式，如utf-8,gbk,gb2312等|utf-8|
|sign_type|String|必选|10|商户生成签名字符串所使用的签名算法类型，目前支持RSA2和RSA，推荐使用RSA2|RSA2|
|sign|String|必选|344|商户请求参数的签名串，详见[签名](https://ideservice.alipay.com/cms/site/02khjm)|详见示例|
|timestamp|String|必选|19|发送请求的时间，格式"yyyy-MM-dd HH:mm:ss"|2014-07-24 03:07:50|
|version|String|必选|3|调用的接口版本，固定为：1.0|1.0|
|app_auth_token|String|可选|40|详见[应用授权概述](https://ideservice.alipay.com/cms/site/04h2nx)|null|
|biz_content|String|必选||请求参数的集合，最大长度不限，除公共参数外所有请求参数都必须放在这个参数中传递，具体参照各产品快速接入文档|null|
### 业务请求参数
|参数英文名|类型|是否必选|长度/取值|描述|示例值|
|---|---|---|---|---|---|
|enterprise_id|String|特殊可选|16|企业ID**注意事项**通过企业码2.0签约接口签约，如填写企业id，accout_id和agreement_no可以不填写**必选条件**通过企业码2.0签约接口签约，必填企业id|2088000194958956|
|target_type|String|必须|32|额度维度 枚举值： INSTITUTION（制度维度）， EXPENSE_TYPE（费用类型维度）**枚举值**制度维度:INSTITUTION费用类型维度:EXPENSE_TYPE**注意事项**制度维度可支持创建点券、余额、次卡资产，费用类型维度仅支持创建余额|EXPENSE_TYPE|
|target_id|String|必须|32|额度维度ID**注意事项**与target_type配合填写，当target_type=INSTITUTION 时，值为制度ID 当 target_type=EXPENSE_TYPE 时，值为 MEAL（工作餐）|MEAL|
|quota_type|String|可选|32|创建额度类型**枚举值**点券:COUPON余额:CAP次卡:COUNT**注意事项**支持点券、余额、次卡，不填写则默认为余额类型；同一人在同一制度/费用类型下仅支持一条余额，且不支持同时创建制度类/费用类型类余额。|COUPON|
|share_mode|String|可选|32|0:不可转赠 1:可以转增**枚举值**不可转增:0可转赠:1**注意事项**不传默认模式为0不可转增，只有点券和余额支持转增|0|
|effective_start_date|Date|特殊可选|32|额度生效时间（格式：yyyy-MM-dd HH:mm:ss）**注意事项**额度类型为点券时必填，额度类型为余额时有默认值，无需填写**必选条件**创建点券或次卡时，必填，创建余额时，无需填写（有默认值）|2021-01-01 00:00:00|
|effective_end_date|Date|特殊可选|32|额度失效时间（格式：yyyy-MM-dd HH:mm:ss）**注意事项**额度类型为点券时必填，额度类型为余额时有默认值，无需填写**必选条件**创建点券或次卡时，必填，创建余额时，无需填写（有默认值）|2021-10-01 00:00:00|
|outer_source_id|String|特殊可选|32|外部操作幂等ID，标识创建额度的唯一性，防止重复创建**注意事项**创建额度类型为点券、次卡时必填，创建余额无需填写，填写该字段请保证唯一性，如果幂等id已存在，会返回已创建成功的额度id或者批次id。**必选条件**当创建点券或次卡时该字段必填|TN00000000000001|
|issue_name|String|可选|20|批量发放时，可填写该字段作为发放名称，如果未填写取outer_source_id为默认值|7号加班餐|
|issue_desc|String|可选|200|批量发放时，可填写该字段|7号加班餐补发放，支持晚上8:00后消费|
|issue_quota_target_list|IssueTargetInfoContent|可选|null|创建额度发放明细列表**注意事项**单次最多创建1000条||
|issue_quota_target_list.owner_type|String|必须|32|owner类型，用来表示owner_id的类型**枚举值**支付宝id:EMPLOYEE员工手机号:PHONE员工企业码id:ENTERPRISE_PAY_UID企业额度类型:ENTERPRISE制度类型:INSTITUTION**注意事项**当制度支持制度下所有人共享额度时，可创建INSTITUTION类型额度，该字段为INSTITUTION时，owner_id默认为制度id，可不填写。INSTITUTION类型的额度是制度下所有人共用，例如：发放5元点券，制度下所有人共用5元，其他类型的额度是每人5元。|PHONE|
|issue_quota_target_list.owner_id|String|特殊可选|32|切换open_id前请使用：owner类型为PHONE时该字段表示员工手机号，owner类型为EMPLOYEE时该字段表示为员工支付宝uid，owner类型为ENTERPRISE_PAY_UID时该字段表示为员工企业码id，owner类型为ENTERPRISE时可不填，如果填写仅支持填企业id，owner类型为INSTITUTION时可不填，默认为制度id**注意事项**手机号或者员工企业码id请和录入员企关系时的值保持一致，否则会校验失败**必选条件**发放员工额度时必填，企业额度和多人共享额度可不填|13055551515|
|issue_quota_target_list.owner_open_id|String|可选|64|切换open_id后请使用：owner类型为PHONE时，填写员工手机号，EMPLOYEE时填写员工open_id|abcdxxxx|
|issue_quota_target_list.user_name|String|可选|20|员工姓名**注意事项**请与录入员企关系时填写的员工名称保持一致，若不一致会校验失败|测试|
|issue_quota_target_list.issue_quota|String|必须|32|当发放余额或点券时，单位为元，币种以创建制度时填写的currency为准，不填写默认为人民币。当发放类型为次卡时，单位为次。**注意事项**个人额度发放上限为10万元，企业额度发放上限为1亿元，次卡发放上限为10万次，不同费用类型可配置上限值可能存在差异，具体以实际接口调用为准。日元和韩元最小单位为元，不支持填写小数。其他币种支持填写两位小数。|10|
|platform|String|可选|32|外部平台编码（通常为接入方大写英文缩写）|RJ|
|quota_value|String|可选|32|额度值，以（分）为单位**注意事项**个人额度不超过100000元，企业额度不超过100000000元；当额度类型为次卡时，当前单位表示次数，值需要为大于0的正整数，最大不超时100000次，不同费用类型可配置上限值可能存在差异，具体以实际接口调用为准|50|
|owner_type|String|必须|32|额度所属者类型**枚举值**员工支付宝id类型:EMPLOYEE员工企业码id类型:ENTERPRISE_PAY_UID员工手机号类型:PHONE企业id类型:ENTERPRISE员工支付宝openId类型:EMPLOYEE_OPEN_ID制度id类型:INSTITUTION**注意事项**可通过设置该字段来指定操作的owner_id类型；其中 enterprise_id支持PHONE、ENTERPRISE_PAY_UID类型 account_id支持EMPLOYEE类型；owner_type为INSTITUTION时，target_type必须也是INSTITUTION，且制度必须支持多人共享额度，多人共享的额度为制度下所有人共用。|EMPLOYEE|
|owner_id|String|可选|32|额度所属者ID（未切换open_id请使用此字段）：**注意事项**owner_type为EMPLOYEE时填写员工支付宝ID； owner_type为ENTERPRISE_PAY_UID时填写员工企业码ID； owner_type为PHONE时填写员工手机号； owner_type为ENTERPRISE时填写企业ID； owner_type为INSTITUTION时该字段默认为target_id的值，可不填写。|2088210888827370|
|owner_open_id|String|可选|64|额度所属者ID（切换open_id后请使用此字段）：**注意事项**owner_type为EMPLOYEE时填写open_id； owner_type为ENTERPRISE_PAY_UID时填写员工企业码ID； owner_type为PHONE时填写员工手机号； owner_type为ENTERPRISE时填写企业ID。|2088210888827370|
|agreement_no|String|可选|32|授权签约协议号（该字段将废弃，不建议使用，可用enterprise_id字段替换）**注意事项**可通过签约消息获取。配合企业共同账户id使用，当填写企业共同账户id时，此字段必填|20215425001112341234|
|account_id|String|可选|32|共同账号id（该字段将废弃，不建议使用，可用enterprise_id字段替换）**注意事项**通过企业码1.0接口签约的共同账户，和agreement_no搭配使用|2088000194958956|
### 请求示例
#### 默认示例
##### csharp
```
 using System;
using System.Collections.Generic;
using Aop.Api;
using Aop.Api.Request;
using Aop.Api.Response;
using Aop.Api.Domain;
using Aop.Api.Util;
namespace SdkDemoTest
{
    public class AlipayEbppInvoiceExpensecontrolQuotaCreate
    {
        public static void Main(string[] args) 
        {
            // 初始化SDK
            IAopClient alipayClient = new DefaultAopClient(GetAlipayConfig());
            // 构造请求参数以调用接口
            AlipayEbppInvoiceExpensecontrolQuotaCreateRequest request = new AlipayEbppInvoiceExpensecontrolQuotaCreateRequest();
            AlipayEbppInvoiceExpensecontrolQuotaCreateModel model = new AlipayEbppInvoiceExpensecontrolQuotaCreateModel();
            
            // 设置企业ID
            model.EnterpriseId = "2088000194958956";
            
            // 设置额度维度
            model.TargetType = "EXPENSE_TYPE";
            
            // 设置额度维度ID
            model.TargetId = "MEAL";
            
            // 设置创建额度类型
            model.QuotaType = "COUPON";
            
            // 设置是否可以转增
            model.ShareMode = "0";
            
            // 设置额度生效时间（格式
            model.EffectiveStartDate = "2021-01-01 00:00:00";
            
            // 设置额度失效时间（格式
            model.EffectiveEndDate = "2021-10-01 00:00:00";
            
            // 设置外部幂等id
            model.OuterSourceId = "TN00000000000001";
            
            // 设置发放名称
            model.IssueName = "7号加班餐";
            
            // 设置发放描述
            model.IssueDesc = "7号加班餐补发放，支持晚上8:00后消费";
            
            // 设置发放明细列表
            List<IssueTargetInfoContent> issueQuotaTargetList = new List<IssueTargetInfoContent>();
            IssueTargetInfoContent issueQuotaTargetList0 = new IssueTargetInfoContent();
            issueQuotaTargetList0.IssueQuota = "10";
            issueQuotaTargetList0.OwnerOpenId = "abcdxxxx";
            issueQuotaTargetList0.OwnerId = "13055551515";
            issueQuotaTargetList0.UserName = "测试";
            issueQuotaTargetList0.OwnerType = "PHONE";
            issueQuotaTargetList.Add(issueQuotaTargetList0);
            model.IssueQuotaTargetList = issueQuotaTargetList;
            
            request.SetBizModel(model);
            // 第三方代调用模式下请设置app_auth_token
            // request.PutOtherTextParam("app_auth_token", "<-- 请填写应用授权令牌 -->");

            AlipayEbppInvoiceExpensecontrolQuotaCreateResponse response = alipayClient.Execute(request);

            if(!response.IsError)
            {
                Console.WriteLine("调用成功");
            }
            else
            {
                Console.WriteLine("调用失败");
            }
        }

        private static AlipayConfig GetAlipayConfig()
        {
            string privateKey  = "<-- 请填写您的应用私钥，例如：MIIEvQIBADANB ... ... -->";
            string alipayPublicKey = "<-- 请填写您的支付宝公钥，例如：MIIBIjANBg... -->";
            AlipayConfig alipayConfig = new AlipayConfig();
            alipayConfig.ServerUrl = "https://openapi.alipay.com/gateway.do";
            alipayConfig.AppId = "<-- 请填写您的AppId，例如：2019091767145019 -->";
            alipayConfig.PrivateKey = privateKey;
            alipayConfig.Format = "json";
            alipayConfig.AlipayPublicKey = alipayPublicKey;
            alipayConfig.Charset = "UTF-8";
            alipayConfig.SignType = "RSA2";
            return alipayConfig;
        }
    }
}
```
 

##### java
```
 package com.java.sdk.demo;

import com.alipay.api.AlipayApiException;
import com.alipay.api.AlipayClient;
import com.alipay.api.DefaultAlipayClient;
import com.alipay.api.AlipayConfig;
import com.alipay.api.response.AlipayEbppInvoiceExpensecontrolQuotaCreateResponse;
import com.alipay.api.domain.IssueTargetInfoContent;
import com.alipay.api.request.AlipayEbppInvoiceExpensecontrolQuotaCreateRequest;
import com.alipay.api.domain.AlipayEbppInvoiceExpensecontrolQuotaCreateModel;

import com.alipay.api.FileItem;
import java.util.Base64;
import java.util.ArrayList;
import java.util.List;
import java.util.TimeZone;
import java.text.ParseException;
import java.text.SimpleDateFormat;

public class AlipayEbppInvoiceExpensecontrolQuotaCreate {

    public static void main(String[] args) throws AlipayApiException, ParseException {
        // 初始化SDK
        AlipayClient alipayClient = new DefaultAlipayClient(getAlipayConfig());
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        sdf.setTimeZone(TimeZone.getTimeZone("GMT+8"));

        // 构造请求参数以调用接口
        AlipayEbppInvoiceExpensecontrolQuotaCreateRequest request = new AlipayEbppInvoiceExpensecontrolQuotaCreateRequest();
        AlipayEbppInvoiceExpensecontrolQuotaCreateModel model = new AlipayEbppInvoiceExpensecontrolQuotaCreateModel();
        
        // 设置企业ID
        model.setEnterpriseId("2088000194958956");
        
        // 设置额度维度
        model.setTargetType("EXPENSE_TYPE");
        
        // 设置额度维度ID
        model.setTargetId("MEAL");
        
        // 设置创建额度类型
        model.setQuotaType("COUPON");
        
        // 设置是否可以转增
        model.setShareMode("0");
        
        // 设置额度生效时间（格式
        model.setEffectiveStartDate(sdf.parse("2021-01-01 00:00:00"));
        
        // 设置额度失效时间（格式
        model.setEffectiveEndDate(sdf.parse("2021-10-01 00:00:00"));
        
        // 设置外部幂等id
        model.setOuterSourceId("TN00000000000001");
        
        // 设置发放名称
        model.setIssueName("7号加班餐");
        
        // 设置发放描述
        model.setIssueDesc("7号加班餐补发放，支持晚上8:00后消费");
        
        // 设置发放明细列表
        List<IssueTargetInfoContent> issueQuotaTargetList = new ArrayList<IssueTargetInfoContent>();
        IssueTargetInfoContent issueQuotaTargetList0 = new IssueTargetInfoContent();
        issueQuotaTargetList0.setIssueQuota("10");
        issueQuotaTargetList0.setOwnerOpenId("abcdxxxx");
        issueQuotaTargetList0.setOwnerId("13055551515");
        issueQuotaTargetList0.setUserName("测试");
        issueQuotaTargetList0.setOwnerType("PHONE");
        issueQuotaTargetList.add(issueQuotaTargetList0);
        model.setIssueQuotaTargetList(issueQuotaTargetList);
        
        request.setBizModel(model);
        // 第三方代调用模式下请设置app_auth_token
        // request.putOtherTextParam("app_auth_token", "<-- 请填写应用授权令牌 -->");

        AlipayEbppInvoiceExpensecontrolQuotaCreateResponse response = alipayClient.execute(request);
        System.out.println(response.getBody());

        if (response.isSuccess()) {
            System.out.println("调用成功");
        } else {
            System.out.println("调用失败");
            // sdk版本是"4.38.0.ALL"及以上,可以参考下面的示例获取诊断链接
            // String diagnosisUrl = DiagnosisUtils.getDiagnosisUrl(response);
            // System.out.println(diagnosisUrl);
        }
    }

    private static AlipayConfig getAlipayConfig() {
        String privateKey  = "<-- 请填写您的应用私钥，例如：MIIEvQIBADANB ... ... -->";
        String alipayPublicKey = "<-- 请填写您的支付宝公钥，例如：MIIBIjANBg... -->";
        AlipayConfig alipayConfig = new AlipayConfig();
        alipayConfig.setServerUrl("https://openapi.alipay.com/gateway.do");
        alipayConfig.setAppId("<-- 请填写您的AppId，例如：2019091767145019 -->");
        alipayConfig.setPrivateKey(privateKey);
        alipayConfig.setFormat("json");
        alipayConfig.setAlipayPublicKey(alipayPublicKey);
        alipayConfig.setCharset("UTF-8");
        alipayConfig.setSignType("RSA2");
        return alipayConfig;
    }
}
```
 

##### php
```
 <?php
require_once '../aop/AopClient.php';
require_once '../aop/AopCertClient.php';
require_once '../aop/AopCertification.php';
require_once '../aop/AlipayConfig.php';
require_once '../aop/request/AlipayEbppInvoiceExpensecontrolQuotaCreateRequest.php';

// 初始化SDK
$alipayClient = new AopClient(getAlipayConfig());
// 构造请求参数以调用接口
$request = new AlipayEbppInvoiceExpensecontrolQuotaCreateRequest();
$model = array();

// 设置企业ID
$model['enterprise_id'] = "2088000194958956";

// 设置额度维度
$model['target_type'] = "EXPENSE_TYPE";

// 设置额度维度ID
$model['target_id'] = "MEAL";

// 设置创建额度类型
$model['quota_type'] = "COUPON";

// 设置是否可以转增
$model['share_mode'] = "0";

// 设置额度生效时间（格式
$model['effective_start_date'] = "2021-01-01 00:00:00";

// 设置额度失效时间（格式
$model['effective_end_date'] = "2021-10-01 00:00:00";

// 设置外部幂等id
$model['outer_source_id'] = "TN00000000000001";

// 设置发放名称
$model['issue_name'] = "7号加班餐";

// 设置发放描述
$model['issue_desc'] = "7号加班餐补发放，支持晚上8:00后消费";

// 设置发放明细列表
$issueQuotaTargetList = array();
$issueQuotaTargetList0 = array();
$issueQuotaTargetList0['issue_quota'] = "10";
$issueQuotaTargetList0['owner_open_id'] = "abcdxxxx";
$issueQuotaTargetList0['owner_id'] = "13055551515";
$issueQuotaTargetList0['user_name'] = "测试";
$issueQuotaTargetList0['owner_type'] = "PHONE";
$issueQuotaTargetList[] = $issueQuotaTargetList0;
$model['issue_quota_target_list'] = $issueQuotaTargetList;

$request->setBizContent(json_encode($model,JSON_UNESCAPED_UNICODE));
// 如果是第三方代调用模式，请设置app_auth_token（应用授权令牌）
$responseResult = $alipayClient->execute($request, null, "<-- 请填写应用授权令牌 -->", null);
$responseApiName = str_replace(".","_",$request->getApiMethodName())."_response";
$response = $responseResult->$responseApiName;
if(!empty($response->code)&&$response->code==10000){
    echo("调用成功");
}
else{
    echo("调用失败");
}

function getAlipayConfig()
{
    $privateKey  = '<-- 请填写您的应用私钥，例如：MIIEvQIBADANB ... ... -->';
    $alipayPublicKey = '<-- 请填写您的支付宝公钥，例如：MIIBIjANBg... -->';
    $alipayConfig = new AlipayConfig();
    $alipayConfig->setServerUrl('https://openapi.alipay.com/gateway.do');
    $alipayConfig->setAppId('<-- 请填写您的AppId，例如：2019091767145019 -->');
    $alipayConfig->setPrivateKey($privateKey);
    $alipayConfig->setFormat('json');
    $alipayConfig->setAlipayPublicKey($alipayPublicKey);
    $alipayConfig->setCharset('UTF-8');
    $alipayConfig->setSignType('RSA2');
    return $alipayConfig;
}
```
 

##### http
```
 curl 'https://openapi.alipay.com/gateway.do?charset=UTF-8&method=alipay.ebpp.invoice.expensecontrol.quota.create&format=json&sign=${sign}&app_id=${appid}&version=1.0&sign_type=RSA2&timestamp=${now}' \
 -F 'app_auth_token=${app_auth_token}' \
 -F 'biz_content={
	"enterprise_id":"2088000194958956",
	"target_type":"EXPENSE_TYPE",
	"target_id":"MEAL",
	"quota_type":"COUPON",
	"share_mode":"0",
	"effective_start_date":"2021-01-01 00:00:00",
	"effective_end_date":"2021-10-01 00:00:00",
	"outer_source_id":"TN00000000000001",
	"issue_name":"7号加班餐",
	"issue_desc":"7号加班餐补发放，支持晚上8:00后消费",
	"issue_quota_target_list":[
		{
			"issue_quota":"10",
			"owner_open_id":"abcdxxxx",
			"owner_id":"13055551515",
			"user_name":"测试",
			"owner_type":"PHONE"
		}
	]
}' 
```
 

### 公共响应参数
|参数英文名|类型|是否必选|长度/取值|描述|示例值|
|---|---|---|---|---|---|
|code|String|必须|~|网关返回码，[详见文档](https://docs.open.alipay.com/common/105806)|40004|
|msg|String|必须|~|网关返回码描述，[详见文档](https://docs.open.alipay.com/common/105806)|Business Failed|
|sub_code|String|可选|~|业务返回码，参见具体的API接口文档||
|sub_msg|String|可选|~|业务返回码描述，参见具体的API接口文档||
|sign|String|必须|64|签名，[详见文档](https://docs.open.alipay.com/291/106074)|DZXh8eeTuAHoYE3w1J+POiPhfDxOYBfUNn1lkeT/V7P4zJdyojWEa6IZs6Hz0yDW5Cp/viufUb5I0/V5WENS3OYR8zRedqo6D+fUTdLHdc+EFyCkiQhBxIzgngPdPdfp1PIS7BdhhzrsZHbRqb7o4k3Dxc+AAnFauu4V6Zdwczo=|
### 业务响应参数
|参数英文名|类型|是否必选|长度/取值|描述|示例值|
|---|---|---|---|---|---|
|quota_id|String|可选|32|创建的额度ID**注意事项**当创建一个额度时，会返回，批量创建时不支持返回额度id，仅返回发放批次id|2023030600152622370000007434|
|issue_batch_id|String|可选|32|发放批次id**注意事项**批量创建多个额度或额度为审批发放时，返回该字段，可通过该字段查询批次下资产发放明细。|2023030600152622370000007434|
|issue_quota_check_failed_list|IssueQuotaCheckInfo|可选|null|额度发放明细检查错误列表，可根据报错信息修改发放明细列表||
|issue_quota_check_failed_list.user_name|String|可选|32|用户姓名|测试|
|issue_quota_check_failed_list.owner_type|String|可选|32|owner_type|PHONE|
|issue_quota_check_failed_list.owner_id|String|可选|32|入参的 owner_id|13055551515|
|issue_quota_check_failed_list.owner_open_id|String|可选|64|入参的 owner_open_id|abcdxxxx|
|issue_quota_check_failed_list.issue_quota|String|可选|32|发放点券和余额时，单位为元，发放次卡时，单位为次|10|
|issue_quota_check_failed_list.message|String|可选|200|校验结果的原因|金额不能为负数|
|issue_quota_check_failed_list.result|Boolean|可选|32|校验结果|true|
### 响应示例
#### 正常响应示例
```
 {
	"alipay_ebpp_invoice_expensecontrol_quota_create_response":{
		"code":"10000",
		"msg":"Success",
		"quota_id":"2023030600152622370000007434",
		"issue_batch_id":"2023030600152622370000007434",
		"issue_quota_check_failed_list":[
			{
				"user_name":"测试",
				"owner_type":"PHONE",
				"owner_id":"13055551515",
				"owner_open_id":"abcdxxxx",
				"issue_quota":"10",
				"message":"金额不能为负数",
				"result":true
			}
		]
	},
	"sign":"ERITJKEIJKJHKKKKKKKHJEREEEEEEEEEEE"
}
```
 
#### 异常响应示例
```
 {"alipay_ebpp_invoice_expensecontrol_quota_create_response":{"code":"20000","msg":"Service Currently Unavailable","sub_code":"isp.unknow-error","sub_msg":"系统繁忙"},"sign":"ERITJKEIJKJHKKKKKKKHJEREEEEEEEEEEE"}
```
 
### 业务错误码
|错误码|错误描述|解决方案|
|---|---|---|
|SYSTEM_ERROR|系统繁忙|服务器异常 可能发生了网络或者系统异常，导致服务调用失败，商户可以用同样的请求发起重试|
|INVALID_PARAMETER|参数有误|请根据接口返回的参数非法的具体错误信息，修改参数后进行重试|
|EMPLOYEE_NOT_IN_INSTITUTION_SCOPE|员工不在制度适配范围内|请确认报错信息中的员工id是否在制度适配范围内，如不在请删除或者将员工添加到制度后再发放额度。|
|INSTITUTION_EXPIRED|制度已过有效期|制度已过有效期，请修改制度有效期后发放资产。|
|ISSUE_BATCH_NO_DUPLICATE|制度下已存在该发放批次号（outer_source_id）|通过修改发放批次号（outer_source_id）来解决，如未能解决，请联系企业码客服或技术支持。|
|ISSUE_NAME_DUPLICATE|发放名称重复|发放名称重复，请修改发放名称或者外部幂等ID|
|PERMISSION_DENIED|权限不足，未能查到企业和isv之间的映射关系|可以通过检查入参的企业ID来解决，如确认企业ID无误后未能解决，请联系企业码客服或技术支持。|
|QUOTA_EXISTS|[废弃]余额已存在，请勿重复创建|仅支持每个人在每个制度下或费用类型下创建一条余额，请勿重复创建，如果已有余额存在，会返回余额id，不会报错|
|REQUEST_REPEAT|[废弃]请求重复，已有相同的outer_source_id创建成功|该错误码已废弃，如已有相同outer_source_id，则返回对应的额度id|