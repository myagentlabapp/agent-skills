---
name: alipay-enterprise-expense-control
description: 支付宝企业码费控集成专用 Skill。当用户提到"企业码费控集成"、"费控制度"、"额度管理"、"内部费控模式"、"外部费控模式"、"费控咨询"、"SPI 接口"、"额度扣减"、"额度发放"、"alipay.ebpp.invoice.institution"、"expensecontrol" 等相关关键词时必须使用此 Skill。帮助企业快速接入支付宝企业码费控能力，支持内部费控和外部费控两种模式。
---

# 支付宝企业码费控集成 Skill

## 重要提示

支持两种使用方式：由方案型 Skill 调用时沿用上游已确定的费控模式和接入模块；独立使用时按本文档完成必要决策。

生成方案或代码时：

1. 先确定费控模式、模块、接口清单和 SDK 版本来源。
2. 接入某个模块时，必须覆盖该模块下全部接口。
3. 生成前读取当前模式流程文档、接口文档、[费控通用代码生成规则](references/codegen-general-rules.md) 和 [费控字段和接口规则](references/field-interface-rules.md)；Java/Maven 场景还需读取 [费控 Java/Maven 质量门禁](references/quality-gates/java-maven.md)，Node.js 场景还需读取 [费控 Node.js 质量门禁](references/quality-gates/nodejs.md)，Python/Go/.NET 场景还需读取 [费控 Python/Go/.NET 质量门禁](references/quality-gates/python-go-dotnet.md)。
4. 按当前模式和模块分段读取、分段生成、分段校验；内部费控基础模块不得读取或实现外部 SPI、手工发放、额度管理等未选择文档。
5. “内部/外部”以企业码为视角，不以服务商平台为视角。平台已有自研费控或额度系统、希望支付中由平台判断和扣减额度时，应选择外部费控；希望企业码/支付宝统一管理规则和额度时，应选择内部费控。
6. 生成接口调用代码前必须完成对应语言的 SDK 或接入方式预检；Java/Maven 场景执行 Java SDK/Maven 预检。
7. 文档中找不到的字段、接口或 SDK 能力，必须说明未找到，不能猜测生成。
8. 已有项目只做增量改造：第一轮只输出现有 SDK、Central Portal 当前 SDK 版本、费控服务、SPI/通知入口、目录结构、已有费用/制度/额度 Entity/Service/Repository/Controller、已实现费控接口、业务衔接点和拟新增/修改文件清单，并按 [已有项目衔接契约](references/integration-contract.md) 给出拟定契约；Java/Maven 项目必须把 `alipay-sdk-java` 升级到当前版本列入计划，用户确认后才能写入契约并修改代码。上下文可推断时，制度、额度或 SPI 结果必须衔接已有费控业务对象；无法推断时暂停确认，不得默认生成孤立旁路模块。
9. 代码生成环境必须运行本域自检脚本；Java/Maven、Node.js、Python、Go 和 .NET 项目会执行对应技术栈门禁，其他技术栈应使用对应语言的构建、测试和 SDK 校验方式。
10. 只有本域官方自检脚本退出码为 `0`，才能声明费控代码生成完成。不得用自写脚本、报告表格、手工 checklist、模型总结或生成工程里的 `scripts/*validate*.js` 替代本域官方自检脚本。
11. 由场景方案 Skill 调用且上游提供 `ruleFactorCapabilities` 时，只按 `SCENARIO_FIXED`、`ENTERPRISE_INPUT` 区分配置来源：文档唯一确定的场景值可预置并禁止企业覆盖，其余企业策略值按租户配置和持久化。订单、商户、金额等运行期数据属于制度匹配或外部 SPI 输入，不是规则配置来源。

由主方案 Skill 调用时，必须遵守主方案阶段闸门；未进入费控阶段前，不得读取费控接口文档。

由多 Agent 主方案调用时：

1. 第一轮必须输出 `已加载 Skill: alipay-enterprise-expense-control (<SKILL.md 路径>)`，并列出沿用的上游费控模式、模块和允许写入范围。
2. 只处理费控代码和费控文档，不读取其他子 Skill。
3. 只生成或修改费控写入范围，例如 `src/main/java/**/expense/**`。
4. 不修改公共构建文件、配置文件、`README.md`、启动入口、SDK 配置或跨域消息聚合配置；已有项目中如需这些改动，只在回执中提出需求。
5. 输出本域已读文档、生成文件、接口覆盖、本域自检结果、未覆盖边界。
6. 本域自检失败时先修正费控代码，不要求其他 Agent 兜底。
7. 回执必须给出本域官方自检脚本的原始命令、退出码和最后几行输出；退出码非 `0` 时不得写 `COMPLETED`、`生成完成`、`通过` 或同义结论。

---

## 步骤 1：确定模式

企业码费控支持两种模式：

| 模式 | 额度管控收口 | 说明 | 约束 |
|------|--------------|------|------|
| 内部费控 | 企业码 | 服务商将管控规则和额度通过接口同步到企业码，由企业码进行费控 | 无特殊约束 |
| 外部费控 | 服务商 | 企业码在支付中通过SPI接口咨询服务商进行费控 | 服务商必须满足「解决其内部多平台额度一致性问题」的条件才允许准入；接口响应时间必须在600ms内（含网络耗时） |

注意：“内部费控”不是指服务商平台内部已有费控系统；它表示企业码内部计算规则和额度。“外部费控”才表示企业码外部的服务商系统通过 SPI 决策额度。

**决策规则**：
- 方案型 Skill 调用：如果上游方案已确定费控模式或接入模块，直接沿用，不要重复询问用户。
- 独立使用：如果用户上下文已明确内部费控、外部费控、SPI、服务商自行管控额度等信息，直接使用对应模式。
- 独立使用：如果需要生成费控方案或代码但上下文无法推断模式，必须让用户选择内部费控或外部费控。
- 独立使用：如果只做总体方案且不展开费控实现，可以标记费控模式待确认，不要擅自默认内部费控或外部费控。

**模块完整性**：
- 制度管理包含：创建、修改、删除、详情查询、分页查询、适用范围查询。
- 内部费控按需模块包含：手工发放管理、额度管理。
- 外部费控除制度管理外，还必须实现 SPI 集成规范、额度咨询、额度扣减、额度退还、额度状态查询和测试用例。

---

## 步骤 2：接入流程

根据选择的模式，查阅对应的接入流程文档：

| 模式 | 文档 |
|------|------|
| **内部费控** | [内部费控流程](references/internal/internal-flow.md) |
| **外部费控** | [外部费控流程](references/external/external-flow.md) |

接入流程文档包含：
- 流程图
- 接口文档（含关键步骤备注）
- 参考文档索引

**制度管理场景闸门**：生成制度创建代码前，如果方案型 Skill 或用户上下文已给出费用类型和费用类型子类，直接沿用；如果无法推断，必须先询问用户确认。未确认场景前不得生成制度创建代码。

跨语言生成原则见 [费控通用代码生成规则](references/codegen-general-rules.md)，已有项目衔接见 [已有项目衔接契约](references/integration-contract.md)，字段、接口、枚举和结构规则见 [费控字段和接口规则](references/field-interface-rules.md)，Java/Maven SDK 和工程质量门禁见 [费控 Java/Maven 质量门禁](references/quality-gates/java-maven.md)，Node.js SDK 和工程质量门禁见 [费控 Node.js 质量门禁](references/quality-gates/nodejs.md)，Python/Go/.NET HTTP(S) 或 SDK 接入门禁见 [费控 Python/Go/.NET 质量门禁](references/quality-gates/python-go-dotnet.md)。

代码生成时先读取当前费控模式流程文档、费控通用代码生成规则和费控字段和接口规则；再按技术栈读取对应质量门禁。随后按当前模块逐个读取接口文档、生成该模块代码并运行对应技术栈自检；不要预读未生成模块的接口文档。

## 生成后校验

本 Skill 自带本域自检脚本，由 Skill/生成环境执行：

```bash
node alipay-enterprise-expense-control/scripts/validate_codegen.js <生成项目目录>
```

脚本会识别 Java/Maven、Node.js、Python、Go 和 .NET 项目。Java/Maven 项目校验费控制度接口覆盖、SDK Model 使用、请求 setter 来源、必填顶层字段、Java package 路径、禁止本地支付宝 SDK stub、制度场景和规则因子结构；Node.js 项目校验 SDK 导入、`appAuthToken`、制度接口覆盖、内部费控制度完整性、模块加载和 `npm test`；Python/Go/.NET 项目校验制度字段结构、费用类型子类映射、内部费控规则完整性、外部 SPI 占位实现，并在运行时存在时执行 Python 语法检查、`go test ./...` 或 `dotnet build`。

退出码 `0` 表示通过，`1` 表示生成代码不符合门禁，`2` 表示 validator 自身执行不可信。

必须执行上面的本域官方自检脚本，不能用自写脚本、手写 checklist、报告表格、`scripts/*validate*.js` 或模型总结替代。最终回复必须列出原始命令、退出码和最后几行输出；退出码不是 `0` 时不得写 `COMPLETED`、`生成完成`、`通过` 或同义结论。
