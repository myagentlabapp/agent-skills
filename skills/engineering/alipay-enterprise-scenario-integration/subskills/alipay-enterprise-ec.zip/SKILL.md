---
name: alipay-enterprise-ec
description: 支付宝企业码员企集成专用 Skill。当用户提到"企业码员企集成"、"企业入驻"、"员工签约"、"企业注册"、"员工管理"、"部门管理"、"核算主体"、"alipay.commerce.ec.enterprise.registerinvite.create"、"alipay.commerce.ec.employee.add"、"alipay.commerce.ec.enterprise.info"、"alipay.commerce.ec.department"、"alipay.commerce.ec.accountingentity"等相关关键词时必须使用此 Skill。帮助企业快速接入支付宝企业码员企能力，支持企业入驻（邀请注册/可信渠道）、员工签约（邀请签约/授权签约）、企业管理、员工管理、部门管理、核算主体管理等功能。
---

# 支付宝企业码员企集成 Skill

## 重要提示

支持两种使用方式：由方案型 Skill 调用时沿用上游已确定的模式、模块和消息接入方式；独立使用时按本文档完成必要决策。

生成方案或代码时：

1. 先确定模式、模块、消息接入方式、接口清单和 SDK 版本来源。
2. 接入某个模块时，必须覆盖该模块下全部接口和必要通知。
3. 生成前读取当前模式流程文档、接口文档、[员企通用代码生成规则](references/codegen-general-rules.md) 和 [员企字段和接口规则](references/field-interface-rules.md)；Java/Maven 场景还需读取 [员企 Java/Maven 质量门禁](references/quality-gates/java-maven.md)，Node.js 场景还需读取 [员企 Node.js 质量门禁](references/quality-gates/nodejs.md)，Python/Go/.NET 场景还需读取 [员企 Python/Go/.NET 质量门禁](references/quality-gates/python-go-dotnet.md)。
4. 按当前模式和模块分段读取、分段生成、分段校验；未选择的部门、核算主体、企业地址、消息任务、可信渠道或授权签约文档不得读取或实现。
5. 生成接口调用代码前必须完成对应语言的 SDK 或接入方式预检；Java/Maven 场景执行 Java SDK/Maven 预检。
6. 文档中找不到的字段、接口、通知或 SDK 能力，必须说明未找到，不能猜测生成。
7. 已有项目只做增量改造：第一轮只输出现有 SDK、Central Portal 当前 SDK 版本、通知入口、目录结构、已有企业/员工 Entity/Service/Repository/Controller、已实现员企接口、业务衔接点和拟新增/修改文件清单，并按 [已有项目衔接契约](references/integration-contract.md) 给出拟定契约；Java/Maven 项目必须把 `alipay-sdk-java` 升级到当前版本列入计划，用户确认后才能写入契约并修改代码。上下文可推断时，企业/员工通知必须衔接已有企业/员工对象；无法推断时暂停确认，不得默认生成仅日志的旁路通知。
8. 代码生成环境必须运行本域自检脚本；Java/Maven、Node.js、Python、Go 和 .NET 项目会执行对应技术栈门禁，其他技术栈应使用对应语言的构建、测试和 SDK 校验方式。
9. 只有本域官方自检脚本退出码为 `0`，才能声明员企代码生成完成。不得用自写脚本、报告表格、手工 checklist、模型总结或生成工程里的 `scripts/*validate*.js` 替代本域官方自检脚本。

由主方案 Skill 调用时，必须遵守主方案阶段闸门；未进入员企阶段前，不得读取员企接口文档。

由多 Agent 主方案调用时：

1. 第一轮必须输出 `已加载 Skill: alipay-enterprise-ec (<SKILL.md 路径>)`，并列出沿用的上游模式、模块、消息接入方式和允许写入范围。
2. 只处理员企代码和员企文档，不读取其他子 Skill。
3. 只生成或修改员企写入范围，例如 `src/main/java/**/ec/**`。
4. 不修改公共构建文件、配置文件、`README.md`、启动入口、SDK 配置或跨域消息聚合配置；已有项目中如需这些改动，只在回执中提出需求。
5. 输出本域已读文档、生成文件、接口和通知覆盖、本域自检结果、未覆盖边界。
6. 本域自检失败时先修正员企代码，不要求其他 Agent 兜底。
7. 回执必须给出本域官方自检脚本的原始命令、退出码和最后几行输出；退出码非 `0` 时不得写 `COMPLETED`、`生成完成`、`通过` 或同义结论。

---

## 步骤 1：确定模式

企业码员企集成分为两大阶段，每个阶段支持不同模式：

### 阶段一：企业入驻

| 模式 | 说明 | 约束 |
|------|------|------|
| **邀请企业注册** | 服务商邀请企业自助完成注册、认证、签约 | 通用模式，无特殊约束 |
| **可信渠道注册** | 面向可信渠道（钉钉、网商等）的专用接口，企业码信任渠道侧的企业认证状态 | 需严格准入评估，仅对可信渠道开放 |

### 阶段二：员工签约

| 模式 | 说明 | 约束 |
|------|------|------|
| **邀请员工签约** | 企业导入员工信息，获取签约链接/吱口令邀请员工完成签约 | 通用模式，员工需主动完成签约流程 |
| **授权签约模式** | 企业导入员工信息并直接激活，无需员工主动签约 | 需申请授权签约密钥，定向开放 |

**决策规则**：
- 方案型 Skill 调用：如果上游方案已确定模式或消息接入方式，直接沿用，不要重复询问用户。
- 独立使用：如果没有上下文，企业入驻默认使用"邀请企业注册"，员工签约默认使用"邀请员工签约"。
- 独立使用：只有用户明确表示默认模式不满足需求时，才说明并切换到可信渠道注册或授权签约模式。
- 消息接入方式：方案型调用时沿用上游统一决策；独立使用时按流程文档中的消息接入章节选择。

---

## 步骤 2：接入流程

根据选择的模式，查阅对应的接入流程文档：

| 阶段 | 模式 | 流程文档 |
|------|------|----------|
| **企业入驻** | 邀请企业注册 | [邀请企业注册流程](references/enterprise-register-invite/enterprise-register-invite-flow.md) |
| **企业入驻** | 可信渠道注册 | [可信渠道注册流程](references/enterprise-register-reliable/enterprise-register-reliable-flow.md) |
| **员工签约** | 邀请员工签约 | [邀请员工签约流程](references/employee-sign-invite/employee-sign-invite-flow.md) |
| **员工签约** | 授权签约模式 | [授权签约流程](references/employee-sign-auth/employee-sign-auth-flow.md) |

接入流程文档包含：
- 前置配置
- 流程图
- 接口文档（含关键步骤备注）
- 消息接入说明
- 必须接入模块（企业管理、员工管理）
- 按需接入模块（部门管理、核算主体管理、企业地址管理、企业消息推送任务）
- 参考文档索引

跨语言生成原则见 [员企通用代码生成规则](references/codegen-general-rules.md)，已有项目衔接见 [已有项目衔接契约](references/integration-contract.md)，字段、接口、枚举和结构规则见 [员企字段和接口规则](references/field-interface-rules.md)，Java/Maven SDK、WebSocket 和工程质量门禁见 [员企 Java/Maven 质量门禁](references/quality-gates/java-maven.md)，Node.js SDK、HTTP(S) 通知和工程质量门禁见 [员企 Node.js 质量门禁](references/quality-gates/nodejs.md)，Python/Go/.NET HTTP(S) 或 SDK 接入门禁见 [员企 Python/Go/.NET 质量门禁](references/quality-gates/python-go-dotnet.md)。

代码生成时先读取当前模式流程文档、员企通用代码生成规则和员企字段和接口规则；再按技术栈读取对应质量门禁。随后按当前模块逐个读取接口文档、生成该模块代码并运行对应技术栈自检；不要预读未生成模块的接口文档。

## 生成后校验

本 Skill 自带本域自检脚本，由 Skill/生成环境执行：

```bash
node alipay-enterprise-ec/scripts/validate_codegen.js <生成项目目录>
```

脚本会识别 Java/Maven、Node.js、Python、Go 和 .NET 项目。Java/Maven 项目校验员企必选接口/通知覆盖、SDK Model 使用、请求 setter 来源、必填顶层字段、通知枚举、Java package 路径、禁止本地支付宝 SDK stub，以及 WebSocket 官方接入模式；Node.js 项目校验 SDK 导入、`appAuthToken`、通知验签、接口覆盖、模块加载和 `npm test`；Python/Go/.NET 项目校验员企核心字段结构、员工查询必填字段、通知验签占位，并在运行时存在时执行 Python 语法检查、`go test ./...`、`dotnet build` 或 PHP 语法检查。

退出码 `0` 表示通过，`1` 表示生成代码不符合门禁，`2` 表示 validator 自身执行不可信。

必须执行上面的本域官方自检脚本，不能用自写脚本、手写 checklist、报告表格、`scripts/*validate*.js` 或模型总结替代。最终回复必须列出原始命令、退出码和最后几行输出；退出码不是 `0` 时不得写 `COMPLETED`、`生成完成`、`通过` 或同义结论。
