# alipay.commerce.ec.enterprise.registerinvite.create(邀请企业注册)
支持第三方代理调用：本接口支持第三方开发者代用户发起调用
## 通用场景
获取企业码-企业注册/认证/签约三合一页面的链接地址，适用于邀请企业或代理企业开通企业码
### 公共请求参数
|参数英文名|类型|是否必选|长度/取值|描述|示例值|
|---|---|---|---|---|---|
|app_id|String|必选|32|支付宝分配给开发者的应用ID|2014072300007148|
|method|String|必选|128|接口名称|alipay.commerce.ec.enterprise.registerinvite.create|
|format|String|可选|40|仅支持JSON|JSON|
|charset|String|必选|10|请求使用的编码格式，如utf-8,gbk,gb2312等|utf-8|
|sign_type|String|必选|10|商户生成签名字符串所使用的签名算法类型，目前支持RSA2和RSA，推荐使用RSA2|RSA2|
|sign|String|必选|344|商户请求参数的签名串，详见[签名](https://opendocs.alipay.com/common/02khjm)|详见示例|
|timestamp|String|必选|19|发送请求的时间，格式"yyyy-MM-dd HH:mm:ss"|2014-07-24 03:07:50|
|version|String|必选|3|调用的接口版本，固定为：1.0|1.0|
|app_auth_token|String|可选|40|详见[应用授权概述](https://opendocs.alipay.com/isv/10467/xldcyq)||
|biz_content|String|必选||请求参数的集合，最大长度不限，除公共参数外所有请求参数都必须放在这个参数中传递，具体参照各产品快速接入文档||
### 业务请求参数
|参数英文名|类型|是否必选|长度/取值|描述|示例值|
|---|---|---|---|---|---|
|out_biz_no|String|必须|64|服务商生成的请求唯一流水号/业务幂等号； 字段作用： 1. 作为邀请注册的幂等标识，使用相同的out_biz_no 会得到相同的注册链接（若链接未使用过期，会重新生成） 2. 使用相同的身份标识（identity）传入不同的out_biz_no 可生成不同的链接，适用于一个用户注册多个企业 3. 若调用失败或超时，可以使用相同的 out_biz_no 进行幂等重试 4. 并发使用相同 out_biz_no 调用，会报错：邀请链接生成中 5. 当企业注册/认证/签约成功后，企业码系统发送的「企业状态变更通知」中，会携带out_biz_no，服务商可用于关联企业ID**注意事项**仅支持英文字母、数字、下划线组成|2024051000000001|
|identity_type|String|必须|64|企业管理员身份类型**枚举值**支付宝用户uid:ALIPAY_USER_ID支付宝登录号:ALIPAY_LOGON_ID服务商用户id:ISV_USER_ID企业邮箱:ENTERPRISE_EMAIL**注意事项**ISV_USER_ID、ENTERPRISE_EMAIL 为定向开放能力，有需求请先联系客服小二处理|ALIPAY_USER_ID|
|identity|String|特殊可选|64|企业管理员身份唯一标识，搭配 identity_type 传参： 1. 当identity_type=ALIPAY_USER_ID时，identity传支付宝用户uid（此时可与identity_open_id二选一） 2. 当identity_type=ALIPAY_LOGON_ID时，identity传已注册支付宝且可以登录支付宝的手机号或邮箱 ； 3. 当identity_type=ISV_USER_ID时，identity传服务商生成的用户唯一标识； 4. 当identity_type=ENTERPRISE_EMAIL时，identity传企业邮箱；|2088501457109512|
|identity_open_id|String|特殊可选|128|企业管理员身份标识openId**注意事项**服务商使用openId方式对接时，且当identity_type=ALIPAY_USER_ID，此字段传入对应的open_id|051PZjio8MFya3OHw9tl41J7Sy6m-z150mJTSHM3N3Es4sb|
|register_mode|String|可选|16|企业注册模式，用于区分接口返回的企业注册页面流程 不传默认为企业自入驻(NORMAL)**枚举值**企业自入驻，企业自助完成注册与认证:NORMAL服务商代入驻，服务商代理企业完成注册与认证:ISV_AGENT服务商注册虚拟企业:ISV_VIRTUAL**注意事项**1. 服务商代入驻模式下，企业签约出资环节不支持代操作，必须使用企业或法人支付宝账号登录签约； 2. 服务商注册虚拟企业模式，仅适用于特定场景，有需求请先联系客服小二处理；|NORMAL|
|sign_fund_way|String|可选|16|企业注册认证后，需要签约的出资方式； 不传默认为企业余额出资(BALANCE)**枚举值**企业余额出资:BALANCE公务卡:CORPORATE_CARD对公快捷:ENT_FA_EXPRESS通用个垫:GEN_PER_ADV_PAY卡付记账:CARD_PAY_LEDGER花呗个垫:PER_ALI_CREDIT|BALANCE|
|base_info|EnterpriseBaseInfoDTO|可选||企业基本信息，仅用于企业注册页面回显信息，用户可编辑修改，请按需使用||
|base_info.enterprise_name|String|可选|48|企业注册页面需要回显的企业名称**注意事项**1. 当用户使用企业支付宝登录时，企业注册页面-企业名称优先回显的企业支付宝账号名称，不会使用此参数； 2. 当其他身份类型（如个人支付宝、企业邮箱）注册企业时，企业注册页面-企业名称会回显此参数|支付宝企业码测试公司|
|base_info.enterprise_alias|String|可选|14|已废弃。企业注册页面回显的企业简称由系统根据企业名称自动生成**注意事项**已废弃。无需再传入该参数|测试公司简称|
|base_info.industry|String|可选|128|企业注册页面需要回显的企业所属行业**枚举值**零售:RETAIL餐饮:CATERING医疗健康:HEALTHCARE制造业:MANUFACTURING金融:FINANCE保险:INSURANCE互联网:INTERNET政务与公共服务:GOVERNMENT_SERVICES教育:EDUCATION运营商:TELECOMMUNICATIONS集团生态:GROUP_ECOSYSTEM大交通:BIG_TRANSPORT物流:LOGISTICS地产物业:REAL_ESTATE旅行社:TRAVEL_AGENCY票务代理:TICKET_AGENCY批发:WHOLESALETMC:TMC**注意事项**传入该参数则企业注册页面-企业所属行业会回显该参数，否则不显示|LOGISTICS|
|base_info.enterprise_code|String|可选|18|企业注册页面需要回显的统一社会信用代码，只能是数字和字母组成**注意事项**1. 当用户使用企业支付宝登录时，企业注册页面-统一社会信用代码会优先回显的企业支付宝账号的证件号，不会使用此参数； 2. 当其他身份类型（如个人支付宝、企业邮箱）注册企业时，企业注册页面-统一社会信用代码会回显此参数|9188051561653411TT|
|profiles|EnterpriseProfilesDTO|可选||企业个性化信息，适用于特殊场景，请按需使用||
|profiles.create_iot_group|Boolean|可选|10|是否需要自动创建企业人脸库，适用于对接团餐刷脸付、门禁刷脸通行等场景； 不传默认为 false，传 true 时会自动创建企业的 IOT 设备人脸库，人脸库创建失败会阻塞企业注册|true|
|profiles.group_app_id|String|特殊可选|32|对接支付宝「一脸通行开通插件」的支付宝小程序appId**必选条件**当参数 create_iot_group=true 时，此参数必选|2014060600164699|
|profiles.credit_applicant_mobile|String|可选|16|企业授信申请人的手机号码； 当出资方式为企业授信出资时(sign_fund_way=CREDIT)，会用于银行授信申请页面免登|15566668888|
|profiles.pc_invite_url_mode|String|可选|32|接口返回的PC端企业注册链接，需适用的集成模式；不传默认为网页跳转的模式，需要跳转页面链接进入企业注册页面；如需以页面组件嵌入其他系统，请传入iframe**枚举值**网页跳转:webpage嵌入其他系统:iframe|webpage|
|profiles.access_channel|String|可选|32|企业注册来源，仅特定场景需要传值**枚举值**碰一下:IOT_NFC|IOT_NFC|
### 请求示例
#### 默认示例
##### java
```
 package com.java.sdk.demo;

import com.alipay.api.AlipayApiException;
import com.alipay.api.AlipayClient;
import com.alipay.api.DefaultAlipayClient;
import com.alipay.api.AlipayConfig;
import com.alipay.api.request.AlipayCommerceEcEnterpriseRegisterinviteCreateRequest;
import com.alipay.api.domain.EnterpriseProfilesDTO;
import com.alipay.api.domain.EnterpriseBaseInfoDTO;
import com.alipay.api.response.AlipayCommerceEcEnterpriseRegisterinviteCreateResponse;
import com.alipay.api.domain.AlipayCommerceEcEnterpriseRegisterinviteCreateModel;

import com.alipay.api.FileItem;
import java.util.Base64;
import java.util.ArrayList;
import java.util.List;

public class AlipayCommerceEcEnterpriseRegisterinviteCreate {

    public static void main(String[] args) throws AlipayApiException {
        // 初始化SDK
        AlipayClient alipayClient = new DefaultAlipayClient(getAlipayConfig());

        // 构造请求参数以调用接口
        AlipayCommerceEcEnterpriseRegisterinviteCreateRequest request = new AlipayCommerceEcEnterpriseRegisterinviteCreateRequest();
        AlipayCommerceEcEnterpriseRegisterinviteCreateModel model = new AlipayCommerceEcEnterpriseRegisterinviteCreateModel();
        
        // 设置外部业务号
        model.setOutBizNo("2024051000000001");
        
        // 设置企业管理员身份类型
        model.setIdentityType("ALIPAY_USER_ID");
        
        // 设置企业管理员身份标识
        model.setIdentity("2088501457109512");
        
        // 设置企业管理员身份标识openId
        model.setIdentityOpenId("051PZjio8MFya3OHw9tl41J7Sy6m-z150mJTSHM3N3Es4sb");
        
        // 设置企业注册模式
        model.setRegisterMode("NORMAL");
        
        // 设置企业需签约的出资方式
        model.setSignFundWay("BALANCE");
        
        // 设置企业基本信息
        EnterpriseBaseInfoDTO baseInfo = new EnterpriseBaseInfoDTO();
        baseInfo.setIndustry("LOGISTICS");
        baseInfo.setEnterpriseCode("9188051561653411TT");
        baseInfo.setEnterpriseName("支付宝企业码测试公司");
        model.setBaseInfo(baseInfo);
        
        // 设置企业个性化信息
        EnterpriseProfilesDTO profiles = new EnterpriseProfilesDTO();
        profiles.setGroupAppId("2014060600164699");
        profiles.setAccessChannel("IOT_NFC");
        profiles.setCreditApplicantMobile("15566668888");
        profiles.setPcInviteUrlMode("webpage");
        profiles.setCreateIotGroup(true);
        model.setProfiles(profiles);
        
        request.setBizModel(model);
        // 第三方代调用模式下请设置app_auth_token
        // request.putOtherTextParam("app_auth_token", "<-- 请填写应用授权令牌 -->");

        AlipayCommerceEcEnterpriseRegisterinviteCreateResponse response = alipayClient.execute(request);
        System.out.println(response.getBody());

        if (response.isSuccess()) {
            System.out.println("调用成功");
        } else {
            System.out.println("调用失败");
            // sdk版本是"4.38.0.ALL"及以上,可以参考下面的示例获取诊断链接
            // String diagnosisUrl = DiagnosisUtils.getDiagnosisUrl(response);
            // System.out.println(diagnosisUrl);
        }
    }

    private static AlipayConfig getAlipayConfig() {
        String privateKey  = "<-- 请填写您的应用私钥，例如：MIIEvQIBADANB ... ... -->";
        String alipayPublicKey = "<-- 请填写您的支付宝公钥，例如：MIIBIjANBg... -->";
        AlipayConfig alipayConfig = new AlipayConfig();
        alipayConfig.setServerUrl("https://openapi.alipay.com/gateway.do");
        alipayConfig.setAppId("<-- 请填写您的AppId，例如：2019091767145019 -->");
        alipayConfig.setPrivateKey(privateKey);
        alipayConfig.setFormat("json");
        alipayConfig.setAlipayPublicKey(alipayPublicKey);
        alipayConfig.setCharset("UTF-8");
        alipayConfig.setSignType("RSA2");
        return alipayConfig;
    }
}
```
 

##### php
```
 <?php
require_once '../aop/AopClient.php';
require_once '../aop/AopCertClient.php';
require_once '../aop/AopCertification.php';
require_once '../aop/AlipayConfig.php';
require_once '../aop/request/AlipayCommerceEcEnterpriseRegisterinviteCreateRequest.php';

// 初始化SDK
$alipayClient = new AopClient(getAlipayConfig());
// 构造请求参数以调用接口
$request = new AlipayCommerceEcEnterpriseRegisterinviteCreateRequest();
$model = array();

// 设置外部业务号
$model['out_biz_no'] = "2024051000000001";

// 设置企业管理员身份类型
$model['identity_type'] = "ALIPAY_USER_ID";

// 设置企业管理员身份标识
$model['identity'] = "2088501457109512";

// 设置企业管理员身份标识openId
$model['identity_open_id'] = "051PZjio8MFya3OHw9tl41J7Sy6m-z150mJTSHM3N3Es4sb";

// 设置企业注册模式
$model['register_mode'] = "NORMAL";

// 设置企业需签约的出资方式
$model['sign_fund_way'] = "BALANCE";

// 设置企业基本信息
$baseInfo = array();
$baseInfo['industry'] = "LOGISTICS";
$baseInfo['enterprise_code'] = "9188051561653411TT";
$baseInfo['enterprise_name'] = "支付宝企业码测试公司";
$model['base_info'] = $baseInfo;

// 设置企业个性化信息
$profiles = array();
$profiles['group_app_id'] = "2014060600164699";
$profiles['access_channel'] = "IOT_NFC";
$profiles['credit_applicant_mobile'] = "15566668888";
$profiles['pc_invite_url_mode'] = "webpage";
$profiles['create_iot_group'] = true;
$model['profiles'] = $profiles;

$request->setBizContent(json_encode($model,JSON_UNESCAPED_UNICODE));
// 如果是第三方代调用模式，请设置app_auth_token（应用授权令牌）
$responseResult = $alipayClient->execute($request, null, "<-- 请填写应用授权令牌 -->", null);
$responseApiName = str_replace(".","_",$request->getApiMethodName())."_response";
$response = $responseResult->$responseApiName;
if(!empty($response->code)&&$response->code==10000){
    echo("调用成功");
}
else{
    echo("调用失败");
}

function getAlipayConfig()
{
    $privateKey  = '<-- 请填写您的应用私钥，例如：MIIEvQIBADANB ... ... -->';
    $alipayPublicKey = '<-- 请填写您的支付宝公钥，例如：MIIBIjANBg... -->';
    $alipayConfig = new AlipayConfig();
    $alipayConfig->setServerUrl('https://openapi.alipay.com/gateway.do');
    $alipayConfig->setAppId('<-- 请填写您的AppId，例如：2019091767145019 -->');
    $alipayConfig->setPrivateKey($privateKey);
    $alipayConfig->setFormat('json');
    $alipayConfig->setAlipayPublicKey($alipayPublicKey);
    $alipayConfig->setCharset('UTF-8');
    $alipayConfig->setSignType('RSA2');
    return $alipayConfig;
}
```
 

##### csharp
```
 using System;
using System.Collections.Generic;
using Aop.Api;
using Aop.Api.Request;
using Aop.Api.Response;
using Aop.Api.Domain;
using Aop.Api.Util;
namespace SdkDemoTest
{
    public class AlipayCommerceEcEnterpriseRegisterinviteCreate
    {
        public static void Main(string[] args) 
        {
            // 初始化SDK
            IAopClient alipayClient = new DefaultAopClient(GetAlipayConfig());
            // 构造请求参数以调用接口
            AlipayCommerceEcEnterpriseRegisterinviteCreateRequest request = new AlipayCommerceEcEnterpriseRegisterinviteCreateRequest();
            AlipayCommerceEcEnterpriseRegisterinviteCreateModel model = new AlipayCommerceEcEnterpriseRegisterinviteCreateModel();
            
            // 设置外部业务号
            model.OutBizNo = "2024051000000001";
            
            // 设置企业管理员身份类型
            model.IdentityType = "ALIPAY_USER_ID";
            
            // 设置企业管理员身份标识
            model.Identity = "2088501457109512";
            
            // 设置企业管理员身份标识openId
            model.IdentityOpenId = "051PZjio8MFya3OHw9tl41J7Sy6m-z150mJTSHM3N3Es4sb";
            
            // 设置企业注册模式
            model.RegisterMode = "NORMAL";
            
            // 设置企业需签约的出资方式
            model.SignFundWay = "BALANCE";
            
            // 设置企业基本信息
            EnterpriseBaseInfoDTO baseInfo = new EnterpriseBaseInfoDTO();
            baseInfo.Industry = "LOGISTICS";
            baseInfo.EnterpriseCode = "9188051561653411TT";
            baseInfo.EnterpriseName = "支付宝企业码测试公司";
            model.BaseInfo = baseInfo;
            
            // 设置企业个性化信息
            EnterpriseProfilesDTO profiles = new EnterpriseProfilesDTO();
            profiles.GroupAppId = "2014060600164699";
            profiles.AccessChannel = "IOT_NFC";
            profiles.CreditApplicantMobile = "15566668888";
            profiles.PcInviteUrlMode = "webpage";
            profiles.CreateIotGroup = true;
            model.Profiles = profiles;
            
            request.SetBizModel(model);
            // 第三方代调用模式下请设置app_auth_token
            // request.PutOtherTextParam("app_auth_token", "<-- 请填写应用授权令牌 -->");

            AlipayCommerceEcEnterpriseRegisterinviteCreateResponse response = alipayClient.Execute(request);

            if(!response.IsError)
            {
                Console.WriteLine("调用成功");
            }
            else
            {
                Console.WriteLine("调用失败");
            }
        }

        private static AlipayConfig GetAlipayConfig()
        {
            string privateKey  = "<-- 请填写您的应用私钥，例如：MIIEvQIBADANB ... ... -->";
            string alipayPublicKey = "<-- 请填写您的支付宝公钥，例如：MIIBIjANBg... -->";
            AlipayConfig alipayConfig = new AlipayConfig();
            alipayConfig.ServerUrl = "https://openapi.alipay.com/gateway.do";
            alipayConfig.AppId = "<-- 请填写您的AppId，例如：2019091767145019 -->";
            alipayConfig.PrivateKey = privateKey;
            alipayConfig.Format = "json";
            alipayConfig.AlipayPublicKey = alipayPublicKey;
            alipayConfig.Charset = "UTF-8";
            alipayConfig.SignType = "RSA2";
            return alipayConfig;
        }
    }
}
```
 

##### http
```
 curl 'https://openapi.alipay.com/gateway.do?charset=UTF-8&method=alipay.commerce.ec.enterprise.registerinvite.create&format=json&sign=${sign}&app_id=${appid}&version=1.0&sign_type=RSA2&timestamp=${now}' \
 -F 'app_auth_token=${app_auth_token}' \
 -F 'biz_content={
	"out_biz_no":"2024051000000001",
	"identity_type":"ALIPAY_USER_ID",
	"identity":"2088501457109512",
	"identity_open_id":"051PZjio8MFya3OHw9tl41J7Sy6m-z150mJTSHM3N3Es4sb",
	"register_mode":"NORMAL",
	"sign_fund_way":"BALANCE",
	"base_info":{
		"industry":"LOGISTICS",
		"enterprise_code":"9188051561653411TT",
		"enterprise_name":"支付宝企业码测试公司"
	},
	"profiles":{
		"group_app_id":"2014060600164699",
		"access_channel":"IOT_NFC",
		"credit_applicant_mobile":"15566668888",
		"pc_invite_url_mode":"webpage",
		"create_iot_group":true
	}
}' 
```
 

### 业务响应参数
|参数英文名|类型|是否必选|长度/取值|描述|示例值|
|---|---|---|---|---|---|
|pc_invite_url|String|必须|512|PC端企业注册链接|https://www.alipay.com/aaa.html|
|expire_time|Date|必须|20|注册链接失效时间，有效期30天**注意事项**格式 yyyy-MM-dd HH:mm:ss|2020-01-01 00:00:01|
### 公共响应参数
|参数英文名|类型|是否必选|长度/取值|描述|示例值|
|---|---|---|---|---|---|
|code|String|必须|~|网关返回码，[详见文档](https://docs.open.alipay.com/common/105806)|40004|
|msg|String|必须|~|网关返回码描述，[详见文档](https://docs.open.alipay.com/common/105806)|Business Failed|
|sub_code|String|可选|~|业务返回码，参见具体的API接口文档||
|sub_msg|String|可选|~|业务返回码描述，参见具体的API接口文档||
|sign|String|必须|64|签名，[详见文档](https://docs.open.alipay.com/291/106074)|DZXh8eeTuAHoYE3w1J+POiPhfDxOYBfUNn1lkeT/V7P4zJdyojWEa6IZs6Hz0yDW5Cp/viufUb5I0/V5WENS3OYR8zRedqo6D+fUTdLHdc+EFyCkiQhBxIzgngPdPdfp1PIS7BdhhzrsZHbRqb7o4k3Dxc+AAnFauu4V6Zdwczo=|
### 响应示例
#### 正常响应示例
```
 {
	"alipay_commerce_ec_enterprise_registerinvite_create_response":{
		"code":"10000",
		"msg":"Success",
		"pc_invite_url":"https://www.alipay.com/aaa.html",
		"expire_time":"2020-01-01 00:00:01"
	},
	"sign":"ERITJKEIJKJHKKKKKKKHJEREEEEEEEEEEE"
}
```
 
#### 异常响应示例
```
 {"alipay_commerce_ec_enterprise_registerinvite_create_response":{"code":"20000","msg":"Service Currently Unavailable","sub_code":"isp.unknow-error","sub_msg":"系统繁忙"},"sign":"ERITJKEIJKJHKKKKKKKHJEREEEEEEEEEEE"}
```
 
### 业务错误码
|错误码|错误描述|解决方案|
|---|---|---|
|SYSTEM_ERROR|系统繁忙|服务器异常 可能发生了网络或者系统异常，导致服务调用失败，商户可以用同样的请求发起重试|
|INVALID_PARAMETER|参数有误|请根据接口返回的参数非法的具体错误信息，修改参数后进行重试|
|AUTHORIZATION_LETTER_NOT_CONFIG|卡付记账时，请先完成相关申请与配置|【错误原因】使用卡付记账时，必须先完成相关申请与配置（无授权函模式）。【排查步骤】请联系支付宝客服申请相关授权函配置。|
|CORPORATE_CARD_NOT_CONFIG|公务卡出资时，请先完成相关申请与配置|【错误原因】使用公务卡出资时，必须先完成相关申请与配置。【排查步骤】请联系支付宝客服完成相关配置。|
|ECEIF_ENTERPRISE_CREATE_OVER_LIMIT|当前账号创建企业数达上限，请更换账号|【错误原因】当前账号已创建的企业数超出上限。 【排查步骤】更换账号创建企业。|
|EMAIL_HAS_REGISTERED_ALIPAY|企业邮箱已注册支付宝账号，不支持重复注册|【错误原因】该企业邮箱已经注册支付宝账号，不支持重复注册。 【排查步骤】可直接登录（登陆密码已发送至该企业邮箱中）或者更换邮箱后重试|
|ENTERPRISE_EMAIL_ALREADY_EXIST|该企业邮箱已经注册过企业，不支持重复注册|【错误原因】该企业邮箱已经注册过其他企业，不支持重复注册。【排查步骤】可直接登录（登陆密码已发送至该企业邮箱中）或者更换邮箱后重试|
|ENTERPRISE_EMAIL_NOT_SUPPORT|权限不足-不支持的身份类型(ENTERPRISE_EMAIL)|【错误原因】身份类型 ENTERPRISE_EMAIL 为定向开放能力。 【排查步骤】修改身份类型传参或联系客服处理。|
|ENTERPRISE_MAIL_INVALID_CHARACTERS|邮箱不能包含特殊关键字词，请更换后重试|【错误原因】邮箱包含非法关键词（如前缀包含aliapy, alibaba, aliyun等）。【排查步骤】请更换邮箱重试|
|INVITE_URL_CREATE_ING|企业邀请链接生成中，请稍后|【错误原因】使用相同 outBizNo 并发调用导致。 【排查步骤】请稍后重试。|
|ISV_USER_ID_NOT_SUPPORT|权限不足-不支持的身份类型(ISV_USER_ID)|【错误原因】身份类型 ISV_USER_ID 为定向开放能力。 【排查步骤】修改身份类型传参或联系客服处理。|
|NO_PERMISSION_NOT_CERTIFIED|支付宝账号未实名认证，请实名认证后重试|【错误原因】用户未实名，无法使用该功能。 【排查步骤】用户先进行支付宝实名认证。|
|SERVICE_PROVIDER_NOT_EXIST|使用公务卡出资或卡付记账时，请先入驻为企业码服务商|【错误原因】使用公务卡出资或卡付记账时，必须先入驻为企业码服务商。【排查步骤】完成企业码服务商入驻后重试。|
|USER_NOT_EXIST|支付宝用户不存在，请修改后重试|【错误原因】支付宝用户不存在。 【排查步骤】请检查入参 identity 的正确性，更换支付宝账号重试。|