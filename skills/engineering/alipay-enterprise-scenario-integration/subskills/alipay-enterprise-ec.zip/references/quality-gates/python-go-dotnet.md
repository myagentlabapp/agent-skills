# 员企 Python/Go/.NET 质量门禁

本文件只约束 Python、Go、.NET 等非 Java/Node.js 生成代码。通用原则见 [员企通用代码生成规则](../codegen-general-rules.md)，字段和接口来源见 [员企字段和接口规则](../field-interface-rules.md)。

1. 生成前必须确认当前语言使用官方 SDK 还是 HTTP(S) 网关调用；没有真实 SDK 能力时使用文档字段手拼请求体，但字段名和嵌套路径必须完全来自接口文档。
2. 企业邀请注册必须包含 `out_biz_no`、`identity_type`，并使用 `identity` / `identity_open_id` 中的一个文档身份标识；企业名称必须位于 `base_info.enterprise_name`，不得放到顶层。
3. 员工新增和修改不得按业务语义猜近义字段；必须使用文档字段和路径，常见反例包括 `name`、`phone`、`role`、`departmentIdList`。
4. `alipay.commerce.ec.employee.idlist.query` 必须传 `department_id`。
5. HTTP(S) 通知必须验签后再处理业务；不得生成验签直接 `return true`、本地 SDK stub 或 mock-success 逻辑。
6. 生成后必须运行本域 validator；validator 会做跨语言字段结构和验签占位检查，并在运行时存在时执行 Python 语法检查、`go test ./...`、`dotnet build` 或 PHP 语法检查。
