# 邀请员工签约模式流程

## 概述

邀请员工签约模式是企业导入员工信息，获取员工签约激活页面链接/吱口令，邀请员工完成签约的通用模式。

## 前置配置

+ 员工身份类型，默认开放「支付宝用户UID」「支付宝登录号」「手机号」「邮箱」「身份证号」，其中五选一即可。
+ 如遇特殊场景，必须使用<u>服务商用户ID (ISV_USER_ID)</u>，需BD同学<u>先联系职能同学（星航、甘茂）+中台同学审批</u>，然后按技术配置SOP提交申请。

说明：服务商用户ID (ISV_USER_ID) 方式下，企业码系统无法核验用户身份，存在较高安全风险，因此需审批后再定向开放。

## 流程图

```
┌─────────────────────────────────────────────────────────────────────────┐
│                        邀请员工签约模式流程                                │
└─────────────────────────────────────────────────────────────────────────┘

【员工签约流程】

┌─────────────┐     ┌─────────────────────────────────────┐     ┌─────────────┐
│   企业管理员 │ ──► │  调用添加员工接口                      │ ──► │  返回员工ID   │
│             │     │  alipay.commerce.ec.employee.add      │     │  签约链接/    │
│             │     │  free_sign_token不传或为空             │     │  吱口令等     │
└─────────────┘     └─────────────────────────────────────┘     └─────────────┘
                                                                         │
                                                                         ▼
┌─────────────┐     ┌─────────────────────────────────────┐     ┌─────────────┐
│   员工      │ ◄── │  员工签约激活                         │ ◄── │  邀请员工     │
│             │     │  （登录支付宝完成签约）                │     │  （链接/吱口令）│
│             │     │                                     │     │             │
└─────────────┘     └─────────────────────────────────────┘     └─────────────┘
       │
       ▼
┌─────────────────────────────────────┐
│  接收员工变更通知                     │
│  alipay.commerce.ec.employee.        │
│         change.notify                │
│  action=EMPLOYEE_ACTIVATED         │
└─────────────────────────────────────┘
```

## 接口文档

| 阶段 | 接口说明 | 接口文档 | 备注 |
|------|----------|----------|------|
| **添加员工** | 添加员工（邀请模式） | [alipay.commerce.ec.employee.add.md](alipay.commerce.ec.employee.add.md) | free_sign_token不传或为空，返回签约链接 |
| **再次邀请** | 获取员工签约链接 | [alipay.commerce.ec.employee.invite.query.md](alipay.commerce.ec.employee.invite.query.md) | 存量员工再次邀约时获取签约链接 |
| **消息接收** | 员工变更通知 | [employee-change-notify.md](employee-change-notify.md) | 接收员工新增、激活、修改、删除通知 |

## 关键说明

### 添加员工接口参数

- **free_sign_token**: 不传或为空，表示邀请模式，员工需主动完成签约
- **返回结果**: 包含员工ID、员工签约页面链接、吱口令等

### 三种邀约方式

1. **唤起支付宝APP**: 跳转企业码员工签约页面
2. **二维码邀请**: 将员工签约链接生成二维码
3. **吱口令邀请**: 使用吱口令邀请员工

## 必须接入模块

### 员工管理

| 接口说明 | 接口文档 | 用途 |
|----------|----------|------|
| 查询员工详情 | [../employee-mgmt/alipay.commerce.ec.employee.info.query.md](../employee-mgmt/alipay.commerce.ec.employee.info.query.md) | 查询员工详细信息 |
| 修改员工信息 | [../employee-mgmt/alipay.commerce.ec.employee.info.modify.md](../employee-mgmt/alipay.commerce.ec.employee.info.modify.md) | 修改员工基本信息、部门、核算主体等 |
| 删除员工 | [../employee-mgmt/alipay.commerce.ec.employee.delete.md](../employee-mgmt/alipay.commerce.ec.employee.delete.md) | 员工离职删除 |
| 查询部门下员工ID列表 | [../employee-mgmt/alipay.commerce.ec.employee.idlist.query.md](../employee-mgmt/alipay.commerce.ec.employee.idlist.query.md) | 分页查询部门下员工 |
| 查询标签下员工ID列表 | [../employee-mgmt/alipay.commerce.ec.label.employeeidlist.query.md](../employee-mgmt/alipay.commerce.ec.label.employeeidlist.query.md) | 根据标签查询员工 |
| 员工变更通知 | [employee-change-notify.md](employee-change-notify.md) | 接收员工新增、激活、修改、删除通知 |

### 企业管理

| 接口说明 | 接口文档 | 用途 |
|----------|----------|------|
| 查询企业详情 | [../enterprise-mgmt/alipay.commerce.ec.enterprise.info.query.md](../enterprise-mgmt/alipay.commerce.ec.enterprise.info.query.md) | 查询企业详细信息 |
| 修改企业信息 | [../enterprise-mgmt/alipay.commerce.ec.enterprise.info.modify.md](../enterprise-mgmt/alipay.commerce.ec.enterprise.info.modify.md) | 修改企业基本信息 |
| 注销企业 | [../enterprise-mgmt/alipay.commerce.ec.enterprise.delete.md](../enterprise-mgmt/alipay.commerce.ec.enterprise.delete.md) | 企业注销、解约 |

## 按需接入模块（可选）

根据业务需求选择性接入：

| 模块 | 流程文档 | 说明 |
|------|----------|------|
| **部门管理** | [../department/department-flow.md](../department/department-flow.md) | 部门树管理、员工所属部门管理 |
| **核算主体管理** | [../accounting-entity/accounting-entity-flow.md](../accounting-entity/accounting-entity-flow.md) | 核算主体管理、员工所属核算主体管理 |
| **企业地址管理** | [../enterprise-address/enterprise-address-flow.md](../enterprise-address/enterprise-address-flow.md) | 企业办公地址管理 |
| **企业消息推送任务** | [../msg-task/msg-task-flow.md](../msg-task/msg-task-flow.md) | 消息盒子、Push消息推送 |

## 消息接入方式选择

若由方案型 Skill 调用且上游已统一消息接入方式，直接沿用上游决策；独立使用时按本节选择，默认推荐 WebSocket 长连接。

员工变更通知支持两种接入方式：

| 接入方式 | 适用场景 | 特点 |
|----------|----------|------|
| **WebSocket 长连接**（推荐） | 消息量大、实时性要求高 | 性能优、通道安全、无需 HTTPS 证书、SDK 自动验签 |
| **HTTP(S) 接入** | 消息量小、已有 HTTP 服务 | 需配置应用网关、需自行实现验签、需处理幂等 |

**详细接入文档**：
- [消息接口集成说明](../common/message-integration.md) - HTTP(S) 消息接入
- [WebSocket 长连接接入](../common/websocket-integration.md) - WebSocket 接入

## 参考文档

- [消息接口集成说明](../common/message-integration.md) - HTTP(S) 消息接入详细说明
- [WebSocket 长连接接入](../common/websocket-integration.md) - WebSocket 接入详细说明
