# 核算主体管理流程（可选接入）

## 概述

> **【可选接入】** 核算主体管理模块为非必须接入模块，仅当业务需要管理企业核算主体、员工所属核算主体时才需要接入。

核算主体管理用于企业核算主体的维护、核算主体基本信息管理、员工所属核算主体管理。

## 前置配置

_无_

## 流程图

```
┌─────────────────────────────────────────────────────────────────────────┐
│                          核算主体管理流程                                  │
└─────────────────────────────────────────────────────────────────────────┘

【核算主体管理】

┌─────────────┐     ┌─────────────────────────────────────┐
│  新增核算   │ ──► │  alipay.commerce.ec.accountingentity.│
│   主体      │     │         create                       │
└─────────────┘     └─────────────────────────────────────┘

┌─────────────┐     ┌─────────────────────────────────────┐
│  查询核算   │ ──► │  alipay.commerce.ec.accountingentity.│
│   主体      │     │         page.query                   │
└─────────────┘     └─────────────────────────────────────┘

┌─────────────┐     ┌─────────────────────────────────────┐
│  修改核算   │ ──► │  alipay.commerce.ec.accountingentity.│
│  主体信息   │     │         info.modify                  │
└─────────────┘     └─────────────────────────────────────┘

┌─────────────┐     ┌─────────────────────────────────────┐
│  删除核算   │ ──► │  alipay.commerce.ec.accountingentity.│
│   主体      │     │         delete                       │
└─────────────┘     └─────────────────────────────────────┘

【员工所属核算主体管理】

┌─────────────┐     ┌─────────────────────────────────────┐
│  将员工加入 │ ──► │  alipay.commerce.ec.employee.add    │
│  核算主体   │     │  或 employee.info.modify             │
│             │     │  accounting_entity_id字段指定       │
└─────────────┘     └─────────────────────────────────────┘

┌─────────────┐     ┌─────────────────────────────────────┐
│  查询核算   │ ──► │  alipay.commerce.ec.accountingentity.│
│  主体下员工 │     │         employeeidlist.query         │
└─────────────┘     └─────────────────────────────────────┘
```

## 接口文档

| 阶段 | 接口说明 | 接口文档 | 备注 |
|------|----------|----------|------|
| **创建核算主体** | 创建核算主体 | [alipay.commerce.ec.accountingentity.create.md](alipay.commerce.ec.accountingentity.create.md) | 创建新的核算主体 |
| **查询核算主体** | 分页查询核算主体 | [alipay.commerce.ec.accountingentity.page.query.md](alipay.commerce.ec.accountingentity.page.query.md) | 分页查询企业核算主体列表 |
| **修改核算主体** | 修改核算主体信息 | [alipay.commerce.ec.accountingentity.info.modify.md](alipay.commerce.ec.accountingentity.info.modify.md) | 修改核算主体基础信息 |
| **删除核算主体** | 删除核算主体 | [alipay.commerce.ec.accountingentity.delete.md](alipay.commerce.ec.accountingentity.delete.md) | 删除单个核算主体 |
| **员工核算主体管理** | 修改员工信息 | [../employee-mgmt/alipay.commerce.ec.employee.info.modify.md](../employee-mgmt/alipay.commerce.ec.employee.info.modify.md) | accounting_entity_id字段指定 |
| **查询核算主体员工** | 查询核算主体下员工Id列表 | [alipay.commerce.ec.accountingentity.employeeidlist.query.md](alipay.commerce.ec.accountingentity.employeeidlist.query.md) | 分页查询核算主体下员工 |

## 业务约束

### 1. 核算主体用途

- 用于企业按核算主体维度管理员工
- 支持多核算主体场景

### 2. 删除限制

- 核算主体下有员工时，可能需要先移除员工才能删除

## 参考文档

- [修改员工信息](../employee-mgmt/alipay.commerce.ec.employee.info.modify.md) - 员工所属核算主体管理
- [查询员工详情](../employee-mgmt/alipay.commerce.ec.employee.info.query.md) - 查询员工详细信息
