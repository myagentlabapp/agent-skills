# 部门管理流程（可选接入）

## 概述

> **【可选接入】** 部门管理模块为非必须接入模块，仅当业务需要管理企业部门树、员工所属部门时才需要接入。

部门管理用于企业部门树的维护、部门基本信息管理、员工所属部门管理。

## 前置配置

_无_

## 流程图

```
┌─────────────────────────────────────────────────────────────────────────┐
│                           部门管理流程                                     │
└─────────────────────────────────────────────────────────────────────────┘

【部门管理】

┌─────────────┐     ┌─────────────────────────────────────┐
│   创建部门   │ ──► │  alipay.commerce.ec.department.create │
└─────────────┘     └─────────────────────────────────────┘

┌─────────────┐     ┌─────────────────────────────────────┐
│  查询子部门  │ ──► │  alipay.commerce.ec.department.     │
│   列表      │     │         sublist.query               │
└─────────────┘     └─────────────────────────────────────┘

┌─────────────┐     ┌─────────────────────────────────────┐
│  查询部门   │ ──► │  alipay.commerce.ec.department.      │
│   详情      │     │         info.query                   │
└─────────────┘     └─────────────────────────────────────┘

┌─────────────┐     ┌─────────────────────────────────────┐
│  修改部门   │ ──► │  alipay.commerce.ec.department.      │
│   信息      │     │         info.modify                  │
└─────────────┘     └─────────────────────────────────────┘

┌─────────────┐     ┌─────────────────────────────────────┐
│   删除部门   │ ──► │  alipay.commerce.ec.department.     │
│             │     │         delete                       │
└─────────────┘     └─────────────────────────────────────┘

【员工所属部门管理】

┌─────────────┐     ┌─────────────────────────────────────┐
│  员工加入   │ ──► │  alipay.commerce.ec.employee.add   │
│   部门      │     │  或 employee.info.modify            │
│             │     │  department_ids字段指定部门         │
└─────────────┘     └─────────────────────────────────────┘

┌─────────────┐     ┌─────────────────────────────────────┐
│  查询部门   │ ──► │  alipay.commerce.ec.employee.      │
│  下员工     │     │         idlist.query                │
└─────────────┘     └─────────────────────────────────────┘
```

## 接口文档

| 阶段 | 接口说明 | 接口文档 | 备注 |
|------|----------|----------|------|
| **创建部门** | 创建部门 | [alipay.commerce.ec.department.create.md](alipay.commerce.ec.department.create.md) | 部门树层级最大深度为20 |
| **查询子部门** | 查询子部门列表 | [alipay.commerce.ec.department.sublist.query.md](alipay.commerce.ec.department.sublist.query.md) | 企业为最高一级部门，取值-1 |
| **查询部门详情** | 查询部门详情 | [alipay.commerce.ec.department.info.query.md](alipay.commerce.ec.department.info.query.md) | 根据部门id查询详细信息 |
| **修改部门信息** | 修改部门信息 | [alipay.commerce.ec.department.info.modify.md](alipay.commerce.ec.department.info.modify.md) | 修改部门基础信息 |
| **删除部门** | 删除部门 | [alipay.commerce.ec.department.delete.md](alipay.commerce.ec.department.delete.md) | 连带删除子部门，有员工时无法删除 |
| **员工部门管理** | 修改员工信息 | [../employee-mgmt/alipay.commerce.ec.employee.info.modify.md](../employee-mgmt/alipay.commerce.ec.employee.info.modify.md) | department_ids字段指定部门 |
| **查询部门员工** | 查询部门下员工id列表 | [../employee-mgmt/alipay.commerce.ec.employee.idlist.query.md](../employee-mgmt/alipay.commerce.ec.employee.idlist.query.md) | 分页查询部门下员工 |
| **部门变更通知** | 部门变更通知 | [department-change-notify.md](department-change-notify.md) | 接收部门创建、修改、删除通知 |

## 业务约束

### 1. 部门层级限制

- 部门树层级最大深度为20
- parent_department_id 可空，为空则默认设置为根部门（根部门值为-1）

### 2. 删除部门限制

- 删除部门会连带删除其所有子部门
- 当指定部门或其子部门下有员工时，无法删除该部门

### 3. 查询企业下一级部门

- department_id 取值-1表示查询企业下一级部门

## 消息接入方式选择

若由方案型 Skill 调用且上游已统一消息接入方式，直接沿用上游决策；独立使用时按本节选择，默认推荐 WebSocket 长连接。

部门变更通知支持两种接入方式：

| 接入方式 | 适用场景 | 特点 |
|----------|----------|------|
| **WebSocket 长连接**（推荐） | 消息量大、实时性要求高 | 性能优、通道安全、无需 HTTPS 证书、SDK 自动验签 |
| **HTTP(S) 接入** | 消息量小、已有 HTTP 服务 | 需配置应用网关、需自行实现验签、需处理幂等 |

**详细接入文档**：
- [消息接口集成说明](../common/message-integration.md) - HTTP(S) 消息接入
- [WebSocket 长连接接入](../common/websocket-integration.md) - WebSocket 接入

## 参考文档

- [消息接口集成说明](../common/message-integration.md) - HTTP(S) 消息接入详细说明
- [WebSocket 长连接接入](../common/websocket-integration.md) - WebSocket 接入详细说明
