# 授权签约模式流程

## 概述

> **【注意】** 授权签约模式为定向开放能力，需先联系BD同学申请**员工授权签约密钥**。

授权签约模式是企业导入员工信息并直接激活该员工，无需员工主动完成签约流程。主要用于服务商已在线下完成员工身份核验的场景。

## 前置配置

+ 员工授权签约密钥，授权签约模式为定向开放能力，请联系BD同学申请。

## 流程图

```
┌─────────────────────────────────────────────────────────────────────────┐
│                        授权签约模式流程                                    │
└─────────────────────────────────────────────────────────────────────────┘

【员工签约流程】

┌─────────────┐     ┌─────────────────────────────────────┐     ┌─────────────┐
│   企业管理员 │ ──► │  调用添加员工接口                      │ ──► │  员工直接激活  │
│             │     │  alipay.commerce.ec.employee.add      │     │  无需员工操作  │
│             │     │  free_sign_token透传                   │     │             │
└─────────────┘     └─────────────────────────────────────┘     └─────────────┘
                                                                         │
                                                                         ▼
┌─────────────────────────────────────┐
│  接收员工变更通知                     │
│  alipay.commerce.ec.employee.        │
│         change.notify                │
│  action=EMPLOYEE_ACTIVATED           │
└─────────────────────────────────────┘
```

## 接口文档

| 阶段 | 接口说明 | 接口文档 | 备注 |
|------|----------|----------|------|
| **添加员工** | 添加员工（授权签约模式） | [alipay.commerce.ec.employee.add.md](../employee-sign-invite/alipay.commerce.ec.employee.add.md) | free_sign_token透传，员工直接激活 |
| **消息接收** | 员工变更通知 | [../employee-sign-invite/employee-change-notify.md](../employee-sign-invite/employee-change-notify.md) | 接收员工新增、激活、修改、删除通知 |

## 关键说明

### 添加员工接口参数

- **free_sign_token**: 需传入有效的授权签约密钥
- **返回结果**: 员工直接激活成功，不返回签约链接

### 适用场景

- 服务商已在线下完成员工身份核验
- 批量导入员工，无需员工逐个签约
- 内部系统已管控员工身份的场景

## 必须接入模块

### 员工管理

| 接口说明 | 接口文档 | 用途 |
|----------|----------|------|
| 查询员工详情 | [../employee-mgmt/alipay.commerce.ec.employee.info.query.md](../employee-mgmt/alipay.commerce.ec.employee.info.query.md) | 查询员工详细信息 |
| 修改员工信息 | [../employee-mgmt/alipay.commerce.ec.employee.info.modify.md](../employee-mgmt/alipay.commerce.ec.employee.info.modify.md) | 修改员工基本信息、部门、核算主体等 |
| 删除员工 | [../employee-mgmt/alipay.commerce.ec.employee.delete.md](../employee-mgmt/alipay.commerce.ec.employee.delete.md) | 员工离职删除 |
| 查询部门下员工ID列表 | [../employee-mgmt/alipay.commerce.ec.employee.idlist.query.md](../employee-mgmt/alipay.commerce.ec.employee.idlist.query.md) | 分页查询部门下员工 |
| 查询标签下员工ID列表 | [../employee-mgmt/alipay.commerce.ec.label.employeeidlist.query.md](../employee-mgmt/alipay.commerce.ec.label.employeeidlist.query.md) | 根据标签查询员工 |
| 员工变更通知 | [../employee-sign-invite/employee-change-notify.md](../employee-sign-invite/employee-change-notify.md) | 接收员工新增、激活、修改、删除通知 |

### 企业管理

| 接口说明 | 接口文档 | 用途 |
|----------|----------|------|
| 查询企业详情 | [../enterprise-mgmt/alipay.commerce.ec.enterprise.info.query.md](../enterprise-mgmt/alipay.commerce.ec.enterprise.info.query.md) | 查询企业详细信息 |
| 修改企业信息 | [../enterprise-mgmt/alipay.commerce.ec.enterprise.info.modify.md](../enterprise-mgmt/alipay.commerce.ec.enterprise.info.modify.md) | 修改企业基本信息 |
| 注销企业 | [../enterprise-mgmt/alipay.commerce.ec.enterprise.delete.md](../enterprise-mgmt/alipay.commerce.ec.enterprise.delete.md) | 企业注销、解约 |

## 按需接入模块（可选）

根据业务需求选择性接入：

| 模块 | 流程文档 | 说明 |
|------|----------|------|
| **部门管理** | [../department/department-flow.md](../department/department-flow.md) | 部门树管理、员工所属部门管理 |
| **核算主体管理** | [../accounting-entity/accounting-entity-flow.md](../accounting-entity/accounting-entity-flow.md) | 核算主体管理、员工所属核算主体管理 |
| **企业地址管理** | [../enterprise-address/enterprise-address-flow.md](../enterprise-address/enterprise-address-flow.md) | 企业办公地址管理 |
| **企业消息推送任务** | [../msg-task/msg-task-flow.md](../msg-task/msg-task-flow.md) | 消息盒子、Push消息推送 |

## 消息接入方式选择

若由方案型 Skill 调用且上游已统一消息接入方式，直接沿用上游决策；独立使用时按本节选择，默认推荐 WebSocket 长连接。

员工变更通知支持两种接入方式：

| 接入方式 | 适用场景 | 特点 |
|----------|----------|------|
| **WebSocket 长连接**（推荐） | 消息量大、实时性要求高 | 性能优、通道安全、无需 HTTPS 证书、SDK 自动验签 |
| **HTTP(S) 接入** | 消息量小、已有 HTTP 服务 | 需配置应用网关、需自行实现验签、需处理幂等 |

**详细接入文档**：
- [消息接口集成说明](../common/message-integration.md) - HTTP(S) 消息接入
- [WebSocket 长连接接入](../common/websocket-integration.md) - WebSocket 接入

## 参考文档

- [消息接口集成说明](../common/message-integration.md) - HTTP(S) 消息接入详细说明
- [WebSocket 长连接接入](../common/websocket-integration.md) - WebSocket 接入详细说明
