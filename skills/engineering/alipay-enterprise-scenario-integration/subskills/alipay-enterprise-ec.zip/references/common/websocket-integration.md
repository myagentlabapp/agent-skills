# WebSocket长连接接入

## 简介

开发者服务端可以与支付宝开放平台服务端建立基于 WebSocket 的长连接通道，用于收发消息。

相对于需要开发者提供应用网关接收 From 蚂蚁消息，长连接通道有如下优点：

- 开发者不需要开发一个 HTTP server 来接收 From 蚂蚁消息，也不需要购买 HTTPS 证书。
- 基于长连接，比 HTTPS 通信更高效。
- 长连接 SDK 高层次封装，通信、数字签名等开发者都不需要考虑，只需要关注消息处理逻辑本身。

## 使用方法

### 选择通信方式

开发者服务端与支付宝开放平台服务端消息交互目前有两种通信方式，一种是基于 HTTPS/HTTP，一种是基于 WebSocket 长连接。因此，开发者在订阅消息 API（From 蚂蚁）时要选择通信方式，这样支付宝服务端才知道通过什么通信方式下发消息给开发者服务端。

### 接入代码

支付宝开放平台提供的服务端 SDK（Java 语言版，其它语言敬请期待）支持长连接通道，使用 SDK 可以不用关心连接通信的细节，只需要关注消息报文的处理。

#### 引入依赖

目前支持长连接通道的服务端 SDK 只有 Java 语言版，请添加 [maven项目依赖](https://search.maven.org/search?q=g:com.alipay.sdk%20AND%20a:alipay-sdk-java&core=gav)，并使用 3.6.0.ALL 及以上版本。如：

**注意**：若使用证书模式接入请使用 4.11.54.ALL 及以上版本 SDK。

```xml
<!-- https://mvnrepository.com/artifact/com.alipay.sdk/alipay-sdk-java -->
<dependency>
    <groupId>com.alipay.sdk</groupId>
    <artifactId>alipay-sdk-java</artifactId>
    <version>4.11.54.ALL</version>
</dependency>
```

#### 获取客户端对象

开发者可根据自身应用加签方式构造、配置基于长连接通道的消息客户端 AlipayMsgClient。使用 AlipayMsgClient.getInstance(appId) 可获取 alipayMsgClient 对象，相同的 appId 会对应同一个实例，不同的 appId 对应不同的实例。

##### 普通公钥方式

若使用 [普通公钥方式](https://opendocs.alipay.com/common/02kdnc#%E5%85%AC%E9%92%A5%E6%96%B9%E5%BC%8F_2) 接入支付宝 API，可参考如下方法构造、配置 AlipayMsgClient ：

```java
String appId =  "your appid" ;
 // 目标支付宝服务端地址，线上环境为 openchannel.alipay.com 
String serverHost =  "openchannel.alipay.com" ;
 // 数据签名方式，请与应用设置的默认签名方式保持一致 
String signType =  "RSA2" ;
 // 应用私钥 
String appPrivateKey =  "your app private key" ;
 // 支付宝公钥 
String alipayPublicKey =  "alipay public key" ;
 // 获取client对象，一个appId对应一个实例 
 final  AlipayMsgClient alipayMsgClient = AlipayMsgClient.getInstance(appId);
alipayMsgClient.setConnector(serverHost);
alipayMsgClient.setSecurityConfig(signType, appPrivateKey, alipayPublicKey);
```

##### 公钥证书方式

若使用 [公钥证书方式](https://opendocs.alipay.com/common/02kdnc#%E5%85%AC%E9%92%A5%E8%AF%81%E4%B9%A6%E6%96%B9%E5%BC%8F_2) 接入支付宝 API，可参考如下方法构造、配置 AlipayMsgClient 。

```java
AlipayMsgClient alipayMsgClient;
    String appId = "your_appid";
    // 目标支付宝服务端地址，线上环境为 openchannel.alipay.com 
    String serverHost =  "openchannel.alipay.com";
    String signType = "RSA2";
    String charset = "your_charset";
    String appPrivateKey= "your_app_Private_Key";
    // 应用公钥证书路径
    String certPath = "your_cerPath";
    // 支付宝公钥证书路径
    String alipayPublicCertPath = "your_alipayPublicCertPath";
    // 支付宝根证书路径
    String rootCertPath = "your_rootCertPath";
    alipayMsgClient = AlipayMsgClient.getInstance(appId);
    alipayMsgClient.setConnector(serverHost);
    alipayMsgClient.setSecurityCertConfig(signType, appPrivateKey, certPath, alipayPublicCertPath, rootCertPath);
    alipayMsgClient.setCharset(charset);
```

#### 建立连接

```javascript
alipayMsgClient.connect();
```

调用上文的方法，客户端就会开始与支付宝开放平台服务端尝试建立连接。如果建连失败，会抛出异常。

**注意**：

1. alipayMsgClient 的所有 setXX 方法都必须在 connect 方法调用之前被调用，否则设置无效。
2. alipayMsgClient.connect() 调用之后，如果连接失败或中断，alipayMsgClient 会自动进行重连，每次重连间隔 0-10s。因此每个 alipayMsgClient 实例，只需要调用 connect 方法一次。
3. 支付宝开放平台服务端对客户端连接数有限制，一般请求下不会达到。但如果集群的机器确实很多，建立的连接达到了限制，connect() 一直抛异常，请联系支付宝技术支持。

#### 处理接收到的消息

```java
alipayMsgClient.setMessageHandler( new  MsgHandler() {
     /**
     * 客户端接收到消息后回调此方法
     *  @param  msgApi 接收到的消息的消息api名
     *  @param  msgId 接收到的消息的消息id
     *  @param  bizContent 接收到的消息的内容，json格式
     */ 
     public   void   onMessage (String msgApi, String msgId, String bizContent)   {
        System.out.println( "receive message. msgApi:"  + msgApi +  " msgId:"  + msgId +  " bizContent:"  + bizContent);
    }
});
```

当客户端收到一条消息时，会回调开发者定义的 MsgHandler 实现，在 onMessage 方法实现中，不抛出任何异常，则认为消费消息成功，否则服务端认为此消息客户端没有消费成功，会触发重试。

**注意**：每一条 From 蚂蚁的消息都会有 msgId，不保证不会重复投递，因此，需要业务上借助 msgId 或其它业务 ID 来做幂等控制。 回调的执行会在单独的线程池中进行，此线程池默认 coreSize 为 5，maxSize 为10。如果想修改，可以如下调用：

```java
alipayMsgClient.setBizThreadPoolCoreSize( 16 );
alipayMsgClient.setBizThreadPoolMaxSize( 32 );
```

#### 发送消息

向支付宝开放平台服务端发送To蚂蚁消息，代码如下。

```java
// 构造消息请求对象，参照To蚂蚁消息API文档，你可以将API名.转驼峰，找到对应的Request和Model类 
AlipayOpenAppOpenbizmockMessageSendRequest request =  new  AlipayOpenAppOpenbizmockMessageSendRequest();
AlipayOpenAppOpenbizmockMessageSendModel model =  new  AlipayOpenAppOpenbizmockMessageSendModel();
 // 设置业务参数 
model.setShopId( "111" );
model.setStatus( "ffcc" );
model.setUserId( "209988278" );
request.setBizModel(model);
 // 发送消息 
ProduceMsgAck produceMsgAck = alipayMsgClient.sendMessage(request);
 if  (produceMsgAck.getxStatus() == MsgStatusEnum.SUCCESS) {
    System.out.println( "服务端接收消息成功" );
}  else  {
    System.out.println( "服务端接收消息失败，错误码："  + produceMsgAck.getxCode() +  " 错误描述："  + produceMsgAck.getxError());
}
```

- sendMessage 是同步调用，得到服务端响应之后，才会返回。超时时间是10s，超时后会抛出异常。
- produceMsgAck.getxCode 结果码查看下方。

## 常见结果码

| code | msg | 说明 | 处理方式 |
| --- | --- | --- | --- |
| 10000 | success | 消息提交成功 | - |
| 20000 | msg.unknow-error | 服务暂不可用 | 请稍后重试或者联系技术支持。 |
| 20001 | msg.no-permission | 无权限发送该消息 | 请检查是否开通相关消息服务。 |
| 30000 | msg.invalid-parameter | 存在非法的消息参数 | 请检查请求参数是否合法。 |
| 30000 | msg.invalid-sign | 验签失败 | - 检查公私钥是否是一对。<br/>- 检查公钥上传是否与私钥匹配。<br/>- 存在中文需要做 urlencode。<br/>- 签名算法是否无误。 |
| | msg.invalid-app-id | 无效的appId | 检查入参 app_id，app_id 不存在，或者未上线。 |
| | msg.invalid-msg-api | 消息 API 不存在 | 请检查消息 API 名称是否有误 |
| | msg.empty-content | 消息内容不允许为空 | 请检查请求消息对象是否正常设置 |
| | msg.invalid-timestamp | 时间戳格式非法或者过期 | 时间戳参数 timestamp 非法，请检查格式为数字，精确到毫秒级，且在10分钟内。 |
| | msg.invalid-sign-type | 非法的签名类型 | 检查入参 sign_type，目前只支持 RSA、RSA2。 |
| | msg.invalid-version | 非法的version | 非法的协议参数 version，请检查入参 version。 |
| | msg.invalid-charset | 非法的字符集类型 | 请求参数 charset 错误，目前支持格式：GBK，UTF-8。 |
| 30001 | msg.missing-sign | 缺少sign参数 | 请检查是否缺少协议参数 sign。 |
| | msg.missing-charset | 缺少charset参数 | 请检查是否缺少协议参数 charset。 |
| | msg.missing-sign-type | 缺少sign_type参数 | 请检查是否缺少协议参数 sign_type。 |
| | msg.missing-timestamp | 缺少timestamp参数 | 请检查是否缺少协议参数 timestamp。 |
| | msg.missing-app-id | 缺少appId参数 | 请检查参数 APPID 是否缺失。 |
| | msg.missing-msg-api | 缺少msgApi参数 | 请检查参数 msgApi 是否缺失。 |
| | msg.missing-msg-id | 缺失msgId参数 | 请检查消息报文是否缺少 msgId。 |
| | msg.missing-content | 消息内容为空 | 请确保投递的消息内容不为空。 |
| 40000 | msg.consumer-not-exist | 该消息不存在消费方 | 请确保该消息接口存在订阅方。 |
| | msg.sys-abort | 系统已终止该消息的发送 | 订阅方取消订阅或者系统自动放弃投递。 |
