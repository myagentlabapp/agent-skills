# alipay.commerce.ec.enterprise.reliableauth.sync(企业码可信渠道企业认证同步)
## 通用场景
可信渠道专用，同步渠道企业认证信息
### 公共请求参数
|参数英文名|类型|是否必选|长度/取值|描述|示例值|
|---|---|---|---|---|---|
|app_id|String|必选|32|支付宝分配给开发者的应用ID|2014072300007148|
|method|String|必选|128|接口名称|alipay.commerce.ec.enterprise.reliableauth.sync|
|format|String|可选|40|仅支持JSON|JSON|
|charset|String|必选|10|请求使用的编码格式，如utf-8,gbk,gb2312等|utf-8|
|sign_type|String|必选|10|商户生成签名字符串所使用的签名算法类型，目前支持RSA2和RSA，推荐使用RSA2|RSA2|
|sign|String|必选|344|商户请求参数的签名串，详见[签名](https://opendocs.alipay.com/common/02khjm)|详见示例|
|timestamp|String|必选|19|发送请求的时间，格式"yyyy-MM-dd HH:mm:ss"|2014-07-24 03:07:50|
|version|String|必选|3|调用的接口版本，固定为：1.0|1.0|
|biz_content|String|必选||请求参数的集合，最大长度不限，除公共参数外所有请求参数都必须放在这个参数中传递，具体参照各产品快速接入文档||
### 业务请求参数
|参数英文名|类型|是否必选|长度/取值|描述|示例值|
|---|---|---|---|---|---|
|enterprise_id|String|必须|32|企业id 可信渠道通过创建企业接口后，获得的企业id|2088100188XXXXXX|
|enterprise_name|String|必须|48|企业名称|测试企业|
|enterprise_code|String|必须|18|统一社会信用代码|918805156111TT11TT|
|access_channel|String|必须|16|企业注册来源渠道 调用方根据实际来源传入对应值 **枚举值**钉钉企业卡:DING_EC_CARD|DING_EC_CARD|
### 请求示例
#### 默认示例
##### java
```
 package com.java.sdk.demo;

import com.alipay.api.AlipayApiException;
import com.alipay.api.AlipayClient;
import com.alipay.api.DefaultAlipayClient;
import com.alipay.api.AlipayConfig;
import com.alipay.api.domain.AlipayCommerceEcEnterpriseReliableauthSyncModel;
import com.alipay.api.response.AlipayCommerceEcEnterpriseReliableauthSyncResponse;
import com.alipay.api.request.AlipayCommerceEcEnterpriseReliableauthSyncRequest;

import com.alipay.api.FileItem;
import java.util.Base64;
import java.util.ArrayList;
import java.util.List;

public class AlipayCommerceEcEnterpriseReliableauthSync {

    public static void main(String[] args) throws AlipayApiException {
        // 初始化SDK
        AlipayClient alipayClient = new DefaultAlipayClient(getAlipayConfig());

        // 构造请求参数以调用接口
        AlipayCommerceEcEnterpriseReliableauthSyncRequest request = new AlipayCommerceEcEnterpriseReliableauthSyncRequest();
        AlipayCommerceEcEnterpriseReliableauthSyncModel model = new AlipayCommerceEcEnterpriseReliableauthSyncModel();
        
        // 设置企业ID
        model.setEnterpriseId("2088100188XXXXXX");
        
        // 设置企业名称	
        model.setEnterpriseName("测试企业");
        
        // 设置统一社会信用代码
        model.setEnterpriseCode("918805156111TT11TT");
        
        // 设置企业来源渠道
        model.setAccessChannel("DING_EC_CARD");
        
        request.setBizModel(model);
        AlipayCommerceEcEnterpriseReliableauthSyncResponse response = alipayClient.execute(request);
        System.out.println(response.getBody());

        if (response.isSuccess()) {
            System.out.println("调用成功");
        } else {
            System.out.println("调用失败");
            // sdk版本是"4.38.0.ALL"及以上,可以参考下面的示例获取诊断链接
            // String diagnosisUrl = DiagnosisUtils.getDiagnosisUrl(response);
            // System.out.println(diagnosisUrl);
        }
    }

    private static AlipayConfig getAlipayConfig() {
        String privateKey  = "<-- 请填写您的应用私钥，例如：MIIEvQIBADANB ... ... -->";
        String alipayPublicKey = "<-- 请填写您的支付宝公钥，例如：MIIBIjANBg... -->";
        AlipayConfig alipayConfig = new AlipayConfig();
        alipayConfig.setServerUrl("https://openapi.alipay.com/gateway.do");
        alipayConfig.setAppId("<-- 请填写您的AppId，例如：2019091767145019 -->");
        alipayConfig.setPrivateKey(privateKey);
        alipayConfig.setFormat("json");
        alipayConfig.setAlipayPublicKey(alipayPublicKey);
        alipayConfig.setCharset("UTF-8");
        alipayConfig.setSignType("RSA2");
        return alipayConfig;
    }
}
```
 

##### php
```
 <?php
require_once '../aop/AopClient.php';
require_once '../aop/AopCertClient.php';
require_once '../aop/AopCertification.php';
require_once '../aop/AlipayConfig.php';
require_once '../aop/request/AlipayCommerceEcEnterpriseReliableauthSyncRequest.php';

// 初始化SDK
$alipayClient = new AopClient(getAlipayConfig());
// 构造请求参数以调用接口
$request = new AlipayCommerceEcEnterpriseReliableauthSyncRequest();
$model = array();

// 设置企业ID
$model['enterprise_id'] = "2088100188XXXXXX";

// 设置企业名称	
$model['enterprise_name'] = "测试企业";

// 设置统一社会信用代码
$model['enterprise_code'] = "918805156111TT11TT";

// 设置企业来源渠道
$model['access_channel'] = "DING_EC_CARD";

$request->setBizContent(json_encode($model,JSON_UNESCAPED_UNICODE));
$responseResult = $alipayClient->execute($request);
$responseApiName = str_replace(".","_",$request->getApiMethodName())."_response";
$response = $responseResult->$responseApiName;
if(!empty($response->code)&&$response->code==10000){
    echo("调用成功");
}
else{
    echo("调用失败");
}

function getAlipayConfig()
{
    $privateKey  = '<-- 请填写您的应用私钥，例如：MIIEvQIBADANB ... ... -->';
    $alipayPublicKey = '<-- 请填写您的支付宝公钥，例如：MIIBIjANBg... -->';
    $alipayConfig = new AlipayConfig();
    $alipayConfig->setServerUrl('https://openapi.alipay.com/gateway.do');
    $alipayConfig->setAppId('<-- 请填写您的AppId，例如：2019091767145019 -->');
    $alipayConfig->setPrivateKey($privateKey);
    $alipayConfig->setFormat('json');
    $alipayConfig->setAlipayPublicKey($alipayPublicKey);
    $alipayConfig->setCharset('UTF-8');
    $alipayConfig->setSignType('RSA2');
    return $alipayConfig;
}
```
 

##### csharp
```
 using System;
using System.Collections.Generic;
using Aop.Api;
using Aop.Api.Request;
using Aop.Api.Response;
using Aop.Api.Domain;
using Aop.Api.Util;
namespace SdkDemoTest
{
    public class AlipayCommerceEcEnterpriseReliableauthSync
    {
        public static void Main(string[] args) 
        {
            // 初始化SDK
            IAopClient alipayClient = new DefaultAopClient(GetAlipayConfig());
            // 构造请求参数以调用接口
            AlipayCommerceEcEnterpriseReliableauthSyncRequest request = new AlipayCommerceEcEnterpriseReliableauthSyncRequest();
            AlipayCommerceEcEnterpriseReliableauthSyncModel model = new AlipayCommerceEcEnterpriseReliableauthSyncModel();
            
            // 设置企业ID
            model.EnterpriseId = "2088100188XXXXXX";
            
            // 设置企业名称	
            model.EnterpriseName = "测试企业";
            
            // 设置统一社会信用代码
            model.EnterpriseCode = "918805156111TT11TT";
            
            // 设置企业来源渠道
            model.AccessChannel = "DING_EC_CARD";
            
            request.SetBizModel(model);
            AlipayCommerceEcEnterpriseReliableauthSyncResponse response = alipayClient.Execute(request);

            if(!response.IsError)
            {
                Console.WriteLine("调用成功");
            }
            else
            {
                Console.WriteLine("调用失败");
            }
        }

        private static AlipayConfig GetAlipayConfig()
        {
            string privateKey  = "<-- 请填写您的应用私钥，例如：MIIEvQIBADANB ... ... -->";
            string alipayPublicKey = "<-- 请填写您的支付宝公钥，例如：MIIBIjANBg... -->";
            AlipayConfig alipayConfig = new AlipayConfig();
            alipayConfig.ServerUrl = "https://openapi.alipay.com/gateway.do";
            alipayConfig.AppId = "<-- 请填写您的AppId，例如：2019091767145019 -->";
            alipayConfig.PrivateKey = privateKey;
            alipayConfig.Format = "json";
            alipayConfig.AlipayPublicKey = alipayPublicKey;
            alipayConfig.Charset = "UTF-8";
            alipayConfig.SignType = "RSA2";
            return alipayConfig;
        }
    }
}
```
 

##### http
```
 curl 'https://openapi.alipay.com/gateway.do?charset=UTF-8&method=alipay.commerce.ec.enterprise.reliableauth.sync&format=json&sign=${sign}&app_id=${appid}&version=1.0&sign_type=RSA2&timestamp=${now}' \
 -F 'biz_content={
	"enterprise_id":"2088100188XXXXXX",
	"enterprise_name":"测试企业",
	"enterprise_code":"918805156111TT11TT",
	"access_channel":"DING_EC_CARD"
}' 
```
 

### 响应示例
#### 正常响应示例
```
 {
	"alipay_commerce_ec_enterprise_reliableauth_sync_response":{
		"code":"10000",
		"msg":"Success"
	},
	"sign":"ERITJKEIJKJHKKKKKKKHJEREEEEEEEEEEE"
}
```
 
#### 异常响应示例
```
 {"alipay_commerce_ec_enterprise_reliableauth_sync_response":{"code":"20000","msg":"Service Currently Unavailable","sub_code":"isp.unknow-error","sub_msg":"系统繁忙"},"sign":"ERITJKEIJKJHKKKKKKKHJEREEEEEEEEEEE"}
```
 
### 业务错误码
|错误码|错误描述|解决方案|
|---|---|---|
|SYSTEM_ERROR|系统繁忙|服务器异常 可能发生了网络或者系统异常，导致服务调用失败，商户可以用同样的请求发起重试|
|INVALID_PARAMETER|参数有误|请根据接口返回的参数非法的具体错误信息，修改参数后进行重试|
|ENTERPRISE_NOT_EXIST|企业不存在|【错误原因】企业不存在。 【排查步骤】请检查企业id是否正确|
|NO_AGREEMENT|产品未签约或合约状态异常|【错误原因】产品未签约或合约状态异常。【排查步骤】接口仅允许认证本渠道创建的企业|
|PERMISSION_DENIED|权限不足|【错误原因】权限不足。【排查步骤】接口仅允许可信渠道调用|