# alipay.commerce.ec.employee.msgstatistic.notify(消息推送统计结果通知)

通知企业日推送消息的统计结果

## 公共请求参数

| 参数 | 类型 | 是否必选 | 最大长度 | 描述 | 示例值 |
| :--- | :--- | :--- | :--- | :--- | :--- |
| notify_id | String | 必选 | 50 | 通知ID | 5608cccc09ddb39d41c2e3c06e3d9fejh2 |
| utc_timestamp | String | 必选 | 13 | 消息发送时的服务端时间 | 1514210452731 |
| msg_method | String | 必选 | 100 | 消息接口名称 | alipay.commerce.ec.employee.msgstatistic.notify |
| app_id | String | 必选 | 20 | 消息接受方的应用id | 2014060600164699 |
| version | String | 必选 | 5 | 版本号(1.1版本为标准消息) | 1.0或者1.1 |
| biz_content | String | 必选 | | 消息报文 | 参见消息属性 |
| sign | String | 必选 | | 签名 | WcO+t3D8Kg71dTlKwN7r9PzUOXeaBJwp8/FOuSxcuSkXsoVYxBpsAidprySCjHCjmaglNcjoKJQLJ28/Asl93joTW39FX6i07lXhnbPknezAlwmvPdnQuI01HZsZF9V1i6ggZjBiAd5lG8bZtTxZOJ87ub2i9GuJ3Nr/NUc9VeY= |
| sign_type | String | 必选 | 10 | 签名类型 | RSA2 |
| charset | String | 必选 | 10 | 编码集，该字符集为验签和解密所需要的字符集 | UTF-8 |

## 消息属性

| 参数英文名 | 类型 | 是否必选 | 长度/取值 | 描述 | 示例值 |
|---|---|---|---|---|---|
| enterprise_id | String | 必选 | 16 | 企业在企业码域内的ID | 20880010xxxxxxxx |
| task_id | String | 必选 | 28 | 企业提交消息推送任务后生成的任务id | 2024082800801805150000066778 |
| biz_scene | String | 必选 | 32 | 消息推送的业务场景<br>**枚举值**：<br>邀请员工签约: INVITE_EMP_SIGN<br>员工签约成功: EMP_SIGN_SUCCESS | INVITE_EMP_SIGN |
| start_time | String | 必选 | 20 | 消息推送的开始时间 | 2024-08-28 15:00:00 |
| success_count | String | 必选 | 10 | 员工消息推送成功的总数 | 100 |
| fail_count | String | 必选 | 10 | 员工消息推送失败的总数 | 100 |
| fail_list | String[] | 条件必选 | 1024 | 推送失败的员工id列表，列表元素是员工在企业码域内的id<br>**必选条件**：当fail_count>0时，fail_list必传 | ['22881234xxxxxxxx'] |

### 消息示例

```bash
curl -X POST 'NOTIFY_URL' \
--header 'Content-Type: application/x-www-form-urlencoded; charset=UTF-8' \
--data-urlencode 'charset=UTF-8' \
--data-urlencode 'biz_content={
	"enterprise_id":"20880010xxxxxxxx",
	"task_id":"2024082800801805150000066778",
	"biz_scene":"INVITE_EMP_SIGN",
	"start_time":"2024-08-28 15:00:00",
	"success_count":"100",
	"fail_count":"100",
	"fail_list":[
		"22881234xxxxxxxx"
	]
}' \
--data-urlencode 'utc_timestamp=${now}' \
--data-urlencode 'sign=${sign}' \
--data-urlencode 'app_id=${appid}' \
--data-urlencode 'version=1.1' \
--data-urlencode 'sign_type=RSA2' \
--data-urlencode 'notify_id=${notify_id}' \
--data-urlencode 'msg_method=alipay.commerce.ec.employee.msgstatistic.notify'
```

**说明：** NOTIFY_URL是开发者在开放平台控制台上设置的应用网关地址

## 通知应答

| 响应报文 | 描述 | 是否重试 | 是否区分大小写 |
| :--- | :--- | :--- | :--- |
| success | 消息处理成功 | 否 | 否 |
| fail | 消息处理失败 | 是 | 否 |

说明：消息服务会根据响应报文判断商户系统是否已经成功处理消息。如果HTTP同步响应报文返回 success 字符串，消息服务则认为消息已经处理成功，停止投递，如果返回 fail ，表示消息获取失败，支付宝会根据投递重试策略重新发送消息到应用网关地址；

投递重试策略：一般情况下，25 小时以内完成 8 次通知，除了第一次是实时投递外，后续的每次重试都会间隔一段时间，间隔频率一般是：2m、10m、10m、1h、2h、6h、15h（第二次消息投递是在第一次投递失败后的 2 分钟；第三次投递是在第二次投递失败后的 10 分钟，以此类推）
