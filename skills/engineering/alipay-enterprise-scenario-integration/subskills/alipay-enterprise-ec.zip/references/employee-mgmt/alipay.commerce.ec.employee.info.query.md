# alipay.commerce.ec.employee.info.query(查询员工详情)
支持第三方代理调用：本接口支持第三方开发者代用户发起调用
## 通用场景
根据员工id或员工uid查询企业下某个员工的详细信息
### 公共请求参数
|参数英文名|类型|是否必选|长度/取值|描述|示例值|
|---|---|---|---|---|---|
|app_id|String|必选|32|支付宝分配给开发者的应用ID|2014072300007148|
|method|String|必选|128|接口名称|alipay.commerce.ec.employee.info.query|
|format|String|可选|40|仅支持JSON|JSON|
|charset|String|必选|10|请求使用的编码格式，如utf-8,gbk,gb2312等|utf-8|
|sign_type|String|必选|10|商户生成签名字符串所使用的签名算法类型，目前支持RSA2和RSA，推荐使用RSA2|RSA2|
|sign|String|必选|344|商户请求参数的签名串，详见[签名](https://opendocs.alipay.com/common/02khjm)|详见示例|
|timestamp|String|必选|19|发送请求的时间，格式"yyyy-MM-dd HH:mm:ss"|2014-07-24 03:07:50|
|version|String|必选|3|调用的接口版本，固定为：1.0|1.0|
|app_auth_token|String|可选|40|详见[应用授权概述](https://opendocs.alipay.com/isv/10467/xldcyq)||
|biz_content|String|必选||请求参数的集合，最大长度不限，除公共参数外所有请求参数都必须放在这个参数中传递，具体参照各产品快速接入文档||
### 业务请求参数
|参数英文名|类型|是否必选|长度/取值|描述|示例值|
|---|---|---|---|---|---|
|enterprise_id|String|必须|32|企业id|2088441363102941|
|user_id|String|特殊可选|16|支付宝用户ID新商户建议使用open_id替代该字段。对于新商户，user_id字段未来计划逐步回收，存量商户可继续使用。如使用open_id，请确认 应用-开发配置-openid配置管理 已启用。无该配置项，可查看[openid配置申请](https://opendocs.alipay.com/mini/0ai9ok?pathHash=de631c06)。**注意事项**员工id（employee_id）、支付宝user_id（open_id）、支付宝登录号（alipay_logon_id）、员工证件号码和证件类型（employee_cert_no、employee_cert_type）、员工手机号（mobile）、员工邮箱（employee_email）至少传入一个。 当传入多个时，优先级为：员工id>支付宝user_id>支付宝登录号>员工证件号码和证件类型>员工手机号>员工邮箱。其中员工证件号码和证件类型需同时传入|2088501304519332|
|open_id|String|特殊可选|128|蚂蚁统一会员ID&nbsp; 详情可查看[ openid简介](https://opendocs.alipay.com/mini/0ai2i6?pathHash=13dd5946)**注意事项**员工employee_id、支付宝user_id（open_id）、员工手机号mobile至少传入一个，同时传入则优先使用员工employee_id|074a1CcTG1LelxKe4xQC0zgNdId0nxi95b5lsNpazWYoCo5|
|employee_id|String|特殊可选|16|员工id**注意事项**员工id（employee_id）、支付宝user_id（open_id）、支付宝登录号（alipay_logon_id）、员工证件号码和证件类型（employee_cert_no、employee_cert_type）员工手机号（mobile）、员工邮箱（employee_email）至少传入一个。 当传入多个时，优先级为：员工id>支付宝user_id>支付宝登录号>员工证件号码和证件类型>员工手机号>员工邮箱。其中员工证件号码和证件类型需同时传入|2284200000000000|
|mobile|String|特殊可选|11|员工手机号码**注意事项**员工id（employee_id）、支付宝user_id（open_id）、支付宝登录号（alipay_logon_id）、员工证件号码和证件类型（employee_cert_no、employee_cert_type）员工手机号（mobile）、员工邮箱（employee_email）至少传入一个。 当传入多个时，优先级为：员工id>支付宝user_id>支付宝登录号>员工证件号码和证件类型>员工手机号>员工邮箱。其中员工证件号码和证件类型需同时传入|134XXXX2526|
|alipay_logon_id|String|特殊可选|64|支付宝登录号（手机号或邮箱）**注意事项**员工id（employee_id）、支付宝user_id（open_id）、支付宝登录号（alipay_logon_id）、员工证件号码和证件类型（employee_cert_no、employee_cert_type）员工手机号（mobile）、员工邮箱（employee_email）至少传入一个。 当传入多个时，优先级为：员工id>支付宝user_id>支付宝登录号>员工证件号码和证件类型>员工手机号>员工邮箱。其中员工证件号码和证件类型需同时传入|134xxxx2526|
|employee_cert_type|String|特殊可选|32|员工证件类型**注意事项**员工id（employee_id）、支付宝user_id（open_id）、支付宝登录号（alipay_logon_id）、员工证件号码和证件类型（employee_cert_no、employee_cert_type）员工手机号（mobile）、员工邮箱（employee_email）至少传入一个。 当传入多个时，优先级为：员工id>支付宝user_id>支付宝登录号>员工证件号码和证件类型>员工手机号>员工邮箱。其中员工证件号码和证件类型需同时传入|IDENTITY_CARD|
|employee_cert_no|String|特殊可选|32|员工证件号码**注意事项**员工id（employee_id）、支付宝user_id（open_id）、支付宝登录号（alipay_logon_id）、员工证件号码和证件类型（employee_cert_no、employee_cert_type）员工手机号（mobile）、员工邮箱（employee_email）至少传入一个。 当传入多个时，优先级为：员工id>支付宝user_id>支付宝登录号>员工证件号码和证件类型>员工手机号>员工邮箱。其中员工证件号码和证件类型需同时传入|220000000000000000|
|employee_email|String|特殊可选|32|员工邮箱**注意事项**员工id（employee_id）、支付宝user_id（open_id）、支付宝登录号（alipay_logon_id）、员工证件号码和证件类型（employee_cert_no、employee_cert_type）员工手机号（mobile）、员工邮箱（employee_email）至少传入一个。 当传入多个时，优先级为：员工id>支付宝user_id>支付宝登录号>员工证件号码和证件类型>员工手机号>员工邮箱。其中员工证件号码和证件类型需同时传入|123@xxx.com|
### 请求示例
#### 默认示例
##### java
```
 package com.java.sdk.demo;

import com.alipay.api.AlipayApiException;
import com.alipay.api.AlipayClient;
import com.alipay.api.DefaultAlipayClient;
import com.alipay.api.AlipayConfig;
import com.alipay.api.domain.AlipayCommerceEcEmployeeInfoQueryModel;
import com.alipay.api.response.AlipayCommerceEcEmployeeInfoQueryResponse;
import com.alipay.api.request.AlipayCommerceEcEmployeeInfoQueryRequest;

import com.alipay.api.FileItem;
import java.util.Base64;
import java.util.ArrayList;
import java.util.List;

public class AlipayCommerceEcEmployeeInfoQuery {

    public static void main(String[] args) throws AlipayApiException {
        // 初始化SDK
        AlipayClient alipayClient = new DefaultAlipayClient(getAlipayConfig());

        // 构造请求参数以调用接口
        AlipayCommerceEcEmployeeInfoQueryRequest request = new AlipayCommerceEcEmployeeInfoQueryRequest();
        AlipayCommerceEcEmployeeInfoQueryModel model = new AlipayCommerceEcEmployeeInfoQueryModel();
        
        // 设置企业id
        model.setEnterpriseId("2088441363102941");
        
        // 设置用户id对应的开放id
        model.setOpenId("074a1CcTG1LelxKe4xQC0zgNdId0nxi95b5lsNpazWYoCo5");
        
        // uid参数未来计划废弃，存量商户可继续使用，新商户请使用openid。请根据应用-开发配置-openid配置选择支持的字段。
        // model.setUserId("2088501304519332");
        
        // 设置员工id
        model.setEmployeeId("2284200000000000");
        
        // 设置员工手机号码
        model.setMobile("134XXXX2526");
        
        // 设置支付宝登录号
        model.setAlipayLogonId("134xxxx2526");
        
        // 设置员工证件类型
        model.setEmployeeCertType("IDENTITY_CARD");
        
        // 设置员工证件号码
        model.setEmployeeCertNo("220000000000000000");
        
        // 设置员工邮箱
        model.setEmployeeEmail("123@xxx.com");
        
        request.setBizModel(model);
        // 第三方代调用模式下请设置app_auth_token
        // request.putOtherTextParam("app_auth_token", "<-- 请填写应用授权令牌 -->");

        AlipayCommerceEcEmployeeInfoQueryResponse response = alipayClient.execute(request);
        System.out.println(response.getBody());

        if (response.isSuccess()) {
            System.out.println("调用成功");
        } else {
            System.out.println("调用失败");
            // sdk版本是"4.38.0.ALL"及以上,可以参考下面的示例获取诊断链接
            // String diagnosisUrl = DiagnosisUtils.getDiagnosisUrl(response);
            // System.out.println(diagnosisUrl);
        }
    }

    private static AlipayConfig getAlipayConfig() {
        String privateKey  = "<-- 请填写您的应用私钥，例如：MIIEvQIBADANB ... ... -->";
        String alipayPublicKey = "<-- 请填写您的支付宝公钥，例如：MIIBIjANBg... -->";
        AlipayConfig alipayConfig = new AlipayConfig();
        alipayConfig.setServerUrl("https://openapi.alipay.com/gateway.do");
        alipayConfig.setAppId("<-- 请填写您的AppId，例如：2019091767145019 -->");
        alipayConfig.setPrivateKey(privateKey);
        alipayConfig.setFormat("json");
        alipayConfig.setAlipayPublicKey(alipayPublicKey);
        alipayConfig.setCharset("UTF-8");
        alipayConfig.setSignType("RSA2");
        return alipayConfig;
    }
}
```
 

##### php
```
 <?php
require_once '../aop/AopClient.php';
require_once '../aop/AopCertClient.php';
require_once '../aop/AopCertification.php';
require_once '../aop/AlipayConfig.php';
require_once '../aop/request/AlipayCommerceEcEmployeeInfoQueryRequest.php';

// 初始化SDK
$alipayClient = new AopClient(getAlipayConfig());
// 构造请求参数以调用接口
$request = new AlipayCommerceEcEmployeeInfoQueryRequest();
$model = array();

// 设置企业id
$model['enterprise_id'] = "2088441363102941";

// 设置用户id对应的开放id
$model['open_id'] = "074a1CcTG1LelxKe4xQC0zgNdId0nxi95b5lsNpazWYoCo5";

// uid参数未来计划废弃，存量商户可继续使用，新商户请使用openid。请根据应用-开发配置-openid配置选择支持的字段。
// $model['user_id'] = "2088501304519332";

// 设置员工id
$model['employee_id'] = "2284200000000000";

// 设置员工手机号码
$model['mobile'] = "134XXXX2526";

// 设置支付宝登录号
$model['alipay_logon_id'] = "134xxxx2526";

// 设置员工证件类型
$model['employee_cert_type'] = "IDENTITY_CARD";

// 设置员工证件号码
$model['employee_cert_no'] = "220000000000000000";

// 设置员工邮箱
$model['employee_email'] = "123@xxx.com";

$request->setBizContent(json_encode($model,JSON_UNESCAPED_UNICODE));
// 如果是第三方代调用模式，请设置app_auth_token（应用授权令牌）
$responseResult = $alipayClient->execute($request, null, "<-- 请填写应用授权令牌 -->", null);
$responseApiName = str_replace(".","_",$request->getApiMethodName())."_response";
$response = $responseResult->$responseApiName;
if(!empty($response->code)&&$response->code==10000){
    echo("调用成功");
}
else{
    echo("调用失败");
}

function getAlipayConfig()
{
    $privateKey  = '<-- 请填写您的应用私钥，例如：MIIEvQIBADANB ... ... -->';
    $alipayPublicKey = '<-- 请填写您的支付宝公钥，例如：MIIBIjANBg... -->';
    $alipayConfig = new AlipayConfig();
    $alipayConfig->setServerUrl('https://openapi.alipay.com/gateway.do');
    $alipayConfig->setAppId('<-- 请填写您的AppId，例如：2019091767145019 -->');
    $alipayConfig->setPrivateKey($privateKey);
    $alipayConfig->setFormat('json');
    $alipayConfig->setAlipayPublicKey($alipayPublicKey);
    $alipayConfig->setCharset('UTF-8');
    $alipayConfig->setSignType('RSA2');
    return $alipayConfig;
}
```
 

##### csharp
```
 using System;
using System.Collections.Generic;
using Aop.Api;
using Aop.Api.Request;
using Aop.Api.Response;
using Aop.Api.Domain;
using Aop.Api.Util;
namespace SdkDemoTest
{
    public class AlipayCommerceEcEmployeeInfoQuery
    {
        public static void Main(string[] args) 
        {
            // 初始化SDK
            IAopClient alipayClient = new DefaultAopClient(GetAlipayConfig());
            // 构造请求参数以调用接口
            AlipayCommerceEcEmployeeInfoQueryRequest request = new AlipayCommerceEcEmployeeInfoQueryRequest();
            AlipayCommerceEcEmployeeInfoQueryModel model = new AlipayCommerceEcEmployeeInfoQueryModel();
            
            // 设置企业id
            model.EnterpriseId = "2088441363102941";
            
            // 设置用户id对应的开放id
            model.OpenId = "074a1CcTG1LelxKe4xQC0zgNdId0nxi95b5lsNpazWYoCo5";
            
            // uid参数未来计划废弃，存量商户可继续使用，新商户请使用openid。请根据应用-开发配置-openid配置选择支持的字段。
            // model.UserId = "2088501304519332";
            
            // 设置员工id
            model.EmployeeId = "2284200000000000";
            
            // 设置员工手机号码
            model.Mobile = "134XXXX2526";
            
            // 设置支付宝登录号
            model.AlipayLogonId = "134xxxx2526";
            
            // 设置员工证件类型
            model.EmployeeCertType = "IDENTITY_CARD";
            
            // 设置员工证件号码
            model.EmployeeCertNo = "220000000000000000";
            
            // 设置员工邮箱
            model.EmployeeEmail = "123@xxx.com";
            
            request.SetBizModel(model);
            // 第三方代调用模式下请设置app_auth_token
            // request.PutOtherTextParam("app_auth_token", "<-- 请填写应用授权令牌 -->");

            AlipayCommerceEcEmployeeInfoQueryResponse response = alipayClient.Execute(request);

            if(!response.IsError)
            {
                Console.WriteLine("调用成功");
            }
            else
            {
                Console.WriteLine("调用失败");
            }
        }

        private static AlipayConfig GetAlipayConfig()
        {
            string privateKey  = "<-- 请填写您的应用私钥，例如：MIIEvQIBADANB ... ... -->";
            string alipayPublicKey = "<-- 请填写您的支付宝公钥，例如：MIIBIjANBg... -->";
            AlipayConfig alipayConfig = new AlipayConfig();
            alipayConfig.ServerUrl = "https://openapi.alipay.com/gateway.do";
            alipayConfig.AppId = "<-- 请填写您的AppId，例如：2019091767145019 -->";
            alipayConfig.PrivateKey = privateKey;
            alipayConfig.Format = "json";
            alipayConfig.AlipayPublicKey = alipayPublicKey;
            alipayConfig.Charset = "UTF-8";
            alipayConfig.SignType = "RSA2";
            return alipayConfig;
        }
    }
}
```
 

##### http
```
 curl 'https://openapi.alipay.com/gateway.do?charset=UTF-8&method=alipay.commerce.ec.employee.info.query&format=json&sign=${sign}&app_id=${appid}&version=1.0&sign_type=RSA2&timestamp=${now}' \
 -F 'app_auth_token=${app_auth_token}' \
 -F 'biz_content={
	"enterprise_id":"2088441363102941",
	"open_id":"074a1CcTG1LelxKe4xQC0zgNdId0nxi95b5lsNpazWYoCo5",
	"user_id":"2088501304519332",
	"employee_id":"2284200000000000",
	"mobile":"134XXXX2526",
	"alipay_logon_id":"134xxxx2526",
	"employee_cert_type":"IDENTITY_CARD",
	"employee_cert_no":"220000000000000000",
	"employee_email":"123@xxx.com"
}' 
```
 

### 业务响应参数
|参数英文名|类型|是否必选|长度/取值|描述|示例值|
|---|---|---|---|---|---|
|employee_info|EmployeeInfoDTO|必须|null|员工信息||
|employee_info.employee_id|String|必须|32|员工id|228420000000057942506|
|employee_info.employee_name|String|必须|80|员工姓名|张三|
|employee_info.employee_no|String|可选|64|员工编号/工号|200818255|
|employee_info.mobile|String|可选|11|手机号码**注意事项**证件号，手机号，邮箱三个必填其一|13456782345|
|employee_info.encrypt_mobile|String|可选|128|加密手机号（使用SHA256进行加密）**注意事项**当加密类型不为空时必填，不与手机号同时存在|f20a8027c95b5b3225c93e81e39ff0f496fd2868de11dbcc49d9584be80463a6|
|employee_info.email|String|可选|64|员工邮箱**注意事项**证件号，手机号，邮箱三个必填其一|123456@qq.com|
|employee_info.employee_cert_no|String|可选|32|证件号**注意事项**证件号，手机号，邮箱三个必填其一|12345|
|employee_info.encrypt_cert_no|String|可选|128|加密证件号（证件号转大写后使用SHA256加密），搭配证件号使用**注意事项**当加密类型不为空时必填，与非加密证件号不同时存在|0fc57efb28cfb5125d32e6d84823d49032d46d10df08f0e599d3844ecd3e0a1f|
|employee_info.employee_cert_type|String|可选|16|证件类型**枚举值**身份证:IDENTITY_CARD护照:PASS_PORT学生学号:STU_NUM工号:COMPANY_NUM台胞证:TAIWAN_CARD港澳证件:HK_MC_CARD**注意事项**当证件号不为空时必填|IDENTITY_CARD|
|employee_info.user_id|String|可选|32|用户ID（绑定支付宝账号的uid）新商户建议使用open_id替代该字段。对于新商户，user_id字段未来计划逐步回收，存量商户可继续使用。如使用open_id，请确认 应用-开发配置-openid配置管理 已启用。无该配置项，可查看[openid配置申请](https://opendocs.alipay.com/mini/0ai9ok?pathHash=de631c06)。|2088123454654356|
|employee_info.open_id|String|可选|128|用户ID（绑定支付宝账号的uid）&nbsp; 详情可查看[ openid简介](https://opendocs.alipay.com/mini/0ai2i6?pathHash=13dd5946)|074a1CcTG1LelxKe4xQC0zgNdId0nxi95b5lsNpazWYoCo5|
|employee_info.role_list|String|必须|1024|角色列表**枚举值**普通员工:USER管理员:ADMIN超级管理员:SUPER_ADMIN代运营:AGENCY_OPERATION自定义角色:CUSTOM|["ADMIN"]|
|employee_info.activate|String|必须|16|是否激活**枚举值**已激活:ACTIVATED未激活:UNACTIVATED激活中:ACTIVATING|ACTIVATED|
|employee_info.department_list|EmployeeDepartmentDTO|必须|null|员工所属部门列表||
|employee_info.department_list.department_id|String|必须|32|部门id|1001094000039142|
|employee_info.department_list.department_name|String|必须|80|部门名称|产品部|
|employee_info.gmt_create|String|必须|32|创建时间**注意事项**日期格式：EEE MMM dd HH:mm:ss Z yyyy  解析示例：new SimpleDateFormat("EEE MMM dd HH:mm:ss Z yyyy", Locale.ENGLISH).parse("Sat Oct 19 11:47:12 CST 2024");|Sat Oct 19 11:47:12 CST 2024|
|employee_info.gmt_modified|String|必须|32|变更时间**注意事项**日期格式：EEE MMM dd HH:mm:ss Z yyyy  解析示例：new SimpleDateFormat("EEE MMM dd HH:mm:ss Z yyyy", Locale.ENGLISH).parse("Sat Oct 19 11:47:12 CST 2024");|Sat Oct 19 11:47:12 CST 2024|
|employee_info.iot_face_status|String|可选|16|员工是否人脸在库**枚举值**在库:1不在库:2|1|
|employee_info.iot_vid|String|可选|32|员工在企业人脸库的人脸唯一标识|2109b5e671aa3ff2eb4851816c65828f|
|employee_info.iot_unique_id|String|可选|64|IOT开通刷脸支持唯一操作流水号，此处透出用于外部服务商通过该unique_id便捷调用IOT侧接口|3444950005320032|
|employee_info.invoice_email|String|必须|128|员工收票邮箱|example@163.com|
|employee_info.job_level_show|String|可选|16|员工职级|S2|
|employee_info.tl_employee_id|String|可选|32|直属主管员工ID|228420000000057942506|
|employee_info.label_names|String|可选|15|员工标签|["差旅员工"]|
|employee_info.accounting_entity_list|EmployeeAccountingEntityDTO|可选|null|员工所属核算主体列表||
|employee_info.accounting_entity_list.accounting_entity_id|String|必须|16|核算主体id|1007000000000000|
|employee_info.accounting_entity_list.accounting_entity_name|String|必须|15|核算主体名称|核算主体|
|employee_info.accounting_entity_list.accounting_entity_code|String|必须|40|核算主体编码|00001|
|employee_info.profiles|String|可选|500|个性化信息 详见文档|{"consume_remark":"员工账单备注内容示例", "inst_id":"CMBC", "card_type":"CC", "check_bind_card":"Y"}|
### 公共响应参数
|参数英文名|类型|是否必选|长度/取值|描述|示例值|
|---|---|---|---|---|---|
|code|String|必须|~|网关返回码，[详见文档](https://docs.open.alipay.com/common/105806)|40004|
|msg|String|必须|~|网关返回码描述，[详见文档](https://docs.open.alipay.com/common/105806)|Business Failed|
|sub_code|String|可选|~|业务返回码，参见具体的API接口文档||
|sub_msg|String|可选|~|业务返回码描述，参见具体的API接口文档||
|sign|String|必须|64|签名，[详见文档](https://docs.open.alipay.com/291/106074)|DZXh8eeTuAHoYE3w1J+POiPhfDxOYBfUNn1lkeT/V7P4zJdyojWEa6IZs6Hz0yDW5Cp/viufUb5I0/V5WENS3OYR8zRedqo6D+fUTdLHdc+EFyCkiQhBxIzgngPdPdfp1PIS7BdhhzrsZHbRqb7o4k3Dxc+AAnFauu4V6Zdwczo=|
### 响应示例
#### 正常响应示例
```
 {
	"alipay_commerce_ec_employee_info_query_response":{
		"code":"10000",
		"msg":"Success",
		"employee_info":{
			"employee_id":"228420000000057942506",
			"employee_name":"张三",
			"employee_no":"200818255",
			"mobile":"13456782345",
			"encrypt_mobile":"f20a8027c95b5b3225c93e81e39ff0f496fd2868de11dbcc49d9584be80463a6",
			"email":"123456@qq.com",
			"employee_cert_no":"12345",
			"encrypt_cert_no":"0fc57efb28cfb5125d32e6d84823d49032d46d10df08f0e599d3844ecd3e0a1f",
			"employee_cert_type":"IDENTITY_CARD",
			"user_id":"2088123454654356",
			"open_id":"074a1CcTG1LelxKe4xQC0zgNdId0nxi95b5lsNpazWYoCo5",
			"role_list":[
				"ADMIN"
			],
			"activate":"ACTIVATED",
			"department_list":[
				{
					"department_id":"1001094000039142",
					"department_name":"产品部"
				}
			],
			"gmt_create":"Sat Oct 19 11:47:12 CST 2024",
			"gmt_modified":"Sat Oct 19 11:47:12 CST 2024",
			"iot_face_status":"1",
			"iot_vid":"2109b5e671aa3ff2eb4851816c65828f",
			"iot_unique_id":"3444950005320032",
			"invoice_email":"example@163.com",
			"job_level_show":"S2",
			"tl_employee_id":"228420000000057942506",
			"label_names":[
				"差旅员工"
			],
			"accounting_entity_list":[
				{
					"accounting_entity_id":"1007000000000000",
					"accounting_entity_name":"核算主体",
					"accounting_entity_code":"00001"
				}
			],
			"profiles":"{\"consume_remark\":\"员工账单备注内容示例\", \"inst_id\":\"CMBC\", \"card_type\":\"CC\", \"check_bind_card\":\"Y\"}"
		}
	},
	"sign":"ERITJKEIJKJHKKKKKKKHJEREEEEEEEEEEE"
}
```
 
#### 异常响应示例
```
 {"alipay_commerce_ec_employee_info_query_response":{"code":"20000","msg":"Service Currently Unavailable","sub_code":"isp.unknow-error","sub_msg":"系统繁忙"},"sign":"ERITJKEIJKJHKKKKKKKHJEREEEEEEEEEEE"}
```
 
### 业务错误码
|错误码|错误描述|解决方案|
|---|---|---|
|SYSTEM_ERROR|系统繁忙|服务器异常 可能发生了网络或者系统异常，导致服务调用失败，商户可以用同样的请求发起重试|
|INVALID_PARAMETER|参数有误|请根据接口返回的参数非法的具体错误信息，修改参数后进行重试|
|EMPLOYEE_NOT_EXIST|员工不存在|【错误原因】员工不存在。 【排查步骤】请检查员工id是否正确。|
|ENTERPRISE_NOT_EXIST|企业不存在|【错误原因】企业不存在。 【排查步骤】请检查企业id是否正确。|
|NO_AGREEMENT|产品未签约或合约状态异常|【错误原因】产品未签约或合约状态异常。 【排查步骤】请检查入参或企业是否已解约。|
|ORG_USER_NOT_EXIST|企业人脸库信息不存在|【错误原因】员工人脸库信息查询不存在【排查步骤】请检查员工id是否正确。|
|USER_NOT_EXIST|用户不存在|【错误原因】未找到支付宝账号【排查步骤】请检查支付宝登录号是否正确|