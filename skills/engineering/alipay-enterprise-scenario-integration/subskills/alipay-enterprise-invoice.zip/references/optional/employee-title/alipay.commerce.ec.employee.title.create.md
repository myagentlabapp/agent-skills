# alipay.commerce.ec.employee.title.create(员工抬头：新增员工抬头关系)
支持第三方代理调用：本接口支持第三方开发者代用户发起调用
## 通用场景
批量新增员工抬头关系，单次新增最大一千条
注意：此接口待升级，当前仅适用于特定企业，新接客户请勿使用
### 公共请求参数
|参数英文名|类型|是否必选|长度/取值|描述|示例值|
|---|---|---|---|---|---|
|app_id|String|必选|32|支付宝分配给开发者的应用ID|2014072300007148|
|method|String|必选|128|接口名称|alipay.commerce.ec.employee.title.create|
|format|String|可选|40|仅支持JSON|JSON|
|charset|String|必选|10|请求使用的编码格式，如utf-8,gbk,gb2312等|utf-8|
|sign_type|String|必选|10|商户生成签名字符串所使用的签名算法类型，目前支持RSA2和RSA，推荐使用RSA2|RSA2|
|sign|String|必选|344|商户请求参数的签名串，详见[签名](https://opendocs.alipay.com/common/02khjm)|详见示例|
|timestamp|String|必选|19|发送请求的时间，格式"yyyy-MM-dd HH:mm:ss"|2014-07-24 03:07:50|
|version|String|必选|3|调用的接口版本，固定为：1.0|1.0|
|app_auth_token|String|可选|40|详见[应用授权概述](https://opendocs.alipay.com/isv/10467/xldcyq)||
|biz_content|String|必选||请求参数的集合，最大长度不限，除公共参数外所有请求参数都必须放在这个参数中传递，具体参照各产品快速接入文档||
### 业务请求参数

> **N选一说明**：employee_title_list.user_id、employee_title_list.open_id，N选一必须传入其中一个

|参数英文名|类型|是否必选|长度/取值|描述|示例值|
|---|---|---|---|---|---|
|employee_title_list|EmployeeTitleDTO|可选||员工与抬头关系列表||
|employee_title_list.user_id|String|特殊可选|32|员工支付宝账号2088,与employee_id两者必填其一新商户建议使用open_id替代该字段。对于新商户，user_id字段未来计划逐步回收，存量商户可继续使用。如使用open_id，请确认 应用-开发配置-openid配置管理 已启用。无该配置项，可查看[openid配置申请](https://opendocs.alipay.com/mini/0ai9ok?pathHash=de631c06)。|2088502255168118|
|employee_title_list.open_id|String|特殊可选|128|员工支付宝账号open_id,与employee_id两者必填其一&nbsp; 详情可查看[ openid简介](https://opendocs.alipay.com/mini/0ai2i6?pathHash=13dd5946)|074a1CcTG1LelxKe4xQC0zgNdId0nxi95b5lsNpazWYoCo5|
|employee_title_list.employee_id|String|特殊可选|32|企业域定义的员工id，与user_id两者必填其一|228800000000002000002|
|employee_title_list.title_id|String|特殊可选|30|抬头id<br><br>**必选条件**<br>当tax_register_no为空时，title_id为必选参数|2022060900801711450000073478|
|employee_title_list.tax_register_no|String|特殊可选|25|税号<br><br>**必选条件**<br>当title_id为空的时候，tax_register_no为必选参数|9133*********5852F|
|employee_title_list.account_id|String|特殊可选|32|共同账户id,与enterprise_id两者必填其一|2088000397722031|
|employee_title_list.enterprise_id|String|特殊可选|32|企业域定义的企业id，与account_id两者必填其一|2088000230921202|
|employee_title_list.title_tag|String|可选|16|关系标记<br>**枚举值**<br>默认抬头:DEFAULT<br>多抬头:MULTI<br>签约主体（已废弃，请使用DEFAULT）:ou|ou|
|employee_title_list.create_by|String|可选|32|创建人|昭运|
|employee_title_list.modify_by|String|可选|32|修改人|昭运|
### 请求示例
#### 默认示例
##### java
```
 package com.java.sdk.demo;

import com.alipay.api.AlipayApiException;
import com.alipay.api.AlipayClient;
import com.alipay.api.DefaultAlipayClient;
import com.alipay.api.AlipayConfig;
import com.alipay.api.request.AlipayCommerceEcEmployeeTitleCreateRequest;
import com.alipay.api.domain.AlipayCommerceEcEmployeeTitleCreateModel;
import com.alipay.api.domain.EmployeeTitleDTO;
import com.alipay.api.response.AlipayCommerceEcEmployeeTitleCreateResponse;

import com.alipay.api.FileItem;
import java.util.Base64;
import java.util.ArrayList;
import java.util.List;

public class AlipayCommerceEcEmployeeTitleCreate {

    public static void main(String[] args) throws AlipayApiException {
        // 初始化SDK
        AlipayClient alipayClient = new DefaultAlipayClient(getAlipayConfig());

        // 构造请求参数以调用接口
        AlipayCommerceEcEmployeeTitleCreateRequest request = new AlipayCommerceEcEmployeeTitleCreateRequest();
        AlipayCommerceEcEmployeeTitleCreateModel model = new AlipayCommerceEcEmployeeTitleCreateModel();

        // 设置员工与抬头关系列表
        List<EmployeeTitleDTO> employeeTitleList = new ArrayList<EmployeeTitleDTO>();
        EmployeeTitleDTO employeeTitleList0 = new EmployeeTitleDTO();
        employeeTitleList0.setCreateBy("昭运");
        employeeTitleList0.setAccountId("2088000397722031");
        // uid参数未来计划废弃，存量商户可继续使用，新商户请使用openid。请根据应用-开发配置-openid配置选择支持的字段。
        // employeeTitleList0.setUserId("2088502255168118");
        employeeTitleList0.setOpenId("074a1CcTG1LelxKe4xQC0zgNdId0nxi95b5lsNpazWYoCo5");
        employeeTitleList0.setEmployeeId("228800000000002000002");
        employeeTitleList0.setTitleId("2022060900801711450000073478");
        employeeTitleList0.setTitleTag("ou");
        employeeTitleList0.setModifyBy("昭运");
        employeeTitleList0.setTaxRegisterNo("9133*********5852F");
        employeeTitleList0.setEnterpriseId("2088000230921202");
        employeeTitleList.add(employeeTitleList0);
        model.setEmployeeTitleList(employeeTitleList);

        request.setBizModel(model);
        // 第三方代调用模式下请设置app_auth_token
        // request.putOtherTextParam("app_auth_token", "<-- 请填写应用授权令牌 -->");

        AlipayCommerceEcEmployeeTitleCreateResponse response = alipayClient.execute(request);
        System.out.println(response.getBody());

        if (response.isSuccess()) {
            System.out.println("调用成功");
        } else {
            System.out.println("调用失败");
            // sdk版本是"4.38.0.ALL"及以上,可以参考下面的示例获取诊断链接
            // String diagnosisUrl = DiagnosisUtils.getDiagnosisUrl(response);
            // System.out.println(diagnosisUrl);
        }
    }

    private static AlipayConfig getAlipayConfig() {
        String privateKey  = "<-- 请填写您的应用私钥，例如：MIIEvQIBADANB ... ... -->";
        String alipayPublicKey = "<-- 请填写您的支付宝公钥，例如：MIIBIjANBg... -->";
        AlipayConfig alipayConfig = new AlipayConfig();
        alipayConfig.setServerUrl("https://openapi.alipay.com/gateway.do");
        alipayConfig.setAppId("<-- 请填写您的AppId，例如：2019091767145019 -->");
        alipayConfig.setPrivateKey(privateKey);
        alipayConfig.setFormat("json");
        alipayConfig.setAlipayPublicKey(alipayPublicKey);
        alipayConfig.setCharset("UTF-8");
        alipayConfig.setSignType("RSA2");
        return alipayConfig;
    }
}
```


##### php
```
 <?php
require_once '../aop/AopClient.php';
require_once '../aop/AopCertClient.php';
require_once '../aop/AopCertification.php';
require_once '../aop/AlipayConfig.php';
require_once '../aop/request/AlipayCommerceEcEmployeeTitleCreateRequest.php';

// 初始化SDK
$alipayClient = new AopClient(getAlipayConfig());
// 构造请求参数以调用接口
$request = new AlipayCommerceEcEmployeeTitleCreateRequest();
$model = array();

// 设置员工与抬头关系列表
$employeeTitleList = array();
$employeeTitleList0 = array();
$employeeTitleList0['create_by'] = "昭运";
$employeeTitleList0['account_id'] = "2088000397722031";
// uid参数未来计划废弃，存量商户可继续使用，新商户请使用openid。请根据应用-开发配置-openid配置选择支持的字段。
// $employeeTitleList0['user_id'] = "2088502255168118";
$employeeTitleList0['open_id'] = "074a1CcTG1LelxKe4xQC0zgNdId0nxi95b5lsNpazWYoCo5";
$employeeTitleList0['employee_id'] = "228800000000002000002";
$employeeTitleList0['title_id'] = "2022060900801711450000073478";
$employeeTitleList0['title_tag'] = "ou";
$employeeTitleList0['modify_by'] = "昭运";
$employeeTitleList0['tax_register_no'] = "9133*********5852F";
$employeeTitleList0['enterprise_id'] = "2088000230921202";
$employeeTitleList[] = $employeeTitleList0;
$model['employee_title_list'] = $employeeTitleList;

$request->setBizContent(json_encode($model,JSON_UNESCAPED_UNICODE));
// 如果是第三方代调用模式，请设置app_auth_token（应用授权令牌）
$responseResult = $alipayClient->execute($request, null, "<-- 请填写应用授权令牌 -->", null);
$responseApiName = str_replace(".","_",$request->getApiMethodName())."_response";
$response = $responseResult->$responseApiName;
if(!empty($response->code)&&$response->code==10000){
    echo("调用成功");
}
else{
    echo("调用失败");
}

function getAlipayConfig()
{
    $privateKey  = '<-- 请填写您的应用私钥，例如：MIIEvQIBADANB ... ... -->';
    $alipayPublicKey = '<-- 请填写您的支付宝公钥，例如：MIIBIjANBg... -->';
    $alipayConfig = new AlipayConfig();
    $alipayConfig->setServerUrl('https://openapi.alipay.com/gateway.do');
    $alipayConfig->setAppId('<-- 请填写您的AppId，例如：2019091767145019 -->');
    $alipayConfig->setPrivateKey($privateKey);
    $alipayConfig->setFormat('json');
    $alipayConfig->setAlipayPublicKey($alipayPublicKey);
    $alipayConfig->setCharset('UTF-8');
    $alipayConfig->setSignType('RSA2');
    return $alipayConfig;
}
```


##### csharp
```
 using System;
using System.Collections.Generic;
using Aop.Api;
using Aop.Api.Request;
using Aop.Api.Response;
using Aop.Api.Domain;
using Aop.Api.Util;
namespace SdkDemoTest
{
    public class AlipayCommerceEcEmployeeTitleCreate
    {
        public static void Main(string[] args)
        {
            // 初始化SDK
            IAopClient alipayClient = new DefaultAopClient(GetAlipayConfig());
            // 构造请求参数以调用接口
            AlipayCommerceEcEmployeeTitleCreateRequest request = new AlipayCommerceEcEmployeeTitleCreateRequest();
            AlipayCommerceEcEmployeeTitleCreateModel model = new AlipayCommerceEcEmployeeTitleCreateModel();

            // 设置员工与抬头关系列表
            List<EmployeeTitleDTO> employeeTitleList = new List<EmployeeTitleDTO>();
            EmployeeTitleDTO employeeTitleList0 = new EmployeeTitleDTO();
            employeeTitleList0.CreateBy = "昭运";
            employeeTitleList0.AccountId = "2088000397722031";
            // uid参数未来计划废弃，存量商户可继续使用，新商户请使用openid。请根据应用-开发配置-openid配置选择支持的字段。
            // employeeTitleList0.UserId = "2088502255168118";
            employeeTitleList0.OpenId = "074a1CcTG1LelxKe4xQC0zgNdId0nxi95b5lsNpazWYoCo5";
            employeeTitleList0.EmployeeId = "228800000000002000002";
            employeeTitleList0.TitleId = "2022060900801711450000073478";
            employeeTitleList0.TitleTag = "ou";
            employeeTitleList0.ModifyBy = "昭运";
            employeeTitleList0.TaxRegisterNo = "9133*********5852F";
            employeeTitleList0.EnterpriseId = "2088000230921202";
            employeeTitleList.Add(employeeTitleList0);
            model.EmployeeTitleList = employeeTitleList;

            request.SetBizModel(model);
            // 第三方代调用模式下请设置app_auth_token
            // request.PutOtherTextParam("app_auth_token", "<-- 请填写应用授权令牌 -->");

            AlipayCommerceEcEmployeeTitleCreateResponse response = alipayClient.Execute(request);

            if(!response.IsError)
            {
                Console.WriteLine("调用成功");
            }
            else
            {
                Console.WriteLine("调用失败");
            }
        }

        private static AlipayConfig GetAlipayConfig()
        {
            string privateKey  = "<-- 请填写您的应用私钥，例如：MIIEvQIBADANB ... ... -->";
            string alipayPublicKey = "<-- 请填写您的支付宝公钥，例如：MIIBIjANBg... -->";
            AlipayConfig alipayConfig = new AlipayConfig();
            alipayConfig.ServerUrl = "https://openapi.alipay.com/gateway.do";
            alipayConfig.AppId = "<-- 请填写您的AppId，例如：2019091767145019 -->";
            alipayConfig.PrivateKey = privateKey;
            alipayConfig.Format = "json";
            alipayConfig.AlipayPublicKey = alipayPublicKey;
            alipayConfig.Charset = "UTF-8";
            alipayConfig.SignType = "RSA2";
            return alipayConfig;
        }
    }
}
```


##### http
```
 curl 'https://openapi.alipay.com/gateway.do?charset=UTF-8&method=alipay.commerce.ec.employee.title.create&format=json&sign=${sign}&app_id=${appid}&version=1.0&sign_type=RSA2&timestamp=${now}' \
 -F 'app_auth_token=${app_auth_token}' \
 -F 'biz_content={
	"employee_title_list":[
		{
			"create_by":"昭运",
			"account_id":"2088000397722031",
			"user_id":"2088502255168118",
			"open_id":"074a1CcTG1LelxKe4xQC0zgNdId0nxi95b5lsNpazWYoCo5",
			"employee_id":"228800000000002000002",
			"title_id":"2022060900801711450000073478",
			"title_tag":"ou",
			"modify_by":"昭运",
			"tax_register_no":"9133*********5852F",
			"enterprise_id":"2088000230921202"
		}
	]
}'
```


### 公共响应参数
|参数英文名|类型|是否必选|长度/取值|描述|示例值|
|---|---|---|---|---|---|
|code|String|必须|~|网关返回码，[详见文档](https://docs.open.alipay.com/common/105806)|40004|
|msg|String|必须|~|网关返回码描述，[详见文档](https://docs.open.alipay.com/common/105806)|Business Failed|
|sub_code|String|可选|~|业务返回码，参见具体的API接口文档||
|sub_msg|String|可选|~|业务返回码描述，参见具体的API接口文档||
|sign|String|必须|64|签名，[详见文档](https://docs.open.alipay.com/291/106074)|DZXh8eeTuAHoYE3w1J+POiPhfDxOYBfUNn1lkeT/V7P4zJdyojWEa6IZs6Hz0yDW5Cp/viufUb5I0/V5WENS3OYR8zRedqo6D+fUTdLHdc+EFyCkiQhBxIzgngPdPdfp1PIS7BdhhzrsZHbRqb7o4k3Dxc+AAnFauu4V6Zdwczo=|
### 业务响应参数
|参数英文名|类型|是否必选|长度/取值|描述|示例值|
|---|---|---|---|---|---|
|title_failed_list|EcEmployeeTitleFailed|可选||抬头失败信息，用来返回批量处理的每一个抬头错误信息||
|title_failed_list.enterprise_id|String|必须|16|企业ID|2088101234567890|
|title_failed_list.employee_id|String|必须|16|员工ID|2288101234567890|
|title_failed_list.title_id|String|必须|28|抬头ID|2024101012345678901234567890|
|title_failed_list.title_tag|String|必须|15|标识抬头是否默认DEFAULT/多抬头MULTI<br>**枚举值**<br>默认抬头:DEFAULT<br>多抬头:MULTI|DEFAULT|
|title_failed_list.message|String|必须|100|返回每一个抬头批量处理信息|抬头ID不能为空|
### 响应示例
#### 正常响应示例
```
 {
	"alipay_commerce_ec_employee_title_create_response":{
		"code":"10000",
		"msg":"Success",
		"title_failed_list":{
			"enterprise_id":"2088101234567890",
			"employee_id":"2288101234567890",
			"title_id":"2024101012345678901234567890",
			"title_tag":"DEFAULT",
			"message":"抬头ID不能为空"
		}
	},
	"sign":"ERITJKEIJKJHKKKKKKKHJEREEEEEEEEEEE"
}
```

#### 异常响应示例
```
 {"alipay_commerce_ec_employee_title_create_response":{"code":"20000","msg":"Service Currently Unavailable","sub_code":"isp.unknow-error","sub_msg":"系统繁忙"},"sign":"ERITJKEIJKJHKKKKKKKHJEREEEEEEEEEEE"}
```

### 公共错误码
[前往查看](https://opendoc.alipay.com/common/02km9f)
### 业务错误码
|错误码|错误描述|解决方案|
|---|---|---|
|SYSTEM_ERROR|系统繁忙|服务器异常 可能发生了网络或者系统异常，导致服务调用失败，商户可以用同样的请求发起重试|
|INVALID_PARAMETER|参数有误|请根据接口返回的参数非法的具体错误信息，修改参数后进行重试|
|ECEIF_ENTERPRISE_NOT_EXIST|企业不存在|【错误原因】企业不存在。 【排查步骤】请检查企业id或account_id是否正确。|
|EMPLOYEE_NOT_EXIST|员工信息不存在|【错误原因】员工信息不存在。 请先添加员工信息|
|ENTERPRISE_ID_IS_BLANK|企业id为空|【错误原因】企业id为空。 【排查步骤】请检查企业id是否正确。|
|OVER_MAXIMUM_CAPACITY|批量插入数量超过一千条|【错误原因】批量插入数量超过一千条。 【排查步骤】分成多个请求重试。|
|REMOTE_SERVICE_ERROR|远程服务调用失败|【错误原因】远程服务调用失败。 【排查步骤】请稍后重试。|
|TITLE_ENTERPRISE_NOT_MATCH|抬头不在当前企业下或企业抬头不存在|【错误原因】抬头不在当前企业下或企业抬头不存在。 【排查步骤】确认抬头和企业是否对应。|