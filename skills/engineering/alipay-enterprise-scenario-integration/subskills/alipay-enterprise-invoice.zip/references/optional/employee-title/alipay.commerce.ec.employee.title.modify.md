# alipay.commerce.ec.employee.title.modify(修改员工抬头信息)
支持第三方代理调用：本接口支持第三方开发者代用户发起调用
## 通用场景
修改员工抬头信息
注意：此接口能力待升级，当前仅适用于特定企业，新接客户请勿使用
### 公共请求参数
|参数英文名|类型|是否必选|长度/取值|描述|示例值|
|---|---|---|---|---|---|
|app_id|String|必选|32|支付宝分配给开发者的应用ID|2014072300007148|
|method|String|必选|128|接口名称|alipay.commerce.ec.employee.title.modify|
|format|String|可选|40|仅支持JSON|JSON|
|charset|String|必选|10|请求使用的编码格式，如utf-8,gbk,gb2312等|utf-8|
|sign_type|String|必选|10|商户生成签名字符串所使用的签名算法类型，目前支持RSA2和RSA，推荐使用RSA2|RSA2|
|sign|String|必选|344|商户请求参数的签名串，详见[签名](https://opendocs.alipay.com/common/02khjm)|详见示例|
|timestamp|String|必选|19|发送请求的时间，格式"yyyy-MM-dd HH:mm:ss"|2014-07-24 03:07:50|
|version|String|必选|3|调用的接口版本，固定为：1.0|1.0|
|app_auth_token|String|可选|40|详见[应用授权概述](https://opendocs.alipay.com/isv/10467/xldcyq)||
|biz_content|String|必选||请求参数的集合，最大长度不限，除公共参数外所有请求参数都必须放在这个参数中传递，具体参照各产品快速接入文档||
### 业务请求参数

> **N选一说明**：open_id、user_id，N选一必须传入其中一个

> **N选一说明**：user_id、open_id，N选一必须传入其中一个

|参数英文名|类型|是否必选|长度/取值|描述|示例值|
|---|---|---|---|---|---|
|user_id|String|可选|32|支付宝id2088，与employee_id两者必填其一新商户建议使用open_id替代该字段。对于新商户，user_id字段未来计划逐步回收，存量商户可继续使用。如使用open_id，请确认 应用-开发配置-openid配置管理 已启用。无该配置项，可查看[openid配置申请](https://opendocs.alipay.com/mini/0ai9ok?pathHash=de631c06)。|2088502255168118|
|open_id|String|可选|128|支付宝open_id，与employee_id两者必填其一&nbsp; 详情可查看[ openid简介](https://opendocs.alipay.com/mini/0ai2i6?pathHash=13dd5946)|074a1CcTG1LelxKe4xQC0zgNdId0nxi95b5lsNpazWYoCo5|
|account_id|String|特殊可选|32|共同账号id，与enterprise_id两者必填其一<br><br>**必选条件**<br>共同账号account_id，与enterprise_id两者必填其一|2088000397722031|
|enterprise_id|String|特殊可选|32|企业域定义下的企业id，与accountId两者必填其一<br><br>**必选条件**<br>企业域定义下的企业id，与account_id两者必填其一|2088000230921202|
|employee_id|String|可选|32|企业域定义的员工id，与user_id两者必填其一|228800000000002000002|
|title_tag|String|可选|10|员工抬头关系标<br>**枚举值**<br>默认抬头:DEFAULT<br>多个可选抬头:MULTI<br>签约主体（已废弃，请使用DEFAULT）:ou|DEFAULT|
|new_title_id|String|特殊可选|32|修改后的抬头id<br>**注意事项**<br>new_title_id和register_tax_no二选一传入<br><br>**必选条件**<br>当title_tag="DEFAULT"时候，则new_title_id和register_tax_no二选一必需传入|2022060900801711450000073478|
|tax_register_no|String|特殊可选|25|税号<br><br>**必选条件**<br>当title_tag="DEFAULT"时候，则new_title_id和register_tax_no二选一必需传入|9133*********5852F|
|multi_title_list|EcEmployeeTitleModifyTaxNoAndTitleId|特殊可选||绑定的抬头ID列表<br><br>**必选条件**<br>当title_tag="MULTI"时候，multi_title_list为必选||
|multi_title_list.title_id|String|特殊可选|32|抬头ID<br><br>**必选条件**<br>当tax_register_no为空时，title_id为必选参数|2025010112345678901234567890|
|multi_title_list.tax_register_no|String|特殊可选|25|税号<br><br>**必选条件**<br>当title_id为空的时候，tax_register_no为必选参数|9133*********5852F|
|create_by|String|可选|32|创建人|昭运|
|modify_by|String|可选|32|修改人|昭运|
### 请求示例
#### 默认示例
##### java
```
 package com.java.sdk.demo;

import com.alipay.api.AlipayApiException;
import com.alipay.api.AlipayClient;
import com.alipay.api.DefaultAlipayClient;
import com.alipay.api.AlipayConfig;
import com.alipay.api.domain.AlipayCommerceEcEmployeeTitleModifyModel;
import com.alipay.api.request.AlipayCommerceEcEmployeeTitleModifyRequest;
import com.alipay.api.response.AlipayCommerceEcEmployeeTitleModifyResponse;
import com.alipay.api.domain.EcEmployeeTitleModifyTaxNoAndTitleId;

import com.alipay.api.FileItem;
import java.util.Base64;
import java.util.ArrayList;
import java.util.List;

public class AlipayCommerceEcEmployeeTitleModify {

    public static void main(String[] args) throws AlipayApiException {
        // 初始化SDK
        AlipayClient alipayClient = new DefaultAlipayClient(getAlipayConfig());

        // 构造请求参数以调用接口
        AlipayCommerceEcEmployeeTitleModifyRequest request = new AlipayCommerceEcEmployeeTitleModifyRequest();
        AlipayCommerceEcEmployeeTitleModifyModel model = new AlipayCommerceEcEmployeeTitleModifyModel();

        // uid参数未来计划废弃，存量商户可继续使用，新商户请使用openid。请根据应用-开发配置-openid配置选择支持的字段。
        // model.setUserId("2088502255168118");

        // 设置支付宝open_id
        model.setOpenId("074a1CcTG1LelxKe4xQC0zgNdId0nxi95b5lsNpazWYoCo5");

        // 设置共同账号id
        model.setAccountId("2088000397722031");

        // 设置企业域定义下的企业id
        model.setEnterpriseId("2088000230921202");

        // 设置企业域定义的员工id
        model.setEmployeeId("228800000000002000002");

        // 设置员工抬头关系标
        model.setTitleTag("DEFAULT");

        // 设置修改后的抬头id
        model.setNewTitleId("2022060900801711450000073478");

        // 设置税号
        model.setTaxRegisterNo("9133*********5852F");

        // 设置绑定的抬头ID列表
        List<EcEmployeeTitleModifyTaxNoAndTitleId> multiTitleList = new ArrayList<EcEmployeeTitleModifyTaxNoAndTitleId>();
        EcEmployeeTitleModifyTaxNoAndTitleId multiTitleList0 = new EcEmployeeTitleModifyTaxNoAndTitleId();
        multiTitleList0.setTitleId("2025010112345678901234567890");
        multiTitleList0.setTaxRegisterNo("9133*********5852F");
        multiTitleList.add(multiTitleList0);
        model.setMultiTitleList(multiTitleList);

        // 设置创建人
        model.setCreateBy("昭运");

        // 设置修改人
        model.setModifyBy("昭运");

        request.setBizModel(model);
        // 第三方代调用模式下请设置app_auth_token
        // request.putOtherTextParam("app_auth_token", "<-- 请填写应用授权令牌 -->");

        AlipayCommerceEcEmployeeTitleModifyResponse response = alipayClient.execute(request);
        System.out.println(response.getBody());

        if (response.isSuccess()) {
            System.out.println("调用成功");
        } else {
            System.out.println("调用失败");
            // sdk版本是"4.38.0.ALL"及以上,可以参考下面的示例获取诊断链接
            // String diagnosisUrl = DiagnosisUtils.getDiagnosisUrl(response);
            // System.out.println(diagnosisUrl);
        }
    }

    private static AlipayConfig getAlipayConfig() {
        String privateKey  = "<-- 请填写您的应用私钥，例如：MIIEvQIBADANB ... ... -->";
        String alipayPublicKey = "<-- 请填写您的支付宝公钥，例如：MIIBIjANBg... -->";
        AlipayConfig alipayConfig = new AlipayConfig();
        alipayConfig.setServerUrl("https://openapi.alipay.com/gateway.do");
        alipayConfig.setAppId("<-- 请填写您的AppId，例如：2019091767145019 -->");
        alipayConfig.setPrivateKey(privateKey);
        alipayConfig.setFormat("json");
        alipayConfig.setAlipayPublicKey(alipayPublicKey);
        alipayConfig.setCharset("UTF-8");
        alipayConfig.setSignType("RSA2");
        return alipayConfig;
    }
}
```


##### php
```
 <?php
require_once '../aop/AopClient.php';
require_once '../aop/AopCertClient.php';
require_once '../aop/AopCertification.php';
require_once '../aop/AlipayConfig.php';
require_once '../aop/request/AlipayCommerceEcEmployeeTitleModifyRequest.php';

// 初始化SDK
$alipayClient = new AopClient(getAlipayConfig());
// 构造请求参数以调用接口
$request = new AlipayCommerceEcEmployeeTitleModifyRequest();
$model = array();

// uid参数未来计划废弃，存量商户可继续使用，新商户请使用openid。请根据应用-开发配置-openid配置选择支持的字段。
// $model['user_id'] = "2088502255168118";

// 设置支付宝open_id
$model['open_id'] = "074a1CcTG1LelxKe4xQC0zgNdId0nxi95b5lsNpazWYoCo5";

// 设置共同账号id
$model['account_id'] = "2088000397722031";

// 设置企业域定义下的企业id
$model['enterprise_id'] = "2088000230921202";

// 设置企业域定义的员工id
$model['employee_id'] = "228800000000002000002";

// 设置员工抬头关系标
$model['title_tag'] = "DEFAULT";

// 设置修改后的抬头id
$model['new_title_id'] = "2022060900801711450000073478";

// 设置税号
$model['tax_register_no'] = "9133*********5852F";

// 设置绑定的抬头ID列表
$multiTitleList = array();
$multiTitleList0 = array();
$multiTitleList0['title_id'] = "2025010112345678901234567890";
$multiTitleList0['tax_register_no'] = "9133*********5852F";
$multiTitleList[] = $multiTitleList0;
$model['multi_title_list'] = $multiTitleList;

// 设置创建人
$model['create_by'] = "昭运";

// 设置修改人
$model['modify_by'] = "昭运";

$request->setBizContent(json_encode($model,JSON_UNESCAPED_UNICODE));
// 如果是第三方代调用模式，请设置app_auth_token（应用授权令牌）
$responseResult = $alipayClient->execute($request, null, "<-- 请填写应用授权令牌 -->", null);
$responseApiName = str_replace(".","_",$request->getApiMethodName())."_response";
$response = $responseResult->$responseApiName;
if(!empty($response->code)&&$response->code==10000){
    echo("调用成功");
}
else{
    echo("调用失败");
}

function getAlipayConfig()
{
    $privateKey  = '<-- 请填写您的应用私钥，例如：MIIEvQIBADANB ... ... -->';
    $alipayPublicKey = '<-- 请填写您的支付宝公钥，例如：MIIBIjANBg... -->';
    $alipayConfig = new AlipayConfig();
    $alipayConfig->setServerUrl('https://openapi.alipay.com/gateway.do');
    $alipayConfig->setAppId('<-- 请填写您的AppId，例如：2019091767145019 -->');
    $alipayConfig->setPrivateKey($privateKey);
    $alipayConfig->setFormat('json');
    $alipayConfig->setAlipayPublicKey($alipayPublicKey);
    $alipayConfig->setCharset('UTF-8');
    $alipayConfig->setSignType('RSA2');
    return $alipayConfig;
}
```


##### csharp
```
 using System;
using System.Collections.Generic;
using Aop.Api;
using Aop.Api.Request;
using Aop.Api.Response;
using Aop.Api.Domain;
using Aop.Api.Util;
namespace SdkDemoTest
{
    public class AlipayCommerceEcEmployeeTitleModify
    {
        public static void Main(string[] args)
        {
            // 初始化SDK
            IAopClient alipayClient = new DefaultAopClient(GetAlipayConfig());
            // 构造请求参数以调用接口
            AlipayCommerceEcEmployeeTitleModifyRequest request = new AlipayCommerceEcEmployeeTitleModifyRequest();
            AlipayCommerceEcEmployeeTitleModifyModel model = new AlipayCommerceEcEmployeeTitleModifyModel();

            // uid参数未来计划废弃，存量商户可继续使用，新商户请使用openid。请根据应用-开发配置-openid配置选择支持的字段。
            // model.UserId = "2088502255168118";

            // 设置支付宝open_id
            model.OpenId = "074a1CcTG1LelxKe4xQC0zgNdId0nxi95b5lsNpazWYoCo5";

            // 设置共同账号id
            model.AccountId = "2088000397722031";

            // 设置企业域定义下的企业id
            model.EnterpriseId = "2088000230921202";

            // 设置企业域定义的员工id
            model.EmployeeId = "228800000000002000002";

            // 设置员工抬头关系标
            model.TitleTag = "DEFAULT";

            // 设置修改后的抬头id
            model.NewTitleId = "2022060900801711450000073478";

            // 设置税号
            model.TaxRegisterNo = "9133*********5852F";

            // 设置绑定的抬头ID列表
            List<EcEmployeeTitleModifyTaxNoAndTitleId> multiTitleList = new List<EcEmployeeTitleModifyTaxNoAndTitleId>();
            EcEmployeeTitleModifyTaxNoAndTitleId multiTitleList0 = new EcEmployeeTitleModifyTaxNoAndTitleId();
            multiTitleList0.TitleId = "2025010112345678901234567890";
            multiTitleList0.TaxRegisterNo = "9133*********5852F";
            multiTitleList.Add(multiTitleList0);
            model.MultiTitleList = multiTitleList;

            // 设置创建人
            model.CreateBy = "昭运";

            // 设置修改人
            model.ModifyBy = "昭运";

            request.SetBizModel(model);
            // 第三方代调用模式下请设置app_auth_token
            // request.PutOtherTextParam("app_auth_token", "<-- 请填写应用授权令牌 -->");

            AlipayCommerceEcEmployeeTitleModifyResponse response = alipayClient.Execute(request);

            if(!response.IsError)
            {
                Console.WriteLine("调用成功");
            }
            else
            {
                Console.WriteLine("调用失败");
            }
        }

        private static AlipayConfig GetAlipayConfig()
        {
            string privateKey  = "<-- 请填写您的应用私钥，例如：MIIEvQIBADANB ... ... -->";
            string alipayPublicKey = "<-- 请填写您的支付宝公钥，例如：MIIBIjANBg... -->";
            AlipayConfig alipayConfig = new AlipayConfig();
            alipayConfig.ServerUrl = "https://openapi.alipay.com/gateway.do";
            alipayConfig.AppId = "<-- 请填写您的AppId，例如：2019091767145019 -->";
            alipayConfig.PrivateKey = privateKey;
            alipayConfig.Format = "json";
            alipayConfig.AlipayPublicKey = alipayPublicKey;
            alipayConfig.Charset = "UTF-8";
            alipayConfig.SignType = "RSA2";
            return alipayConfig;
        }
    }
}
```


##### http
```
 curl 'https://openapi.alipay.com/gateway.do?charset=UTF-8&method=alipay.commerce.ec.employee.title.modify&format=json&sign=${sign}&app_id=${appid}&version=1.0&sign_type=RSA2&timestamp=${now}' \
 -F 'app_auth_token=${app_auth_token}' \
 -F 'biz_content={
	"user_id":"2088502255168118",
	"open_id":"074a1CcTG1LelxKe4xQC0zgNdId0nxi95b5lsNpazWYoCo5",
	"account_id":"2088000397722031",
	"enterprise_id":"2088000230921202",
	"employee_id":"228800000000002000002",
	"title_tag":"DEFAULT",
	"new_title_id":"2022060900801711450000073478",
	"tax_register_no":"9133*********5852F",
	"multi_title_list":[
		{
			"title_id":"2025010112345678901234567890",
			"tax_register_no":"9133*********5852F"
		}
	],
	"create_by":"昭运",
	"modify_by":"昭运"
}'
```


### 响应示例
#### 正常响应示例
```
 {
	"alipay_commerce_ec_employee_title_modify_response":{
		"code":"10000",
		"msg":"Success"
	},
	"sign":"ERITJKEIJKJHKKKKKKKHJEREEEEEEEEEEE"
}
```

#### 异常响应示例
```
 {"alipay_commerce_ec_employee_title_modify_response":{"code":"20000","msg":"Service Currently Unavailable","sub_code":"isp.unknow-error","sub_msg":"系统繁忙"},"sign":"ERITJKEIJKJHKKKKKKKHJEREEEEEEEEEEE"}
```

### 公共错误码
[前往查看](https://opendoc.alipay.com/common/02km9f)
### 业务错误码
|错误码|错误描述|解决方案|
|---|---|---|
|SYSTEM_ERROR|系统繁忙|服务器异常 可能发生了网络或者系统异常，导致服务调用失败，商户可以用同样的请求发起重试|
|INVALID_PARAMETER|参数有误|请根据接口返回的参数非法的具体错误信息，修改参数后进行重试|
|EMPLOYEE_TITLE_ALREADY_EXIST|员工抬头已存在|【错误原因】员工抬头已被绑定 【排查步骤】无需重复绑定|
|EMPLOYEE_TITLE_PEROID_INVALID|员工绑定抬头的生效周期重叠|【错误原因】当前生效时间必须大于上个失效时间和生效时间 【解决办法】请修改后重新绑定|
|TITLE_ENTERPRISE_NOT_MATCH|抬头不在当前企业下或企业抬头不存在|【错误原因】抬头不在当前企业下或企业抬头不存在。 【排查步骤】检查抬头id和企业是否一致。|