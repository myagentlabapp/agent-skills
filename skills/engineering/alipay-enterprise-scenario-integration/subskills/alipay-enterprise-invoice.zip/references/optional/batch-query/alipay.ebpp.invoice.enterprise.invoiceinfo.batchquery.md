# alipay.ebpp.invoice.enterprise.invoiceinfo.batchquery(企业发票分页查询)
支持第三方代理调用：本接口支持第三方开发者代用户发起调用
## 通用场景
企业票夹，企业发票分页查询
### 公共请求参数
|参数英文名|类型|是否必选|长度/取值|描述|示例值|
|---|---|---|---|---|---|
|app_id|String|必选|32|支付宝分配给开发者的应用ID|2014072300007148|
|method|String|必选|128|接口名称|alipay.ebpp.invoice.enterprise.invoiceinfo.batchquery|
|format|String|可选|40|仅支持JSON|JSON|
|charset|String|必选|10|请求使用的编码格式，如utf-8,gbk,gb2312等|utf-8|
|sign_type|String|必选|10|商户生成签名字符串所使用的签名算法类型，目前支持RSA2和RSA，推荐使用RSA2|RSA2|
|sign|String|必选|344|商户请求参数的签名串，详见[签名](https://opendocs.alipay.com/common/02khjm)|详见示例|
|timestamp|String|必选|19|发送请求的时间，格式"yyyy-MM-dd HH:mm:ss"|2014-07-24 03:07:50|
|version|String|必选|3|调用的接口版本，固定为：1.0|1.0|
|app_auth_token|String|可选|40|详见[应用授权概述](https://opendocs.alipay.com/isv/10467/xldcyq)||
|biz_content|String|必选||请求参数的集合，最大长度不限，除公共参数外所有请求参数都必须放在这个参数中传递，具体参照各产品快速接入文档||
### 业务请求参数
|参数英文名|类型|是否必选|长度/取值|描述|示例值|
|---|---|---|---|---|---|
|enterprise_id|String|必须|32|企业ID|2088111111111111|
|employee_id|String|可选|32|员工id|2300078764711183|
|reimburse_status_list|String|可选|32|报销状态：REIMBURSE_WAIT：待报销；REIMBURSE_APPLY：报销已提交；REIMBURSE_FINISH：报销完成<br>**枚举值**<br>待报销:REIMBURSE_WAIT<br>报销已提交:REIMBURSE_APPLY<br>报销完成:REIMBURSE_FINISH|['REIMBURSE_WAIT']|
|start_time|Date|必须|32|发票日期查询起始时间|2022-12-03 12:12:12|
|end_time|Date|必须|32|发票日期查询结束时间|2023-09-08 12:23:33|
|page_num|Number|必须|32|当前页码|1|
|page_size|Number|必须|32|每页数量|10|
### 请求示例
#### 默认示例
##### java
```
 package com.java.sdk.demo;

import com.alipay.api.AlipayApiException;
import com.alipay.api.AlipayClient;
import com.alipay.api.DefaultAlipayClient;
import com.alipay.api.AlipayConfig;
import com.alipay.api.domain.AlipayEbppInvoiceEnterpriseInvoiceinfoBatchqueryModel;
import com.alipay.api.response.AlipayEbppInvoiceEnterpriseInvoiceinfoBatchqueryResponse;
import com.alipay.api.request.AlipayEbppInvoiceEnterpriseInvoiceinfoBatchqueryRequest;

import com.alipay.api.FileItem;
import java.util.Base64;
import java.util.ArrayList;
import java.util.List;
import java.util.TimeZone;
import java.text.ParseException;
import java.text.SimpleDateFormat;

public class AlipayEbppInvoiceEnterpriseInvoiceinfoBatchquery {

    public static void main(String[] args) throws AlipayApiException, ParseException {
        // 初始化SDK
        AlipayClient alipayClient = new DefaultAlipayClient(getAlipayConfig());
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        sdf.setTimeZone(TimeZone.getTimeZone("GMT+8"));

        // 构造请求参数以调用接口
        AlipayEbppInvoiceEnterpriseInvoiceinfoBatchqueryRequest request = new AlipayEbppInvoiceEnterpriseInvoiceinfoBatchqueryRequest();
        AlipayEbppInvoiceEnterpriseInvoiceinfoBatchqueryModel model = new AlipayEbppInvoiceEnterpriseInvoiceinfoBatchqueryModel();

        // 设置企业ID
        model.setEnterpriseId("2088111111111111");

        // 设置员工id
        model.setEmployeeId("2300078764711183");

        // 设置报销状态列表
        List<String> reimburseStatusList = new ArrayList<String>();
        reimburseStatusList.add("REIMBURSE_WAIT");
        model.setReimburseStatusList(reimburseStatusList);

        // 设置发票日期起始时间
        model.setStartTime(sdf.parse("2022-12-03 12:12:12"));

        // 设置发票日期结束时间
        model.setEndTime(sdf.parse("2023-09-08 12:23:33"));

        // 设置当前页码
        model.setPageNum(1L);

        // 设置每页数量
        model.setPageSize(10L);

        request.setBizModel(model);
        // 第三方代调用模式下请设置app_auth_token
        // request.putOtherTextParam("app_auth_token", "<-- 请填写应用授权令牌 -->");

        AlipayEbppInvoiceEnterpriseInvoiceinfoBatchqueryResponse response = alipayClient.execute(request);
        System.out.println(response.getBody());

        if (response.isSuccess()) {
            System.out.println("调用成功");
        } else {
            System.out.println("调用失败");
            // sdk版本是"4.38.0.ALL"及以上,可以参考下面的示例获取诊断链接
            // String diagnosisUrl = DiagnosisUtils.getDiagnosisUrl(response);
            // System.out.println(diagnosisUrl);
        }
    }

    private static AlipayConfig getAlipayConfig() {
        String privateKey  = "<-- 请填写您的应用私钥，例如：MIIEvQIBADANB ... ... -->";
        String alipayPublicKey = "<-- 请填写您的支付宝公钥，例如：MIIBIjANBg... -->";
        AlipayConfig alipayConfig = new AlipayConfig();
        alipayConfig.setServerUrl("https://openapi.alipay.com/gateway.do");
        alipayConfig.setAppId("<-- 请填写您的AppId，例如：2019091767145019 -->");
        alipayConfig.setPrivateKey(privateKey);
        alipayConfig.setFormat("json");
        alipayConfig.setAlipayPublicKey(alipayPublicKey);
        alipayConfig.setCharset("UTF-8");
        alipayConfig.setSignType("RSA2");
        return alipayConfig;
    }
}
```


##### php
```
 <?php
require_once '../aop/AopClient.php';
require_once '../aop/AopCertClient.php';
require_once '../aop/AopCertification.php';
require_once '../aop/AlipayConfig.php';
require_once '../aop/request/AlipayEbppInvoiceEnterpriseInvoiceinfoBatchqueryRequest.php';

// 初始化SDK
$alipayClient = new AopClient(getAlipayConfig());
// 构造请求参数以调用接口
$request = new AlipayEbppInvoiceEnterpriseInvoiceinfoBatchqueryRequest();
$model = array();

// 设置企业ID
$model['enterprise_id'] = "2088111111111111";

// 设置员工id
$model['employee_id'] = "2300078764711183";

// 设置报销状态列表
$reimburseStatusList = array();
$reimburseStatusList[] = "REIMBURSE_WAIT";
$model['reimburse_status_list'] = $reimburseStatusList;

// 设置发票日期起始时间
$model['start_time'] = "2022-12-03 12:12:12";

// 设置发票日期结束时间
$model['end_time'] = "2023-09-08 12:23:33";

// 设置当前页码
$model['page_num'] = 1;

// 设置每页数量
$model['page_size'] = 10;

$request->setBizContent(json_encode($model,JSON_UNESCAPED_UNICODE));
// 如果是第三方代调用模式，请设置app_auth_token（应用授权令牌）
$responseResult = $alipayClient->execute($request, null, "<-- 请填写应用授权令牌 -->", null);
$responseApiName = str_replace(".","_",$request->getApiMethodName())."_response";
$response = $responseResult->$responseApiName;
if(!empty($response->code)&&$response->code==10000){
    echo("调用成功");
}
else{
    echo("调用失败");
}

function getAlipayConfig()
{
    $privateKey  = '<-- 请填写您的应用私钥，例如：MIIEvQIBADANB ... ... -->';
    $alipayPublicKey = '<-- 请填写您的支付宝公钥，例如：MIIBIjANBg... -->';
    $alipayConfig = new AlipayConfig();
    $alipayConfig->setServerUrl('https://openapi.alipay.com/gateway.do');
    $alipayConfig->setAppId('<-- 请填写您的AppId，例如：2019091767145019 -->');
    $alipayConfig->setPrivateKey($privateKey);
    $alipayConfig->setFormat('json');
    $alipayConfig->setAlipayPublicKey($alipayPublicKey);
    $alipayConfig->setCharset('UTF-8');
    $alipayConfig->setSignType('RSA2');
    return $alipayConfig;
}
```


##### csharp
```
 using System;
using System.Collections.Generic;
using Aop.Api;
using Aop.Api.Request;
using Aop.Api.Response;
using Aop.Api.Domain;
using Aop.Api.Util;
namespace SdkDemoTest
{
    public class AlipayEbppInvoiceEnterpriseInvoiceinfoBatchquery
    {
        public static void Main(string[] args)
        {
            // 初始化SDK
            IAopClient alipayClient = new DefaultAopClient(GetAlipayConfig());
            // 构造请求参数以调用接口
            AlipayEbppInvoiceEnterpriseInvoiceinfoBatchqueryRequest request = new AlipayEbppInvoiceEnterpriseInvoiceinfoBatchqueryRequest();
            AlipayEbppInvoiceEnterpriseInvoiceinfoBatchqueryModel model = new AlipayEbppInvoiceEnterpriseInvoiceinfoBatchqueryModel();

            // 设置企业ID
            model.EnterpriseId = "2088111111111111";

            // 设置员工id
            model.EmployeeId = "2300078764711183";

            // 设置报销状态列表
            List<String> reimburseStatusList = new List<String>();
            reimburseStatusList.Add("REIMBURSE_WAIT");
            model.ReimburseStatusList = reimburseStatusList;

            // 设置发票日期起始时间
            model.StartTime = "2022-12-03 12:12:12";

            // 设置发票日期结束时间
            model.EndTime = "2023-09-08 12:23:33";

            // 设置当前页码
            model.PageNum = 1;

            // 设置每页数量
            model.PageSize = 10;

            request.SetBizModel(model);
            // 第三方代调用模式下请设置app_auth_token
            // request.PutOtherTextParam("app_auth_token", "<-- 请填写应用授权令牌 -->");

            AlipayEbppInvoiceEnterpriseInvoiceinfoBatchqueryResponse response = alipayClient.Execute(request);

            if(!response.IsError)
            {
                Console.WriteLine("调用成功");
            }
            else
            {
                Console.WriteLine("调用失败");
            }
        }

        private static AlipayConfig GetAlipayConfig()
        {
            string privateKey  = "<-- 请填写您的应用私钥，例如：MIIEvQIBADANB ... ... -->";
            string alipayPublicKey = "<-- 请填写您的支付宝公钥，例如：MIIBIjANBg... -->";
            AlipayConfig alipayConfig = new AlipayConfig();
            alipayConfig.ServerUrl = "https://openapi.alipay.com/gateway.do";
            alipayConfig.AppId = "<-- 请填写您的AppId，例如：2019091767145019 -->";
            alipayConfig.PrivateKey = privateKey;
            alipayConfig.Format = "json";
            alipayConfig.AlipayPublicKey = alipayPublicKey;
            alipayConfig.Charset = "UTF-8";
            alipayConfig.SignType = "RSA2";
            return alipayConfig;
        }
    }
}
```


##### http
```
 curl 'https://openapi.alipay.com/gateway.do?charset=UTF-8&method=alipay.ebpp.invoice.enterprise.invoiceinfo.batchquery&format=json&sign=${sign}&app_id=${appid}&version=1.0&sign_type=RSA2&timestamp=${now}' \
 -F 'app_auth_token=${app_auth_token}' \
 -F 'biz_content={
	"enterprise_id":"2088111111111111",
	"employee_id":"2300078764711183",
	"reimburse_status_list":[
		"REIMBURSE_WAIT"
	],
	"start_time":"2022-12-03 12:12:12",
	"end_time":"2023-09-08 12:23:33",
	"page_num":1,
	"page_size":10
}'
```


### 公共响应参数
|参数英文名|类型|是否必选|长度/取值|描述|示例值|
|---|---|---|---|---|---|
|code|String|必须|~|网关返回码，[详见文档](https://docs.open.alipay.com/common/105806)|40004|
|msg|String|必须|~|网关返回码描述，[详见文档](https://docs.open.alipay.com/common/105806)|Business Failed|
|sub_code|String|可选|~|业务返回码，参见具体的API接口文档||
|sub_msg|String|可选|~|业务返回码描述，参见具体的API接口文档||
|sign|String|必须|64|签名，[详见文档](https://docs.open.alipay.com/291/106074)|DZXh8eeTuAHoYE3w1J+POiPhfDxOYBfUNn1lkeT/V7P4zJdyojWEa6IZs6Hz0yDW5Cp/viufUb5I0/V5WENS3OYR8zRedqo6D+fUTdLHdc+EFyCkiQhBxIzgngPdPdfp1PIS7BdhhzrsZHbRqb7o4k3Dxc+AAnFauu4V6Zdwczo=|
### 业务响应参数
|参数英文名|类型|是否必选|长度/取值|描述|示例值|
|---|---|---|---|---|---|
|page_num|Number|必须|10|当前页码|1|
|page_size|Number|必须|10|每页数量|20|
|total_size|Number|必须|10|总条数|20|
|invoice_info_list|EnterpriseInvoiceInfoDTO|可选||发票列表||
|invoice_info_list.enterprise_id|String|必须|32|企业ID|2088111111111111|
|invoice_info_list.batch_id|String|可选|32|批次ID<br>**注意事项**<br>当发票有匹配账单时，不为空|2023031500152805690000432058|
|invoice_info_list.employee_id|String|可选|32|员工ID|2288111111111111|
|invoice_info_list.invoice_code|String|特殊可选|20|发票代码<br><br>**必选条件**<br>当invoice_kind为31或32时为空，否则不为空|123456789012|
|invoice_info_list.invoice_no|String|必须|20|发票号码|12345678|
|invoice_info_list.invoice_type|String|必须|10|发票类型<br>**枚举值**<br>蓝票:blue<br>红票:red|blue|
|invoice_info_list.invoice_kind|String|必须|10|发票类型<br>**枚举值**<br>增值税普通电子发票:0<br>增值税普通发票:1<br>增值税专用发票:2<br>增值税专用电子发票:3<br>财政电子发票:4<br>电子发票（普通发票:32<br>电子发票（增值税专用发票）:31|1|
|invoice_info_list.invoice_date|String|必须|10|开票日期|2023-08-11|
|invoice_info_list.sum_amount|String|必须|32|发票金额，价税合计金额，单位元|30.12|
|invoice_info_list.tax_amount|String|可选|32|税额，单位元|0.12|
|invoice_info_list.without_tax_amount|String|可选|32|不含税金额，单位元|30.00|
|invoice_info_list.payer_name|String|必须|128|购方抬头|测试企业|
|invoice_info_list.payer_register_no|String|必须|32|购方税号|91310230MA1K05DW69|
|invoice_info_list.payer_mobile|String|可选|32|购方电话|15587667875|
|invoice_info_list.payer_address|String|可选|256|购方地址|杭州市西湖区|
|invoice_info_list.payer_bank_name|String|可选|256|购方开户行|招商银行|
|invoice_info_list.payer_bank_account|String|可选|256|购方银行账号|88888888888888|
|invoice_info_list.payee_name|String|必须|128|销方抬头|测试企业|
|invoice_info_list.payee_register_no|String|必须|32|销方税号|91310230MA1K05DW69|
|invoice_info_list.payee_mobile|String|可选|32|销方电话|15576887654|
|invoice_info_list.payee_address|String|可选|256|销方地址|杭州市西湖区|
|invoice_info_list.payee_bank_name|String|可选|256|销方开户行|招商银行|
|invoice_info_list.payee_bank_account|String|可选|256|销方银行账户|88888888888888|
|invoice_info_list.invoice_item_list|EnterpriseInvoiceItemDTO|可选||发票明细列表||
|invoice_info_list.invoice_item_list.item_name|String|必须|64|发票项目名称/货物名称|电脑|
|invoice_info_list.invoice_item_list.amount|String|必须|10|价税合计。格式为2位小数，单位为元|1.20|
|invoice_info_list.invoice_item_list.price|String|可选|32|商品单价。单位为元|1.20|
|invoice_info_list.invoice_item_list.sum_price|String|可选|10|总价 (不含税)。格式为2位小数，单位为元|1.20|
|invoice_info_list.invoice_item_list.tax|String|必须|20|税额。格式为2位小数，单位为元|1.20|
|invoice_info_list.invoice_item_list.tax_rate|String|必须|10|税率。格式为2位小数，如：0.00, 0.03, 0.13|0.13|
|invoice_info_list.invoice_item_list.unit|String|可选|10|单位|台|
|invoice_info_list.invoice_item_list.quantity|String|可选|10|数量|1000|
|invoice_info_list.invoice_item_list.specification|String|可选|16|规格型号|件|
|invoice_info_list.invoice_item_list.item_no|String|可选|32|税收分类编码|1111111111xx|
|invoice_info_list.invoice_item_list.row_type|String|可选|2|发票行性质。0表示正常行，1表示折扣行，2表示被折扣行。<br>**枚举值**<br>正常行:0<br>折扣行:1<br>被折扣行:2|0|
|invoice_info_list.payee|String|可选|32|收款人|张三|
|invoice_info_list.checker|String|可选|32|复核人|李四|
|invoice_info_list.operator|String|可选|32|开票人|张三|
|invoice_info_list.invoice_memo|String|可选|500|备注|发票备注信息|
|invoice_info_list.anti_fake_code|String|可选|32|防伪码|2343454345678654|
|invoice_info_list.file_type|String|必须|10|文件类型<br>**枚举值**<br>ofd:ofd<br>pdf:pdf|pdf|
|invoice_info_list.file_download_url|String|必须|500|发票下载地址|https://mdgwdev.alipay.net/induspt_invoice/afts/file/A*3XR8QrJu9agAAAAAAAAAAAAAAUYnAA?t=cRYtqJkpCS-MfK_zdS2ZxwAAAABkJ0YAAAAA&af_fileName=A*3XR8QrJu9agAAAAAAAAAAAAAAUYnAA.pdf|
|invoice_info_list.invoice_check_time|Date|可选|32|发票查验时间|2023-09-19 12:23:11|
|invoice_info_list.invoice_check_result|String|可选|32|发票查验结果<br>**枚举值**<br>待查验:WAIT_CHECK<br>查验失败:CHECK_FAIL<br>不查验:NOT_CHECK<br>查验为真:REAL_INVOICE<br>发票已冲红:INVOICE_REVERSE<br>发票不存在:INVOICE_NOT_EXIST<br>不一致:CHECK_INCONSISTENT<br>不支持查验:CHECK_NOT_SUPPORT<br>**注意事项**<br>查验时间查验到的结果|REAL_INVOICE|
|invoice_info_list.related_to_consume|Boolean|可选|10|是否关联到账单|true|
|invoice_info_list.specific_factor|String|可选|32|特定行业要素类型<br>**枚举值**<br>铁路电子客票:RAILWAY<br>航空运输电子客票:AIR_TRANSPORTATION<br>出租车票:TAXI_INVOICE<br>网约车票:TRAFFIC_RIDE_HAILING<br>轮船票:FERRY_TICKET<br>汽车票:BUS_TICKET<br>过路过桥费:TOLL_INVOICE<br>定额票:FIXED_AMOUNT_TICKET<br>酒店水单:HOTEL_BILL<br>网约车:HAILING_RIDE<br>电子小票:PURCHASE_BILL|RAILWAY|
|invoice_info_list.industry_specific_infos|String|可选|2048|特定行业信息，需要根据特定行业要素类型（specific_factor），获取[具体行业模型](https://opendocs.alipay.com/pre-open/07wr4t?pathHash=5d7c31e5#%E8%A1%8C%E4%B8%9A%E6%A8%A1%E5%9E%8B%E5%AE%9A%E4%B9%89)|["{\"departure\":\"上海\",\"departureDate\":\"2024-01-01\",\"departureTime\":\"08:00\",\"destination\":\"北京\",\"flightNo\":\"MU1234\"}"]|
|invoice_info_list.collect_source|String|可选|32|发票归集来源<br>**枚举值**<br>收票邮箱:INVOICE_EMAIL<br>其他:OTHER|INVOICE_EMAIL|
|invoice_info_list.reimburse_status|String|可选|32|报销状态：REIMBURSE_WAIT：待报销；REIMBURSE_APPLY：报销已提交；REIMBURSE_FINISH：报销完成<br>**枚举值**<br>待报销:REIMBURSE_WAIT<br>报销已提交:REIMBURSE_APPLY<br>报销完成:REIMBURSE_FINISH|REIMBURSE_WAIT|
### 响应示例
#### 正常响应示例
```
 {
	"alipay_ebpp_invoice_enterprise_invoiceinfo_batchquery_response":{
		"code":"10000",
		"msg":"Success",
		"page_num":1,
		"page_size":20,
		"total_size":20,
		"invoice_info_list":[
			{
				"enterprise_id":"2088111111111111",
				"batch_id":"2023031500152805690000432058",
				"employee_id":"2288111111111111",
				"invoice_code":"123456789012",
				"invoice_no":"12345678",
				"invoice_type":"blue",
				"invoice_kind":"1",
				"invoice_date":"2023-08-11",
				"sum_amount":"30.12",
				"tax_amount":"0.12",
				"without_tax_amount":"30.00",
				"payer_name":"测试企业",
				"payer_register_no":"91310230MA1K05DW69",
				"payer_mobile":"15587667875",
				"payer_address":"杭州市西湖区",
				"payer_bank_name":"招商银行",
				"payer_bank_account":"88888888888888",
				"payee_name":"测试企业",
				"payee_register_no":"91310230MA1K05DW69",
				"payee_mobile":"15576887654",
				"payee_address":"杭州市西湖区",
				"payee_bank_name":"招商银行",
				"payee_bank_account":"88888888888888",
				"invoice_item_list":[
					{
						"item_name":"电脑",
						"amount":"1.20",
						"price":"1.20",
						"sum_price":"1.20",
						"tax":"1.20",
						"tax_rate":"0.13",
						"unit":"台",
						"quantity":"1000",
						"specification":"件",
						"item_no":"1111111111xx",
						"row_type":"0"
					}
				],
				"payee":"张三",
				"checker":"李四",
				"operator":"张三",
				"invoice_memo":"发票备注信息",
				"anti_fake_code":"2343454345678654",
				"file_type":"pdf",
				"file_download_url":"https://mdgwdev.alipay.net/induspt_invoice/afts/file/A*3XR8QrJu9agAAAAAAAAAAAAAAUYnAA?t=cRYtqJkpCS-MfK_zdS2ZxwAAAABkJ0YAAAAA&af_fileName=A*3XR8QrJu9agAAAAAAAAAAAAAAUYnAA.pdf",
				"invoice_check_time":"2023-09-19 12:23:11",
				"invoice_check_result":"REAL_INVOICE",
				"related_to_consume":true,
				"specific_factor":"RAILWAY",
				"industry_specific_infos":[
					"{\\\"departure\\\":\\\"上海\\",
					"\\\"departureDate\\\":\\\"2024-01-01\\\"",
					"\\\"departureTime\\\":\\\"08:00\\\"",
					"\\\"destination\\\":\\\"北京\\\"",
					"\\\"flightNo\\\":\\\"MU1234\\\"}\""
				],
				"collect_source":"INVOICE_EMAIL",
				"reimburse_status":"REIMBURSE_WAIT"
			}
		]
	},
	"sign":"ERITJKEIJKJHKKKKKKKHJEREEEEEEEEEEE"
}
```

#### 异常响应示例
```
 {"alipay_ebpp_invoice_enterprise_invoiceinfo_batchquery_response":{"code":"20000","msg":"Service Currently Unavailable","sub_code":"isp.unknow-error","sub_msg":"系统繁忙"},"sign":"ERITJKEIJKJHKKKKKKKHJEREEEEEEEEEEE"}
```

### 公共错误码
[前往查看](https://opendoc.alipay.com/common/02km9f)
### 业务错误码
|错误码|错误描述|解决方案|
|---|---|---|
|SYSTEM_ERROR|系统繁忙|服务器异常 可能发生了网络或者系统异常，导致服务调用失败，商户可以用同样的请求发起重试|
|INVALID_PARAMETER|参数有误|请根据接口返回的参数非法的具体错误信息，修改参数后进行重试|
|NO_AGREEMENT|产品未签约或合约状态异常|产品未签约或合约状态异常，请联系客服或技术支持处理|