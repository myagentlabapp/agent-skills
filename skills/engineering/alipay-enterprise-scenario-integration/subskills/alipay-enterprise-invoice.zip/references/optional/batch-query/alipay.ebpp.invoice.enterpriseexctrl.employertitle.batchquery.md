# alipay.ebpp.invoice.enterpriseexctrl.employertitle.batchquery(企业抬头：分页查询企业抬头信息)
支持第三方代理调用：本接口支持第三方开发者代用户发起调用
## 通用场景
分页查询企业抬头列表
### 公共请求参数
|参数英文名|类型|是否必选|长度/取值|描述|示例值|
|---|---|---|---|---|---|
|app_id|String|必选|32|支付宝分配给开发者的应用ID|2014072300007148|
|method|String|必选|128|接口名称|alipay.ebpp.invoice.enterpriseexctrl.employertitle.batchquery|
|format|String|可选|40|仅支持JSON|JSON|
|charset|String|必选|10|请求使用的编码格式，如utf-8,gbk,gb2312等|utf-8|
|sign_type|String|必选|10|商户生成签名字符串所使用的签名算法类型，目前支持RSA2和RSA，推荐使用RSA2|RSA2|
|sign|String|必选|344|商户请求参数的签名串，详见[签名](https://opendocs.alipay.com/common/02khjm)|详见示例|
|timestamp|String|必选|19|发送请求的时间，格式"yyyy-MM-dd HH:mm:ss"|2014-07-24 03:07:50|
|version|String|必选|3|调用的接口版本，固定为：1.0|1.0|
|app_auth_token|String|可选|40|详见[应用授权概述](https://opendocs.alipay.com/isv/10467/xldcyq)||
|biz_content|String|必选||请求参数的集合，最大长度不限，除公共参数外所有请求参数都必须放在这个参数中传递，具体参照各产品快速接入文档||
### 业务请求参数
|参数英文名|类型|是否必选|长度/取值|描述|示例值|
|---|---|---|---|---|---|
|account_id|String|特殊可选|32|企业共同账户id<br>**注意事项**<br>通过企业码1.0接口签约的共同账户，和agreement_no搭配使用。|2088000194958956|
|enterprise_id|String|特殊可选|32|企业id<br>**注意事项**<br>通过企业码2.0签约接口签约，只填写企业id，无需填写共同账户id和授权签约协议号。|2088123412341234|
|agreement_no|String|特殊可选|32|授权签约协议号<br>**注意事项**<br>可通过签约消息获取。配合共同账户id使用，当填写企业共同账户id时，此字段必填。|20215425001181407500|
|tax_register_no|String|可选|25|税号|9133*********5852F|
|page_num|Number|必须|10000|页码|1|
|page_size|Number|必须|20|每页行数|10|
### 请求示例
#### 默认示例
##### java
```
 package com.java.sdk.demo;

import com.alipay.api.AlipayApiException;
import com.alipay.api.AlipayClient;
import com.alipay.api.DefaultAlipayClient;
import com.alipay.api.AlipayConfig;
import com.alipay.api.domain.AlipayEbppInvoiceEnterpriseexctrlEmployertitleBatchqueryModel;
import com.alipay.api.request.AlipayEbppInvoiceEnterpriseexctrlEmployertitleBatchqueryRequest;
import com.alipay.api.response.AlipayEbppInvoiceEnterpriseexctrlEmployertitleBatchqueryResponse;

import com.alipay.api.FileItem;
import java.util.Base64;
import java.util.ArrayList;
import java.util.List;

public class AlipayEbppInvoiceEnterpriseexctrlEmployertitleBatchquery {

    public static void main(String[] args) throws AlipayApiException {
        // 初始化SDK
        AlipayClient alipayClient = new DefaultAlipayClient(getAlipayConfig());

        // 构造请求参数以调用接口
        AlipayEbppInvoiceEnterpriseexctrlEmployertitleBatchqueryRequest request = new AlipayEbppInvoiceEnterpriseexctrlEmployertitleBatchqueryRequest();
        AlipayEbppInvoiceEnterpriseexctrlEmployertitleBatchqueryModel model = new AlipayEbppInvoiceEnterpriseexctrlEmployertitleBatchqueryModel();

        // 设置企业共同账户id
        model.setAccountId("2088000194958956");

        // 设置企业id
        model.setEnterpriseId("2088123412341234");

        // 设置授权签约协议号
        model.setAgreementNo("20215425001181407500");

        // 设置税号
        model.setTaxRegisterNo("9133*********5852F");

        // 设置页码
        model.setPageNum(1L);

        // 设置每页行数
        model.setPageSize(10L);

        request.setBizModel(model);
        // 第三方代调用模式下请设置app_auth_token
        // request.putOtherTextParam("app_auth_token", "<-- 请填写应用授权令牌 -->");

        AlipayEbppInvoiceEnterpriseexctrlEmployertitleBatchqueryResponse response = alipayClient.execute(request);
        System.out.println(response.getBody());

        if (response.isSuccess()) {
            System.out.println("调用成功");
        } else {
            System.out.println("调用失败");
            // sdk版本是"4.38.0.ALL"及以上,可以参考下面的示例获取诊断链接
            // String diagnosisUrl = DiagnosisUtils.getDiagnosisUrl(response);
            // System.out.println(diagnosisUrl);
        }
    }

    private static AlipayConfig getAlipayConfig() {
        String privateKey  = "<-- 请填写您的应用私钥，例如：MIIEvQIBADANB ... ... -->";
        String alipayPublicKey = "<-- 请填写您的支付宝公钥，例如：MIIBIjANBg... -->";
        AlipayConfig alipayConfig = new AlipayConfig();
        alipayConfig.setServerUrl("https://openapi.alipay.com/gateway.do");
        alipayConfig.setAppId("<-- 请填写您的AppId，例如：2019091767145019 -->");
        alipayConfig.setPrivateKey(privateKey);
        alipayConfig.setFormat("json");
        alipayConfig.setAlipayPublicKey(alipayPublicKey);
        alipayConfig.setCharset("UTF-8");
        alipayConfig.setSignType("RSA2");
        return alipayConfig;
    }
}
```


##### php
```
 <?php
require_once '../aop/AopClient.php';
require_once '../aop/AopCertClient.php';
require_once '../aop/AopCertification.php';
require_once '../aop/AlipayConfig.php';
require_once '../aop/request/AlipayEbppInvoiceEnterpriseexctrlEmployertitleBatchqueryRequest.php';

// 初始化SDK
$alipayClient = new AopClient(getAlipayConfig());
// 构造请求参数以调用接口
$request = new AlipayEbppInvoiceEnterpriseexctrlEmployertitleBatchqueryRequest();
$model = array();

// 设置企业共同账户id
$model['account_id'] = "2088000194958956";

// 设置企业id
$model['enterprise_id'] = "2088123412341234";

// 设置授权签约协议号
$model['agreement_no'] = "20215425001181407500";

// 设置税号
$model['tax_register_no'] = "9133*********5852F";

// 设置页码
$model['page_num'] = 1;

// 设置每页行数
$model['page_size'] = 10;

$request->setBizContent(json_encode($model,JSON_UNESCAPED_UNICODE));
// 如果是第三方代调用模式，请设置app_auth_token（应用授权令牌）
$responseResult = $alipayClient->execute($request, null, "<-- 请填写应用授权令牌 -->", null);
$responseApiName = str_replace(".","_",$request->getApiMethodName())."_response";
$response = $responseResult->$responseApiName;
if(!empty($response->code)&&$response->code==10000){
    echo("调用成功");
}
else{
    echo("调用失败");
}

function getAlipayConfig()
{
    $privateKey  = '<-- 请填写您的应用私钥，例如：MIIEvQIBADANB ... ... -->';
    $alipayPublicKey = '<-- 请填写您的支付宝公钥，例如：MIIBIjANBg... -->';
    $alipayConfig = new AlipayConfig();
    $alipayConfig->setServerUrl('https://openapi.alipay.com/gateway.do');
    $alipayConfig->setAppId('<-- 请填写您的AppId，例如：2019091767145019 -->');
    $alipayConfig->setPrivateKey($privateKey);
    $alipayConfig->setFormat('json');
    $alipayConfig->setAlipayPublicKey($alipayPublicKey);
    $alipayConfig->setCharset('UTF-8');
    $alipayConfig->setSignType('RSA2');
    return $alipayConfig;
}
```


##### csharp
```
 using System;
using System.Collections.Generic;
using Aop.Api;
using Aop.Api.Request;
using Aop.Api.Response;
using Aop.Api.Domain;
using Aop.Api.Util;
namespace SdkDemoTest
{
    public class AlipayEbppInvoiceEnterpriseexctrlEmployertitleBatchquery
    {
        public static void Main(string[] args)
        {
            // 初始化SDK
            IAopClient alipayClient = new DefaultAopClient(GetAlipayConfig());
            // 构造请求参数以调用接口
            AlipayEbppInvoiceEnterpriseexctrlEmployertitleBatchqueryRequest request = new AlipayEbppInvoiceEnterpriseexctrlEmployertitleBatchqueryRequest();
            AlipayEbppInvoiceEnterpriseexctrlEmployertitleBatchqueryModel model = new AlipayEbppInvoiceEnterpriseexctrlEmployertitleBatchqueryModel();

            // 设置企业共同账户id
            model.AccountId = "2088000194958956";

            // 设置企业id
            model.EnterpriseId = "2088123412341234";

            // 设置授权签约协议号
            model.AgreementNo = "20215425001181407500";

            // 设置税号
            model.TaxRegisterNo = "9133*********5852F";

            // 设置页码
            model.PageNum = 1;

            // 设置每页行数
            model.PageSize = 10;

            request.SetBizModel(model);
            // 第三方代调用模式下请设置app_auth_token
            // request.PutOtherTextParam("app_auth_token", "<-- 请填写应用授权令牌 -->");

            AlipayEbppInvoiceEnterpriseexctrlEmployertitleBatchqueryResponse response = alipayClient.Execute(request);

            if(!response.IsError)
            {
                Console.WriteLine("调用成功");
            }
            else
            {
                Console.WriteLine("调用失败");
            }
        }

        private static AlipayConfig GetAlipayConfig()
        {
            string privateKey  = "<-- 请填写您的应用私钥，例如：MIIEvQIBADANB ... ... -->";
            string alipayPublicKey = "<-- 请填写您的支付宝公钥，例如：MIIBIjANBg... -->";
            AlipayConfig alipayConfig = new AlipayConfig();
            alipayConfig.ServerUrl = "https://openapi.alipay.com/gateway.do";
            alipayConfig.AppId = "<-- 请填写您的AppId，例如：2019091767145019 -->";
            alipayConfig.PrivateKey = privateKey;
            alipayConfig.Format = "json";
            alipayConfig.AlipayPublicKey = alipayPublicKey;
            alipayConfig.Charset = "UTF-8";
            alipayConfig.SignType = "RSA2";
            return alipayConfig;
        }
    }
}
```


##### http
```
 curl 'https://openapi.alipay.com/gateway.do?charset=UTF-8&method=alipay.ebpp.invoice.enterpriseexctrl.employertitle.batchquery&format=json&sign=${sign}&app_id=${appid}&version=1.0&sign_type=RSA2&timestamp=${now}' \
 -F 'app_auth_token=${app_auth_token}' \
 -F 'biz_content={
	"account_id":"2088000194958956",
	"enterprise_id":"2088123412341234",
	"agreement_no":"20215425001181407500",
	"tax_register_no":"9133*********5852F",
	"page_num":1,
	"page_size":10
}'
```


### 公共响应参数
无公共响应参数
### 业务响应参数
|参数英文名|类型|是否必选|长度/取值|描述|示例值|
|---|---|---|---|---|---|
|code|String|必须|64|返回码 10000-成功 其他都是失败|10000|
|msg|String|必须|255|返回消息|成功|
|title_info_list|EnterpriseTitleInfo|可选||企业抬头信息||
|title_info_list.title_id|String|必须|64|抬头ID|****|
|title_info_list.title_name|String|必须|100|企业抬头名称|*****有限公司|
|title_info_list.tax_register_no|String|必须|20|税号|********|
|title_info_list.address|String|可选|50|详细地址|***省***市****区|
|title_info_list.bank_name|String|可选|100|开户行地址|******|
|title_info_list.bank_account|String|可选|50|开户行账号|622000********|
|title_info_list.telephone|String|可选|30|电话|0739-56*****|
|title_code|String|可选|64|抬头编码|43523452345345****|
### 响应示例
#### 正常响应示例
```
 {
	"alipay_ebpp_invoice_enterpriseexctrl_employertitle_batchquery_response":{
		"code":"10000",
		"msg":"成功",
		"title_info_list":[
			{
				"title_id":"****",
				"title_name":"*****有限公司",
				"tax_register_no":"********",
				"address":"***省***市****区",
				"bank_name":"******",
				"bank_account":"622000********",
				"telephone":"0739-56*****"
			}
		],
		"title_code":"43523452345345****"
	},
	"sign":"ERITJKEIJKJHKKKKKKKHJEREEEEEEEEEEE"
}
```

#### 异常响应示例
```
 {"alipay_ebpp_invoice_enterpriseexctrl_employertitle_batchquery_response":{"code":"20000","msg":"Service Currently Unavailable","sub_code":"isp.unknow-error","sub_msg":"系统繁忙"},"sign":"ERITJKEIJKJHKKKKKKKHJEREEEEEEEEEEE"}
```

### 公共错误码
[前往查看](https://opendoc.alipay.com/common/02km9f)
### 业务错误码
|错误码|错误描述|解决方案|
|---|---|---|
|SYSTEM_ERROR|系统繁忙|服务器异常 可能发生了网络或者系统异常，导致服务调用失败，商户可以用同样的请求发起重试|
|PARAMETER_ILLEGAL|参数异常|【错误原因】参数异常。 【排查步骤】请检查参数格式、长度、是否可选等是否符合要求。|
|PERMISSION_DENIED|权限不足，未能查到企业和isv之间的映射关系|【错误原因】权限不足，未能查到企业和isv之间的映射关系。 【排查步骤】检查传入的企业ID或共同账户ID是否正确。|