# 已有项目衔接契约

已有项目增量接入时，第一轮只输出盘点和拟定契约，不修改代码。用户确认后，在生成目录写入 `.alipay-skill/integration-contract.json`，再开始发票域改造。

契约说明企业抬头、开票规则、发票通知和查询结果接到哪些既有对象或入口。它不是运行时依赖，而是生成与校验的衔接证据。

最小结构：

```json
{
  "schemaVersion": 1,
  "projectMode": "existing",
  "baseline": {
    "sdkVersion": "当前项目版本",
    "targetSdkVersion": "已确认的目标版本",
    "buildStatus": "passed | failed | not-run"
  },
  "domains": {
    "invoice": {
      "status": "CONFIRMED",
      "modules": {
        "enterpriseTitle": "REQUIRED",
        "openRule": "REQUIRED",
        "invoiceNotifyAndQuery": "REQUIRED",
        "employeeTitle": "NOT_SELECTED",
        "enterpriseTitleBatchQuery": "NOT_SELECTED",
        "invoiceBatchQuery": "NOT_SELECTED"
      },
      "joinPoints": [
        {
          "capability": "invoice.notify",
          "status": "CONFIRMED",
          "strategy": "service",
          "evidenceFiles": ["src/main/.../InvoiceService.java"],
          "symbols": ["InvoiceService"]
        }
      ],
      "changes": [
        {
          "path": "src/main/.../InvoiceNotifyHandler.java",
          "action": "add"
        }
      ]
    }
  },
  "gaps": []
}
```

规则：

1. `domains.invoice.status` 必须是 `CONFIRMED` 或 `NOT_APPLICABLE`。
2. 三个必选模块状态必须是 `REQUIRED`；选接模块使用 `SELECTED` 或 `NOT_SELECTED`。
3. 员工抬头为 `SELECTED` 时，契约或证据中必须记录准入已确认。
4. `joinPoints` 支持 service、repository、controller、event、gateway、other 等策略。
5. `evidenceFiles` 和 `changes.path` 必须指向项目内真实文件，不得逃出项目目录。
6. `gaps` 中不得保留 `NEEDS_USER_CONFIRM` 后继续生成。
7. 无法确认发票通知或查询结果如何衔接已有业务对象时，先在 `gaps` 中说明并暂停，不生成孤立旁路。
