# 发票 Java/Maven 质量门禁

本文件只用于发票 Skill 生成 Java/Maven 代码。通用原则见 [发票通用代码生成规则](../codegen-general-rules.md)，字段来源见 [发票字段与接口规则](../field-interface-rules.md)。

## SDK 与 OpenAPI

1. OpenAPI 正常调用使用官方 `Request + Model + request.setBizModel(model)`。实际 jar 中 Model 缺少文档必填 setter 时，先验证升级；若官方 Request 暴露 `setBizContent(String)`，允许按文档序列化缺失字段后继续使用 `AlipayClient.execute(request)`，由 SDK 托管请求签名和响应验签。场景接入的聚合 validator 不禁止这条 SDK 托管路径，不得以“聚合校验禁止手拼 `biz_content`”为由拒绝合法能力。禁止反射、Map 修改 SDK Model、本地 `com.alipay.api` 影子类或绕开官方 Client。
2. 生成前从 Central Portal 确认当前 `alipay-sdk-java` 版本；对项目实际解析的 jar 使用 `jar tf` 验证 8 个必选接口的 Request/Model/Response 以及 `AlipayMsgClient`、`MsgHandler`，再用 `javap -classpath <sdk.jar> <class>` 核验关键 getter/setter。
3. Maven 编译失败时修正真实 SDK 类型，不得用 stub、空实现或固定成功返回绕过。
4. 对 SDK typed response 逐个核对业务字段。企业抬头创建/修改、开票规则修改等响应暴露 `getSuccess()` 时，在网关 `code/subCode` 判断之外显式判断该字段；只有 `Boolean.TRUE` 是成功，`null` 与 `false` 都失败关闭，`AlipayResponse.isSuccess()` 不能替代它。
5. 必选字段在当前 SDK 缺 setter/getter 时依次检查可升级版本、官方 Request `setBizContent(...)` + SDK `execute(...)` 和文档允许的手工 HTTP(S) 方案。仍无法实现则停止并报告阻塞，不得以反射、Map、`UnsupportedOperationException` 或只支持部分合法枚举伪装完整能力。
6. 企业抬头创建/修改/查询、开票规则创建/修改/查询和单笔发票查询都在调用 SDK 前校验各自文档的必填、二选一、条件必填和枚举，不依赖网关代替本地输入校验。
7. 企业身份值本身必须拒绝 `null`、空字符串和纯空白；只校验 `identity` 对象非空不算完成。查询开票规则要在创建 Query Model 前显式校验 `invoice_rule_id` 非空白。
8. 接口证据表只作为生成过程中的结构化输出，记录 SDK 版本、类名和 `jar tf`/`javap` 结论；不要求生成固定证据文件，不用 validator 解析自然语言。SDK 成员真值由实际 jar 和编译结果确定。
9. 手工 HTTP(S) OpenAPI 仅在官方 Request 不支持 `setBizContent` 或 SDK 托管执行确实不可用时使用。客户端必须从完整响应中提取根节点 `sign`，并只对 `alipay_*_response` 的 JSON 值对象原文验签；起点是值对象的 `{`，不得从响应键名起截取。实际 SDK 若公开 `AlipaySignature.extractSignContent(...)` 则直接复用，否则实现等价提取并用官方结果做测试向量。RSA2 使用 `AlipaySignature.rsa256CheckContent(content, sign, publicKey, charset)`，或使用显式传入 `signType` 的五参 `rsaCheck(...)`/`rsaCertCheck(...)`；四参 `rsaCheckContent(...)` 在 `4.41.248` 中固定选择 RSA/SHA1，不得用于 RSA2。
10. 开票规则查询支持 SINGLE 时，查询 DTO 和映射必须保留 `bill_scope`、`combined_pay_mode`、`default_invoice_kind`；SDK record getter 缺失时使用 `response.getBody()` 补充，并按 `invoice_rule_record_id` 与 typed record 关联，禁止按数组下标配对。raw `open_mode` 不作为完整性判断依据；映射完成后遍历 typed records，以 typed `getOpenMode()` 识别 SINGLE，并对缺 ID、未匹配 raw 记录以及三个字段的 `null`/空字符串/纯空白统一抛业务异常。
11. 所有必填字符串（抬头、税号、规则名、规则 ID、条件必填的抬头 ID、收件人组等）拒绝纯空白。单笔发票查询的请求模型构建前必须同时拥有 `invoice_kind` 与 `invoice_code` 并完成条件校验。

## WebSocket 消息接入

全新、独立且无其他约束的 Java 接入默认推荐官方 WebSocket；存量 HTTP 订阅、项目已有 HTTP 入口或用户明确选择 HTTP 时，本节不构成迁移要求。已选择 WebSocket 时：

1. 只允许 `AlipayMsgClient + MsgHandler`；不得使用 `@ClientEndpoint`、`Java-WebSocket`、`javax.websocket` 或 `jakarta.websocket` 手写协议。
2. 必须包含 `getInstance`、`setConnector`、`setSecurityConfig` 或 `setSecurityCertConfig`、`setMessageHandler`、`connect` 和应用关闭时的连接释放。
3. `setSecurityConfig` 第一个参数是 `signType`，不是 `appId`。所有配置在 `connect` 前完成。
4. `msgApi` 只把 `alipay.ebpp.invoice.enterprise.newinvoice.notify` 路由到发票 handler；未知消息默认抛异常或交给显式 unknown handler。
5. 使用 `msgId` 做投递幂等；处理中冲突、详情查询失败或业务落库失败必须抛异常，不能吞异常后正常返回。
6. WebSocket SDK 已处理通道签名，不得把 `bizContent` 再按 HTTP 公共参数执行 `rsaCheck`。
7. 初次 `connect` 失败必须失败启动，或同时具备重试与 readiness/health 降级信号，不能只记录日志后让应用继续运行。

由方案型 Skill 统一消息接入时，本域不得创建独立客户端，只生成接受 `msgApi`、`msgId`、`bizContent` 的发票 handler。运行 validator 时设置 `ALIPAY_MESSAGE_ROUTER_MODE=shared`。

## HTTP(S) 消息接入

1. 使用 SDK `AlipaySignature.rsaCheck` / `rsaCheckV1` 或证书验签能力校验完整原始参数，验签后再解析 `biz_content`。
2. 使用 `notify_id` 做投递幂等，成功返回 `success`、失败返回 `fail`。
3. 验签、幂等、字段校验、详情查询或业务处理任一步骤失败都不得确认成功。
4. `biz_content` 必须校验全部文档必填字段、`invoice_kind`、`notify_reason`、`collect_source` 枚举和 `invoice_code` 条件必填；未知值失败关闭。

## 工程质量

1. 代码生成交付必须为投递幂等和发票业务落库提供可替换接口。没有数据库依赖时，fail-closed 实现必须是无 Spring stereotype 的普通类，由独立 `@Configuration` 中的 `@Bean` 方法创建，并在工厂方法上使用 `@ConditionalOnMissingBean(<Port>.class)`；不能把条件注解直接放到普通扫描的 `@Component/@Repository` 实现类上，也不能标 `@Primary`。未绑定生产实现时抛异常或返回失败，让平台重试，不把通知误确认成功。validator 校验这个安全扩展边界，不要求生成环境预装数据库。`Map`/`Set` 等进程内实现只允许 `local/demo/test` profile。
2. 核心 Handler、Router、Service 不得被 `demo/test` profile 包住。
3. H2 和 `ddl-auto=update/create` 只允许明确的 local/demo/test profile；默认及生产配置使用外部共享 RDBMS。`REPLACE_WITH_*` 等占位凭据允许存在于示例配置，但必须通过配置校验使应用启动失败。
4. 测试至少覆盖正常通知、重复通知、处理中冲突、未知消息、详情查询失败和业务失败重试；业务失败后的第二次投递必须用调用次数或状态转换断言证明详情查询与业务落地被重新执行，连续两次只写 `assertThrows` 不算重试证据。负例逐项覆盖 7 个必填业务字段为空以及 `invoice_kind`、`notify_reason`、`collect_source` 三个枚举越界。
5. 企业抬头、开票规则和单笔发票查询分别具有聚焦测试。单笔查询在 SDK 调用前拒绝请求 `invoice_kind` 枚举外值；网关成功后逐项校验文档必填响应字段，核对响应 `enterprise_id`、`invoice_no`、`invoice_kind` 及条件适用的 `invoice_code` 与请求一致，并拒绝响应枚举外值。`row_type` 是可选字段：缺失或空白时接受，非空时只接受 `0/1/2`。测试分别覆盖非法请求种类、必填响应字段缺失、响应种类错配、非数电票响应代码缺失/错配、嵌套发票项目、非法金额、非法 `row_type`，以及 `row_type` 缺失和空白的成功路径；不能用一个非法 `invoice_type` 测试替代所有响应枚举。使用 `response.getBody()` 补充 SDK 未暴露字段时，还必须测试响应节点缺失和字段映射。开票规则额外覆盖 raw 记录乱序、raw 数组缺失、typed SINGLE 无匹配 raw 记录、raw `open_mode` 缺失时仍按 typed SINGLE 校验，以及三个专属字段为空白。
6. 生成后运行本域 validator、`mvn clean test` 和必要的集成测试；clean 是最终证据的一部分，避免已删除测试的 class/报告残留在 `target` 中继续被统计。零测试或只测试通知模块不算通过。
7. 默认/生产数据源选择 MySQL、PostgreSQL 等数据库时，构建依赖必须包含对应 JDBC driver；使用 `ddl-auto=validate` 时同时交付 Flyway/Liquibase 迁移或 `schema.sql`，并至少运行一次非嵌入式数据源启动测试。
8. 支付宝配置校验同时拒绝 `null`、空字符串、纯空白和示例占位值；测试覆盖 `REPLACE_WITH_*`、`CHANGE_ME`、`YOUR_*` 三类占位值，并证明 `appId`、应用私钥和支付宝公钥各自不能绕过，不能只测其中一个字段或一类字面量。
9. `FailClosedInvoiceBusinessAdapter`、fail-closed `NotifyIdempotencyStore` 可作为集成交付的生产默认边界，前提是实现类不参与组件扫描，由独立配置类的条件 `@Bean` 工厂装配、不标 `@Primary`，并确保失败传播到消息重试。至少用加载真实启动类的 Spring 上下文测试同时验证：默认 profile 能取得 fail-closed Bean，local/demo 实现或接入方测试 Bean 存在时默认 Bean让位，且共享路由集合明确包含 `InvoiceNotifyHandler.MSG_API` 或 `alipay.ebpp.invoice.enterprise.newinvoice.notify`；仅断言路由数量大于零不算发票接入证据。生产部署是否已绑定真实 Bean 属于部署就绪检查，不作为代码生成 validator 的完成条件。
10. validator 输出 `OK` 前不得存在必选接口“未实现/阻塞/待确认”的披露。若确有外部阻塞，validator 应非零退出，回执报告阻塞而不是通过改措辞取得绿灯。
11. `SINGLE` 分支内因条件必填、长度或枚举非法而抛参数异常是正常校验，不代表拒绝 `SINGLE` 能力。validator 只依据明确未实现语义、固定不支持异常或只支持 `SUMMARY` 的证据判定能力缺失，不按附近任意 `throw` 推断。
12. `FAILED -> PENDING` 重试取得必须在同一 CAS 更新中刷新处理租约时间；测试用一个早已过期的失败记录验证重新取得后不会立即满足 stale 条件。
13. 业务落地接口必须传递 `enterprise_id + invoice_no + invoice_code` 业务键。项目选择内置持久化实现时，对业务键建立唯一约束并覆盖并发冲突及不同投递 ID 的去重测试；项目只交付 fail-closed 扩展边界时，不强制引入数据库驱动、表结构或数据库并发测试。
14. 占位凭据判断使用归一化值，测试至少包含带前导空白和尾随空白的占位值。仅测试原样 `REPLACE_WITH_*` 不能证明启动期失败关闭完整。
15. 手工 OpenAPI 网关测试既覆盖响应签名缺失、错误或篡改，也用临时 RSA 密钥和 RSA2/SHA256 生成合法签名，验证正确响应能够通过；正向测试的签名原文必须是响应值对象。官方 Request 的 `setBizContent` workaround 使用 `ArgumentCaptor`/`argThat` 或等价方式取得真实 Request，把 `getBizContent()` 解析为 JSON，并逐值断言企业身份、`tax_register_no`，或开票规则 create/modify 的身份、规则 ID/名称与 SINGLE 三字段；只写 `executor.execute(any())`、成功响应或 `contains("field")` 键名检查不算覆盖。项目选择内置数据库持久化时，业务键数据库测试必须真实触发并发唯一键冲突；只交付 fail-closed Port 边界时不适用。
16. 若生成 README、SDK 证据表、DTO/Javadoc 或配置注释，交付前对照实际 jar 的 `javap`、最终源码和生效配置复核。文档不得引用不存在的类/方法，不得把 SDK 托管 `setBizContent + AlipayClient.execute` 描述为手工 HTTP 网关，不得对同一 SDK setter 给出互相矛盾的存在性结论，也不得保留“请求一律 setBizModel”、默认 H2 或默认固定失败适配器等已失效声明。
