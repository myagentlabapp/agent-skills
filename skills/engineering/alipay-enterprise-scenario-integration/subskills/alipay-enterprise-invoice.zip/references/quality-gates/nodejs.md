# 发票 Node.js 质量门禁

本文件只约束 Node.js 生成代码。通用原则见 [发票通用代码生成规则](../codegen-general-rules.md)，字段来源见 [发票字段与接口规则](../field-interface-rules.md)。

1. 当前仅按 HTTP(S) 应用网关接入发票通知，不生成非官方 WebSocket 协议客户端。
2. 读取真实安装的 `alipay-sdk` 导出；CommonJS 使用 `const { AlipaySdk } = require("alipay-sdk")`，不得使用未经验证的 `.default`。
3. HTTP(S) 验签使用 SDK `checkNotifySign` / `checkNotifySignV2`；不得手写 `crypto.createVerify`。异步验签必须 `await`。
4. 使用原始表单参数验签后再解析 `biz_content`；不得只对 JSON 业务内容验签。
5. 使用 `notify_id` 做投递幂等，成功返回 `success`、失败返回 `fail`。验签、字段、详情查询或业务处理失败不得确认成功。
6. OpenAPI `appAuthToken` 必须放在 SDK 要求的网关参数位置并参与签名。
7. 生成后通过本域 validator、`node --check`、模块加载和 `npm test`。
