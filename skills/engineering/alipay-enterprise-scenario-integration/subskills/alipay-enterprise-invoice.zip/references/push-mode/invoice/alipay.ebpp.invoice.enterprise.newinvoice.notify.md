# alipay.ebpp.invoice.enterprise.newinvoice.notify(企业票夹票据变更通知)
企业票夹企业票据发生变更后，通知企业
## 公共请求参数
|参数英文名|类型|是否必选|最大长度|描述|示例值|
|---|---|---|---|---|---|
|notify_id|String|必选|50|通知ID|5608cccc09ddb39d41c2e3c06e3d9fejh2|
|utc_timestamp|String|必选|13|消息发送时的服务端时间|1514210452731|
|msg_method|String|必选|100|消息接口名称|alipay.ebpp.invoice.enterprise.newinvoice.notify|
|app_id|String|必选|20|消息接受方的应用id|2014060600164699|
|version|String|必选|5|版本号(1.1版本为标准消息)|1.0或者1.1|
|biz_content|String|必选||消息报文|参见消息属性|
|sign|String|必选||签名|WcO+t3D8Kg71dTlKwN7r9PzUOXeaBJwp8/FOuSxcuSkXsoVYxBpsAidprySCjHCjmaglNcjoKJQLJ28/Asl93joTW39FX6i07lXhnbPknezAlwmvPdnQuI01HZsZF9V1i6ggZjBiAd5lG8bZtTxZOJ87ub2i9GuJ3Nr/NUc9VeY=|
|sign_type|String|必选|10|签名类型|RSA2|
|charset|String|必选|10|编码集，该字符集为验签和解密所需要的字符集|UTF-8|
## 消息属性
|参数英文名|类型|是否必选|最大长度|描述|示例值|
|---|---|---|---|---|---|
|enterprise_id|String|必选|32|企业ID|2088441400705849|
|employee_id|String|必选|32|员工id|2288xxx|
|einv_id|String|必选|64|发票id|2024112800152005000000000239|
|invoice_no|String|必选|20|发票号码|12345678|
|invoice_kind|String|必选|10|发票种类<br>**枚举值**<br>增值税普通电子发票:0<br>增值税普通发票:1<br>增值税专用发票:2<br>增值税专用电子发票:3<br>财政电子发票:4<br>电子发票（普通发票）:32<br>电子发票（增值税专用发票）:31|0|
|notify_reason|String|必选|32|通知原因<br>**枚举值**<br>票据新增:INVOICE_COLLECT<br>发票信息变更:INVOICE_INFO_CHANGE|INVOICE_COLLECT|
|collect_source|String|必选|32|发票归集来源<br>**枚举值**<br>收票邮箱:INVOICE_EMAIL<br>其他:OTHER|INVOICE_EMAIL|
|invoice_code|String|条件必选|20|发票代码<br>**必选条件**<br>当传入invoice_kind为31或32时，可以为空，否则不可为空|123456781234|
## 消息示例
### 默认示例
#### cURL
```bash
curl -X POST 'NOTIFY_URL' \
--header 'Content-Type: application/x-www-form-urlencoded; charset=UTF-8' \
--data-urlencode 'charset=UTF-8' \
--data-urlencode 'biz_content={
	"enterprise_id":"2088441400705849",
	"employee_id":"2288xxx",
	"einv_id":"2024112800152005000000000239",
	"invoice_code":"123456781234",
	"invoice_no":"12345678",
	"invoice_kind":"0",
	"notify_reason":"INVOICE_COLLECT",
	"collect_source":"INVOICE_EMAIL"
}' \
--data-urlencode 'utc_timestamp=${now}' \
--data-urlencode 'sign=${sign}' \
--data-urlencode 'app_id=${appid}' \
--data-urlencode 'version=1.1' \
--data-urlencode 'sign_type=RSA2' \
--data-urlencode 'notify_id=${notify_id}' \
--data-urlencode 'msg_method=alipay.ebpp.invoice.enterprise.newinvoice.notify'
```

说明：NOTIFY_URL是开发者在开放平台控制台上设置的应用网关地址
## 通知应答
|响应报文|描述|是否重试|是否区分大小写|
|---|---|---|---|
|success|消息处理成功|否|否|
|fail|消息处理失败|是|否|

说明：消息服务会根据响应报文判断商户系统是否已经成功处理消息。如果HTTP同步响应报文返回 success 字符串，消息服务则认为消息已经处理成功，停止投递，如果返回 fail ，表示消息获取失败，支付宝会根据投递重试策略重新发送消息到应用网关地址；

投递重试策略：一般情况下，25 小时以内完成 8 次通知，除了第一次是实时投递外，后续的每次重试都会间隔一段时间，间隔频率一般是：2m、10m、10m、1h、2h、6h、15h（第二次消息投递是在第一次投递失败后的 2 分钟；第三次投递是在第二次投递失败后的 10 分钟，以此类推）