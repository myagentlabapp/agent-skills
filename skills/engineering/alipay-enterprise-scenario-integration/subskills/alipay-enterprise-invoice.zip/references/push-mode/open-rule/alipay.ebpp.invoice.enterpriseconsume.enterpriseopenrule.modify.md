# alipay.ebpp.invoice.enterpriseconsume.enterpriseopenrule.modify(修改开票规则)
支持第三方代理调用：本接口支持第三方开发者代用户发起调用
## 通用场景
修改开票规则
### 公共请求参数
|参数英文名|类型|是否必选|长度/取值|描述|示例值|
|---|---|---|---|---|---|
|app_id|String|必选|32|支付宝分配给开发者的应用ID|2014072300007148|
|method|String|必选|128|接口名称|alipay.ebpp.invoice.enterpriseconsume.enterpriseopenrule.modify|
|format|String|可选|40|仅支持JSON|JSON|
|charset|String|必选|10|请求使用的编码格式，如utf-8,gbk,gb2312等|utf-8|
|sign_type|String|必选|10|商户生成签名字符串所使用的签名算法类型，目前支持RSA2和RSA，推荐使用RSA2|RSA2|
|sign|String|必选|344|商户请求参数的签名串，详见[签名](https://opendocs.alipay.com/common/02khjm)|详见示例|
|timestamp|String|必选|19|发送请求的时间，格式"yyyy-MM-dd HH:mm:ss"|2014-07-24 03:07:50|
|version|String|必选|3|调用的接口版本，固定为：1.0|1.0|
|app_auth_token|String|可选|40|详见[应用授权概述](https://opendocs.alipay.com/isv/10467/xldcyq)||
|biz_content|String|必选||请求参数的集合，最大长度不限，除公共参数外所有请求参数都必须放在这个参数中传递，具体参照各产品快速接入文档||
### 业务请求参数
|参数英文名|类型|是否必选|长度/取值|描述|示例值|
|---|---|---|---|---|---|
|enterprise_id|String|特殊可选|32|企业ID<br>**注意事项**<br>通过企业码2.0签约接口签约，只填写企业id，无需填写共同账户id和授权签约协议号。|2088000194958956|
|invoice_rule_id|String|必须|32|开票规则ID|2021032900152710950000000001|
|invoice_rule_name|String|必须|20|开票规则名称|开票规则测试2|
|seller_type|String|必须|100|销方类型<br>**枚举值**<br>TP开票:TP<br>商户开票:MERCHANT|TP|
|invoice_title_id|String|可选|100|发票抬头<br>**注意事项**<br>仅汇总开且tag不等于EMPLOYEE_TITLE_FIRST（员工签约优先）场景下，该字段必填|2021080500152710850000000421|
|account_id|String|特殊可选|32|企业共同账户ID<br>**注意事项**<br>通过企业码1.0接口签约的共同账户，和agreement_no搭配使用。|2088000194958956|
|agreement_no|String|特殊可选|100|授权签约协议号<br>**注意事项**<br>授权签约协议号 可通过签约消息获取。配合共同账户id使用，当填写企业共同账户id时，此字段必填。|20215425001112341234|
|receive_name|String|特殊可选|10|收件人姓名<br>**注意事项**<br>填写收件人姓名，用于接收纸质发票。收件人信息保证完整，即收件人姓名，电话，地址要么全填写，要么都不填。|张三|
|receive_phone|String|特殊可选|11|收件人手机号<br>**注意事项**<br>填写收件人手机号，用于邮寄纸质发票时使用。收件人信息保证完整，即收件人姓名，电话，地址要么全填写，要么都不填。|15555555555|
|receive_address|String|特殊可选|100|收件人地址<br>**注意事项**<br>填写收件人地址，用于接受纸质发票使用。收件人信息保证完整，即收件人姓名，电话，地址要么全填写，要么都不填。|杭州市西湖区|
|bill_scope|String|特殊可选|64|开票账单范围<br>**枚举值**<br>因公企业代付:PEER_PAY<br><br>**必选条件**<br>当传入open_mode，且open_mode=SINGLE时必选|PEER_PAY|
|combined_pay_mode|String|特殊可选|64|组合支付模式<br>**枚举值**<br>仅企业代付部分开票:ONLY_PEER_PAY<br>全部金额开票:ALL_AMOUNT<br><br>**必选条件**<br>当传入bill_scope，且bill_scope=SINGLE时必选|ONLY_PEER_PAY|
|default_invoice_kind|String|特殊可选|64|默认开票类型<br>**枚举值**<br>专票(默认):SPECIAL<br>普票:NORMAL<br><br>**必选条件**<br>当传入bill_scope，且bill_scope=SINGLE时必选|SPECIAL|
### 请求示例
#### 默认示例
##### java
```
 package com.java.sdk.demo;

import com.alipay.api.AlipayApiException;
import com.alipay.api.AlipayClient;
import com.alipay.api.DefaultAlipayClient;
import com.alipay.api.AlipayConfig;
import com.alipay.api.response.AlipayEbppInvoiceEnterpriseconsumeEnterpriseopenruleModifyResponse;
import com.alipay.api.request.AlipayEbppInvoiceEnterpriseconsumeEnterpriseopenruleModifyRequest;
import com.alipay.api.domain.AlipayEbppInvoiceEnterpriseconsumeEnterpriseopenruleModifyModel;

import com.alipay.api.FileItem;
import java.util.Base64;
import java.util.ArrayList;
import java.util.List;

public class AlipayEbppInvoiceEnterpriseconsumeEnterpriseopenruleModify {

    public static void main(String[] args) throws AlipayApiException {
        // 初始化SDK
        AlipayClient alipayClient = new DefaultAlipayClient(getAlipayConfig());

        // 构造请求参数以调用接口
        AlipayEbppInvoiceEnterpriseconsumeEnterpriseopenruleModifyRequest request = new AlipayEbppInvoiceEnterpriseconsumeEnterpriseopenruleModifyRequest();
        AlipayEbppInvoiceEnterpriseconsumeEnterpriseopenruleModifyModel model = new AlipayEbppInvoiceEnterpriseconsumeEnterpriseopenruleModifyModel();

        // 设置企业id
        model.setEnterpriseId("2088000194958956");

        // 设置开票规则ID
        model.setInvoiceRuleId("2021032900152710950000000001");

        // 设置开票规则名称
        model.setInvoiceRuleName("开票规则测试2");

        // 设置销方类型
        model.setSellerType("TP");

        // 设置发票抬头
        model.setInvoiceTitleId("2021080500152710850000000421");

        // 设置企业共同账户ID
        model.setAccountId("2088000194958956");

        // 设置授权签约协议号
        model.setAgreementNo("20215425001112341234");

        // 设置收件人姓名
        model.setReceiveName("张三");

        // 设置收件人手机号
        model.setReceivePhone("15555555555");

        // 设置收件人地址
        model.setReceiveAddress("杭州市西湖区");

        // 设置账单范围
        model.setBillScope("PEER_PAY");

        // 设置组合支付模式
        model.setCombinedPayMode("ONLY_PEER_PAY");

        // 设置默认开票类型
        model.setDefaultInvoiceKind("SPECIAL");

        request.setBizModel(model);
        // 第三方代调用模式下请设置app_auth_token
        // request.putOtherTextParam("app_auth_token", "<-- 请填写应用授权令牌 -->");

        AlipayEbppInvoiceEnterpriseconsumeEnterpriseopenruleModifyResponse response = alipayClient.execute(request);
        System.out.println(response.getBody());

        if (response.isSuccess()) {
            System.out.println("调用成功");
        } else {
            System.out.println("调用失败");
            // sdk版本是"4.38.0.ALL"及以上,可以参考下面的示例获取诊断链接
            // String diagnosisUrl = DiagnosisUtils.getDiagnosisUrl(response);
            // System.out.println(diagnosisUrl);
        }
    }

    private static AlipayConfig getAlipayConfig() {
        String privateKey  = "<-- 请填写您的应用私钥，例如：MIIEvQIBADANB ... ... -->";
        String alipayPublicKey = "<-- 请填写您的支付宝公钥，例如：MIIBIjANBg... -->";
        AlipayConfig alipayConfig = new AlipayConfig();
        alipayConfig.setServerUrl("https://openapi.alipay.com/gateway.do");
        alipayConfig.setAppId("<-- 请填写您的AppId，例如：2019091767145019 -->");
        alipayConfig.setPrivateKey(privateKey);
        alipayConfig.setFormat("json");
        alipayConfig.setAlipayPublicKey(alipayPublicKey);
        alipayConfig.setCharset("UTF-8");
        alipayConfig.setSignType("RSA2");
        return alipayConfig;
    }
}
```


##### php
```
 <?php
require_once '../aop/AopClient.php';
require_once '../aop/AopCertClient.php';
require_once '../aop/AopCertification.php';
require_once '../aop/AlipayConfig.php';
require_once '../aop/request/AlipayEbppInvoiceEnterpriseconsumeEnterpriseopenruleModifyRequest.php';

// 初始化SDK
$alipayClient = new AopClient(getAlipayConfig());
// 构造请求参数以调用接口
$request = new AlipayEbppInvoiceEnterpriseconsumeEnterpriseopenruleModifyRequest();
$model = array();

// 设置企业id
$model['enterprise_id'] = "2088000194958956";

// 设置开票规则ID
$model['invoice_rule_id'] = "2021032900152710950000000001";

// 设置开票规则名称
$model['invoice_rule_name'] = "开票规则测试2";

// 设置销方类型
$model['seller_type'] = "TP";

// 设置发票抬头
$model['invoice_title_id'] = "2021080500152710850000000421";

// 设置企业共同账户ID
$model['account_id'] = "2088000194958956";

// 设置授权签约协议号
$model['agreement_no'] = "20215425001112341234";

// 设置收件人姓名
$model['receive_name'] = "张三";

// 设置收件人手机号
$model['receive_phone'] = "15555555555";

// 设置收件人地址
$model['receive_address'] = "杭州市西湖区";

// 设置账单范围
$model['bill_scope'] = "PEER_PAY";

// 设置组合支付模式
$model['combined_pay_mode'] = "ONLY_PEER_PAY";

// 设置默认开票类型
$model['default_invoice_kind'] = "SPECIAL";

$request->setBizContent(json_encode($model,JSON_UNESCAPED_UNICODE));
// 如果是第三方代调用模式，请设置app_auth_token（应用授权令牌）
$responseResult = $alipayClient->execute($request, null, "<-- 请填写应用授权令牌 -->", null);
$responseApiName = str_replace(".","_",$request->getApiMethodName())."_response";
$response = $responseResult->$responseApiName;
if(!empty($response->code)&&$response->code==10000){
    echo("调用成功");
}
else{
    echo("调用失败");
}

function getAlipayConfig()
{
    $privateKey  = '<-- 请填写您的应用私钥，例如：MIIEvQIBADANB ... ... -->';
    $alipayPublicKey = '<-- 请填写您的支付宝公钥，例如：MIIBIjANBg... -->';
    $alipayConfig = new AlipayConfig();
    $alipayConfig->setServerUrl('https://openapi.alipay.com/gateway.do');
    $alipayConfig->setAppId('<-- 请填写您的AppId，例如：2019091767145019 -->');
    $alipayConfig->setPrivateKey($privateKey);
    $alipayConfig->setFormat('json');
    $alipayConfig->setAlipayPublicKey($alipayPublicKey);
    $alipayConfig->setCharset('UTF-8');
    $alipayConfig->setSignType('RSA2');
    return $alipayConfig;
}
```


##### csharp
```
 using System;
using System.Collections.Generic;
using Aop.Api;
using Aop.Api.Request;
using Aop.Api.Response;
using Aop.Api.Domain;
using Aop.Api.Util;
namespace SdkDemoTest
{
    public class AlipayEbppInvoiceEnterpriseconsumeEnterpriseopenruleModify
    {
        public static void Main(string[] args)
        {
            // 初始化SDK
            IAopClient alipayClient = new DefaultAopClient(GetAlipayConfig());
            // 构造请求参数以调用接口
            AlipayEbppInvoiceEnterpriseconsumeEnterpriseopenruleModifyRequest request = new AlipayEbppInvoiceEnterpriseconsumeEnterpriseopenruleModifyRequest();
            AlipayEbppInvoiceEnterpriseconsumeEnterpriseopenruleModifyModel model = new AlipayEbppInvoiceEnterpriseconsumeEnterpriseopenruleModifyModel();

            // 设置企业id
            model.EnterpriseId = "2088000194958956";

            // 设置开票规则ID
            model.InvoiceRuleId = "2021032900152710950000000001";

            // 设置开票规则名称
            model.InvoiceRuleName = "开票规则测试2";

            // 设置销方类型
            model.SellerType = "TP";

            // 设置发票抬头
            model.InvoiceTitleId = "2021080500152710850000000421";

            // 设置企业共同账户ID
            model.AccountId = "2088000194958956";

            // 设置授权签约协议号
            model.AgreementNo = "20215425001112341234";

            // 设置收件人姓名
            model.ReceiveName = "张三";

            // 设置收件人手机号
            model.ReceivePhone = "15555555555";

            // 设置收件人地址
            model.ReceiveAddress = "杭州市西湖区";

            // 设置账单范围
            model.BillScope = "PEER_PAY";

            // 设置组合支付模式
            model.CombinedPayMode = "ONLY_PEER_PAY";

            // 设置默认开票类型
            model.DefaultInvoiceKind = "SPECIAL";

            request.SetBizModel(model);
            // 第三方代调用模式下请设置app_auth_token
            // request.PutOtherTextParam("app_auth_token", "<-- 请填写应用授权令牌 -->");

            AlipayEbppInvoiceEnterpriseconsumeEnterpriseopenruleModifyResponse response = alipayClient.Execute(request);

            if(!response.IsError)
            {
                Console.WriteLine("调用成功");
            }
            else
            {
                Console.WriteLine("调用失败");
            }
        }

        private static AlipayConfig GetAlipayConfig()
        {
            string privateKey  = "<-- 请填写您的应用私钥，例如：MIIEvQIBADANB ... ... -->";
            string alipayPublicKey = "<-- 请填写您的支付宝公钥，例如：MIIBIjANBg... -->";
            AlipayConfig alipayConfig = new AlipayConfig();
            alipayConfig.ServerUrl = "https://openapi.alipay.com/gateway.do";
            alipayConfig.AppId = "<-- 请填写您的AppId，例如：2019091767145019 -->";
            alipayConfig.PrivateKey = privateKey;
            alipayConfig.Format = "json";
            alipayConfig.AlipayPublicKey = alipayPublicKey;
            alipayConfig.Charset = "UTF-8";
            alipayConfig.SignType = "RSA2";
            return alipayConfig;
        }
    }
}
```


##### http
```
 curl 'https://openapi.alipay.com/gateway.do?charset=UTF-8&method=alipay.ebpp.invoice.enterpriseconsume.enterpriseopenrule.modify&format=json&sign=${sign}&app_id=${appid}&version=1.0&sign_type=RSA2&timestamp=${now}' \
 -F 'app_auth_token=${app_auth_token}' \
 -F 'biz_content={
	"enterprise_id":"2088000194958956",
	"invoice_rule_id":"2021032900152710950000000001",
	"invoice_rule_name":"开票规则测试2",
	"seller_type":"TP",
	"invoice_title_id":"2021080500152710850000000421",
	"account_id":"2088000194958956",
	"agreement_no":"20215425001112341234",
	"receive_name":"张三",
	"receive_phone":"15555555555",
	"receive_address":"杭州市西湖区",
	"bill_scope":"PEER_PAY",
	"combined_pay_mode":"ONLY_PEER_PAY",
	"default_invoice_kind":"SPECIAL"
}'
```


### 公共响应参数
|参数英文名|类型|是否必选|长度/取值|描述|示例值|
|---|---|---|---|---|---|
|code|String|必须|~|网关返回码，[详见文档](https://docs.open.alipay.com/common/105806)|40004|
|msg|String|必须|~|网关返回码描述，[详见文档](https://docs.open.alipay.com/common/105806)|Business Failed|
|sub_code|String|可选|~|业务返回码，参见具体的API接口文档||
|sub_msg|String|可选|~|业务返回码描述，参见具体的API接口文档||
|sign|String|必须|64|签名，[详见文档](https://docs.open.alipay.com/291/106074)|DZXh8eeTuAHoYE3w1J+POiPhfDxOYBfUNn1lkeT/V7P4zJdyojWEa6IZs6Hz0yDW5Cp/viufUb5I0/V5WENS3OYR8zRedqo6D+fUTdLHdc+EFyCkiQhBxIzgngPdPdfp1PIS7BdhhzrsZHbRqb7o4k3Dxc+AAnFauu4V6Zdwczo=|
### 业务响应参数
|参数英文名|类型|是否必选|长度/取值|描述|示例值|
|---|---|---|---|---|---|
|success|Boolean|必须|100|success|true|
### 响应示例
#### 正常响应示例
```
 {
	"alipay_ebpp_invoice_enterpriseconsume_enterpriseopenrule_modify_response":{
		"code":"10000",
		"msg":"Success",
		"success":true
	},
	"sign":"ERITJKEIJKJHKKKKKKKHJEREEEEEEEEEEE"
}
```

#### 异常响应示例
```
 {"alipay_ebpp_invoice_enterpriseconsume_enterpriseopenrule_modify_response":{"code":"20000","msg":"Service Currently Unavailable","sub_code":"isp.unknow-error","sub_msg":"系统繁忙"},"sign":"ERITJKEIJKJHKKKKKKKHJEREEEEEEEEEEE"}
```

### 公共错误码
[前往查看](https://opendoc.alipay.com/common/02km9f)
### 业务错误码
|错误码|错误描述|解决方案|
|---|---|---|
|SYSTEM_ERROR|系统繁忙|服务器异常 可能发生了网络或者系统异常，导致服务调用失败，商户可以用同样的请求发起重试|
|BIZ_ERROR|业务异常业务异常|重试|
|ENTERPRISE_TITLE_NOT_EXISTS|企业抬头不存在|检查传入的抬头ID是否正确|
|INVOICE_RULE_FUTURE_EXIST|已存在一个未生效规则|不允许修改开票模式|
|INVOICE_RULE_MODIFIED_FAIL|修改开票规则失败|重试|
|INVOICE_RULE_NAME_EXIST|开票规则名称已存在|修改开票规则名称|
|INVOICE_RULE_NAME_ILLEGAL|开票名称敏感词|输入非敏感词|
|INVOICE_RULE_NAME_TOO_LONG|开票规则名称过长|修改开票规则名称长度|
|INVOICE_RULE_NOT_EXIST|开票规则不存在|检查传入的企业ID和开票规则ID是否正确|
|PARAMETER_ILLEGAL|参数不合法|修改参数|
|PERMISSION_DENIED|权限不足，未能查到企业和isv之间的映射关系|检查传入的企业ID是否正确|