# 企业码发票集成流程（推模式，主要推荐）

## 概述

推模式以企业票夹票据变更通知为主入口。接入方先维护企业抬头和开票规则；支付宝在企业票夹票据新增或信息变更后推送消息，接入方验签并查询单笔发票详情，再衔接发票、报销、账单或档案业务。

基础接入必须包含企业抬头、开票规则、发票消息和单笔发票查询。批量查询只用于初始化、补偿或运营查询，不能替代通知主链路。

## 消息接入方式

发票变更通知属于 From 蚂蚁消息。订阅 `alipay.ebpp.invoice.enterprise.newinvoice.notify` 时选择一种投递方式：

| 接入方式 | 适用场景 | 处理语义 |
|---|---|---|
| Java WebSocket 长连接（推荐） | 全新 Java 服务、消息量大或实时性要求高，希望免应用网关和协议验签 | 官方 `AlipayMsgClient + MsgHandler` 自动处理通道与签名；用 `msgId` 幂等，失败时抛异常 |
| HTTP(S) 应用网关 | 非 Java 技术栈、消息量小、存量 HTTP 订阅或项目已有统一 HTTP 消息网关 | 使用原始公共参数验签；用 `notify_id` 幂等，返回 `success/fail` |

按“上游方案统一入口 > 用户明确指定 > 存量订阅或项目已有入口 > 新建项目默认”的优先级选择通道。方案型 Skill 调用时沿用上游统一消息入口，只生成可被公共路由调用的发票 handler。存量 HTTP 订阅或现有 HTTP 入口默认保持不变，只在用户明确要求时迁移。全新、独立且无其他约束的 Java 接入默认推荐 WebSocket；其他技术栈默认使用 HTTP(S)。详细配置见 [通用消息接口集成](../common/message-integration.md) 和 [WebSocket 长连接接入](../common/websocket-integration.md)。

## 主流程

```text
企业抬头创建/修改/查询
          |
          v
开票规则创建/修改/查询
          |
          v
企业票夹票据新增或信息变更
          |
          v
接收 newinvoice.notify
          |
          v
传输校验 -> notify_id/msgId 幂等占位 -> 校验消息字段
          |
          v
按 enterprise_id + invoice_no + 条件 invoice_code 查询单笔发票
          |
          v
写入真实发票/报销/账单/档案业务
          |
          v
标记处理完成并返回 success
```

任一步骤失败时不得提前标记完成。HTTP(S) 返回 `fail`；WebSocket 回调抛出异常，让消息服务触发重试。

## 必选模块

### 1. 企业抬头

| 能力 | 接口 |
|---|---|
| 新增企业抬头 | `alipay.ebpp.invoice.enterpriseexctrl.employertitle.create` |
| 修改企业抬头 | `alipay.ebpp.invoice.enterpriseexctrl.employertitle.modify` |
| 查询企业抬头 | `alipay.ebpp.invoice.enterpriseexctrl.employertitle.query` |

企业码 2.0 使用 `enterprise_id`；企业码 1.0 使用 `account_id` 与 `agreement_no` 的文档组合。不要把两套身份字段无条件同时发送。

查询接口中 `title_id` 与 `tax_register_no` 按文档二选一。创建返回的 `title_id` 应持久化并用于开票规则关联。

### 2. 开票规则

| 能力 | 接口 |
|---|---|
| 新增开票规则 | `alipay.ebpp.invoice.enterpriseconsume.enterpriseopenrule.create` |
| 修改开票规则 | `alipay.ebpp.invoice.enterpriseconsume.enterpriseopenrule.modify` |
| 查询开票规则 | `alipay.ebpp.invoice.enterpriseconsume.enterpriseopenrule.query` |

创建规则时：

- `open_mode=SUMMARY` 时，`bill_month_day` 必填；`tag` 不是 `EMPLOYEE_TITLE_FIRST` 时 `invoice_title_id` 必填。
- `open_mode=SINGLE` 时，按文档填写 `bill_scope`、`combined_pay_mode` 和 `default_invoice_kind`。
- 纸票收件人姓名、电话和地址要么全部填写，要么全部不填。

修改接口文档没有把 `open_mode` 列为请求字段，却在部分字段说明中引用它。生成代码时只能发送参数表中的字段，不得自行添加 `open_mode`；如果业务需要改变开票模式，应把该文档缺口列为待确认事项。

### 3. 发票消息与查询

| 能力 | 接口/消息 |
|---|---|
| 企业票夹票据变更通知 | `alipay.ebpp.invoice.enterprise.newinvoice.notify` |
| 单笔企业发票查询 | `alipay.ebpp.invoice.enterprise.invoiceinfo.query` |

两种接入方式共同要求：

1. 校验消息接口名、`enterprise_id`、`invoice_no`、`invoice_kind` 和 `notify_reason`。
2. 取得幂等处理权，区分首次处理、已完成和处理中。
3. HTTP(S) 使用 SDK 或文档支持的方式验签完整原始参数；WebSocket 依赖官方 SDK 通道校验，不重复解析 HTTP 签名参数。
4. `invoice_kind` 不是 `31`/`32` 时要求 `invoice_code` 非空。
5. 查询单笔发票详情并完成真实业务处理后，才标记幂等完成。
6. HTTP(S) 成功返回 `success`、失败返回 `fail`；WebSocket 成功正常返回、失败抛异常。

HTTP(S) 的投递幂等键是公共参数 `notify_id`。WebSocket 的投递幂等键是 `MsgHandler.onMessage` 的 `msgId`；`msgApi` 必须路由到 `alipay.ebpp.invoice.enterprise.newinvoice.notify`。

消息文档给出的重试周期约 25 小时、最多 8 次。业务实现应保留可重试状态和错误证据。

## 选接模块

### 员工抬头

员工抬头包含新增关系、修改信息和失效关系三个接口。三份接口文档均提示能力待升级、仅适用于特定企业、新接客户请勿使用，因此只有准入已确认时才能生成调用代码。

选择后完整覆盖：

- `alipay.commerce.ec.employee.title.create`
- `alipay.commerce.ec.employee.title.modify`
- `alipay.commerce.ec.employee.title.delete`

新增和失效是批量处理接口，必须解析逐项失败列表，不能只看网关成功码。

### 批量查询

企业抬头分页查询和发票分页查询可独立选择：

- `alipay.ebpp.invoice.enterpriseexctrl.employertitle.batchquery`
- `alipay.ebpp.invoice.enterprise.invoiceinfo.batchquery`

实现分页时处理 `page_num`、`page_size` 和响应总量；不要把单笔接口字段迁移到批量请求。

## 恢复与补偿

- 通知失败：返回 `fail`，依赖消息重试，并记录失败原因。
- 通知丢失或历史初始化：只有已选择发票批量查询时，才使用分页查询补偿。
- 详情暂不可用：保留幂等处理中/可重试状态，不得标记完成。
- 重复通知：已完成时可幂等返回 `success`；仍在处理时进入重试失败路径，避免并发重复落库。
