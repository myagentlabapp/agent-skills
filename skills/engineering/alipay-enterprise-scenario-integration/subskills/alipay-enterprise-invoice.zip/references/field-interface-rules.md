# 发票字段与接口生成规则

本文件约束发票域的接口完整性、字段来源、条件必填、枚举和通知处理。跨语言原则见 [发票通用代码生成规则](codegen-general-rules.md)。

## 通用规则

1. 接口、通知、请求字段、响应字段和枚举只来自当前已选择模块的接口 Markdown。
2. 请求、响应和通知字段分开使用，不能互相迁移；单笔和批量接口也不能互相继承字段。
3. 生成调用代码前输出接口证据表：接口方法名或 `msg_method`、Markdown 路径、SDK/HTTP(S) 接入方式、Request/Model/Response 或字段来源、关键字段、条件必填和响应处理。
4. Java/Maven 证据表必须写明 SDK Request、Model、Response 类，并用真实 SDK jar 或 `javap` 确认关键 setter/getter。不得用反射、Map 或本地 stub 绕过缺失类型。
5. 文档存在冲突或条件引用了请求参数表中不存在的字段时，保留原始文档边界并列为待确认项，不自行补字段。

## 模块完成标准

- 企业抬头：`employertitle.create`、`employertitle.modify`、`employertitle.query`。
- 开票规则：`enterpriseopenrule.create`、`enterpriseopenrule.modify`、`enterpriseopenrule.query`。
- 发票消息与查询：`enterprise.newinvoice.notify`、`enterprise.invoiceinfo.query`。
- 员工抬头（选接）：`employee.title.create`、`employee.title.modify`、`employee.title.delete`，并处理逐项失败信息。
- 企业抬头批量查询（选接）：`employertitle.batchquery`。
- 发票批量查询（选接）：`invoiceinfo.batchquery`。

## 企业身份字段

- 企业码 2.0 按接口文档使用 `enterprise_id`。
- 企业码 1.0 按接口文档组合使用 `account_id` 和 `agreement_no`。
- 不得为了“兼容”而无条件同时发送两套身份字段。
- 每个接口的“必须/特殊可选”以该接口自己的参数表为准，不把其他接口的规则迁入。

## 企业抬头

- 创建时 `title_name` 和 `tax_register_no` 必填。
- 查询时 `title_id` 与 `tax_register_no` 按文档二选一。
- 修改时完整传递该接口标记为必须的字段，不把创建接口的可选语义套到修改接口。
- 抬头创建/修改接口的业务响应具有 `code`、`msg`、`success` 等字段时，应按接口文档共同判断业务结果，不能只判断 HTTP 成功。
- Java SDK typed response 暴露 `getSuccess()` 时必须显式检查；通用 `AlipayResponse.isSuccess()` 只判断网关基础响应，不能替代业务字段。

## 开票规则

- `open_mode` 只能使用 `SUMMARY` 或 `SINGLE`。
- `seller_type`、`tag`、`bill_scope`、`combined_pay_mode`、`default_invoice_kind` 只能使用各接口文档列出的枚举。
- `SUMMARY` 与 `SINGLE` 的条件必填分别校验，不得用默认值掩盖缺失参数。
- `SINGLE` 是文档中的合法必选能力。当前 SDK 缺少 `bill_scope`、`combined_pay_mode` 或 `default_invoice_kind` setter 时，必须验证升级 SDK 或文档允许的网关调用；不能以 `UnsupportedOperationException` 拒绝 `SINGLE` 后宣称开票规则模块完成。
- `seller_type` 只接受 `MERCHANT`、`TP`，`tag` 只接受 `DEFAULT`、`EMPLOYEE_TITLE_FIRST`；未知值失败关闭。
- 收件人姓名、电话、地址保持成组完整。
- 修改接口请求参数表没有 `open_mode`。不得因为条件说明引用 `open_mode` 就自行生成该请求字段。
- 查询响应中的规则记录和绑定关系列表保持原始嵌套结构，不扁平化或混入请求对象。
- 查询 SINGLE 规则时保留 `bill_scope`、`combined_pay_mode`、`default_invoice_kind`。当前 SDK record 类型缺 getter 时，从响应原始 body 的规则记录节点补充，并按 `invoice_rule_record_id` 与 typed record 关联，不能按数组位置假定顺序一致。raw body 只提供补充值，不能决定记录是否为 SINGLE；映射完成后以 typed record 的 `openMode` 逐条校验。typed SINGLE 缺 ID、找不到 raw 记录、raw 数组缺失或三个字段任一为空白都失败关闭；raw `open_mode` 缺失或不一致不能绕过 typed SINGLE 校验。

## 发票通知

- HTTP(S) 验签使用完整原始通知参数，验签后再解析 `biz_content`。
- WebSocket 使用官方 `AlipayMsgClient + MsgHandler`，`msgApi` 对应消息接口名、`msgId` 对应投递消息 ID、`bizContent` 对应业务内容；不要要求 WebSocket 回调出现 HTTP 的 `notify_id`、`sign` 或 `success/fail` 字符串。
- `msg_method` 必须等于 `alipay.ebpp.invoice.enterprise.newinvoice.notify`。
- HTTP(S) 投递幂等键使用公共参数 `notify_id`；WebSocket 投递幂等键使用回调 `msgId`。业务唯一性至少结合 `enterprise_id`、`invoice_no` 和可用的 `invoice_code`。
- `notify_reason` 只接受 `INVOICE_COLLECT`、`INVOICE_INFO_CHANGE`。
- 必填业务字段为 `enterprise_id`、`employee_id`、`einv_id`、`invoice_no`、`invoice_kind`、`notify_reason`、`collect_source`，任何一个为空都失败关闭。
- `invoice_kind` 只接受 `0`、`1`、`2`、`3`、`4`、`31`、`32`；`collect_source` 只接受 `INVOICE_EMAIL`、`OTHER`。
- `invoice_kind` 为 `31`/`32` 时 `invoice_code` 可空，其他种类必填。
- HTTP(S) 业务成功返回纯文本 `success`，失败返回纯文本 `fail`；WebSocket 业务成功正常返回，失败抛异常；不能在异常分支固定确认成功。

## 消息传输隔离

- 同一消息订阅选择 HTTP(S) 或 WebSocket，不生成两个入口竞争消费。
- HTTP(S) Controller/Handler 负责公共参数验签和同步应答。
- WebSocket `MsgHandler` 只处理 SDK 传入的 `msgApi`、`msgId`、`bizContent`，不得再次按 HTTP 表单参数验签。
- 由方案型 Skill 统一消息路由时，本域只实现发票 handler，不独立创建 `AlipayMsgClient` 或应用网关。

## 发票查询

- 单笔查询请求固定使用 `enterprise_id`、`invoice_no` 和条件必填的 `invoice_code`。
- 查询服务在调用 SDK 前必须获得可信的 `invoice_kind`（显式参数或已校验请求对象），先拒绝文档枚举外值，再决定 `invoice_code` 是否可空；不能仅由调用方口头约定，也不能用查询响应中的种类事后证明请求合法。
- 网关成功后仍要校验业务响应契约。`enterprise_id`、`invoice_no`、`invoice_type`、`invoice_kind`、`invoice_date`、`sum_amount`、`payer_name`、`payer_register_no`、`payee_name` 任一缺失或空白都失败关闭；响应 `enterprise_id`、`invoice_no`、`invoice_kind` 必须与请求一致。响应种类非 `31`/`32` 时，响应 `invoice_code` 必须存在并与请求一致，不能用“请求或响应代码为空就跳过比较”代替条件必填。不得把残缺或错配的成功响应落库后确认通知完成。
- 金额字段是文档中的字符串金额，必须使用十进制定点类型解析，不得使用二进制浮点直接参与财务计算。
- `invoice_type`、`invoice_kind`、`row_type`、`invoice_check_result`、`specific_factor`、`collect_source` 只使用文档枚举。
- `file_download_url` 非空时要求 `file_type` 非空。
- 发票项目保留 `invoice_item_list` 嵌套结构；列表存在时，每一项的 `item_name`、`amount`、`tax`、`tax_rate` 都按文档必填校验，`row_type` 非空时只接受 `0`、`1`、`2`，金额解析失败或枚举越界时整笔查询失败关闭。
- `industry_specific_infos` 是特定行业信息字符串；未读取对应行业模型文档时只透传或持久化原值，不猜测内部结构。

## 批量接口隔离

- 企业抬头批量查询与单笔查询的请求/响应结构分开。
- 发票批量查询使用其文档中的 `start_time`、`end_time`、`page_num`、`page_size` 等字段，不继承单笔查询的发票号码条件。
- 分页结果必须处理页码、页大小、总量和列表；不能只处理第一页后宣称批量同步完成。
- 批量能力未选择时，不生成定时任务、分页游标或对应 API 调用。

## 员工抬头准入与批量结果

- 未确认特定企业准入资格时，不生成员工抬头调用。
- 新商户优先使用文档建议的 `open_id`；使用前确认 OpenID 配置已启用。
- 员工标识和企业标识的 N 选一关系按各接口参数表分别校验。
- `title_tag=DEFAULT` 与 `MULTI` 的字段结构分开处理。
- 新增/失效接口可能网关成功但部分条目失败，必须解析并返回逐项失败列表。
