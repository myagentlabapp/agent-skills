class AlipayGatewayClient {
  String execute(Map<String, String> params) {
    params.put("sign", AlipaySignature.sign(params, privateKey, charset, signType));
    HttpURLConnection connection = openConnection();
    String body = postForm(connection, params);
    String sign = root(body).get("sign");
    int keyIdx = body.indexOf("\"alipay_");
    String responseContent = body.substring(keyIdx, body.lastIndexOf('}') - 1);
    if (!AlipaySignature.rsa256CheckContent(responseContent, sign, alipayPublicKey, charset)) {
      throw new InvoiceCallException("invalid response sign");
    }
    return body;
  }
}
