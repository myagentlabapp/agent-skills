class FailClosedInvoiceBusinessAdapter implements InvoiceBusinessPort {
  boolean persist(Object record) { return false; }
}
