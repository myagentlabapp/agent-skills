class EnterpriseOpenRuleServiceTest {
  // 验证 SUMMARY 与 SINGLE 都是允许的 open_mode。
}
