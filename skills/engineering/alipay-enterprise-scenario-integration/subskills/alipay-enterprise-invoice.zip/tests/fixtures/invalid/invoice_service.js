const methods = [
  "alipay.ebpp.invoice.enterpriseexctrl.employertitle.create",
  "alipay.ebpp.invoice.enterpriseconsume.enterpriseopenrule.create",
  "alipay.ebpp.invoice.enterprise.newinvoice.notify",
  "alipay.commerce.ec.employee.title.create",
];

function handleNotification() {
  return "success";
}

module.exports = { handleNotification, methods };
