class EnterpriseInvoiceQueryServiceTest {
  void missingEnterpriseIdResponse_isRejected() {}
  void missingInvoiceNoResponse_isRejected() {}
  void missingInvoiceTypeResponse_isRejected() {}
  void missingInvoiceKindResponse_isRejected() {}
  void missingInvoiceDateResponse_isRejected() {}
  void missingSumAmountResponse_isRejected() {}
  void missingPayerNameResponse_isRejected() {}
  void missingPayerRegisterNoResponse_isRejected() {}
  void missingPayeeNameResponse_isRejected() {}
  void enterpriseIdMismatchResponse_isRejected() {}
  void invoiceItemList_isMapped() {}
  void invalidSumAmount_isRejected() {}
  void invalidInvoiceTypeResponse_isRejected() {}
}
