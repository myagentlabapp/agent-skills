class InvoiceNotifyService {
  String invoiceKind;
  String notifyReason;
}
