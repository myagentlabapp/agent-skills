class DispatchingMsgHandler implements MsgHandler {
  Set<String> getRoutes() { return routes; }
}
