@SpringBootTest
class EntMetroContextTest {
  void routesAreNonEmpty() {
    assertTrue(dispatchingMsgHandler.getRoutes().size() > 0);
  }
}
