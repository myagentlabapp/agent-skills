class EnterpriseInvoiceQueryService {
  Object query(String enterpriseId, String invoiceNo, String invoiceKind, String invoiceCode) {
    require(!isBlank(enterpriseId), "enterpriseId required");
    require(!isBlank(invoiceNo), "invoiceNo required");
    require(!isBlank(invoiceKind), "invoiceKind required");
    boolean digital = "31".equals(invoiceKind) || "32".equals(invoiceKind);
    if (!digital) require(!isBlank(invoiceCode), "invoiceCode required");
    Object model = new InvoiceinfoQueryModel();
    InvoiceResponse response = execute(model);
    requireText(response.getEnterpriseId());
    requireText(response.getInvoiceNo());
    requireText(response.getInvoiceType());
    requireText(response.getInvoiceKind());
    requireText(response.getInvoiceDate());
    requireText(response.getSumAmount());
    requireText(response.getPayerName());
    requireText(response.getPayerRegisterNo());
    requireText(response.getPayeeName());
    requireSame(enterpriseId, response.getEnterpriseId());
    requireSame(invoiceNo, response.getInvoiceNo());
    if (invoiceCode != null && response.getInvoiceCode() != null) {
      requireSame(invoiceCode, response.getInvoiceCode());
    }
    requireEnum(response.getInvoiceType(), "blue", "red");
    requireEnum(response.getInvoiceKind(), "0", "1", "2", "3", "4", "31", "32");
    for (InvoiceItem item : response.getInvoiceItemList()) {
      requireText(item.getItemName());
      requireText(item.getAmount());
      requireText(item.getTax());
      requireText(item.getTaxRate());
      if (!ROW_TYPES.contains(item.getRowType())) throw new InvoiceBusinessException("rowType invalid");
      mapped.setRowType(item.getRowType());
    }
    return response;
  }
}
