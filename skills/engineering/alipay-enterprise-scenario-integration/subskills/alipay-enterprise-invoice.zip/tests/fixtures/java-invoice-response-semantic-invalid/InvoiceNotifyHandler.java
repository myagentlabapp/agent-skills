class InvoiceNotifyHandler {
  static final String MSG_API = "alipay.ebpp.invoice.enterprise.newinvoice.notify";
}
