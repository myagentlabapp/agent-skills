class EnterpriseOpenRuleServiceTest {
  void querySingle_mapsFields() {
    assertEquals("PEER_PAY", result.getBillScope());
    assertEquals("ONLY_PEER_PAY", result.getCombinedPayMode());
    assertEquals("SPECIAL", result.getDefaultInvoiceKind());
  }
}
