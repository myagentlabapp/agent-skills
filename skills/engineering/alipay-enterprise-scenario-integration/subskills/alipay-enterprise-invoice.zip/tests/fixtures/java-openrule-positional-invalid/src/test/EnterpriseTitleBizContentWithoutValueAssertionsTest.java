class EnterpriseTitleBizContentWithoutValueAssertionsTest {
  void queryByTaxNo_parsesButDoesNotAssertValues() {
    ArgumentCaptor<AlipayEbppInvoiceEnterpriseexctrlEmployertitleQueryRequest> captor = requestCaptor();
    verify(executor).execute(captor.capture());
    String biz = captor.getValue().getBizContent();
    JsonNode payload = new ObjectMapper().readTree(biz);
    assertNotNull(payload);
  }
}
