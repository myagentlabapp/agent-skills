class SdkBizContentWithoutAssertions {
  static final String METHOD_CREATE =
      "alipay.ebpp.invoice.enterpriseconsume.enterpriseopenrule.create";
  static final String METHOD_TITLE_QUERY =
      "alipay.ebpp.invoice.enterpriseexctrl.employertitle.query";

  void createSingle(String bizContent) {
    AlipayEbppInvoiceEnterpriseconsumeEnterpriseopenruleCreateRequest request =
        new AlipayEbppInvoiceEnterpriseconsumeEnterpriseopenruleCreateRequest();
    request.setBizContent(bizContent);
    executor.execute(request);
  }

  Object queryByTaxRegisterNo(String bizContent) {
    AlipayEbppInvoiceEnterpriseexctrlEmployertitleQueryRequest request =
        new AlipayEbppInvoiceEnterpriseexctrlEmployertitleQueryRequest();
    request.setBizContent(bizContent);
    return executor.execute(request);
  }
}
