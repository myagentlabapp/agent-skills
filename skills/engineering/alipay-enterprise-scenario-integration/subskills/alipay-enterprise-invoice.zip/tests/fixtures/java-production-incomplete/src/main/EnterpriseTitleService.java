class EnterpriseTitleService {
  // tax_register_no 查询路径仅支持 title_id，留作待确认，不生成调用。
  void create() {
    AlipayEbppInvoiceEnterpriseexctrlEmployertitleCreateResponse resp = execute();
    Boolean businessSuccess = resp.getSuccess();
    if (businessSuccess != null && !businessSuccess) throw new InvoiceCallException();
  }

  void modify() {
    AlipayEbppInvoiceEnterpriseexctrlEmployertitleModifyResponse resp = execute();
    Boolean businessSuccess = resp.getSuccess();
    if (businessSuccess != null && !businessSuccess) throw new InvoiceCallException();
  }
}
