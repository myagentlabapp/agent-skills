interface NotifyIdempotentRepository {
  // The update references :now but the method declaration does not bind a lease timestamp.
  @Query("UPDATE NotifyRecord r SET r.state = 'PENDING', r.firstSeenAt = :now "
      + "WHERE r.notifyId = :id AND r.state = 'FAILED'")
  int reacquireFailed(String id);

  @Query("UPDATE NotifyRecord r SET r.firstSeenAt = :now WHERE r.notifyId = :id AND r.firstSeenAt < :staleBefore")
  int reacquireStalePending(String id, long now, long staleBefore);
}
