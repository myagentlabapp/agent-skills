class InvoiceNotifyService {
  static final long STALE_PENDING_MS = 300000L;

  boolean handle(String enterpriseId, String employeeId, String einvId, String invoiceNo,
      String invoiceKind, String notifyReason, String collectSource) {
    return invoiceKind != null && notifyReason != null;
  }

  void retry(NotifyIdempotentRepository repository, String notifyId) {
    repository.reacquireFailed(notifyId);
    repository.reacquireStalePending(notifyId, 1L, 0L);
  }
}
