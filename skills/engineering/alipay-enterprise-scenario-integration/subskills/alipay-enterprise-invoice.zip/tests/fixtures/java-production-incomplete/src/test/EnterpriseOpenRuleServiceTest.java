class EnterpriseOpenRuleServiceTest {}
