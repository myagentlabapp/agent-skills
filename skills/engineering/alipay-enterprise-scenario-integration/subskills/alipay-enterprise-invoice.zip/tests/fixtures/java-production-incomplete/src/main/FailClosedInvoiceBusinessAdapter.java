@Primary
@ConditionalOnMissingBean(InvoiceBusinessPort.class)
class FailClosedInvoiceBusinessAdapter {
  boolean persistInvoice(Object invoice, String notifyId, String bizKey) {
    repository.findByNotifyId(notifyId);
    repository.save(invoice);
    return false;
  }
}
