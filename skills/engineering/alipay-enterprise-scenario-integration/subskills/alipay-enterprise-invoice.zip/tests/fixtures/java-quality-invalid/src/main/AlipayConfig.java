class AlipayConfig {
  String appId = "REPLACE_WITH_APP_ID";
}
