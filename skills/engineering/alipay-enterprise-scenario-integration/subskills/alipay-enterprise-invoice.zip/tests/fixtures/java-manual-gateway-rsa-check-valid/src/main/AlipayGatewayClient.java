class AlipayGatewayClient {
  String execute(Map<String, String> params) {
    params.put("sign", AlipaySignature.sign(params, privateKey, charset, signType));
    HttpURLConnection connection = openConnection();
    String body = postForm(connection, params);
    String sign = root(body).get("sign");
    String content = root(body).get("response");
    if (!AlipaySignature.rsaCheck(content, sign, alipayPublicKey, charset, signType)) {
      throw new InvoiceCallException("invalid response sign");
    }
    return body;
  }
}
