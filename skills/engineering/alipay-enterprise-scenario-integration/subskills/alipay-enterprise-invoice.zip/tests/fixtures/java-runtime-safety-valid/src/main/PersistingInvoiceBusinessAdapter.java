class PersistingInvoiceBusinessAdapter {
  boolean persistInvoice(Object invoice, String notifyId, String bizKey) {
    if (repository.findByBizKey(bizKey).isPresent()) return true;
    repository.save(invoice, notifyId, bizKey);
    return true;
  }
}
