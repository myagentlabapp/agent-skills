class EnterpriseTitleServiceTest {
  void blankTitleNameTaxRegisterNoAndTitleId_areRejected() {}
}
