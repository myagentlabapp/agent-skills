@DataJpaTest
class InvoiceBusinessConcurrencyTest {
  void concurrentSameBizKey_handlesDataIntegrityViolationException() {
    CountDownLatch start = new CountDownLatch(1);
    assertThrows(DataIntegrityViolationException.class,
        () -> insertSameBizKeyConcurrently(entityManager, "biz_key", start));
  }
}
