class EnterpriseTitleService {
  void create(TitleRequest request) {
    require(request.getIdentity() != null, "identity required");
    require(!isBlank(request.getTitleName()), "titleName required");
    require(!isBlank(request.getTaxRegisterNo()), "taxRegisterNo required");
  }

  void modify(TitleRequest request) {
    require(!isBlank(request.getTitleId()), "titleId required");
    require(!isBlank(request.getTitleName()), "titleName required");
    require(!isBlank(request.getTaxRegisterNo()), "taxRegisterNo required");
  }

  Object query(EnterpriseIdentity identity, String titleId) {
    require(!isBlank(titleId), "titleId required");
    return execute(identity, titleId);
  }
}
