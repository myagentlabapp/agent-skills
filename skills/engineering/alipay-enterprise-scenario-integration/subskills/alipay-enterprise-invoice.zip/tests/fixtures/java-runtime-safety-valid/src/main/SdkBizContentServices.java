class SdkBizContentServices {
  void createSingle(String bizContent) {
    AlipayEbppInvoiceEnterpriseconsumeEnterpriseopenruleCreateRequest request =
        new AlipayEbppInvoiceEnterpriseconsumeEnterpriseopenruleCreateRequest();
    request.setBizContent(bizContent);
    executor.execute(request);
  }

  void queryTitleByTaxNo(String bizContent) {
    AlipayEbppInvoiceEnterpriseexctrlEmployertitleQueryRequest request =
        new AlipayEbppInvoiceEnterpriseexctrlEmployertitleQueryRequest();
    request.setBizContent(bizContent);
    executor.execute(request);
  }
}
