class EnterpriseOpenRuleServiceTest {
  void querySingle_mapsBillScopeCombinedPayModeAndDefaultInvoiceKind() {
    assertEquals("PEER_PAY", result.getBillScope());
    assertEquals("ONLY_PEER_PAY", result.getCombinedPayMode());
    assertEquals("SPECIAL", result.getDefaultInvoiceKind());
  }

  void querySingle_reorderedRawRecords_correlatesByInvoiceRuleRecordId() {
    String invoice_rule_record_id = "raw-2-before-raw-1";
    assertEquals("record-1", result.getInvoiceRuleRecordId());
  }

  void querySingle_missingSupplementalFields_throws() {
    String missing = "bill_scope combined_pay_mode default_invoice_kind";
    assertThrows(InvoiceCallException.class, () -> service.query(identity, "rule-1"));
  }

  void querySingle_missingRawRecord_throws() {
    assertThrows(InvoiceCallException.class, () -> service.query(identity, "rule-missing-raw"));
  }

  void querySingle_missingRawOpenMode_stillValidatesTypedSingle() {
    assertThrows(InvoiceCallException.class, () -> service.query(identity, "rule-raw-open-mode-absent"));
  }

  void querySingle_blankSupplementalFields_throws() {
    assertThrows(InvoiceCallException.class, () -> service.query(identity, "rule-blank-fields"));
  }

  void differentNotifyIds_sameBizKey_areDeduplicated() {
    adapter.persistInvoice(invoice, "notify-1", "biz-1");
    adapter.persistInvoice(invoice, "notify-2", "biz-1");
    assertEquals(1, repository.count());
    validateCredential(" REPLACE_WITH_APP_ID ");
  }
}
