class OpenRuleBizContentTest {
  void createSingle_capturesAndChecksBizContent() {
    ArgumentCaptor<AlipayEbppInvoiceEnterpriseconsumeEnterpriseopenruleCreateRequest> captor = requestCaptor();
    verify(executor).execute(captor.capture());
    String json = captor.getValue().getBizContent();
    JsonNode payload = new ObjectMapper().readTree(json);
    assertEquals("2088123412341234", payload.path("enterprise_id").asText());
    assertEquals("Travel invoices", payload.path("invoice_rule_name").asText());
    assertEquals("SINGLE", payload.path("open_mode").asText());
    assertEquals("PEER_PAY", payload.path("bill_scope").asText());
    assertEquals("ONLY_PEER_PAY", payload.path("combined_pay_mode").asText());
    assertEquals("SPECIAL", payload.path("default_invoice_kind").asText());
  }
}
