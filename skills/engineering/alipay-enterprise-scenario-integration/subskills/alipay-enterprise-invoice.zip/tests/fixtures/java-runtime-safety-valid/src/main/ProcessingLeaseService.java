class ProcessingLeaseService {
  static final long STALE_PENDING_MS = 300000L;

  void retry(ProcessingLeaseRepository repository, String deliveryId, long now) {
    repository.reacquireFailed(deliveryId, now);
    repository.reacquireStalePending(deliveryId, now, now - STALE_PENDING_MS);
  }
}
