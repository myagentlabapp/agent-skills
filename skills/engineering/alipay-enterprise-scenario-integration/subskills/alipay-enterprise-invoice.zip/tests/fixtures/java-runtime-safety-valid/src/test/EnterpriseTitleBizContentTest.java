class EnterpriseTitleBizContentTest {
  void queryByTaxNo_capturesAndChecksBizContent() {
    ArgumentCaptor<AlipayEbppInvoiceEnterpriseexctrlEmployertitleQueryRequest> captor = requestCaptor();
    verify(executor).execute(captor.capture());
    String json = captor.getValue().getBizContent();
    JsonNode payload = new ObjectMapper().readTree(json);
    assertEquals("2088123412341234", payload.path("enterprise_id").asText());
    assertEquals("91330000TEST000000", payload.path("tax_register_no").asText());
  }
}
