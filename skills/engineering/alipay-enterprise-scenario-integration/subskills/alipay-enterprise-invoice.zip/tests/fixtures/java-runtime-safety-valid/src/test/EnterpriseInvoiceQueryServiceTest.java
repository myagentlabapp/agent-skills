class EnterpriseInvoiceQueryServiceTest {
  void nonDigitalInvoiceKindWithBlankInvoiceCode_isRejected() {
    mapFromBody("invoice_item_list");
  }

  void missingEnterpriseIdResponse_isRejected() {}
  void missingInvoiceNoResponse_isRejected() {}
  void missingInvoiceTypeResponse_isRejected() {}
  void missingInvoiceKindResponse_isRejected() {}
  void missingInvoiceDateResponse_isRejected() {}
  void missingSumAmountResponse_isRejected() {}
  void missingPayerNameResponse_isRejected() {}
  void missingPayerRegisterNoResponse_isRejected() {}
  void missingPayeeNameResponse_isRejected() {}
  void enterpriseIdMismatchResponse_isRejected() {}
  void invalidRequestInvoiceKind_beforeSdk_isRejected() {}
  void invoiceKindMismatchResponse_isRejected() {}
  void nonDigitalInvoiceCodeMissingResponse_isRejected() {}
  void invoiceItemList_isMapped() {}
  void invalidRowType_isRejected() {}
  void missingRowType_isAccepted() {}
  void blankRowType_isAccepted() {}
  void invalidSumAmount_isRejected() {}
  void invalidInvoiceTypeResponse_isRejected() {}
}
