class EnterpriseOpenRuleService {
  static final String OPEN_MODE_SINGLE = "SINGLE";
  static final String[] SELLER_TYPES = {"MERCHANT", "TP"};
  static final String[] TAGS = {"DEFAULT", "EMPLOYEE_TITLE_FIRST"};

  void create(OpenRuleRequest request) {
    require(!isBlank(request.getInvoiceRuleName()), "invoiceRuleName required");
    require(!isBlank(request.getInvoiceTitleId()), "invoiceTitleId required when applicable");
  }

  void modify(OpenRuleRequest request) {
    require(!isBlank(request.getInvoiceRuleId()), "invoiceRuleId required");
    require(!isBlank(request.getInvoiceRuleName()), "invoiceRuleName required");
  }

  Object query(EnterpriseIdentity identity, String invoiceRuleId) {
    require(!isBlank(invoiceRuleId), "invoiceRuleId required");
    String body = execute(identity, invoiceRuleId).getBody();
    Map<String, RawRecord> rawById = indexBy(body, "invoice_rule_record_id");
    for (TypedRecord typed : typedRecords()) {
      RawRecord raw = rawById.get(typed.getInvoiceRuleRecordId());
      if (raw != null) {
        typed.setBillScope(raw.get("bill_scope"));
        typed.setCombinedPayMode(raw.get("combined_pay_mode"));
        typed.setDefaultInvoiceKind(raw.get("default_invoice_kind"));
      }
    }
    for (TypedRecord typed : typedRecords()) {
      if ("SINGLE".equals(typed.getOpenMode())) {
        validateSingleResponseFields(
            typed.getBillScope(), typed.getCombinedPayMode(), typed.getDefaultInvoiceKind());
      }
    }
    return results();
  }

  int countPresent(String... values) {
    int count = 0;
    for (String value : values) if (!isBlank(value)) count++;
    return count;
  }
}
