class EnterpriseOpenRuleService {
  static final String[] SELLER_TYPES = {"MERCHANT", "TP"};
  static final String[] TAGS = {"DEFAULT", "EMPLOYEE_TITLE_FIRST"};

  static class ModifyCommand {
    String getOpenMode() { return "SINGLE"; }
    String getInvoiceRuleId() { return "rule-id"; }
    String getBillScope() { return "ALL"; }
    String getCombinedPayMode() { return "COMBINED"; }
    String getDefaultInvoiceKind() { return "1"; }
  }

  void create(ModifyCommand command) {
    validateSingle(command.getBillScope(), command.getCombinedPayMode(), command.getDefaultInvoiceKind());
    if ("SINGLE".equals(command.getOpenMode())) {
      throw new InvoiceBusinessException("SINGLE 模式暂不支持，需升级 SDK");
    }
    AlipayEbppInvoiceEnterpriseconsumeEnterpriseopenruleCreateRequest request = newRequest();
    request.setBizModel(command);
    client.execute(request);
  }

  void modify(ModifyCommand command) {
    require(command.getInvoiceRuleId());
    AlipayEbppInvoiceEnterpriseconsumeEnterpriseopenruleModifyRequest request = newModifyRequest();
    request.setBizModel(command.getInvoiceRuleId());
    client.execute(request);
  }
}
