import java.util.concurrent.ConcurrentHashMap;

class InvoiceBusinessAdapter implements InvoiceBusinessPort {
  private final ConcurrentHashMap<String, Object> store = new ConcurrentHashMap<String, Object>();

  public boolean persist(Object invoice) {
    return store.putIfAbsent(invoice.toString(), invoice) == null;
  }
}
