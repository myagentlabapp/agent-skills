class AlipayProperties {
  private String appId;
  private String privateKey;
  private String alipayPublicKey;

  void validate() {
    if (appId == null || appId.trim().isEmpty()) {
      throw new IllegalStateException("appId missing");
    }
  }
}
