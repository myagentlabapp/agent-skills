#!/usr/bin/env node
"use strict";

const assert = require("assert");
const fs = require("fs");
const path = require("path");
const { spawnSync } = require("child_process");

const skillDir = path.resolve(__dirname, "..");
const validator = path.join(skillDir, "scripts", "validate_codegen.js");

testSkillMetadata();
testReferenceLinks();
testInterfaceDocuments();
testEvals();
testValidatorFixtures();
console.log("[alipay-enterprise-invoice tests] OK");

function testSkillMetadata() {
  const skill = fs.readFileSync(path.join(skillDir, "SKILL.md"), "utf8");
  assert.match(skill, /^---\nname: alipay-enterprise-invoice\n/);
  assert.match(skill, /推模式/);
  assert.match(skill, /员工抬头.*选接/);
  assert.match(skill, /8 个必选接口\/通知/);
  assert.match(skill, /AlipayMsgClient \+ MsgHandler/);
  assert.match(skill, /HTTP\(S\).*WebSocket/);
  assert.match(skill, /失败重试重新取得.*刷新/);
  assert.match(skill, /不同投递 ID、相同业务键/);
  assert.match(skill, /先 `trim`\/`strip` 再判断/);
  assert.match(skill, /响应(?:根节点)? `sign`/);
  assert.match(skill, /bill_scope.*combined_pay_mode.*default_invoice_kind/);
  assert.match(skill, /RSA2\/SHA256 生成合法响应签名/);
  assert.match(skill, /rsa256CheckContent/);
  assert.match(skill, /四参 `rsaCheckContent/);
  assert.match(skill, /通知 ID 冲突或 Mockito 查询结果替代/);
  assert.match(skill, /单笔查询不能把网关成功直接视为可落库/);
}

function testReferenceLinks() {
  for (const file of walk(skillDir).filter((item) => item.endsWith(".md"))) {
    const text = fs.readFileSync(file, "utf8");
    for (const match of text.matchAll(/\[[^\]]+\]\(([^)#]+)(?:#[^)]+)?\)/g)) {
      const link = match[1];
      if (/^[a-z]+:\/\//i.test(link)) continue;
      const resolved = path.resolve(path.dirname(file), decodeURIComponent(link));
      assert.ok(fs.existsSync(resolved), `${path.relative(skillDir, file)} has broken link: ${link}`);
    }
  }
}

function testInterfaceDocuments() {
  const expected = [
    "alipay.ebpp.invoice.enterpriseexctrl.employertitle.create",
    "alipay.ebpp.invoice.enterpriseexctrl.employertitle.modify",
    "alipay.ebpp.invoice.enterpriseexctrl.employertitle.query",
    "alipay.ebpp.invoice.enterpriseconsume.enterpriseopenrule.create",
    "alipay.ebpp.invoice.enterpriseconsume.enterpriseopenrule.modify",
    "alipay.ebpp.invoice.enterpriseconsume.enterpriseopenrule.query",
    "alipay.ebpp.invoice.enterprise.newinvoice.notify",
    "alipay.ebpp.invoice.enterprise.invoiceinfo.query",
    "alipay.commerce.ec.employee.title.create",
    "alipay.commerce.ec.employee.title.modify",
    "alipay.commerce.ec.employee.title.delete",
    "alipay.ebpp.invoice.enterpriseexctrl.employertitle.batchquery",
    "alipay.ebpp.invoice.enterprise.invoiceinfo.batchquery",
  ];
  const docs = walk(path.join(skillDir, "references")).filter((item) => item.endsWith(".md"));
  const allText = docs.map((file) => fs.readFileSync(file, "utf8")).join("\n");
  for (const method of expected) assert.ok(allText.includes(method), `missing interface document: ${method}`);

  const employeeDocs = docs.filter((file) => file.includes(`${path.sep}employee-title${path.sep}`));
  assert.strictEqual(employeeDocs.length, 3);
  for (const file of employeeDocs) {
    assert.match(fs.readFileSync(file, "utf8"), /仅适用于特定企业/);
  }

  for (const relative of [
    "common/message-integration.md",
    "common/websocket-integration.md",
    "quality-gates/java-maven.md",
    "quality-gates/nodejs.md",
    "quality-gates/python-go-dotnet.md",
  ]) {
    assert.ok(fs.existsSync(path.join(skillDir, "references", relative)), `missing message reference: ${relative}`);
  }
}

function testEvals() {
  const evalFile = path.resolve(skillDir, "..", "..", "evals", "alipay-enterprise-invoice", "evals.json");
  if (!fs.existsSync(evalFile)) return;
  const data = JSON.parse(fs.readFileSync(evalFile, "utf8"));
  assert.strictEqual(data.skill_name, "alipay-enterprise-invoice");
  assert.ok(data.evals.length >= 3);
}

function testValidatorFixtures() {
  assertExit(path.join(__dirname, "fixtures", "valid"), 0);
  const invalid = runValidator(path.join(__dirname, "fixtures", "invalid"));
  assert.strictEqual(invalid.status, 1, output(invalid));
  assert.match(output(invalid), /does not validate required business fields/);
  assert.match(output(invalid), /documented invoice_kind enum/);
  assert.match(output(invalid), /documented collect_source enum/);
  assertExit(path.join(__dirname, "fixtures", "websocket-valid"), 0);
  const camelHttp = runValidator(path.join(__dirname, "fixtures", "http-camel-notify-invalid"));
  assert.strictEqual(camelHttp.status, 1, output(camelHttp));
  assert.match(output(camelHttp), /HTTP\(S\) invoice notification has no recognizable real signature-verification call/);
  assert.match(output(camelHttp), /must expose both success and fail acknowledgement paths/);
  const websocketInvalid = runValidator(path.join(__dirname, "fixtures", "websocket-invalid"));
  assert.strictEqual(websocketInvalid.status, 1, output(websocketInvalid));
  assert.match(output(websocketInvalid), /hand-rolls the protocol/);
  assert.match(output(websocketInvalid), /does not use callback msgId/);

  const fixedSignature = runValidator(path.join(__dirname, "fixtures", "http-fixed-signature"));
  assert.strictEqual(fixedSignature.status, 1, output(fixedSignature));
  assert.match(output(fixedSignature), /signature verifier returns a fixed true result/);

  assertExit(path.join(__dirname, "fixtures", "http-test-override-valid"), 0);
  assertExit(path.join(__dirname, "fixtures", "java-single-comments-valid"), 0);
  assertExit(path.join(__dirname, "fixtures", "java-runtime-safety-valid"), 0);
  assertExit(path.join(__dirname, "fixtures", "java-manual-gateway-rsa-check-valid"), 0);

  const javaResponseSemantic = runValidator(path.join(__dirname, "fixtures", "java-invoice-response-semantic-invalid"));
  assert.strictEqual(javaResponseSemantic.status, 1, output(javaResponseSemantic));
  assert.match(output(javaResponseSemantic), /request invoice_kind outside the documented enum/);
  assert.match(output(javaResponseSemantic), /identity mismatch: invoice_kind/);
  assert.match(output(javaResponseSemantic), /require and match response invoice_code/);
  assert.match(output(javaResponseSemantic), /treats optional row_type as required/);
  assert.match(output(javaResponseSemantic), /invalid request invoice_kind rejected before the SDK call/);
  assert.match(output(javaResponseSemantic), /response invoice_kind mismatching the request/);
  assert.match(output(javaResponseSemantic), /non-digital response with missing invoice_code/);
  assert.match(output(javaResponseSemantic), /invalid row_type failing closed/);
  assert.match(output(javaResponseSemantic), /optional row_type missing values are accepted/);
  assert.match(output(javaResponseSemantic), /optional row_type blank values are accepted/);
  assert.match(output(javaResponseSemantic), /shared message router contains the invoice notification route/);
  assert.match(output(javaResponseSemantic), /query and business persistence execute again/);
  assert.match(output(javaResponseSemantic), /placeholder families: CHANGE_ME, YOUR_\*/);
  assert.match(output(javaResponseSemantic), /credential fields: privateKey, alipayPublicKey/);

  const generatedFalseGreen = runValidator(path.join(__dirname, "fixtures", "java-generated-false-green"));
  assert.strictEqual(generatedFalseGreen.status, 1, output(generatedFalseGreen));
  assert.match(output(generatedFalseGreen), /rejects documented SINGLE mode/);
  assert.match(output(generatedFalseGreen), /SINGLE create models required fields but does not send them through Request\.setBizContent/);
  assert.match(output(generatedFalseGreen), /modify silently drops bill_scope\/combined_pay_mode\/default_invoice_kind/);
  assert.match(output(generatedFalseGreen), /fail-closed NotifyIdempotencyStore default/);
  assert.match(output(generatedFalseGreen), /production in-memory Map\/Set/);
  assert.match(output(generatedFalseGreen), /credential startup validation does not reject null\/blank/);

  const javaWrongSignContent = runValidator(path.join(__dirname, "fixtures", "java-manual-gateway-key-content-invalid"));
  assert.strictEqual(javaWrongSignContent.status, 1, output(javaWrongSignContent));
  assert.match(output(javaWrongSignContent), /response-sign content includes the response key/);
  assert.match(output(javaWrongSignContent), /positive test signs the response key plus value/);
  assert.match(output(javaWrongSignContent), /EnterpriseopenruleCreateRequest exposes setBizContent/);
  assert.match(output(javaWrongSignContent), /EmployertitleQueryRequest exposes setBizContent/);

  const javaPositionalOpenRule = runValidator(path.join(__dirname, "fixtures", "java-openrule-positional-invalid"));
  assert.strictEqual(javaPositionalOpenRule.status, 1, output(javaPositionalOpenRule));
  assert.match(output(javaPositionalOpenRule), /correlate by invoice_rule_record_id instead of array position/);
  assert.match(output(javaPositionalOpenRule), /no reordered-record test/);
  assert.match(output(javaPositionalOpenRule), /no query test for missing supplemental fields/);
  assert.match(output(javaPositionalOpenRule), /does not validate every mapped typed SINGLE record/);
  assert.match(output(javaPositionalOpenRule), /no test for a missing raw array\/record match/);
  assert.match(output(javaPositionalOpenRule), /no test proving missing raw open_mode/);
  assert.match(output(javaPositionalOpenRule), /no test for blank supplemental fields/);
  assert.match(output(javaPositionalOpenRule), /open-rule SINGLE setBizContent path test only checks text/);
  assert.match(output(javaPositionalOpenRule), /enterprise-title tax_register_no query setBizContent path test does not assert parsed JSON values/);
  assert.match(output(javaPositionalOpenRule), /references missing Java symbol: createSingleViaGateway/);
  assert.match(output(javaPositionalOpenRule), /references missing Java symbol: FailClosedInvoiceBusinessAdapter/);
  assert.match(output(javaPositionalOpenRule), /only supports title_id despite queryByTaxRegisterNo/);
  assert.match(output(javaPositionalOpenRule), /SDK-managed setBizContent path as a hand-written HTTP gateway/);
  assert.match(output(javaPositionalOpenRule), /all requests use setBizModel/);
  assert.match(output(javaPositionalOpenRule), /claims open-rule CreateModel SINGLE setters/);
  assert.match(output(javaPositionalOpenRule), /H2 is the default despite an external default datasource profile/);

  const javaSha1Gateway = runValidator(path.join(__dirname, "fixtures", "java-manual-gateway-sha1-invalid"));
  assert.strictEqual(javaSha1Gateway.status, 1, output(javaSha1Gateway));
  assert.match(output(javaSha1Gateway), /uses RSA\/SHA1-only response verification instead of RSA2/);
  assert.match(output(javaSha1Gateway), /positive test does not generate an RSA2\/SHA256 signature/);

  const javaQuality = runValidator(path.join(__dirname, "fixtures", "java-quality-invalid"));
  assert.strictEqual(javaQuality.status, 1, output(javaQuality));
  assert.match(output(javaQuality), /business success field is not checked with getSuccess/);
  assert.match(output(javaQuality), /rejects documented SINGLE mode/);
  assert.match(output(javaQuality), /has no focused test: enterprise-title/);
  assert.match(output(javaQuality), /raw response-body mapping has no focused test/);
  assert.match(output(javaQuality), /base application profile uses H2/);
  assert.match(output(javaQuality), /automatic schema mutation/);
  assert.match(output(javaQuality), /does not reject recognized placeholder values/);

  const productionIncomplete = runValidator(path.join(__dirname, "fixtures", "java-production-incomplete"));
  assert.strictEqual(productionIncomplete.status, 1, output(productionIncomplete));
  assert.match(output(productionIncomplete), /explicitly unresolved: open-rule SINGLE/);
  assert.match(output(productionIncomplete), /explicitly unresolved: enterprise-title tax_register_no query/);
  assert.match(output(productionIncomplete), /accept only Boolean.TRUE/);
  assert.match(output(productionIncomplete), /does not preflight documented required/);
  assert.match(output(productionIncomplete), /does not preflight enterpriseId\/invoiceNo/);
  assert.match(output(productionIncomplete), /fail-closed InvoiceBusinessPort default must be a plain implementation/);
  assert.match(output(productionIncomplete), /no MySQL JDBC driver/);
  assert.match(output(productionIncomplete), /no Flyway\/Liquibase migration/);
  assert.match(output(productionIncomplete), /does not reject null\/blank/);
  assert.match(output(productionIncomplete), /open-rule query does not preflight required invoiceRuleId/);
  assert.match(output(productionIncomplete), /failed-notification reacquire does not atomically refresh/);
  assert.match(output(productionIncomplete), /business persistence does not enforce enterprise\/invoice business-key/);
  assert.match(output(productionIncomplete), /business-key idempotency has no test for different delivery IDs/);
  assert.match(output(productionIncomplete), /placeholder credential validation can be bypassed/);
  assert.match(output(productionIncomplete), /credential validation has no test for whitespace-padded placeholder/);
  assert.match(output(productionIncomplete), /manual HTTP OpenAPI client does not verify/);
  assert.match(output(productionIncomplete), /response-sign verification has no negative test/);
  assert.match(output(productionIncomplete), /response-sign verification has no positive test/);
  assert.match(output(productionIncomplete), /open-rule query drops SINGLE/);
  assert.match(output(productionIncomplete), /invoice-query service cannot enforce invoice_code/);
  assert.match(output(productionIncomplete), /required strings do not all reject whitespace/);
  assert.match(output(productionIncomplete), /notification tests do not cover blank\/missing required fields individually/);
  assert.match(output(productionIncomplete), /notification tests do not cover documented enum rejection individually/);
  assert.match(output(productionIncomplete), /business-key idempotency has no real-database concurrency test/);
  assert.match(output(productionIncomplete), /successful response does not fail closed on required fields/);
  assert.match(output(productionIncomplete), /does not reject request\/response identity mismatch/);
  assert.match(output(productionIncomplete), /notification tests do not cover an in-flight processing conflict/);
  assert.match(output(productionIncomplete), /notification tests do not prove that query and business persistence execute again/);
  assert.match(output(productionIncomplete), /invoice-query tests do not cover missing required response fields/);
  assert.match(output(productionIncomplete), /invoice-query tests do not cover invalid monetary values/);
  assert.match(output(productionIncomplete), /invoice-query tests do not cover invalid response enums/);
  const missing = spawnSync(process.execPath, [validator, path.join(__dirname, "fixtures", "missing")], {
    encoding: "utf8",
  });
  assert.strictEqual(missing.status, 2, output(missing));
}

function assertExit(target, expected) {
  const result = runValidator(target);
  assert.strictEqual(result.status, expected, output(result));
}

function runValidator(target) {
  return spawnSync(process.execPath, [validator, target], { encoding: "utf8" });
}

function output(result) {
  return `${result.stdout || ""}\n${result.stderr || ""}`.trim();
}

function walk(root) {
  const files = [];
  for (const entry of fs.readdirSync(root, { withFileTypes: true })) {
    const full = path.join(root, entry.name);
    if (entry.isDirectory()) files.push(...walk(full));
    else if (entry.isFile()) files.push(full);
  }
  return files;
}
