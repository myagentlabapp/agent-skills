#!/usr/bin/env node
"use strict";

const fs = require("fs");
const path = require("path");

const targetDir = path.resolve(process.argv[2] || ".");
const textExtensions = new Set([
  ".java", ".kt", ".js", ".cjs", ".mjs", ".ts", ".py", ".go", ".cs", ".php",
  ".json", ".xml", ".yaml", ".yml", ".properties", ".sql",
]);

const requiredCapabilities = [
  capability(
    "alipay.ebpp.invoice.enterpriseexctrl.employertitle.create",
    "AlipayEbppInvoiceEnterpriseexctrlEmployertitleCreate",
  ),
  capability(
    "alipay.ebpp.invoice.enterpriseexctrl.employertitle.modify",
    "AlipayEbppInvoiceEnterpriseexctrlEmployertitleModify",
  ),
  capability(
    "alipay.ebpp.invoice.enterpriseexctrl.employertitle.query",
    "AlipayEbppInvoiceEnterpriseexctrlEmployertitleQuery",
  ),
  capability(
    "alipay.ebpp.invoice.enterpriseconsume.enterpriseopenrule.create",
    "AlipayEbppInvoiceEnterpriseconsumeEnterpriseopenruleCreate",
  ),
  capability(
    "alipay.ebpp.invoice.enterpriseconsume.enterpriseopenrule.modify",
    "AlipayEbppInvoiceEnterpriseconsumeEnterpriseopenruleModify",
  ),
  capability(
    "alipay.ebpp.invoice.enterpriseconsume.enterpriseopenrule.query",
    "AlipayEbppInvoiceEnterpriseconsumeEnterpriseopenruleQuery",
  ),
  capability(
    "alipay.ebpp.invoice.enterprise.newinvoice.notify",
    "AlipayEbppInvoiceEnterpriseNewinvoiceNotify",
  ),
  capability(
    "alipay.ebpp.invoice.enterprise.invoiceinfo.query",
    "AlipayEbppInvoiceEnterpriseInvoiceinfoQuery",
  ),
];

const employeeTitleCapabilities = [
  capability("alipay.commerce.ec.employee.title.create", "AlipayCommerceEcEmployeeTitleCreate"),
  capability("alipay.commerce.ec.employee.title.modify", "AlipayCommerceEcEmployeeTitleModify"),
  capability("alipay.commerce.ec.employee.title.delete", "AlipayCommerceEcEmployeeTitleDelete"),
];

run();

function run() {
  try {
    const errors = [];
    const warnings = [];
    if (!fs.existsSync(targetDir) || !fs.statSync(targetDir).isDirectory()) {
      broken(`target directory not found: ${targetDir}`);
    }

    const allFiles = walk(targetDir);
    const files = allFiles.filter((file) => textExtensions.has(path.extname(file).toLowerCase()));
    const documentationFiles = allFiles.filter((file) => path.extname(file).toLowerCase() === ".md"
      && !isTestOrDemoFile(file));
    if (files.length === 0) {
      errors.push("target contains no supported source or configuration files");
      report(errors, warnings);
      return;
    }

    const productionFiles = files.filter((file) => !isTestOrDemoFile(file));
    const testFiles = files.filter((file) => isTestFile(file));
    const text = files.map(read).join("\n");
    const productionText = productionFiles.map(read).join("\n");
    const javaProductionFiles = productionFiles.filter((file) => file.endsWith(".java"));
    const javaText = javaProductionFiles
      .map(read)
      .join("\n");
    const testText = testFiles.map(read).join("\n");
    checkCapabilities(text, requiredCapabilities, errors, "required push-mode capability");
    checkOptionalModuleCompleteness(text, employeeTitleCapabilities, errors, "employee-title");
    checkNotification(productionText, javaText, javaProductionFiles, errors);
    checkJavaOpenApi(javaText, javaProductionFiles, testFiles, testText, errors);
    checkJavaNotificationReliability(productionFiles, javaProductionFiles, testText, errors);
    checkRequiredCapabilityBlockers(productionText, javaProductionFiles, errors);
    checkJavaProductionConfig(productionFiles, javaProductionFiles, errors);
    checkJavaGeneratedDocumentation(documentationFiles, javaProductionFiles, productionFiles, errors);
    checkBatchModules(text, warnings);
    checkExistingProjectContract(errors);
    report(errors, warnings);
  } catch (error) {
    broken(error && error.stack ? error.stack : String(error));
  }
}

function capability(method, sdkPrefix) {
  return { method, sdkPrefix };
}

function hasCapability(text, item) {
  return text.includes(item.method) || text.includes(item.sdkPrefix);
}

function checkCapabilities(text, capabilities, errors, label) {
  for (const item of capabilities) {
    if (!hasCapability(text, item)) errors.push(`missing ${label}: ${item.method}`);
  }
}

function checkOptionalModuleCompleteness(text, capabilities, errors, moduleName) {
  const selected = capabilities.filter((item) => hasCapability(text, item));
  if (selected.length === 0 || selected.length === capabilities.length) return;
  const missing = capabilities.filter((item) => !hasCapability(text, item));
  errors.push(`${moduleName} is partially implemented; missing ${missing.map((item) => item.method).join(", ")}`);
}

function checkNotification(text, javaText, javaFiles, errors) {
  const sharedRouter = process.env.ALIPAY_MESSAGE_ROUTER_MODE === "shared";
  const websocketSelected = sharedRouter || /AlipayMsgClient|MsgHandler|@ClientEndpoint|(?:javax|jakarta)\.websocket|org\.java_websocket/.test(text);
  const httpSelected = hasHttpNotifyId(text) || /(?:checkNotifySign(?:V2)?|rsaCheckV?1|rsaCertCheckV?1)/.test(text);

  if (!websocketSelected && !httpSelected) {
    errors.push("invoice notification must implement HTTP(S) or official Java WebSocket message intake");
  }
  if (httpSelected) checkHttpNotification(text, errors);
  if (websocketSelected) checkWebSocketNotification(text, javaText, errors, sharedRouter);

  if (!/(?:invoice_kind|invoiceKind)/.test(text) || !/(?:invoice_code|invoiceCode)/.test(text)) {
    errors.push("invoice notification does not preserve invoice_kind/invoice_code conditional handling");
  }
  if (!/(?:idempoten|dedup|tryAcquire|putIfAbsent|notify[_A-Za-z]*state|processedNotify|message[_A-Za-z]*state)/i.test(text)) {
    errors.push("invoice notification has no recognizable idempotency handling");
  }
  checkNotificationBusinessFields(text, javaFiles, errors);
}

function checkNotificationBusinessFields(text, javaFiles, errors) {
  const javaNotificationFiles = javaFiles.filter((file) => {
    const source = read(file);
    return /notify|message/i.test(path.basename(file))
      || source.includes("alipay.ebpp.invoice.enterprise.newinvoice.notify");
  });
  const logicFiles = javaNotificationFiles.filter((file) => !/(?:Dto|Content|Payload|Model)\.java$/i.test(file));
  const logicText = logicFiles.length > 0 ? logicFiles.map(read).join("\n") : text;
  const required = [
    ["enterprise_id", /(?:getEnterpriseId\s*\(|\.enterpriseId\b|enterprise_id\b)/],
    ["employee_id", /(?:getEmployeeId\s*\(|\.employeeId\b|employee_id\b)/],
    ["einv_id", /(?:getEinvId\s*\(|\.einvId\b|einv_id\b)/],
    ["invoice_no", /(?:getInvoiceNo\s*\(|\.invoiceNo\b|invoice_no\b)/],
    ["invoice_kind", /(?:getInvoiceKind\s*\(|\.invoiceKind\b|invoice_kind\b)/],
    ["notify_reason", /(?:getNotifyReason\s*\(|\.notifyReason\b|notify_reason\b)/],
    ["collect_source", /(?:getCollectSource\s*\(|\.collectSource\b|collect_source\b)/],
  ];
  const missing = required.filter(([, pattern]) => !pattern.test(logicText)).map(([name]) => name);
  if (missing.length > 0) {
    errors.push(`invoice notification does not validate required business fields: ${missing.join(", ")}`);
  }
  for (const [label, values] of [
    ["invoice_kind", ["0", "1", "2", "3", "4", "31", "32"]],
    ["notify_reason", ["INVOICE_COLLECT", "INVOICE_INFO_CHANGE"]],
    ["collect_source", ["INVOICE_EMAIL", "OTHER"]],
  ]) {
    if (!values.every((value) => logicText.includes(`\"${value}\"`) || logicText.includes(`'${value}'`) || logicText.includes(`\`${value}\``))) {
      errors.push(`invoice notification does not fail closed against the documented ${label} enum`);
    }
  }
}

function checkHttpNotification(text, errors) {
  if (!hasHttpNotifyId(text)) {
    errors.push("HTTP(S) invoice notification does not use notify_id as the delivery idempotency key");
  }
  if (!/(?:checkNotifySign(?:V2)?|rsaCheckV?1|rsaCertCheckV?1|verify(?:Notification|Notify|Signature|Sign)|VerifySignature)/i.test(text)) {
    errors.push("HTTP(S) invoice notification has no recognizable real signature-verification call");
  }
  if (hasFixedTrueSignatureVerifier(text)) {
    errors.push("HTTP(S) invoice notification signature verifier returns a fixed true result");
  }
  if (!/["'`]success["'`]/i.test(text) || !/["'`]fail["'`]/i.test(text)) {
    errors.push("HTTP(S) invoice notification must expose both success and fail acknowledgement paths");
  }
}

function hasHttpNotifyId(text) {
  return /(?:\bnotify_id\b|\bnotifyId\b)/.test(text);
}

function checkWebSocketNotification(text, javaText, errors, sharedRouter) {
  if (/@ClientEndpoint|(?:javax|jakarta)\.websocket|org\.java_websocket|Java-WebSocket/.test(javaText)) {
    errors.push("Java WebSocket notification hand-rolls the protocol; use official AlipayMsgClient + MsgHandler");
  }
  if (!/(?:msgId|msg_id)/.test(text)) {
    errors.push("WebSocket invoice notification does not use callback msgId as the delivery idempotency key");
  }
  if (!/(?:msgApi|msg_api)/.test(text) || !text.includes("alipay.ebpp.invoice.enterprise.newinvoice.notify")) {
    errors.push("WebSocket invoice notification does not route msgApi to alipay.ebpp.invoice.enterprise.newinvoice.notify");
  }
  if (!/\bthrow\b|completeExceptionally\s*\(|(?:return|complete)\s+(?:false|FAIL|RETRY)/i.test(text)) {
    errors.push("WebSocket invoice notification has no failure path that can trigger message retry");
  }
  if (sharedRouter) return;

  const hasClient = /AlipayMsgClient\.getInstance\s*\(|AlipayMsgClient\s+[A-Za-z0-9_]+/.test(javaText);
  const hasSecurity = /setSecurity(?:Config|CertConfig)\s*\(/.test(javaText);
  const hasExecutableLifecycle = hasClient
    && /setConnector\s*\(/.test(javaText)
    && hasSecurity
    && /setMessageHandler\s*\(/.test(javaText)
    && /\.connect\s*\(/.test(javaText);
  if (!hasExecutableLifecycle) {
    errors.push("Java WebSocket message intake must contain executable getInstance + setConnector + security config + setMessageHandler + connect logic");
  }
  if (/setSecurityConfig\s*\(\s*(?:appId|["'][0-9]{10,}["'])\s*,/i.test(javaText)) {
    errors.push("AlipayMsgClient.setSecurityConfig first argument must be signType, not appId");
  }
  if (/AlipayMsgClient|MsgHandler/.test(javaText) && /rsaCheckV?1\s*\(|checkNotifySign(?:V2)?\s*\(/.test(javaText)) {
    errors.push("WebSocket MsgHandler must not re-run HTTP notification signature verification on bizContent");
  }
}

function hasFixedTrueSignatureVerifier(text) {
  const pattern = /(?:function\s+|(?:public|private|protected|static|async|boolean|bool|Boolean)\s+)*(?:verify[A-Za-z0-9_]*(?:Sign|Signature|Notify|Notification)|checkNotifySign[A-Za-z0-9_]*)\s*\([^)]*\)\s*(?::\s*(?:boolean|bool|Boolean)\s*)?\{([^{}]{0,500})\}/gi;
  for (const match of text.matchAll(pattern)) {
    const body = match[1].replace(/\s+/g, " ").trim();
    if (/^return\s+true\s*;?$/.test(body)) return true;
  }
  return false;
}

function checkJavaOpenApi(javaText, javaFiles, testFiles, testText, errors) {
  if (!javaText) return;

  const typedSuccessResponses = [
    "AlipayEbppInvoiceEnterpriseexctrlEmployertitleCreateResponse",
    "AlipayEbppInvoiceEnterpriseexctrlEmployertitleModifyResponse",
    "AlipayEbppInvoiceEnterpriseconsumeEnterpriseopenruleModifyResponse",
  ];
  for (const type of typedSuccessResponses) {
    const declaration = new RegExp(`\\b${type}\\s+([A-Za-z_$][A-Za-z0-9_$]*)`, "g");
    const variables = [...javaText.matchAll(declaration)].map((match) => match[1]);
    if (variables.length > 0 && !variables.every((name) => new RegExp(`\\b${escapeRegExp(name)}\\.getSuccess\\s*\\(`).test(javaText))) {
      errors.push(`${type} business success field is not checked with getSuccess()`);
    }
    if (variables.length > 0 && !variables.every((name) => hasFailClosedBusinessSuccessCheck(javaText, name))) {
      errors.push(`${type} must treat getSuccess() null/false as failure and accept only Boolean.TRUE`);
    }
  }

  for (const file of javaFiles) {
    const source = read(file);
    const executable = stripJavaComments(source);
    const throwsUnsupported = /\bthrow\s+new\s+(?:java\.lang\.)?UnsupportedOperationException\s*\(/.test(executable);
    const rejectsSingle = /(?:only\s+(?:supports?\s+)?SUMMARY(?:\s+is\s+supported)?|(?:仅|只)\s*支持\s*SUMMARY)(?!\s*(?:\/|\||、|或|and)\s*SINGLE)/i.test(executable);
    const createBody = findJavaMethodBody(executable, "create", null);
    const rejectsSingleWithFixedFailure = createBody
      && /SINGLE/.test(createBody)
      && /throw\s+new\s+[A-Za-z0-9_$.]*(?:Exception|Error)\s*\([^;]{0,320}(?:暂不支持|不支持[^;]{0,80}SINGLE|SINGLE[^;]{0,80}(?:暂不支持|未实现|无法实现|未覆盖边界|需升级)|需升级[^;]{0,80}(?:SDK|SINGLE))/i.test(createBody);
    if (/EnterpriseopenruleCreate|EnterpriseOpenRuleService/.test(executable)
        && /SINGLE/.test(executable)
        && (throwsUnsupported || rejectsSingle || rejectsSingleWithFixedFailure)) {
      errors.push("open-rule module rejects documented SINGLE mode while claiming required capability coverage");
    }

    if (/EnterpriseOpenRuleService\.java$/i.test(file)) {
      const singleFields = ["BillScope", "CombinedPayMode", "DefaultInvoiceKind"];
      const modelsSingleCreate = createBody && singleFields.every((name) => new RegExp(`get${name}\\s*\\(`).test(createBody));
      if (modelsSingleCreate && !/\.setBizContent\s*\(/.test(createBody)) {
        errors.push("open-rule SINGLE create models required fields but does not send them through Request.setBizContent");
      }

      const modifyBody = findJavaMethodBody(executable, "modify", null);
      const modifyCommand = findJavaClassBody(source, "ModifyCommand");
      const commandExposesSingleFields = modifyCommand
        && singleFields.every((name) => new RegExp(`get${name}\\s*\\(`).test(modifyCommand));
      const modifyMapsSingleFields = modifyBody && singleFields.every((name) =>
        new RegExp(`get${name}\\s*\\(|set${name}\\s*\\(|${name.charAt(0).toLowerCase() + name.slice(1)}`).test(modifyBody));
      if (modifyBody && commandExposesSingleFields && !modifyMapsSingleFields) {
        errors.push("open-rule modify silently drops bill_scope/combined_pay_mode/default_invoice_kind");
      }
    }
  }

  const openRuleText = javaFiles
    .filter((file) => /OpenRule|Enterpriseopenrule/i.test(path.basename(file)) || /Enterpriseopenrule/.test(read(file)))
    .map(read)
    .join("\n");
  if (openRuleText && !["MERCHANT", "TP", "DEFAULT", "EMPLOYEE_TITLE_FIRST"].every((value) => openRuleText.includes(`\"${value}\"`))) {
    errors.push("open-rule module does not fail closed against documented seller_type/tag enums");
  }

  const coreModules = [
    ["enterprise-title", /EnterpriseTitleService|EmployertitleCreateResponse/, /EnterpriseTitle/i, /Employertitle(?:Create|Modify|Query)Response/],
    ["open-rule", /EnterpriseOpenRuleService|EnterpriseopenruleCreateResponse/, /OpenRule/i, /Enterpriseopenrule(?:Create|Modify|Query)Response/],
    ["invoice-query", /EnterpriseInvoiceQueryService|EnterpriseInvoiceinfoQueryResponse/, /EnterpriseInvoiceQuery/i, /EnterpriseInvoiceinfoQueryResponse/],
  ];
  for (const [name, productionPattern, testNamePattern, responsePattern] of coreModules) {
    const hasFocusedTest = testFiles.some((file) => testNamePattern.test(path.basename(file)))
      || responsePattern.test(testText);
    if (productionPattern.test(javaText) && !hasFocusedTest) {
      errors.push(`Java required module has no focused test: ${name}`);
    }
  }
  if (/EnterpriseInvoiceQueryService|EnterpriseInvoiceinfoQueryResponse/.test(javaText)
      && /getBody\s*\(|invoice_item_list|mapFromBody/.test(javaText)
      && !/getBody\s*\(|invoice_item_list|mapFromBody/.test(testText)) {
    errors.push("Java invoice-query raw response-body mapping has no focused test");
  }

  checkJavaManualGatewayResponseVerification(javaFiles, testFiles, errors);
  checkJavaSdkBizContentTests(javaFiles, testFiles, errors);
  checkJavaOpenRuleSingleQueryMapping(javaFiles, testFiles, errors);
  checkJavaRequiredFieldPreflight(javaFiles, errors);
  checkJavaInvoiceQueryResponseContract(javaFiles, testFiles, errors);
  checkJavaNotificationTestCoverage(javaFiles, testFiles, errors);
  checkJavaInvoiceSpringWiringTests(javaFiles, testFiles, errors);
  checkJavaBusinessKeyConcurrencyTests(javaFiles, testFiles, errors);
  for (const file of javaFiles) {
    const source = stripJavaComments(read(file));
    if (/FailClosedInvoiceBusinessAdapter\.java$/i.test(file)
        && /return\s+false\s*;/.test(source)
        && !/implements\s+InvoiceBusinessPort\b/.test(source)
        && !hasSafeConditionalDefault(javaFiles, source, "InvoiceBusinessPort")) {
      errors.push("fail-closed InvoiceBusinessPort default must be a plain implementation created by a @Configuration @Bean guarded with @ConditionalOnMissingBean(InvoiceBusinessPort.class), and must not be a scanned component or @Primary");
    }
  }
}

function checkJavaSdkBizContentTests(javaFiles, testFiles, errors) {
  const cases = [
    {
      requestType: "AlipayEbppInvoiceEnterpriseconsumeEnterpriseopenruleCreateRequest",
      testFile: /OpenRule/i,
      fields: ["enterprise_id", "invoice_rule_name", "open_mode", "bill_scope", "combined_pay_mode", "default_invoice_kind"],
      label: "open-rule SINGLE",
    },
    {
      requestType: "AlipayEbppInvoiceEnterpriseconsumeEnterpriseopenruleModifyRequest",
      testFile: /OpenRule/i,
      fields: ["enterprise_id", "invoice_rule_id", "invoice_rule_name", "bill_scope", "combined_pay_mode", "default_invoice_kind"],
      label: "open-rule modify SINGLE fields",
    },
    {
      requestType: "AlipayEbppInvoiceEnterpriseexctrlEmployertitleQueryRequest",
      testFile: /EnterpriseTitle|EmployerTitle/i,
      fields: ["enterprise_id", "tax_register_no"],
      label: "enterprise-title tax_register_no query",
    },
  ];

  for (const item of cases) {
    const usesBizContent = javaFiles.some((file) => {
      const source = stripJavaComments(read(file));
      return source.includes(item.requestType) && /\.setBizContent\s*\(/.test(source);
    });
    if (!usesBizContent) continue;

    const tests = testFiles
      .filter((file) => item.testFile.test(path.basename(file)))
      .map((file) => stripJavaComments(read(file)))
      .join("\n");
    const capturesRequest = /ArgumentCaptor|argThat\s*\(|\.capture\s*\(|getArgument\s*\(/.test(tests);
    const readsBizContent = /\.getBizContent\s*\(/.test(tests);
    if (!capturesRequest || !readsBizContent) {
      errors.push(`Java ${item.label} setBizContent path test does not capture the executed Request and inspect getBizContent()`);
      continue;
    }
    const parsesJson = /(?:readTree|readValue|parseObject|parseString|fromJson)\s*\([^)]*(?:bizContent|biz|json|payload|content)/i.test(tests);
    if (!parsesJson) {
      errors.push(`Java ${item.label} setBizContent path test only checks text; parse getBizContent() as JSON before asserting values`);
      continue;
    }
    const missingValueAssertions = item.fields.filter((field) => !hasStructuredJsonValueAssertion(tests, field));
    if (missingValueAssertions.length > 0) {
      errors.push(`Java ${item.label} setBizContent path test does not assert parsed JSON values for required fields: ${missingValueAssertions.join(", ")}`);
    }
  }
}

function hasStructuredJsonValueAssertion(source, field) {
  const escaped = escapeRegExp(field);
  const accessor = `(?:\\.path|\\.get)\\s*\\(\\s*["']${escaped}["']\\s*\\)(?:\\.asText\\s*\\(\\s*\\))?`;
  const junit = new RegExp(`assertEquals\\s*\\([^;]{0,260}${accessor}[^;]{0,80}\\)`).test(source);
  const assertJ = new RegExp(`assertThat\\s*\\([^;]{0,180}${accessor}[^;]{0,180}\\)\\s*\\.isEqualTo\\s*\\(`).test(source);
  const helper = new RegExp(`(?:assertJsonValue|assertJsonFieldEquals|assertFieldEquals)\\s*\\([^;]{0,180}["']${escaped}["'][^;]{0,180}\\)`).test(source);
  return junit || assertJ || helper;
}

function checkJavaManualGatewayResponseVerification(javaFiles, testFiles, errors) {
  const manualGateways = javaFiles.filter((file) => {
    const source = stripJavaComments(read(file));
    return /AlipaySignature\.sign\s*\(/.test(source)
      && /HttpURLConnection|HttpClient|postForm\s*\(|openConnection\s*\(/.test(source);
  });
  if (manualGateways.length === 0) return;

  const gatewaySources = manualGateways.map((file) => stripJavaComments(read(file)));
  const sdkManagedRequests = [
    {
      type: "AlipayEbppInvoiceEnterpriseconsumeEnterpriseopenruleCreateRequest",
      method: "alipay.ebpp.invoice.enterpriseconsume.enterpriseopenrule.create",
    },
    {
      type: "AlipayEbppInvoiceEnterpriseexctrlEmployertitleQueryRequest",
      method: "alipay.ebpp.invoice.enterpriseexctrl.employertitle.query",
    },
  ];
  for (const request of sdkManagedRequests) {
    const bypassesSdkManagedExecution = javaFiles.some((file) => {
      const source = stripJavaComments(read(file));
      return source.includes(request.type)
        && source.includes(request.method)
        && /(?:gateway|http|openApi)[A-Za-z0-9_$]*\.execute\s*\(|HttpURLConnection|postForm\s*\(|openConnection\s*\(/i.test(source)
        && !/\.setBizContent\s*\(/.test(source);
    });
    if (bypassesSdkManagedExecution) {
      errors.push(`${request.type} exposes setBizContent; use AlipayClient.execute instead of a hand-written HTTP gateway`);
    }
  }

  if (gatewaySources.some((source) =>
    /indexOf\s*\(\s*["']\\?["']alipay_/.test(source)
      && /substring\s*\(\s*(?:keyIdx|keyIndex|responseKeyIdx|responseKeyIndex)\b/.test(source))) {
    errors.push("Java manual HTTP OpenAPI response-sign content includes the response key; extract only the alipay_*_response JSON value object");
  }
  const responseVerificationCalls = gatewaySources.flatMap((source) => [
    ...findJavaCalls(source, "AlipaySignature.rsa256CheckContent"),
    ...findJavaCalls(source, "AlipaySignature.rsaCheck"),
    ...findJavaCalls(source, "AlipaySignature.rsaCertCheck"),
  ]).filter((call) => /(?:response|body|content)/i.test(call.args[0] || "")
    && /sign/i.test(call.args[1] || ""));
  const verifiesRsa2Response = responseVerificationCalls.some((call) =>
    (call.method.endsWith("rsa256CheckContent") && call.args.length === 4)
      || (/(?:rsaCheck|rsaCertCheck)$/.test(call.method)
        && call.args.length === 5
        && !/^["']RSA["']$/.test(call.args[4].trim())));
  const usesSha1OnlyResponseCheck = gatewaySources.some((source) => {
    const fixedRsaCalls = findJavaCalls(source, "AlipaySignature.rsaCheckContent")
      .filter((call) => call.args.length === 4);
    const explicitRsaCalls = [
      ...findJavaCalls(source, "AlipaySignature.rsaCheck"),
      ...findJavaCalls(source, "AlipaySignature.rsaCertCheck"),
    ].filter((call) => call.args.length === 5 && /^["']RSA["']$/.test(call.args[4].trim()));
    return [...fixedRsaCalls, ...explicitRsaCalls].some((call) =>
      /(?:response|body|content)/i.test(call.args[0] || "")
        && /sign/i.test(call.args[1] || ""));
  });
  if (!verifiesRsa2Response && !usesSha1OnlyResponseCheck) {
    errors.push("Java manual HTTP OpenAPI client does not verify the Alipay response sign before accepting the business node");
  }
  if (usesSha1OnlyResponseCheck && !verifiesRsa2Response) {
    errors.push("Java manual HTTP OpenAPI client uses RSA/SHA1-only response verification instead of RSA2");
  }

  const gatewayTests = testFiles
    .filter((file) => /Gateway|OpenApi|AlipayClient/i.test(path.basename(file)))
    .map((file) => stripJavaComments(read(file)));
  const gatewayTestText = gatewayTests.join("\n");
  if (/(?:signedContent|signContent|contentToSign|content)\s*=\s*["']\\?["']alipay_[A-Za-z0-9_]+_response\\?["']\s*:/i.test(gatewayTestText)) {
    errors.push("Java manual HTTP OpenAPI positive test signs the response key plus value instead of the official response value object");
  }
  if (!/(?:invalid|bad|tamper|missing|wrong|非法|错误|篡改|缺失)[A-Za-z0-9_\s-]{0,80}(?:response)?sign|(?:response)?sign[A-Za-z0-9_\s-]{0,80}(?:invalid|bad|tamper|missing|wrong|非法|错误|篡改|缺失)/i.test(gatewayTestText)) {
    errors.push("Java manual HTTP OpenAPI response-sign verification has no negative test for a missing/invalid/tampered sign");
  }
  const hasValidSignedResponseTest = gatewayTests.some((source) =>
    /verifyResponseSign\s*\(/.test(source)
    && hasRsa2SignatureGenerator(source)
    && /(?:assertDoesNotThrow|assertTrue|valid[A-Za-z0-9_]*(?:Response)?Sign[A-Za-z0-9_]*(?:accept|pass|success)|(?:accept|pass|success)[A-Za-z0-9_]*Valid[A-Za-z0-9_]*(?:Response)?Sign)/i.test(source));
  const hasNonRsa2PositiveSignatureTest = gatewayTests.some((source) =>
    /verifyResponseSign\s*\(/.test(source)
    && /(?:AlipaySignature\.(?:sign|rsaSign)|Signature\.getInstance)\s*\(/.test(source)
    && !hasRsa2SignatureGenerator(source)
    && /(?:assertDoesNotThrow|assertTrue|valid[A-Za-z0-9_]*(?:Response)?Sign[A-Za-z0-9_]*(?:accept|pass|success)|(?:accept|pass|success)[A-Za-z0-9_]*Valid[A-Za-z0-9_]*(?:Response)?Sign)/i.test(source));
  if (!hasValidSignedResponseTest && !hasNonRsa2PositiveSignatureTest) {
    errors.push("Java manual HTTP OpenAPI response-sign verification has no positive test that generates a valid signature and accepts the response");
  }
  if (hasNonRsa2PositiveSignatureTest && !hasValidSignedResponseTest) {
    errors.push("Java manual HTTP OpenAPI response-sign positive test does not generate an RSA2/SHA256 signature");
  }
}

function hasRsa2SignatureGenerator(source) {
  if (/AlipaySignature\.rsa256Sign\s*\(/.test(source)
      || /Signature\.getInstance\s*\(\s*["']SHA256withRSA["']\s*\)/i.test(source)) {
    return true;
  }
  return findJavaCalls(source, "AlipaySignature.sign").some((call) => {
    if (call.args.length !== 4) return false;
    const signType = call.args[3].trim();
    if (/^["']RSA2["']$/.test(signType)) return true;
    if (!/^[A-Za-z_$][A-Za-z0-9_$]*$/.test(signType)) return false;
    return new RegExp(`\\b${escapeRegExp(signType)}\\s*=\\s*["']RSA2["']`).test(source);
  });
}

function checkJavaOpenRuleSingleQueryMapping(javaFiles, testFiles, errors) {
  const serviceFiles = javaFiles.filter((file) => /EnterpriseOpenRuleService\.java$/i.test(file));
  for (const file of serviceFiles) {
    const source = stripJavaComments(read(file));
    if (!/\bSINGLE\b/.test(source) || !/\bquery\s*\(/.test(source)) continue;
    const body = findJavaMethodBody(source, "query", /invoiceRuleId/);
    if (!body) continue;
    const fields = ["bill_scope", "combined_pay_mode", "default_invoice_kind"];
    const typedGetters = ["getBillScope", "getCombinedPayMode", "getDefaultInvoiceKind"];
    const mapsTyped = typedGetters.every((name) => new RegExp(`\\b${name}\\s*\\(`).test(body));
    const mapsRaw = /getBody\s*\(/.test(body)
      && fields.every((name) => new RegExp(`${name}|${snakeToCamel(name)}`).test(body));
    if (!mapsTyped && !mapsRaw) {
      errors.push("Java open-rule query drops SINGLE bill_scope/combined_pay_mode/default_invoice_kind instead of mapping typed getters or the raw response body");
    }

    if (mapsRaw) {
      const mapsByStableId = /invoice_rule_record_id|invoiceRuleRecordId/.test(body)
        && /getInvoiceRuleRecordId\s*\(/.test(body);
      const mapsByPosition = /\.get\s*\(\s*(?:i|index|idx)\s*\)/.test(body);
      if (!mapsByStableId || mapsByPosition) {
        errors.push("Java open-rule raw SINGLE records must correlate by invoice_rule_record_id instead of array position");
      }
      if (/String\s+[A-Za-z_$][A-Za-z0-9_$]*\s*=\s*(?:text|read)[A-Za-z0-9_$]*\s*\([^;]*["']open_mode["'][^;]*\)[\s\S]{0,500}["']SINGLE["']\.equals\s*\(/.test(body)) {
        errors.push("Java open-rule query trusts raw open_mode to decide SINGLE completeness instead of the typed record");
      }
      if (/if\s*\(\s*[A-Za-z_$][A-Za-z0-9_$]*\s*==\s*null\s*\)\s*\{?\s*continue\s*;/.test(body)) {
        errors.push("Java open-rule query silently skips an unmatched raw record instead of failing a typed SINGLE record closed");
      }

      const validatesTypedSingle = /getOpenMode\s*\(\s*\)/.test(body)
        && typedGetters.every((name) => new RegExp(`\\b${name}\\s*\\(`).test(body))
        && /(?:require|validate|check|assert)[A-Za-z0-9_$]*(?:Single|Supplemental|ResponseFields)[A-Za-z0-9_$]*\s*\(|\bthrow\b/.test(body);
      if (!validatesTypedSingle) {
        errors.push("Java open-rule query does not validate every mapped typed SINGLE record for a raw match and three nonblank supplemental fields");
      }
    }

    const openRuleTests = testFiles
      .filter((testFile) => /OpenRule/i.test(path.basename(testFile)))
      .map(read)
      .join("\n");
    if (!fields.every((name) => new RegExp(`${name}|${snakeToCamel(name)}`, "i").test(openRuleTests))) {
      errors.push("Java open-rule query has no focused test for all SINGLE response fields");
    }
    if (mapsRaw && (!/invoice_rule_record_id|invoiceRuleRecordId/i.test(openRuleTests)
        || !/(?:reorder|outOfOrder|differentOrder|rawOrder|乱序|顺序不同)/i.test(openRuleTests))) {
      errors.push("Java open-rule raw SINGLE mapping has no reordered-record test proving invoice_rule_record_id correlation");
    }
    if (mapsRaw && (!/query[A-Za-z0-9_]*(?:missing|absent|null|缺失)/i.test(openRuleTests)
        || !/assertThrows|expectThrows|assertThatThrownBy/i.test(openRuleTests))) {
      errors.push("Java open-rule raw SINGLE mapping has no query test for missing supplemental fields failing closed");
    }
    if (mapsRaw && !/query[A-Za-z0-9_]*(?:missing|absent)[A-Za-z0-9_]*(?:Raw|Record|Match|Array|Node)/i.test(openRuleTests)) {
      errors.push("Java open-rule raw SINGLE mapping has no test for a missing raw array/record match");
    }
    if (mapsRaw && !/query[A-Za-z0-9_]*(?:missing|absent)[A-Za-z0-9_]*(?:OpenMode|RawOpenMode)/i.test(openRuleTests)) {
      errors.push("Java open-rule raw SINGLE mapping has no test proving missing raw open_mode cannot bypass typed SINGLE validation");
    }
    if (mapsRaw && !/query[A-Za-z0-9_]*(?:blank|whitespace|empty)[A-Za-z0-9_]*(?:Supplemental|BillScope|Fields)/i.test(openRuleTests)) {
      errors.push("Java open-rule raw SINGLE mapping has no test for blank supplemental fields failing closed");
    }
  }
}

function checkJavaGeneratedDocumentation(documentationFiles, javaFiles, productionFiles, errors) {
  if (javaFiles.length === 0) return;
  const narrativeFiles = [...new Set([
    ...documentationFiles,
    ...productionFiles.filter((file) => [".java", ".xml", ".yaml", ".yml", ".properties"].includes(path.extname(file).toLowerCase())),
  ])];
  const narrative = narrativeFiles.map(read).join("\n");
  const narrativeLines = narrative.split(/\r?\n/);
  const java = javaFiles.map((file) => stripJavaComments(read(file))).join("\n");

  for (const symbol of ["createSingleViaGateway", "AlipayGatewayClient", "FailClosedInvoiceBusinessAdapter"]) {
    if (new RegExp(`\\b${symbol}\\b`).test(narrative) && !new RegExp(`\\b${symbol}\\b`).test(java)) {
      errors.push(`generated documentation references missing Java symbol: ${symbol}`);
    }
  }

  if (/queryByTaxRegisterNo\s*\(/.test(java)
      && narrativeLines.some((line) => /查询仅支持\s*`?title_id|query\s+only\s+supports?\s+`?title_id/i.test(line))) {
    errors.push("generated documentation says enterprise-title query only supports title_id despite queryByTaxRegisterNo implementation");
  }

  const usesSdkBizContent = /\.setBizContent\s*\(/.test(java);
  if (usesSdkBizContent) {
    const staleGatewayDescription = narrativeLines.some((line) =>
      /(?:SINGLE|tax_register_no)/i.test(line)
        && /(?:经|走|使用|via).{0,20}(?:HTTP\(S\)|HTTP).{0,20}(?:网关|gateway)|(?:HTTP\(S\)|HTTP).{0,20}(?:网关|gateway).{0,20}(?:实现|调用)/i.test(line));
    if (staleGatewayDescription) {
      errors.push("generated documentation describes an SDK-managed setBizContent path as a hand-written HTTP gateway");
    }
    if (narrativeLines.some((line) => /(?:请求.*一律|一律.*请求|统一.*Request|request.*(?:all|always)).*setBizModel/i.test(line))) {
      errors.push("generated documentation claims all requests use setBizModel despite setBizContent workaround paths");
    }
  }

  const claimsCreateModelSingleSetters = narrativeLines.some((line) =>
    /新增开票规则|open.?rule.*create/i.test(line)
      && ["setBillScope", "setCombinedPayMode", "setDefaultInvoiceKind"].every((name) => line.includes(name)));
  const createUsesBizContent = /AlipayEbppInvoiceEnterpriseconsumeEnterpriseopenruleCreateRequest[\s\S]{0,1800}\.setBizContent\s*\(/.test(java);
  if (claimsCreateModelSingleSetters && createUsesBizContent) {
    errors.push("generated documentation claims open-rule CreateModel SINGLE setters that the implementation treats as absent");
  }

  const baseConfigText = productionFiles
    .filter((file) => /(?:^|\/)(?:application|bootstrap)\.(?:ya?ml|properties)$/i.test(normalize(file)))
    .map(read)
    .join("\n");
  const baseUsesExternalRdbms = /jdbc:(?:mysql|mariadb|postgresql|oracle|sqlserver):/i.test(baseConfigText)
    && !/jdbc:h2:/i.test(baseConfigText);
  if (baseUsesExternalRdbms && narrativeLines.some((line) =>
    /(?:默认(?:使用|采用|为|是)?\s*(?:嵌入式\s*)?H2|H2[^。\n]{0,20}(?:开发)?默认)/i.test(line))) {
    errors.push("generated documentation says H2 is the default despite an external default datasource profile");
  }
}

function hasFailClosedBusinessSuccessCheck(javaText, responseName) {
  const direct = `${escapeRegExp(responseName)}\\.getSuccess\\s*\\(\\s*\\)`;
  if (new RegExp(`Boolean\\.TRUE\\.equals\\s*\\(\\s*${direct}\\s*\\)`).test(javaText)) return true;
  if (new RegExp(`${direct}\\s*==\\s*null`).test(javaText)
      && new RegExp(`!\\s*${direct}|Boolean\\.FALSE\\.equals\\s*\\(\\s*${direct}\\s*\\)`).test(javaText)) return true;

  const aliasPattern = new RegExp(`\\bBoolean\\s+([A-Za-z_$][A-Za-z0-9_$]*)\\s*=\\s*${direct}`);
  const aliasMatch = javaText.match(aliasPattern);
  if (!aliasMatch) return false;
  const alias = escapeRegExp(aliasMatch[1]);
  return new RegExp(`Boolean\\.TRUE\\.equals\\s*\\(\\s*${alias}\\s*\\)`).test(javaText)
    || (new RegExp(`\\b${alias}\\s*==\\s*null`).test(javaText)
      && new RegExp(`!\\s*${alias}\\b|Boolean\\.FALSE\\.equals\\s*\\(\\s*${alias}\\s*\\)`).test(javaText));
}

function checkJavaRequiredFieldPreflight(javaFiles, errors) {
  for (const file of javaFiles) {
    const source = stripJavaComments(read(file));
    if (/EnterpriseTitleService\.java$/i.test(file)) {
      const hasTitlePreflight = /(?:validate|require|isBlank|hasText|notBlank)/.test(source)
        && /getIdentity\s*\(/.test(source)
        && /getTitleName\s*\(/.test(source)
        && /getTaxRegisterNo\s*\(/.test(source)
        && /titleId/.test(source);
      if (!hasTitlePreflight) {
        errors.push("Java enterprise-title service does not preflight documented required create/modify/query fields");
      }
      const blankSafeTitleFields = ["TitleName", "TaxRegisterNo", "TitleId"];
      if (!blankSafeTitleFields.every((name) => hasJavaBlankCheck(source, name))) {
        errors.push("Java enterprise-title required strings do not all reject whitespace-only values before the SDK/gateway call");
      }
    }
    if (/EnterpriseInvoiceQueryService\.java$/i.test(file)) {
      const checksEnterpriseId = /(?:isBlank|hasText|notBlank|require)\s*\([^;]{0,160}\benterpriseId\b/i.test(source);
      const checksInvoiceNo = /(?:isBlank|hasText|notBlank|require)\s*\([^;]{0,160}\binvoiceNo\b/i.test(source);
      if (!checksEnterpriseId || !checksInvoiceNo) {
        errors.push("Java invoice-query service does not preflight enterpriseId/invoiceNo before the SDK call");
      }
      const queryBody = findJavaMethodBody(source, "query", /invoiceNo/);
      const queryParameters = findJavaMethodParameterLists(source, "query");
      const hasKindInput = queryParameters.some((parameters) => /\binvoiceKind\b|\bInvoiceKind\b/.test(parameters))
        || (queryBody && /getInvoiceKind\s*\(/.test(queryBody));
      const preRequestBody = queryBody && queryBody.split(/new\s+[A-Za-z0-9_$.]*InvoiceinfoQueryModel|setBizModel\s*\(|execute\s*\(/)[0];
      const checksConditionalCode = preRequestBody
        && /invoiceKind|getInvoiceKind/.test(preRequestBody)
        && /invoiceCode|getInvoiceCode/.test(preRequestBody)
        && hasJavaBlankCheck(preRequestBody, "InvoiceCode")
        && /["']31["']/.test(source)
        && /["']32["']/.test(source);
      if (!hasKindInput || !checksConditionalCode) {
        errors.push("Java invoice-query service cannot enforce invoice_code conditional requiredness because invoice_kind is missing or checked only after the request");
      }
      const checksRequestKindEnum = preRequestBody
        && (/\b(?:VALID_)?INVOICE_KINDS?\s*\.\s*contains\s*\(\s*invoiceKind\s*\)/.test(preRequestBody)
          || /(?:validate|require|check|assert)[A-Za-z0-9_$]*InvoiceKind[A-Za-z0-9_$]*\s*\(\s*invoiceKind\s*\)/i.test(preRequestBody)
          || /switch\s*\(\s*invoiceKind\s*\)/.test(preRequestBody));
      if (!checksRequestKindEnum) {
        errors.push("Java invoice-query service does not reject a request invoice_kind outside the documented enum before the SDK call");
      }
    }
    if (/EnterpriseOpenRuleService\.java$/i.test(file)) {
      if (/\bquery\s*\(/.test(source)) {
        const queryBody = findJavaMethodBody(source, "query", /invoiceRuleId/);
        const checksRuleId = queryBody
          && /(?:isBlank|hasText|notBlank|require)\s*\([^;]{0,220}\binvoiceRuleId\b/i.test(queryBody);
        if (!checksRuleId) {
          errors.push("Java open-rule query does not preflight required invoiceRuleId before the SDK call");
        }
      }
      const implementsOpenRuleOperations = /\b(?:create|modify|query)\s*\(/.test(source);
      if (implementsOpenRuleOperations
          && !["InvoiceRuleName", "InvoiceRuleId", "InvoiceTitleId"].every((name) => hasJavaBlankCheck(source, name))) {
        errors.push("Java open-rule required strings do not all reject whitespace-only values before the SDK/gateway call");
      }
      const countPresentBody = findJavaMethodBody(source, "countPresent", null);
      if (countPresentBody && !/isBlank\s*\(|hasText\s*\(|trim\s*\(\s*\)\.isEmpty\s*\(/.test(countPresentBody)) {
        errors.push("Java open-rule recipient group treats whitespace-only name/phone/address as present values");
      }
    }
    if (/EnterpriseIdentity\.java$/i.test(file)) {
      const v1 = findJavaMethodBody(source, "ofV1", /accountId|agreementNo/);
      const v2 = findJavaMethodBody(source, "ofV2", /enterpriseId/);
      const rejectsBlank = (body, names) => body && names.every((name) =>
        new RegExp(`(?:isBlank|hasText|notBlank|require|trim\\s*\\(\\s*\\)\\.isEmpty)\\s*\\([^;]{0,220}\\b${name}\\b`, "i").test(body)
        || new RegExp(`\\b${name}\\b[^;]{0,100}trim\\s*\\(\\s*\\)\\.isEmpty`, "i").test(body));
      if (!rejectsBlank(v2, ["enterpriseId"]) || !rejectsBlank(v1, ["accountId", "agreementNo"])) {
        errors.push("Java enterprise identity factories do not reject blank enterpriseId/accountId/agreementNo values");
      }
    }
  }
}

function checkJavaNotificationTestCoverage(javaFiles, testFiles, errors) {
  const hasFullJavaInvoiceModule = javaFiles.some((file) => /EnterpriseInvoiceQueryService\.java$/i.test(file));
  const hasJavaNotification = javaFiles.some((file) => /Notify|Message/i.test(path.basename(file))
    && /alipay\.ebpp\.invoice\.enterprise\.newinvoice\.notify|invoiceKind|notifyReason/.test(read(file)));
  if (!hasFullJavaInvoiceModule || !hasJavaNotification) return;
  const tests = testFiles
    .filter((file) => /Notify|Message/i.test(path.basename(file)))
    .map(read)
    .join("\n");
  const requiredFields = [
    ["enterprise_id", "enterpriseId"],
    ["employee_id", "employeeId"],
    ["einv_id", "einvId"],
    ["invoice_no", "invoiceNo"],
    ["invoice_kind", "invoiceKind"],
    ["notify_reason", "notifyReason"],
    ["collect_source", "collectSource"],
  ];
  const missingNegativeCases = requiredFields
    .filter(([snake, camel]) => !hasNamedNegativeTest(tests, [snake, camel], [
      "missing", "blank", "empty", "null", "omit", "without", "required", "缺失", "空白", "为空",
    ]))
    .map(([snake]) => snake);
  if (missingNegativeCases.length > 0) {
    errors.push(`Java invoice notification tests do not cover blank/missing required fields individually: ${missingNegativeCases.join(", ")}`);
  }

  const missingEnumCases = [
    ["invoice_kind", "invoiceKind"],
    ["notify_reason", "notifyReason"],
    ["collect_source", "collectSource"],
  ].filter(([snake, camel]) => !hasNamedNegativeTest(tests, [snake, camel], [
    "invalid", "unknown", "unsupported", "outOfRange", "bad", "非法", "未知", "枚举外",
  ])).map(([snake]) => snake);
  if (missingEnumCases.length > 0) {
    errors.push(`Java invoice notification tests do not cover documented enum rejection individually: ${missingEnumCases.join(", ")}`);
  }

  const coversProcessingConflict = /(?:processing|inFlight|pending|处理中)[A-Za-z0-9_\s-]{0,100}(?:conflict|retry|duplicate|冲突|重试)|(?:conflict|retry|duplicate|冲突|重试)[A-Za-z0-9_\s-]{0,100}(?:processing|inFlight|pending|处理中)/i.test(tests);
  if (!coversProcessingConflict) {
    errors.push("Java invoice notification tests do not cover an in-flight processing conflict triggering retry");
  }
  const coversBusinessFailureRetry = /(?:businessPort|persist|business|业务落地)[A-Za-z0-9_\s-]{0,120}(?:fail|throw|retry|失败|重试)|(?:fail|throw|retry|失败|重试)[A-Za-z0-9_\s-]{0,120}(?:businessPort|persist|business|业务落地)/i.test(tests)
    && hasRetryExecutionEvidence(tests);
  if (!coversBusinessFailureRetry) {
    errors.push("Java invoice notification tests do not prove that query and business persistence execute again after a persistence failure");
  }
}

function hasRetryExecutionEvidence(tests) {
  const repeatedCall = (method) => {
    return new RegExp(`verify\\s*\\(\\s*[A-Za-z_$][A-Za-z0-9_$.]*\\s*,\\s*(?:times|atLeast)\\s*\\(\\s*[2-9][0-9]*\\s*\\)\\s*\\)\\s*\\.\\s*${method}\\s*\\(`, "i").test(tests)
      || new RegExp(`assertEquals\\s*\\(\\s*[2-9][0-9]*\\s*,[^;]{0,240}${method}[^;]{0,120}(?:count|calls|invocations)`, "i").test(tests);
  };
  return repeatedCall("query") && repeatedCall("persist");
}

function checkJavaInvoiceQueryResponseContract(javaFiles, testFiles, errors) {
  const serviceFiles = javaFiles.filter((file) => /EnterpriseInvoiceQueryService\.java$/i.test(file)
    || /EnterpriseInvoiceinfoQueryResponse/.test(read(file)));
  if (serviceFiles.length === 0) return;

  const requiredFields = [
    ["enterprise_id", "EnterpriseId"],
    ["invoice_no", "InvoiceNo"],
    ["invoice_type", "InvoiceType"],
    ["invoice_kind", "InvoiceKind"],
    ["invoice_date", "InvoiceDate"],
    ["sum_amount", "SumAmount"],
    ["payer_name", "PayerName"],
    ["payer_register_no", "PayerRegisterNo"],
    ["payee_name", "PayeeName"],
  ];

  for (const file of serviceFiles) {
    const source = stripJavaComments(read(file));
    const responseVariables = [...source.matchAll(/\b[A-Za-z_$][A-Za-z0-9_$.]*Response\s+([A-Za-z_$][A-Za-z0-9_$]*)\b/g)]
      .map((match) => match[1]);
    const responseReceiver = `(?:${[...new Set([...responseVariables, "response", "resp", "result", "r"])].map(escapeRegExp).join("|")})`;
    const missingGuards = requiredFields
      .filter(([, camel]) => !hasJavaResponseFieldValidation(source, camel, responseReceiver))
      .map(([snake]) => snake);
    if (missingGuards.length > 0) {
      errors.push(`Java invoice-query successful response does not fail closed on required fields: ${missingGuards.join(", ")}`);
    }

    const missingIdentityGuards = [
      ["enterprise_id", "EnterpriseId", "enterpriseId"],
      ["invoice_no", "InvoiceNo", "invoiceNo"],
      ["invoice_kind", "InvoiceKind", "invoiceKind"],
      ["invoice_code", "InvoiceCode", "invoiceCode"],
    ].filter(([, getter, input]) => !hasJavaResponseIdentityGuard(source, getter, input, responseReceiver))
      .map(([field]) => field);
    if (missingIdentityGuards.length > 0) {
      errors.push(`Java invoice-query does not reject request/response identity mismatch: ${missingIdentityGuards.join(", ")}`);
    }

    const hasResponseEnums = ["blue", "red", "0", "1", "2", "3", "4", "31", "32"]
      .every((value) => source.includes(`\"${value}\"`) || source.includes(`'${value}'`));
    if (!hasResponseEnums) {
      errors.push("Java invoice-query does not fail closed against documented invoice_type/invoice_kind response enums");
    }
    if (!hasConditionalResponseInvoiceCodeGuard(source, responseReceiver)) {
      errors.push("Java invoice-query does not require and match response invoice_code when the response invoice_kind is non-digital");
    }

    if (/getInvoiceItemList\s*\(|invoice_item_list/.test(source)) {
      const missingItemGuards = ["ItemName", "Amount", "Tax", "TaxRate"]
        .filter((field) => !hasJavaResponseFieldValidation(source, field, "(?:item|line|detail|dto)"));
      if (missingItemGuards.length > 0) {
        errors.push(`Java invoice-query does not validate required invoice item fields: ${missingItemGuards.join(", ")}`);
      }
      if (/getRowType\s*\(/.test(source) && !hasRowTypeEnumGuard(source)) {
        errors.push("Java invoice-query maps row_type without rejecting values outside 0/1/2");
      } else if (/getRowType\s*\(/.test(source) && !hasOptionalRowTypeEnumGuard(source)) {
        errors.push("Java invoice-query treats optional row_type as required instead of validating 0/1/2 only when nonblank");
      }
    }
    if (/getFileDownloadUrl\s*\(/.test(source)
        && !["ofd", "pdf"].every((value) => source.includes(`\"${value}\"`) || source.includes(`'${value}'`))) {
      errors.push("Java invoice-query does not validate the documented file_type enum when a download URL is present");
    }
  }

  const tests = testFiles
    .filter((file) => /EnterpriseInvoiceQuery|InvoiceinfoQuery/i.test(path.basename(file)))
    .map((file) => stripJavaComments(read(file)))
    .join("\n");
  const missingRequiredFieldTests = requiredFields
    .filter(([snake, camel]) => !hasRequiredResponseFieldTest(tests, snake, camel))
    .map(([snake]) => snake);
  if (missingRequiredFieldTests.length > 0) {
    errors.push(`Java invoice-query tests do not cover missing required response fields: ${missingRequiredFieldTests.join(", ")}`);
  }
  if (!hasNamedNegativeTest(tests, ["enterprise_id", "enterpriseId", "invoice_no", "invoiceNo", "invoice_code", "invoiceCode"], [
    "mismatch", "different", "wrong", "错配", "不一致",
  ])) {
    errors.push("Java invoice-query tests do not cover request/response identity mismatch");
  }
  if (!hasNamedNegativeTest(tests, ["invoice_kind", "invoiceKind"], [
    "invalidRequest", "requestInvalid", "invalidInput", "inputInvalid", "beforeSdk", "beforeGateway", "非法请求", "入参非法",
  ])) {
    errors.push("Java invoice-query tests do not cover an invalid request invoice_kind rejected before the SDK call");
  }
  if (!hasNamedNegativeTest(tests, ["invoice_kind", "invoiceKind"], [
    "mismatch", "different", "wrong", "错配", "不一致",
  ])) {
    errors.push("Java invoice-query tests do not cover response invoice_kind mismatching the request");
  }
  if (!hasJavaTestNameWithConcepts(tests, [
    ["invoice_code", "invoiceCode"],
    ["nonDigital", "non_digital", "非数电"],
    ["response", "sdkResponse", "响应"],
    ["missing", "blank", "empty", "null", "without", "缺失", "空白", "为空"],
  ])) {
    errors.push("Java invoice-query tests do not cover a non-digital response with missing invoice_code");
  }
  if (!/(?:invoiceItemList|getInvoiceItemList|invoice_item_list)/i.test(tests)) {
    errors.push("Java invoice-query tests do not cover nested invoice item mapping");
  }
  if (!hasNamedNegativeTest(tests, ["sum_amount", "sumAmount", "amount", "tax"], [
    "invalid", "malformed", "nonNumeric", "bad", "非法", "格式错误",
  ])) {
    errors.push("Java invoice-query tests do not cover invalid monetary values failing closed");
  }
  if (!hasNamedNegativeTest(tests, ["invoice_type", "invoiceType", "invoice_kind", "invoiceKind"], [
    "invalid", "unknown", "unsupported", "bad", "非法", "枚举外",
  ])) {
    errors.push("Java invoice-query tests do not cover invalid response enums failing closed");
  }
  if (!hasNamedNegativeTest(tests, ["row_type", "rowType"], [
    "invalid", "unknown", "unsupported", "bad", "非法", "枚举外",
  ])) {
    errors.push("Java invoice-query tests do not cover invalid row_type failing closed");
  }
  for (const [label, markers] of [
    ["missing", ["missing", "null", "absent", "without", "omitted", "缺失"]],
    ["blank", ["blank", "empty", "whitespace", "空白", "空字符串"]],
  ]) {
    if (!hasJavaTestNameWithConcepts(tests, [
      ["row_type", "rowType"],
      markers,
      ["allow", "accept", "success", "map", "optional", "允许", "接受", "成功"],
    ])) {
      errors.push(`Java invoice-query tests do not prove optional row_type ${label} values are accepted`);
    }
  }
}

function hasConditionalResponseInvoiceCodeGuard(source, responseReceiver) {
  const codeGetter = `${responseReceiver}\\s*\\.\\s*getInvoiceCode\\s*\\(\\s*\\)`;
  const kindGetter = `${responseReceiver}\\s*\\.\\s*getInvoiceKind\\s*\\(\\s*\\)`;
  for (const match of source.matchAll(new RegExp(codeGetter, "g"))) {
    const window = source.slice(Math.max(0, match.index - 900), match.index + match[0].length + 500);
    const checksResponseKind = new RegExp(kindGetter).test(window)
      || /responseKind|resultKind|actualKind/.test(window);
    const distinguishesDigital = /DIGITAL[A-Za-z0-9_$]*\s*\.\s*contains|["']31["']|["']32["']/.test(window);
    const requiresCode = new RegExp(`(?:(?:require|validate|check|assert)(?:Text|Required|Present|NonBlank|NotBlank)|isBlank|hasText|notBlank)[A-Za-z0-9_$]*\\s*\\([^;]{0,220}${codeGetter}`, "i").test(window)
      || new RegExp(`${codeGetter}[^;]{0,180}(?:==\\s*null|trim\\s*\\(\\s*\\)\\s*\\.\\s*isEmpty\\s*\\()`, "i").test(window);
    if (checksResponseKind && distinguishesDigital && requiresCode) return true;
  }
  return false;
}

function hasRowTypeEnumGuard(source) {
  const getter = `[A-Za-z_$][A-Za-z0-9_$]*\\s*\\.\\s*getRowType\\s*\\(\\s*\\)`;
  if (new RegExp(`(?:VALID_)?ROW_TYPES?\\s*\\.\\s*contains\\s*\\(\\s*${getter}\\s*\\)`).test(source)
      || /(?:validate|require|check|assert)[A-Za-z0-9_$]*RowType[A-Za-z0-9_$]*\s*\([^;]{0,160}getRowType\s*\(/i.test(source)) {
    return true;
  }
  const aliasMatch = source.match(new RegExp(`\\bString\\s+([A-Za-z_$][A-Za-z0-9_$]*)\\s*=\\s*${getter}`));
  if (aliasMatch) {
    const alias = escapeRegExp(aliasMatch[1]);
    if (new RegExp(`(?:VALID_)?ROW_TYPES?\\s*\\.\\s*contains\\s*\\(\\s*${alias}\\s*\\)`).test(source)
        || new RegExp(`switch\\s*\\(\\s*${alias}\\s*\\)`).test(source)) return true;
  }
  return new RegExp(`switch\\s*\\(\\s*${getter}\\s*\\)`).test(source)
    || ["0", "1", "2"].every((value) => new RegExp(`["']${value}["']\\s*\\.\\s*equals\\s*\\(\\s*${getter}\\s*\\)`).test(source));
}

function hasOptionalRowTypeEnumGuard(source) {
  const getter = `[A-Za-z_$][A-Za-z0-9_$]*\\s*\\.\\s*getRowType\\s*\\(\\s*\\)`;
  const candidates = [getter];
  for (const match of source.matchAll(new RegExp(`\\bString\\s+([A-Za-z_$][A-Za-z0-9_$]*)\\s*=\\s*${getter}`, "g"))) {
    candidates.push(`\\b${escapeRegExp(match[1])}\\b`);
  }

  return candidates.some((value) => {
    const enumUse = new RegExp(`(?:VALID_)?ROW_TYPES?\\s*\\.\\s*contains\\s*\\(\\s*${value}\\s*\\)`, "g");
    for (const match of source.matchAll(enumUse)) {
      const window = source.slice(Math.max(0, match.index - 500), match.index + match[0].length + 240);
      const positivePresence = new RegExp(`(?:isPresent|hasText|isNotBlank)\\s*\\(\\s*${value}\\s*\\)|!\\s*(?:isBlank|isEmpty)\\s*\\(\\s*${value}\\s*\\)`, "i").test(window);
      const earlySkip = new RegExp(`(?:isBlank|isEmpty)\\s*\\(\\s*${value}\\s*\\)[^{};]{0,80}(?:return|continue)\\b`, "i").test(window);
      const explicitEmptySkip = new RegExp(`${value}\\s*==\\s*null[\\s\\S]{0,180}${value}\\s*\\.\\s*trim\\s*\\(\\s*\\)\\s*\\.\\s*isEmpty\\s*\\(\\s*\\)[^{};]{0,100}(?:return|continue)\\b`, "i").test(window);
      const explicitNullable = new RegExp(`${value}\\s*!=\\s*null[\\s\\S]{0,180}!\\s*${value}\\s*\\.\\s*trim\\s*\\(\\s*\\)\\s*\\.\\s*isEmpty\\s*\\(`, "i").test(window);
      if (positivePresence || earlySkip || explicitEmptySkip || explicitNullable) return true;
    }
    return false;
  });
}

function checkJavaInvoiceSpringWiringTests(javaFiles, testFiles, errors) {
  const production = javaFiles.map((file) => stripJavaComments(read(file))).join("\n");
  const hasSharedRouter = /class\s+(?:Dispatching|Routing|Composite)[A-Za-z0-9_$]*MsgHandler\b|(?:List|Map)\s*<[^;>]*BizMsgHandler/.test(production);
  const hasInvoiceHandler = /class\s+InvoiceNotifyHandler\b|alipay\.ebpp\.invoice\.enterprise\.newinvoice\.notify/.test(production);
  if (!hasSharedRouter || !hasInvoiceHandler) return;

  const hasExactRouteAssertion = testFiles.some((file) => {
    const source = stripJavaComments(read(file));
    if (!/@SpringBootTest\b|ApplicationContextRunner|AnnotationConfigApplicationContext/.test(source)) return false;
    const readsRoutes = /getRoutes\s*\(\s*\)[\s\S]{0,240}(?:contains|containsExactly|containsAll)/.test(source);
    const namesInvoiceRoute = /InvoiceNotifyHandler\s*\.\s*MSG_API|alipay\.ebpp\.invoice\.enterprise\.newinvoice\.notify/.test(source);
    return readsRoutes && namesInvoiceRoute;
  });
  if (!hasExactRouteAssertion) {
    errors.push("Java Spring context tests do not explicitly assert that the shared message router contains the invoice notification route");
  }
}

function hasJavaResponseFieldValidation(source, fieldName, receiverPattern) {
  const getter = `${receiverPattern}\\s*\\.\\s*get${escapeRegExp(fieldName)}\\s*\\(\\s*\\)`;
  if (new RegExp(`(?:require|validate|check|assert|isBlank|hasText|notBlank)[A-Za-z0-9_$]*\\s*\\([^;]{0,240}${getter}`, "i").test(source)
      || new RegExp(`${getter}[^;]{0,180}(?:==\\s*null|trim\\s*\\(\\s*\\)\\s*\\.\\s*isEmpty\\s*\\()`, "i").test(source)) {
    return true;
  }
  const aliasMatch = source.match(new RegExp(`\\bString\\s+([A-Za-z_$][A-Za-z0-9_$]*)\\s*=\\s*${getter}`));
  if (!aliasMatch) return false;
  const alias = escapeRegExp(aliasMatch[1]);
  return new RegExp(`(?:require|validate|check|assert|isBlank|hasText|notBlank)[A-Za-z0-9_$]*\\s*\\([^;]{0,180}\\b${alias}\\b`, "i").test(source)
    || new RegExp(`\\b${alias}\\b[^;]{0,140}(?:==\\s*null|trim\\s*\\(\\s*\\)\\s*\\.\\s*isEmpty\\s*\\()`, "i").test(source);
}

function hasJavaResponseIdentityGuard(source, fieldName, inputName, receiverPattern) {
  const getter = new RegExp(`${receiverPattern}\\s*\\.\\s*get${escapeRegExp(fieldName)}\\s*\\(\\s*\\)`, "g");
  for (const match of source.matchAll(getter)) {
    const window = source.slice(Math.max(0, match.index - 320), match.index + match[0].length + 320);
    if (new RegExp(`\\b${escapeRegExp(inputName)}\\b`).test(window)
        && /(?:equals|compare|mismatch|same|match|identity)/i.test(window)) {
      return true;
    }
  }
  return false;
}

function hasRequiredResponseFieldTest(tests, snake, camel) {
  if (hasNamedNegativeTest(tests, [snake, camel], [
    "missing", "blank", "empty", "null", "omit", "without", "required", "缺失", "空白", "为空",
  ])) return true;
  const parameterized = /@ParameterizedTest|@MethodSource|@ValueSource|for\s*\(/.test(tests)
    && /(?:missing|blank|empty|null|required|缺失|空白|为空)[A-Za-z0-9_\s-]{0,120}(?:response|field|响应|字段)/i.test(tests);
  return parameterized && (tests.includes(`\"${snake}\"`) || tests.includes(`\"${camel}\"`));
}

function checkJavaBusinessKeyConcurrencyTests(javaFiles, testFiles, errors) {
  const hasBusinessKeyPersistence = javaFiles.some((file) => {
    const source = stripJavaComments(read(file));
    return /findByBizKey\s*\(|\bbizKey\b|businessKey|biz_key/.test(source)
      && /persistInvoice\s*\(|save(?:AndFlush)?\s*\(/.test(source);
  });
  if (!hasBusinessKeyPersistence) return;
  const hasDatabaseBusinessKeyRace = testFiles
    .filter((file) => /Business|InvoiceRecord|Persistence/i.test(path.basename(file)))
    .some((file) => {
      const source = stripJavaComments(read(file));
      const hasDatabaseFixture = /@DataJpaTest|@SpringBootTest|TestEntityManager|EntityManager|JdbcTemplate/.test(source);
      const hasBusinessKey = /\bbizKey\b|businessKey|biz_key/.test(source);
      const hasConcurrency = /concurrent|parallel|race|ExecutorService|CountDownLatch|CyclicBarrier/i.test(source);
      const hasUniqueConflict = /DataIntegrityViolationException|ConstraintViolationException/.test(source);
      return hasDatabaseFixture && hasBusinessKey && hasConcurrency && hasUniqueConflict;
    });
  if (!hasDatabaseBusinessKeyRace) {
    errors.push("Java invoice business-key idempotency has no real-database concurrency test for a business-key unique-constraint race");
  }
}

function hasJavaBlankCheck(source, fieldName) {
  const camel = fieldName.charAt(0).toLowerCase() + fieldName.slice(1);
  const value = `(?:get${escapeRegExp(fieldName)}\\s*\\([^)]*\\)|\\b${escapeRegExp(camel)}\\b)`;
  return new RegExp(`(?:isBlank|hasText|notBlank)\\s*\\([^;]{0,180}${value}`, "i").test(source)
    || new RegExp(`${value}[^;]{0,140}trim\\s*\\(\\s*\\)\\.isEmpty\\s*\\(`, "i").test(source)
    || new RegExp(`@NotBlank[^;]{0,160}\\b${escapeRegExp(camel)}\\b`, "i").test(source);
}

function hasNamedNegativeTest(text, fieldNames, markers) {
  const field = `(?:${fieldNames.map(escapeRegExp).join("|")})`;
  const marker = `(?:${markers.map(escapeRegExp).join("|")})`;
  return new RegExp(`${marker}[A-Za-z0-9_\\s-]{0,80}${field}|${field}[A-Za-z0-9_\\s-]{0,80}${marker}`, "i").test(text);
}

function hasJavaTestNameWithConcepts(text, conceptGroups) {
  const methodNames = [...text.matchAll(/\b(?:void|public|protected|private)\s+([A-Za-z_$][A-Za-z0-9_$]*)\s*\(/g)]
    .map((match) => match[1].toLowerCase());
  return methodNames.some((method) => conceptGroups.every((group) =>
    group.some((concept) => method.includes(concept.toLowerCase().replace(/_/g, "")))
      || group.some((concept) => method.includes(concept.toLowerCase()))));
}

function snakeToCamel(value) {
  return value.replace(/_([a-z])/g, (_, letter) => letter.toUpperCase());
}

function checkJavaNotificationReliability(productionFiles, javaFiles, testText, errors) {
  if (javaFiles.length === 0) return;
  const executable = javaFiles.map((file) => stripJavaComments(read(file))).join("\n");
  const productionText = productionFiles.map(read).join("\n");

  const usesFailedRetryLease = /reacquireFailed\s*\(/.test(executable)
    && /(?:STALE_PENDING|stalePending|reacquireStale|lease)/i.test(executable);
  if (usesFailedRetryLease) {
    const retryFiles = javaFiles.filter((file) => /reacquireFailed\s*\(/.test(stripJavaComments(read(file))));
    const refreshesLease = retryFiles.some((file) => {
      const source = stripJavaComments(read(file));
      return /(?:firstSeenAt|processingStartedAt|lease(?:Started|Acquired|Updated)?At)\s*=\s*:?(?:now|ts|timestamp)/i.test(source)
        && findJavaMethodParameterLists(source, "reacquireFailed")
          .some((parameters) => /\b(?:now|ts|timestamp)\b/i.test(parameters));
    });
    if (!refreshesLease) {
      errors.push("Java failed-notification reacquire does not atomically refresh the processing lease timestamp");
    }
  }

  const hasBusinessPort = /\bpersistInvoice\s*\(|\bInvoiceBusinessPort\b/.test(executable);
  const passesBusinessKey = /\bbizKey\b|\bbiz_key\b/.test(executable);
  if (hasBusinessPort && passesBusinessKey) {
    const enforcesBusinessKey = /(?:find|exists|delete|lock|putIfAbsent)[A-Za-z0-9_]*(?:BizKey|BusinessKey)/i.test(executable)
      || /UNIQUE\s*(?:KEY|INDEX)?\s*[^\n;]*\(?[^\n;]*biz_key|UNIQUE\s*\([^)]*biz_key/i.test(productionText)
      || /uniqueConstraints\s*=\s*@UniqueConstraint\s*\([^)]*(?:biz_key|bizKey)/i.test(executable)
      || /\b(?:deduplicate|ensureIdempotent|acquireBusinessKey|reserveBusinessKey)\s*\([^;]{0,160}\bbizKey\b/i.test(executable);
    if (!enforcesBusinessKey) {
      errors.push("Java invoice business persistence does not enforce enterprise/invoice business-key idempotency beyond notifyId/msgId");
    }
    const testsCrossDeliveryDedup = /(?:different|distinct|不同|两个|second)[^\n]{0,120}(?:notifyId|notify_id|msgId)/i.test(testText)
      && /(?:same|相同)[^\n]{0,120}(?:bizKey|biz_key|invoice)/i.test(testText);
    if (!testsCrossDeliveryDedup) {
      errors.push("Java invoice business-key idempotency has no test for different delivery IDs referencing the same invoice");
    }
  }

  for (const file of javaFiles) {
    const source = stripJavaComments(read(file));
    if (/implements\s+NotifyIdempotencyStore\b/.test(source)) {
      const operationalMethods = ["tryAcquire", "markDone", "markFailed", "isDone"]
        .map((name) => findJavaMethodBody(source, name, null))
        .filter(Boolean);
      if (operationalMethods.length >= 3
          && operationalMethods.every((body) => /throw\s+new\s+[A-Za-z0-9_$.]*(?:Exception|Error)\s*\(/.test(body))
          && !hasSafeConditionalDefault(javaFiles, source, "NotifyIdempotencyStore")) {
        errors.push("fail-closed NotifyIdempotencyStore default must be a plain implementation created by a @Configuration @Bean guarded with @ConditionalOnMissingBean(NotifyIdempotencyStore.class), and must not be a scanned component or @Primary");
      }
    }

    if (/implements\s+InvoiceBusinessPort\b/.test(source)
        && /FailClosed|NotConfigured|未配置/i.test(source)) {
      const persistBody = findJavaMethodBody(source, "persist", null);
      if (persistBody && /throw\s+new|return\s+false\s*;/.test(persistBody)
          && !hasSafeConditionalDefault(javaFiles, source, "InvoiceBusinessPort")) {
        errors.push("fail-closed InvoiceBusinessPort default must be a plain implementation created by a @Configuration @Bean guarded with @ConditionalOnMissingBean(InvoiceBusinessPort.class), and must not be a scanned component or @Primary");
      }
    }

    if (/implements\s+InvoiceBusinessPort\b/.test(source)
        && /(?:new\s+(?:ConcurrentHashMap|HashMap|HashSet|ConcurrentSkipListMap)\s*<|\b(?:Map|Set)\s*<[^;=]+>\s+[A-Za-z_$][A-Za-z0-9_$]*\s*=)/.test(source)
        && !hasLocalOnlyProfile(source)) {
      errors.push("invoice business persistence uses a production in-memory Map/Set; use durable shared storage or restrict it to local/demo/test profile");
    }
  }
}

function hasSafeConditionalDefault(javaFiles, source, portName) {
  const port = escapeRegExp(portName);
  const classMatch = source.match(new RegExp(`\\bclass\\s+([A-Za-z_$][A-Za-z0-9_$]*)[^\\{]*\\bimplements\\s+[^\\{]*\\b${port}\\b`));
  if (!classMatch || /@Primary\b/.test(source)) return false;
  if (/@(?:[A-Za-z_$][\w$]*\.)*(?:Component|Service|Repository|Controller|RestController)\b/.test(source)) return false;
  const implementation = escapeRegExp(classMatch[1]);
  return javaFiles.some((file) => {
    const config = stripJavaComments(read(file));
    if (!/@Configuration\b/.test(config)) return false;
    const beanMethod = /((?:@[A-Za-z_$][\w$.]*(?:\s*\([^)]*\))?\s*)+)(?:public|private|protected)?\s*(?:static\s+)?([A-Za-z_$][\w$<>, ?.[\]]*)\s+[A-Za-z_$][\w$]*\s*\([^)]*\)\s*\{/g;
    for (const match of config.matchAll(beanMethod)) {
      if (!/@Bean\b/.test(match[1])) continue;
      if (!new RegExp(`@ConditionalOnMissingBean\\s*\\(\\s*(?:value\\s*=\\s*)?(?:\\{\\s*)?${port}\\s*\\.\\s*class\\b`).test(match[1])) continue;
      if (!new RegExp(`\\b(?:${port}|${implementation})\\b`).test(match[2])) continue;
      const open = match.index + match[0].length - 1;
      const close = findMatchingJavaDelimiter(config, open, "{", "}");
      const body = close > open ? config.slice(open + 1, close) : "";
      if (new RegExp(`\\bnew\\s+${implementation}\\s*\\(`).test(body)) return true;
    }
    return false;
  });
}

function hasLocalOnlyProfile(source) {
  return /@Profile\s*\(\s*(?:\{\s*)?["'](?:local|demo|test)["'](?:\s*,\s*["'](?:local|demo|test)["'])*(?:\s*})?\s*\)/i.test(source);
}

function checkRequiredCapabilityBlockers(text, javaFiles, errors) {
  const blockers = [
    ["open-rule SINGLE", /SINGLE[\s\S]{0,400}(?:当前未实现|暂不支持|需升级\s*SDK|未覆盖边界|标记为阻塞|不属于已完整交付|本迭代未接入)/i],
    ["enterprise-title tax_register_no query", /(?:tax_register_no|taxRegisterNo)[\s\S]{0,320}(?:仅支持\s*title_id|不生成调用|留作待确认)/i],
  ];
  for (const [name, pattern] of blockers) {
    if (pattern.test(text)) errors.push(`required capability is explicitly unresolved: ${name}`);
  }

}

function checkJavaProductionConfig(productionFiles, javaFiles, errors) {
  if (javaFiles.length === 0) return;
  const baseConfigFiles = productionFiles.filter((file) => /(?:^|\/)(?:application|bootstrap)\.(?:ya?ml|properties)$/i.test(normalize(file)));
  if (baseConfigFiles.some((file) => /jdbc:h2:/i.test(read(file)))) {
    errors.push("base application profile uses H2; embedded databases are allowed only in explicit local/demo/test profiles");
  }
  if (baseConfigFiles.some((file) => /ddl-auto\s*:\s*(?:update|create|create-drop)\b|hibernate\.hbm2ddl\.auto\s*=\s*(?:update|create|create-drop)\b/i.test(read(file)))) {
    errors.push("base application profile enables automatic schema mutation; restrict ddl-auto update/create to local/demo/test profiles");
  }

  const productionText = productionFiles.map(read).join("\n");
  const usesMysql = /jdbc:mysql:|com\.mysql\.cj\.jdbc\.Driver/.test(productionText);
  if (usesMysql && !/mysql-connector-(?:j|java)|com\.mysql\s*:\s*mysql-connector/i.test(productionText)) {
    errors.push("production datasource selects MySQL but the build has no MySQL JDBC driver dependency");
  }
  const validatesSchema = /ddl-auto\s*:\s*validate\b|hibernate\.hbm2ddl\.auto\s*=\s*validate\b/i.test(productionText);
  const hasSchemaManagement = productionFiles.some((file) => /(?:^|\/)(?:db\/migration\/.*\.sql|schema\.sql|db\/changelog\/)/i.test(normalize(path.relative(targetDir, file))))
    || /flyway|liquibase/i.test(productionText);
  if (validatesSchema && !hasSchemaManagement) {
    errors.push("production ddl-auto=validate has no Flyway/Liquibase migration or schema.sql");
  }

  const placeholderFiles = productionFiles.filter((file) => /REPLACE_WITH_|<--\s*请填写|CHANGE_ME|YOUR_[A-Z0-9_]+/.test(read(file)));
  const hasCredentialConfig = productionFiles.some((file) =>
    /(?:app[-_.]?id|private[-_.]?key|alipay[-_.]?public[-_.]?key)\s*[:=]/i.test(read(file)));
  const hasEmptyCredentialDefault = productionFiles.some((file) =>
    /(?:ALIPAY_APP_ID|ALIPAY_PRIVATE_KEY|ALIPAY_PUBLIC_KEY)\s*:\s*}/.test(read(file)));
  if (placeholderFiles.length === 0 && !hasCredentialConfig && !hasEmptyCredentialDefault) return;
  const configJavaFiles = javaFiles.filter((file) => /(?:Config|Properties|Application)\.java$/i.test(file));
  const failsOnPlaceholder = configJavaFiles.some((file) => {
    const source = read(file);
    return /REPLACE_WITH_|CHANGE_ME|YOUR_[A-Z0-9_]+/.test(source)
      && /throw\s+new\s+[A-Za-z0-9_.]*(?:Exception|Error)\s*\(/.test(source);
  });
  if ((hasCredentialConfig || hasEmptyCredentialDefault || placeholderFiles.length > 0) && !failsOnPlaceholder) {
    errors.push("Alipay credential startup validation does not reject recognized placeholder values");
  }
  const configJava = configJavaFiles.map(read).join("\n");
  const credentialConfigText = productionFiles
    .filter((file) => /\.(?:ya?ml|properties)$/i.test(file))
    .map(read)
    .join("\n");
  const configuredCredentialFields = [
    ["appId", /\bapp[-_.]?id\s*[:=]/i],
    ["privateKey", /\bprivate[-_.]?key\s*[:=]/i],
    ["alipayPublicKey", /\balipay[-_.]?public[-_.]?key\s*[:=]/i],
  ].filter(([, pattern]) => pattern.test(credentialConfigText)).map(([field]) => field);
  if (configuredCredentialFields.length === 0) {
    for (const field of ["appId", "privateKey", "alipayPublicKey"]) {
      if (new RegExp(`\\b${field}\\b`).test(configJava)) configuredCredentialFields.push(field);
    }
  }
  const rejectsBlankCredentials = configuredCredentialFields.length > 0
    && configuredCredentialFields.every((field) => hasCredentialNullAndBlankCheck(configJava, field));
  if (!rejectsBlankCredentials) {
    errors.push("Alipay credential startup validation does not reject null/blank values");
  }
  const normalizesBeforePlaceholderCheck = /trim\s*\(\s*\)\s*\.\s*(?:startsWith|equals|matches)\s*\(/.test(configJava)
    || /\b([A-Za-z_$][A-Za-z0-9_$]*)\s*=\s*[A-Za-z_$][A-Za-z0-9_$]*\.trim\s*\(\s*\)[\s\S]{0,500}\b\1\s*\.\s*(?:startsWith|equals|matches)\s*\(/.test(configJava);
  if ((hasCredentialConfig || hasEmptyCredentialDefault || placeholderFiles.length > 0) && !normalizesBeforePlaceholderCheck) {
    errors.push("Alipay placeholder credential validation can be bypassed by leading/trailing whitespace");
  }
  const credentialTests = testTextForFiles();
  const testsWhitespacePlaceholder = /(?:REPLACE_WITH_|CHANGE_ME|YOUR_[A-Z0-9_]+)[ \\t]+["']|["'][ \\t]+(?:REPLACE_WITH_|CHANGE_ME|YOUR_[A-Z0-9_]+)/.test(credentialTests);
  if ((hasCredentialConfig || hasEmptyCredentialDefault || placeholderFiles.length > 0) && !testsWhitespacePlaceholder) {
    errors.push("Alipay credential validation has no test for whitespace-padded placeholder values");
  }
  const missingPlaceholderFamilies = [
    ["REPLACE_WITH_*", /REPLACE_WITH_[A-Z0-9_]*/],
    ["CHANGE_ME", /CHANGE_ME/],
    ["YOUR_*", /YOUR_[A-Z0-9_]+/],
  ].filter(([, pattern]) => !pattern.test(credentialTests)).map(([family]) => family);
  if (missingPlaceholderFamilies.length > 0) {
    errors.push(`Alipay credential validation tests do not cover placeholder families: ${missingPlaceholderFamilies.join(", ")}`);
  }
  const missingCredentialFieldTests = ["appId", "privateKey", "alipayPublicKey"]
    .filter((field) => !hasPlaceholderCredentialFieldTest(credentialTests, field));
  if (missingCredentialFieldTests.length > 0) {
    errors.push(`Alipay credential validation tests do not cover placeholder rejection for credential fields: ${missingCredentialFieldTests.join(", ")}`);
  }
}

function hasPlaceholderCredentialFieldTest(tests, field) {
  const name = escapeRegExp(field);
  const placeholder = "(?:REPLACE_WITH_[A-Z0-9_]*|CHANGE_ME|YOUR_[A-Z0-9_]+)";
  if (new RegExp(`\\b${name}\\b[\\s\\S]{0,260}${placeholder}|${placeholder}[\\s\\S]{0,260}\\b${name}\\b`, "i").test(tests)) {
    return true;
  }

  const constructorIndex = { appId: 0, privateKey: 1, alipayPublicKey: 2 }[field];
  return findJavaCalls(tests, "newConfig").some((call) => {
    const argument = call.args[constructorIndex] || "";
    return new RegExp(placeholder).test(argument);
  });
}

function hasCredentialNullAndBlankCheck(source, field) {
  const name = escapeRegExp(field);
  if (new RegExp(`@(?:NotBlank|NotEmpty)\\b[^;]{0,180}\\b${name}\\b`).test(source)) return true;
  const rejectsNull = new RegExp(`\\b${name}\\b\\s*==\\s*null|Objects\\.isNull\\s*\\(\\s*${name}\\s*\\)`).test(source);
  const rejectsDirectBlank = new RegExp(`(?:isBlank|isEmpty)\\s*\\(\\s*${name}\\s*\\)|!\\s*(?:StringUtils\\.)?hasText\\s*\\(\\s*${name}\\s*\\)|\\b${name}\\b\\s*\\.\\s*trim\\s*\\(\\s*\\)\\s*\\.\\s*isEmpty\\s*\\(`).test(source);
  const normalizedAlias = new RegExp(`\\b(?:String|var)\\s+([A-Za-z_$][A-Za-z0-9_$]*)\\s*=\\s*${name}\\s*\\.\\s*trim\\s*\\(\\s*\\)[\\s\\S]{0,500}\\b\\1\\s*\\.\\s*isEmpty\\s*\\(`).test(source);
  if (rejectsNull && (rejectsDirectBlank || normalizedAlias)) return true;

  const helperCalls = [...source.matchAll(new RegExp(`\\b((?:validate|require|check|assert)[A-Za-z0-9_$]*)\\s*\\(\\s*${name}\\s*\\)`, "ig"))];
  return helperCalls.some((match) => {
    const method = match[1];
    const parameterLists = findJavaMethodParameterLists(source, method);
    const body = findJavaMethodBody(source, method, null);
    if (!body || parameterLists.length === 0) return false;
    const parameter = parameterLists[0].match(/([A-Za-z_$][A-Za-z0-9_$]*)\s*$/);
    if (!parameter || parameter[1] === field) return false;
    return hasCredentialNullAndBlankCheck(body, parameter[1]);
  });
}

function testTextForFiles() {
  return walk(targetDir).filter((file) => isTestFile(file) && textExtensions.has(path.extname(file).toLowerCase()))
    .map(read)
    .join("\n");
}

function findJavaMethodParameterLists(source, methodName) {
  const results = [];
  const declaration = new RegExp(`\\b${escapeRegExp(methodName)}\\s*\\(`, "g");
  for (const match of source.matchAll(declaration)) {
    const prefix = source.slice(Math.max(0, match.index - 240), match.index);
    const looksLikeDeclaration = /(?:^|[;{}\r\n])\s*(?:(?:public|protected|private|static|final|default|abstract|synchronized|native|strictfp)\s+)*(?:<[^;{}()]+>\s+)?[A-Za-z_$][A-Za-z0-9_$.]*(?:\s*<[^;{}()]+>)?(?:\s*\[\s*\])?\s*$/.test(prefix);
    if (!looksLikeDeclaration) continue;

    const open = match.index + match[0].lastIndexOf("(");
    let depth = 0;
    let quote = null;
    for (let i = open; i < source.length; i += 1) {
      const char = source[i];
      if (quote) {
        if (char === "\\") i += 1;
        else if (char === quote) quote = null;
        continue;
      }
      if (char === '"' || char === "'") {
        quote = char;
      } else if (char === "(") {
        depth += 1;
      } else if (char === ")") {
        depth -= 1;
        if (depth === 0) {
          results.push(source.slice(open + 1, i));
          break;
        }
      }
    }
  }
  return results;
}

function findJavaCalls(source, qualifiedMethod) {
  const calls = [];
  const pattern = new RegExp(`\\b${escapeRegExp(qualifiedMethod)}\\s*\\(`, "g");
  for (const match of source.matchAll(pattern)) {
    const open = match.index + match[0].lastIndexOf("(");
    const close = findMatchingJavaDelimiter(source, open, "(", ")");
    if (close < 0) continue;
    calls.push({
      method: qualifiedMethod,
      args: splitJavaArguments(source.slice(open + 1, close)),
    });
  }
  return calls;
}

function findMatchingJavaDelimiter(source, openIndex, openChar, closeChar) {
  let depth = 0;
  let quote = null;
  for (let i = openIndex; i < source.length; i += 1) {
    const char = source[i];
    if (quote) {
      if (char === "\\") i += 1;
      else if (char === quote) quote = null;
      continue;
    }
    if (char === '"' || char === "'") {
      quote = char;
    } else if (char === openChar) {
      depth += 1;
    } else if (char === closeChar) {
      depth -= 1;
      if (depth === 0) return i;
    }
  }
  return -1;
}

function splitJavaArguments(source) {
  if (!source.trim()) return [];
  const args = [];
  let start = 0;
  let quote = null;
  const depths = { "(": 0, "[": 0, "{": 0 };
  for (let i = 0; i < source.length; i += 1) {
    const char = source[i];
    if (quote) {
      if (char === "\\") i += 1;
      else if (char === quote) quote = null;
      continue;
    }
    if (char === '"' || char === "'") {
      quote = char;
    } else if (char === "(" || char === "[" || char === "{") {
      depths[char] += 1;
    } else if (char === ")") {
      depths["("] -= 1;
    } else if (char === "]") {
      depths["["] -= 1;
    } else if (char === "}") {
      depths["{"] -= 1;
    } else if (char === "," && Object.values(depths).every((depth) => depth === 0)) {
      args.push(source.slice(start, i).trim());
      start = i + 1;
    }
  }
  args.push(source.slice(start).trim());
  return args;
}

function findJavaMethodBody(source, methodName, parameterPattern) {
  const declaration = new RegExp(`\\b${escapeRegExp(methodName)}\\s*\\(([^)]*)\\)\\s*\\{`, "g");
  for (const match of source.matchAll(declaration)) {
    if (parameterPattern && !parameterPattern.test(match[1])) continue;
    const open = match.index + match[0].lastIndexOf("{");
    let depth = 0;
    for (let i = open; i < source.length; i += 1) {
      if (source[i] === "{") depth += 1;
      if (source[i] === "}") depth -= 1;
      if (depth === 0) return source.slice(open + 1, i);
    }
  }
  return null;
}

function findJavaClassBody(source, className) {
  const declaration = new RegExp(`\\bclass\\s+${escapeRegExp(className)}\\b[^\\{]*\\{`).exec(source);
  if (!declaration) return null;
  const open = declaration.index + declaration[0].lastIndexOf("{");
  const close = findMatchingJavaDelimiter(source, open, "{", "}");
  return close < 0 ? null : source.slice(open + 1, close);
}

function checkBatchModules(text, warnings) {
  const titleBatch = /alipay\.ebpp\.invoice\.enterpriseexctrl\.employertitle\.batchquery|AlipayEbppInvoiceEnterpriseexctrlEmployertitleBatchquery/.test(text);
  const invoiceBatch = /alipay\.ebpp\.invoice\.enterprise\.invoiceinfo\.batchquery|AlipayEbppInvoiceEnterpriseInvoiceinfoBatchquery/.test(text);
  if (titleBatch && !/(?:page_num|pageNum)/.test(text)) {
    warnings.push("enterprise-title batch query is present but page_num/pageNum was not found");
  }
  if (invoiceBatch && !/(?:start_time|startTime)/.test(text)) {
    warnings.push("invoice batch query is present but start_time/startTime was not found");
  }
}

function checkExistingProjectContract(errors) {
  if (process.env.ALIPAY_PROJECT_MODE !== "existing") return;
  const contractFile = path.join(targetDir, ".alipay-skill", "integration-contract.json");
  if (!fs.existsSync(contractFile)) {
    errors.push("existing project requires .alipay-skill/integration-contract.json");
    return;
  }

  let contract;
  try {
    contract = JSON.parse(fs.readFileSync(contractFile, "utf8"));
  } catch (error) {
    errors.push(`integration contract is not valid JSON: ${error.message}`);
    return;
  }

  if (contract.projectMode !== "existing") errors.push("integration contract projectMode must be existing");
  const invoice = contract.domains && contract.domains.invoice;
  if (!invoice || invoice.status !== "CONFIRMED") {
    errors.push("integration contract domains.invoice.status must be CONFIRMED");
    return;
  }

  const modules = invoice.modules || {};
  for (const name of ["enterpriseTitle", "openRule", "invoiceNotifyAndQuery"]) {
    if (modules[name] !== "REQUIRED") errors.push(`integration contract module ${name} must be REQUIRED`);
  }
  if (JSON.stringify(contract.gaps || []).includes("NEEDS_USER_CONFIRM")) {
    errors.push("integration contract still contains NEEDS_USER_CONFIRM");
  }
  for (const joinPoint of invoice.joinPoints || []) {
    for (const relative of joinPoint.evidenceFiles || []) {
      const resolved = resolveInsideTarget(relative);
      if (!resolved || !fs.existsSync(resolved)) errors.push(`integration contract evidence file does not exist: ${relative}`);
    }
  }
}

function resolveInsideTarget(relative) {
  const resolved = path.resolve(targetDir, relative);
  if (resolved !== targetDir && !resolved.startsWith(`${targetDir}${path.sep}`)) return null;
  return resolved;
}

function read(file) {
  return fs.readFileSync(file, "utf8");
}

function normalize(file) {
  return file.split(path.sep).join("/");
}

function relativeParts(file) {
  return normalize(path.relative(targetDir, file)).split("/");
}

function isTestFile(file) {
  const relative = normalize(path.relative(targetDir, file));
  const parts = relativeParts(file);
  return relative.startsWith("src/test/")
    || relative.startsWith("src/testFixtures/")
    || parts.includes("__tests__")
    || parts[0] === "test"
    || parts[0] === "tests"
    || /(?:Test|Tests|Spec)\.java$|(?:\.test|\.spec)\.[A-Za-z0-9]+$/i.test(path.basename(file));
}

function isTestOrDemoFile(file) {
  const parts = relativeParts(file);
  return isTestFile(file)
    || parts[0] === "demo"
    || parts[0] === "demos"
    || parts[0] === "example"
    || parts[0] === "examples"
    || normalize(path.relative(targetDir, file)).startsWith("src/demo/");
}

function escapeRegExp(value) {
  return value.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

function stripJavaComments(source) {
  let result = "";
  let state = "code";
  for (let i = 0; i < source.length; i += 1) {
    const current = source[i];
    const next = source[i + 1];

    if (state === "line-comment") {
      if (current === "\n") {
        result += current;
        state = "code";
      } else {
        result += " ";
      }
      continue;
    }
    if (state === "block-comment") {
      if (current === "*" && next === "/") {
        result += "  ";
        i += 1;
        state = "code";
      } else {
        result += current === "\n" ? "\n" : " ";
      }
      continue;
    }
    if (state === "string" || state === "character") {
      result += current;
      if (current === "\\" && next !== undefined) {
        result += next;
        i += 1;
      } else if ((state === "string" && current === "\"") || (state === "character" && current === "'")) {
        state = "code";
      }
      continue;
    }
    if (state === "text-block") {
      if (source.slice(i, i + 3) === "\"\"\"") {
        result += "\"\"\"";
        i += 2;
        state = "code";
      } else {
        result += current;
      }
      continue;
    }

    if (current === "/" && next === "/") {
      result += "  ";
      i += 1;
      state = "line-comment";
    } else if (current === "/" && next === "*") {
      result += "  ";
      i += 1;
      state = "block-comment";
    } else if (source.slice(i, i + 3) === "\"\"\"") {
      result += "\"\"\"";
      i += 2;
      state = "text-block";
    } else {
      result += current;
      if (current === "\"") state = "string";
      if (current === "'") state = "character";
    }
  }
  return result;
}

function walk(root) {
  const files = [];
  const ignored = new Set([".git", "node_modules", "target", "build", "dist", ".gradle"]);
  for (const entry of fs.readdirSync(root, { withFileTypes: true })) {
    if (ignored.has(entry.name)) continue;
    const full = path.join(root, entry.name);
    if (entry.isDirectory()) files.push(...walk(full));
    else if (entry.isFile()) files.push(full);
  }
  return files;
}

function report(errors, warnings) {
  for (const warning of warnings) console.warn(`[alipay-enterprise-invoice] WARN ${warning}`);
  if (errors.length > 0) {
    for (const error of errors) console.error(`[alipay-enterprise-invoice] ERROR ${error}`);
    process.exitCode = 1;
    return;
  }
  console.log("[alipay-enterprise-invoice] OK");
}

function broken(message) {
  console.error(`[alipay-enterprise-invoice] BROKEN ${message}`);
  process.exit(2);
}
